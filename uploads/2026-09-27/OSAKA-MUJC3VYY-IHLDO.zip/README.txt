ASET LOGO OSAKA — cara pakai:

1. Extract semua isi zip ini langsung ke folder `public/` di root proyek Next.js.
2. File-file ini SUDAH SESUAI NAMA yang dipakai di prompt penyesuaian (PENYESUAIAN_OSAKA.md).
   Jangan diganti nama filenya kecuali kamu juga mengubah rujukannya di kode.

Daftar file:
- logo.png                     → logo utama transparan, dipakai di header, footer, halaman profil
- logo-square-1024.png         → transparan, kotak, resolusi tinggi (untuk OG image / keperluan lain)
- logo-square-white-1024.png   → versi latar putih solid, kotak, resolusi tinggi
- icon-512.png / icon-192.png  → untuk web app manifest (PWA icons)
- apple-touch-icon.png         → 180x180, latar putih solid (wajib solid untuk iOS)
- favicon-32x32.png / favicon-16x16.png / favicon.ico → favicon browser

Catatan penting soal logo transparan di atas latar gelap (mis. sidebar admin #0F172A):
Logo ini transparan tapi warnanya (biru muda) kontrasnya kurang kalau ditaruh polos di atas
warna gelap. Prompt sudah mengarahkan agent untuk membungkusnya dalam chip/lingkaran putih
kecil (padding 6-8px, radius penuh, shadow tipis) setiap kali logo ditaruh di permukaan gelap,
supaya tetap kelihatan jelas dan rapi — bukan ditempel polos begitu saja.
