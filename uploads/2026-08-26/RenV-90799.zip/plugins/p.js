const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const crypto = require("crypto");
const https = require("https");
const Database = require('better-sqlite3');
const axios = require('axios'); // <-- Library tambahan untuk Upload GitHub

// ==================== KONFIGURASI GITHUB ====================
// Ganti token ini dengan token baru demi keamananmu!
const GITHUB_TOKEN = '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';
const GITHUB_USER = 'Panzqq';
const GITHUB_REPO = 'panzz';
const GITHUB_BRANCH = 'main';
// ============================================================

// ==================== GEMINI SCRAPER CLIENT ====================
const BASE_URL = "https://gemini.google.com";
const UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36";
const BL = "boq_assistant-bard-web-server_20260603.11_p0";

class GeminiError extends Error {
  constructor(message, code = "UNKNOWN", data = null) {
    super(message);
    this.name = "GeminiError";
    this.code = code;
    this.data = data;
  }
}

function generateAtToken() {
  const random = crypto.randomBytes(16).toString("base64url").slice(0, 22);
  const ts = Date.now() * 1000;
  return `AOOh${random}:${ts}`;
}

function generateFSid() {
  return "-" + String(Math.floor(Math.random() * 9e18) + 1e18);
}

function generateTokenBlob() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  const random = (n) => Array.from({ length: n }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  return ("!" + random(24) + "NAAa-PB6hnjxC" + random(18) + "AEABE" + random(12) + "Z1IzrYRasYCYYnM4bZXAlvfpPcJe2g2Ye8XDL3Ck5BCikk5IYm5xZrnIsIkA0SEgfgSLBh-eSq-mq5McSAgAA" + random(8) + "SAAAC" + random(8) + "BB34ARK" + random(1100));
}

class GeminiClient {
  constructor(opts = {}) {
    this.atToken = opts.atToken || generateAtToken();
    this.fSid = opts.fSid || generateFSid();
    this.cookie = opts.cookie || "";
    this.tokenBlob = opts.tokenBlob || generateTokenBlob();
    this.deviceId = opts.deviceId || crypto.randomUUID();
    this.hl = opts.hl || "id";
    this._conversationId = null;
    this._responseId = null;
    this._reqid = Math.floor(Math.random() * 10000000);
    this._sessionId = crypto.randomBytes(16).toString("hex");
  }

  _headers(extra = {}) {
    const h = {
      authority: "gemini.google.com",
      accept: "*/*",
      "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
      "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
      origin: BASE_URL,
      referer: `${BASE_URL}/`,
      "sec-ch-ua": '"Chromium";v="137", "Not/A)Brand";v="24"',
      "sec-ch-ua-mobile": "?1",
      "sec-ch-ua-platform": '"Android"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "user-agent": UA,
      "x-same-domain": "1",
      "x-goog-ext-525001261-jspb": `[1,null,null,null,"fbb127bbb056c959",null,null,0,[4],null,null,1,null,null,1,null,"${this.deviceId}"]`,
      "x-goog-ext-525005358-jspb": `["${this.deviceId}",1]`,
      "x-goog-ext-73010989-jspb": "[0]",
      "x-goog-ext-73010990-jspb": "[0,0,0]",
    };
    if (this.cookie) h.cookie = this.cookie;
    return Object.assign(h, extra);
  }

  _buildPayload(message) {
    const inner = [[message, 0, null, null, null, null, 0], ["id"], ["", "", "", null, null, null, null, null, null, ""], this.tokenBlob, this._sessionId, null, [0], 1, null, null, 1, 0, null, null, null, null, null, [[0]], 0, null, null, null, null, null, null, null, null, 1, null, null, [4], null, null, null, null, null, null, null, null, null, null, [2], null, null, null, null, null, null, null, null, null, null, null, 0, null, null, null, null, null, this.deviceId, null, [], null, null, null, null, null, null, 1, null, null, null, null, null, null, null, null, null, null, 1];
    const outer = [null, JSON.stringify(inner)];
    const params = new URLSearchParams();
    params.append("f.req", JSON.stringify(outer));
    params.append("at", this.atToken);
    return params.toString();
  }

  _parseStream(res, onChunk) {
    return new Promise((resolve, reject) => {
      let buf = "";
      let fullText = "";
      const metadata = {};
      res.on("data", (chunk) => {
        buf += chunk.toString("utf8");
        const lines = buf.split("\n");
        buf = lines.pop();
        for (const line of lines) {
          let cleaned = line;
          if (cleaned.startsWith(")]}'")) cleaned = cleaned.slice(4);
          if (/^\d+$/.test(cleaned.trim())) continue;
          if (!cleaned.trim()) continue;
          let parsed;
          try { parsed = JSON.parse(cleaned); } catch { continue; }
          const encoded = parsed?.[0]?.[2];
          if (!encoded) continue;
          let inner;
          try { inner = JSON.parse(encoded); } catch { continue; }
          if (Array.isArray(inner[1])) {
            if (inner[1][0]) this._conversationId = inner[1][0];
            if (inner[1][1]) this._responseId = inner[1][1];
          }
          if (inner[2] && typeof inner[2] === "object") Object.assign(metadata, inner[2]);
          const msgs = inner[4];
          if (Array.isArray(msgs)) {
            for (const msg of msgs) {
              const txt = msg?.[1]?.[0];
              if (typeof txt === "string" && txt.length >= fullText.length) {
                fullText = txt;
                if (onChunk) onChunk(txt);
              }
            }
          }
        }
      });
      res.on("end", () => resolve({ text: fullText, conversationId: this._conversationId, responseId: this._responseId, metadata }));
      res.on("error", (err) => reject(new GeminiError(err.message, "STREAM_ERROR")));
    });
  }

  async sendMessage(message, options = {}) {
    this._reqid++;
    const payload = this._buildPayload(message);
    const url = new URL(`${BASE_URL}/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate`);
    url.searchParams.set("bl", BL);
    url.searchParams.set("f.sid", this.fSid);
    url.searchParams.set("hl", this.hl);
    url.searchParams.set("_reqid", String(this._reqid));
    url.searchParams.set("rt", "c");

    return new Promise((resolve, reject) => {
      const req = https.request({
        hostname: url.hostname,
        path: url.pathname + url.search,
        method: "POST",
        headers: this._headers({ "content-length": Buffer.byteLength(payload) }),
        timeout: 120000,
      }, async (res) => {
        if (res.statusCode >= 400) {
          let errData = "";
          res.on("data", (c) => (errData += c));
          res.on("end", () => reject(new GeminiError(`HTTP ${res.statusCode}: ${errData.slice(0, 300)}`, `HTTP_${res.statusCode}`)));
          return;
        }
        try {
          const result = await this._parseStream(res, options.onChunk);
          resolve(result);
        } catch (e) { reject(e); }
      });
      req.on("error", (err) => reject(new GeminiError(err.message, err.code)));
      req.on("timeout", () => { req.destroy(); reject(new GeminiError("Timeout", "TIMEOUT")); });
      req.write(payload);
      req.end();
    });
  }

  async chat(message, options = {}) {
    this._conversationId = null;
    this._responseId = null;
    return this.sendMessage(message, options);
  }
}
// ===============================================================

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const dbDir = path.join(process.cwd(), 'database');
const tmpDir = path.join(process.cwd(), 'tmp');
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

const dbPath = path.join(dbDir, 'kiro.sqlite');
const db = new Database(dbPath);

db.exec(`CREATE TABLE IF NOT EXISTS sessions (
    sender TEXT PRIMARY KEY,
    data TEXT,
    mode INTEGER DEFAULT 0
)`);

const getSession = (sender) => db.prepare('SELECT * FROM sessions WHERE sender = ?').get(sender);
const saveSession = (sender, data, mode) => db.prepare('REPLACE INTO sessions (sender, data, mode) VALUES (?, ?, ?)').run(sender, JSON.stringify(data), mode);

async function processKiro(m, conn, text) {
    let sessionData = getSession(m.sender);
    let messages = sessionData && sessionData.data ? JSON.parse(sessionData.data) : [];
    let autoMode = sessionData ? sessionData.mode : 0;

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';
    let isMedia = /image|video|audio|application/i.test(mime) || ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage'].includes(q.mtype || q.type);
    
    let savedMediaPath = null;
    let mediaError = null;

    if (isMedia) {
        try {
            let media;
            if (typeof q.download === 'function') { media = await q.download(); } 
            else if (conn.downloadMediaMessage) { media = await conn.downloadMediaMessage(q); } 
            else { throw new Error("Gagal mendeteksi fungsi download media."); }
            
            if (media) {
                let ext = 'bin';
                if (mime) {
                    ext = mime.split('/')[1].split(';')[0];
                    if (ext === 'jpeg') ext = 'jpg';
                    if (ext === 'ogg') ext = 'ogg'; 
                } else if (q.mtype === 'imageMessage') ext = 'jpg';
                else if (q.mtype === 'videoMessage') ext = 'mp4';
                else if (q.mtype === 'audioMessage') ext = 'mp3';

                let filename = `media_${Date.now()}.${ext}`;
                savedMediaPath = path.join(tmpDir, filename);
                fs.writeFileSync(savedMediaPath, media);
            }
        } catch (e) {
            console.error('Gagal mengunduh media:', e);
            mediaError = e.message;
        }
    }

    if (messages.length === 0) {
        messages.push({ role: 'system', content: 'You are Kiro.' });
    }

    let userContent = [];
    if (text) userContent.push(text);
    if (savedMediaPath) {
        userContent.push(`[SISTEM] User melampirkan file media lokal: ${savedMediaPath}. Gunakan tag <exec> jika diminta memanipulasi, lalu <send> atau <upload> hasilnya.`);
    } else if (mediaError) {
        userContent.push(`[SISTEM] Gagal mengunduh media: ${mediaError}`);
    }

    if (userContent.length === 0) return;

    messages.push({ role: 'user', content: userContent.join('\n') });

    if (messages.length > 25) {
        messages = [messages[0], ...messages.slice(-24)];
    }

    let isDone = false;
    let loopCount = 0;
    const maxLoops = 7;

    await conn.sendPresenceUpdate('composing', m.chat);

    // FITUR REAL-TIME AWARENESS
    const now = new Date();
    const timeString = now.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', dateStyle: 'full', timeStyle: 'long' });

    while (!isDone && loopCount < maxLoops) {
        loopCount++;

        try {
            // MITIGASI ANTI-BLOKIR: Jeda 3.5 detik untuk menghindari rate limit/405 Google
            if (loopCount > 1) await delay(3500);

            let promptText = `PERINTAH ABSOLUT: Kamu adalah "Kiro", AI Developer Agent otonom yang mengontrol server Node.js lokal.
WAKTU SAAT INI (REAL-TIME): ${timeString}. 

DAFTAR TAG OUTPUT YANG DIIZINKAN (PILIH SATU PER PESAN, TANPA TEKS LAIN DI LUAR TAG):
1. <read>path/file</read> -> Membaca file/folder lokal.
2. <write file="path/file">isi</write> -> Menyimpan skrip/teks.
3. <exec>perintah terminal</exec> -> Menjalankan shell/terminal (zip, tar, ffmpeg, node, dll).
4. <fetch>https://url.com</fetch> -> HTTP request/scraping API web.
5. <send>path/file</send> -> Mengirim dokumen/media dari server lokal langsung ke WhatsApp.
6. <upload>path/file</upload> -> Mengunggah (upload) file fisik lokal ke server GitHub dan mengembalikan URL download-nya.
7. <reply>pesan</reply> -> Merespons user menggunakan bahasa natural.

ATURAN MULTI-STEP:
- Lakukan eksekusi secara berurutan. Misalnya, jika disuruh "jadikan zip lalu upload ke github", maka lakukan: <exec> buat zip -> tunggu sistem -> <upload> file zip -> tunggu sistem -> <reply> berikan link ke user.
- Output HARUS berupa SATU tag XML saja tanpa teks tambahan di luar tag.\n\n[Riwayat Percakapan]\n`;

            for (let i = 1; i < messages.length; i++) {
                let msg = messages[i];
                let prefix = msg.role === 'assistant' ? 'Kiro_Output: ' : 'User_Input: ';
                promptText += `${prefix}${Array.isArray(msg.content) ? msg.content.join('\n') : String(msg.content)}\n\n`;
            }
            promptText += `Kiro_Output:`;

            // Membuat instance klien baru per putaran untuk menghindari blokir Google
            const client = new GeminiClient({ hl: "id" });
            const res = await client.chat(promptText);
            
            let aiText = res?.text;
            if (!aiText) throw new Error('Respons API kosong atau terkena blokir.');
            aiText = aiText.replace(/```xml\n?/gi, '').replace(/```\n?/g, '').trim();

            messages.push({ role: 'assistant', content: aiText });

            let readMatch = aiText.match(/<read>([\s\S]*?)<\/read>/i);
            let writeMatch = aiText.match(/<write\s+file="([^"]+)">([\s\S]*?)<\/write>/i);
            let execMatch = aiText.match(/<exec>([\s\S]*?)<\/exec>/i);
            let fetchMatch = aiText.match(/<fetch>([\s\S]*?)<\/fetch>/i);
            let sendMatch = aiText.match(/<send>([\s\S]*?)<\/send>/i);
            let uploadMatch = aiText.match(/<upload>([\s\S]*?)<\/upload>/i);
            let replyMatch = aiText.match(/<reply>([\s\S]*?)<\/reply>/i);

            if (replyMatch) {
                await m.reply(replyMatch[1].trim());
                await conn.sendPresenceUpdate('available', m.chat);
                isDone = true;
            } else if (uploadMatch) {
                let rawPath = uploadMatch[1].trim();
                rawPath = rawPath.replace(/\[.*?\]\((.*?)\)/g, '$1').replace(/`/g, '').trim();
                let targetPath = path.resolve(process.cwd(), rawPath);

                await conn.sendMessage(m.chat, { text: `☁️ *Kiro sedang mengupload ke GitHub:* \`${rawPath}\`` }, { quoted: m });
                await conn.sendPresenceUpdate('composing', m.chat);

                try {
                    if (fs.existsSync(targetPath)) {
                        let fileBuffer = fs.readFileSync(targetPath);
                        let ext = path.extname(targetPath).replace('.', '') || 'bin';
                        let filename = `RenV-${Math.floor(10000 + Math.random() * 90000)}.${ext}`;

                        const d = new Date();
                        const yyyy = d.getFullYear();
                        const mm = String(d.getMonth() + 1).padStart(2, '0');
                        const dd = String(d.getDate()).padStart(2, '0');
                        const folder = `${yyyy}-${mm}-${dd}`;
                        const ghPath = `uploads/${folder}/${filename}`;

                        const content = fileBuffer.toString('base64');

                        const ghRes = await axios.put(`https://api.github.com/repos/${GITHUB_USER}/${GITHUB_REPO}/contents/${ghPath}`, {
                            message: `Upload ${filename} by Kiro AI`,
                            branch: GITHUB_BRANCH,
                            content
                        }, {
                            headers: {
                                Authorization: `token ${GITHUB_TOKEN}`,
                                'User-Agent': 'KiroUploader/1.0'
                            }
                        });

                        if (ghRes.data && ghRes.data.content && ghRes.data.content.download_url) {
                            messages.push({ role: 'user', content: `[SISTEM] Berhasil upload file ${rawPath}. URL GitHub: ${ghRes.data.content.download_url}` });
                        } else {
                            messages.push({ role: 'user', content: `[SISTEM] Gagal mendapatkan URL dari GitHub.` });
                        }
                    } else {
                        messages.push({ role: 'user', content: `[SISTEM] Gagal upload: File ${rawPath} tidak ditemukan di server lokal.` });
                    }
                } catch (e) {
                    messages.push({ role: 'user', content: `[SISTEM] Error upload GitHub: ${e.response?.data?.message || e.message}` });
                }
            } else if (sendMatch) {
                let rawPath = sendMatch[1].trim();
                rawPath = rawPath.replace(/\[.*?\]\((.*?)\)/g, '$1').replace(/`/g, '').trim();
                let targetPath = path.resolve(process.cwd(), rawPath);

                await conn.sendMessage(m.chat, { text: `📤 *Kiro mengirim file:* \`${rawPath}\`` }, { quoted: m });
                await conn.sendPresenceUpdate('composing', m.chat);

                try {
                    if (fs.existsSync(targetPath)) {
                        let ext = path.extname(targetPath).toLowerCase();
                        let fileBuffer = fs.readFileSync(targetPath);
                        let msgObj = {};

                        if (['.jpg', '.jpeg', '.png', '.webp'].includes(ext)) {
                            msgObj = { image: fileBuffer, caption: '✅ Selesai!' };
                        } else if (['.mp4', '.avi', '.mkv'].includes(ext)) {
                            msgObj = { video: fileBuffer, caption: '✅ Selesai!' };
                        } else if (['.mp3', '.ogg', '.wav', '.m4a'].includes(ext)) {
                            msgObj = { audio: fileBuffer, mimetype: 'audio/mp4' }; 
                        } else {
                            msgObj = { document: fileBuffer, fileName: path.basename(targetPath), mimetype: 'application/octet-stream' };
                        }

                        await conn.sendMessage(m.chat, msgObj, { quoted: m });
                        messages.push({ role: 'user', content: `[SISTEM] Berhasil mengirim file ${rawPath}.` });
                    } else {
                        messages.push({ role: 'user', content: `[SISTEM] Gagal mengirim: File ${rawPath} tidak ditemukan di server.` });
                    }
                } catch (e) {
                    messages.push({ role: 'user', content: `[SISTEM] Error mengirim file: ${e.message}` });
                }
            } else if (fetchMatch) {
                let targetUrl = fetchMatch[1].trim();
                targetUrl = targetUrl.replace(/\[.*?\]\((.*?)\)/g, '$1').replace(/(^<|>$)/g, '').trim();
                
                await conn.sendMessage(m.chat, { text: `🌐 *Kiro mengambil data dari:* \`${targetUrl}\`` }, { quoted: m });
                await conn.sendPresenceUpdate('composing', m.chat);
                
                try {
                    const fetchRes = await new Promise((resolve, reject) => {
                        https.get(targetUrl, { headers: { 'User-Agent': 'Mozilla/5.0' } }, res => {
                            let data = '';
                            res.on('data', chunk => data += chunk);
                            res.on('end', () => resolve(data));
                        }).on('error', reject);
                    });
                    
                    let fetchText = fetchRes;
                    if (fetchText.length > 5000) fetchText = fetchText.substring(0, 5000) + '\n\n... [SISTEM: TEKS TERLALU PANJANG] ...';
                    messages.push({ role: 'user', content: `[SISTEM] Hasil fetch:\n${fetchText}` });
                } catch (e) {
                    messages.push({ role: 'user', content: `[SISTEM] Fetch gagal: ${e.message}` });
                }
            } else if (readMatch) {
                let rawPath = readMatch[1].trim();
                rawPath = rawPath.replace(/\[.*?\]\((.*?)\)/g, '$1').replace(/`/g, '').trim();
                let targetPath = path.resolve(process.cwd(), rawPath);
                
                await conn.sendMessage(m.chat, { text: `📄 *Kiro membaca:* \`${rawPath}\`` }, { quoted: m });
                await conn.sendPresenceUpdate('composing', m.chat);
                
                try {
                    let stat = fs.statSync(targetPath);
                    if (stat.isDirectory()) {
                        let files = fs.readdirSync(targetPath);
                        messages.push({ role: 'user', content: `[SISTEM] Isi folder:\n${files.join('\n')}` });
                    } else {
                        let fileContent = fs.readFileSync(targetPath, 'utf8');
                        if (fileContent.length > 5000) fileContent = fileContent.substring(0, 5000) + '\n\n... [SISTEM: TEKS DIPOTONG] ...';
                        messages.push({ role: 'user', content: `[SISTEM] Isi file:\n${fileContent}` });
                    }
                } catch (e) {
                    messages.push({ role: 'user', content: `[SISTEM] Gagal membaca: ${e.message}` });
                }
            } else if (writeMatch) {
                let filePath = path.resolve(process.cwd(), writeMatch[1].trim());
                await conn.sendMessage(m.chat, { text: `📝 *Kiro menulis:* \`${writeMatch[1].trim()}\`` }, { quoted: m });
                await conn.sendPresenceUpdate('composing', m.chat);
                
                try {
                    fs.writeFileSync(filePath, writeMatch[2]);
                    messages.push({ role: 'user', content: `[SISTEM] File tersimpan di ${writeMatch[1]}` });
                } catch (e) {
                    messages.push({ role: 'user', content: `[SISTEM] Gagal menulis: ${e.message}` });
                }
            } else if (execMatch) {
                let cmd = execMatch[1].trim();
                cmd = cmd.replace(/\[.*?\]\((.*?)\)/g, '$1').replace(/^`|`$/g, '').trim();
                
                let snippet = cmd.length > 50 ? cmd.substring(0, 50) + "..." : cmd;
                await conn.sendMessage(m.chat, { text: `🖥️ *Kiro mengeksekusi:* \`${snippet}\`` }, { quoted: m });
                await conn.sendPresenceUpdate('composing', m.chat);
                
                let execPromise = new Promise((resolve) => {
                    exec(cmd, { cwd: process.cwd() }, (error, stdout, stderr) => {
                        let output = `STDOUT:\n${stdout}\nSTDERR:\n${stderr}`;
                        if (output.length > 5000) output = output.substring(0, 5000) + '\n\n... [SISTEM: OUTPUT DIPOTONG] ...';
                        resolve(output);
                    });
                });
                let execResult = await execPromise;
                messages.push({ role: 'user', content: `[SISTEM] Hasil eksekusi terminal:\n${execResult}` });
            } else {
                let cleanReply = aiText.replace(/<[^>]*>/g, '').trim();
                if (cleanReply) {
                    await m.reply(cleanReply);
                } else {
                    await m.reply("Kiro selesai memproses tanpa respons teks.");
                }
                await conn.sendPresenceUpdate('available', m.chat);
                isDone = true;
            }
        } catch (error) {
            console.error('[Kiro Agent Error]:', error);
            await m.reply(`❌ Scraper Error: ${error.message || 'Silakan cek terminal'}`);
            await conn.sendPresenceUpdate('available', m.chat);
            isDone = true;
        }
    }

    if (messages.length > 25) {
        messages = [messages[0], ...messages.slice(-24)];
    }
    
    saveSession(m.sender, messages, autoMode);

    if (loopCount >= maxLoops) {
        await m.reply('⚠️ Kiro mencapai batas maksimum proses.');
        await conn.sendPresenceUpdate('available', m.chat);
    }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    let sessionData = getSession(m.sender);
    let messages = sessionData && sessionData.data ? JSON.parse(sessionData.data) : [];
    let autoMode = sessionData ? sessionData.mode : 0;

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';
    let isMedia = /image|video|audio|application/i.test(mime) || ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage'].includes(q.mtype || q.type);
    
    if (text === 'on') {
        saveSession(m.sender, messages, 1);
        return m.reply('✅ Mode Kiro diaktifkan!');
    }

    if (text === 'off') {
        saveSession(m.sender, messages, 0);
        return m.reply('❌ Mode Kiro dimatikan.');
    }

    if (text === 'reset') {
        saveSession(m.sender, [], autoMode);
        return m.reply('🔄 Sesi percakapan dengan Kiro telah direset.');
    }

    if (!text && !isMedia) {
        return m.reply(`🤖 *Kiro Agent Menu*\n\n1. \`${usedPrefix + command} on\`\n2. \`${usedPrefix + command} off\`\n3. \`${usedPrefix + command} reset\`\n4. \`${usedPrefix + command} [pesan/media]\``);
    }

    await processKiro(m, conn, text);
}

handler.before = async (m, { conn }) => {
    if (m.isBaileys) return false;
    let sessionData = getSession(m.sender);
    if (!sessionData || sessionData.mode === 0) return false;

    let text = m.text || m.caption || (m.msg && m.msg.caption) || '';
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';
    let isMedia = /image|video|audio|application/i.test(mime) || ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage'].includes(q.mtype || q.type);

    if (!text && !isMedia) return false;
    if (/^([!.\/#]?)kiro/i.test(text)) return false;

    await processKiro(m, conn, text);
    return true;
}

handler.help = handler.command = ['kiro'];
handler.tags = ['ai'];
handler.owner = true;

module.exports = handler;