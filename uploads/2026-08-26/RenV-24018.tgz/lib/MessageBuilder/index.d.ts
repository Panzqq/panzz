export declare const VERSION: string;

export declare class Button {
    constructor(client: any);
    setTitle(v: string): this; setSubtitle(v: string): this; setBody(v: string): this; setFooter(v: string): this;
    setContextInfo(o: object): this; addPayload(o: object): this;
    setVideo(p: string | Buffer, o?: object): this; setImage(p: string | Buffer, o?: object): this;
    setDocument(p: string | Buffer, o?: object): this; setMedia(o: object): this;
    clearButtons(): this; setParams(o: object): this;
    addButton(name: string, params: string | object): this;
    addSelection(title: string, options?: object): this;
    makeSection(title?: string, highlight_label?: string): this;
    makeRow(header?: string, title?: string, description?: string, id?: string): this;
    addReply(display_text?: string, id?: string, options?: object): this;
    addCall(display_text?: string, id?: string, options?: object): this;
    addReminder(display_text?: string, id?: string, options?: object): this;
    addCancelReminder(display_text?: string, id?: string, options?: object): this;
    addAddress(display_text?: string, id?: string, options?: object): this;
    addLocation(options?: object): this;
    addUrl(display_text?: string, url?: string, webview_interaction?: boolean, options?: object): this;
    addCopy(display_text?: string, copy_code?: string, options?: object): this;
    toCard(): Promise<object>;
    build(jid: string, options?: object): Promise<any>;
    send(jid: string, options?: object): Promise<any>;
}

export declare class ButtonV2 {
    constructor(client: any);
    setTitle(v: string): this; setBody(v: string): this; setFooter(v: string): this;
    setContextInfo(o: object): this; addPayload(o: object): this;
    addButton(displayText?: string, buttonId?: string): this;
    addRawButton(o: object): this; setThumbnail(p: string | Buffer): this; setMedia(o: object): this;
    build(jid: string, options?: object): Promise<any>;
    send(jid: string, options?: object): Promise<any>;
}

export declare class Carousel {
    constructor(client: any);
    setBody(v: string): this; setFooter(v: string): this;
    setContextInfo(o: object): this; addPayload(o: object): this;
    addCard(card: object | object[]): this;
    build(jid: string, options?: object): any;
    send(jid: string, options?: object): Promise<any>;
}

export interface NativeFlowResponse {
    name: string; id: string; display_text: string; params: Record<string, unknown>;
}
export declare const parseNativeFlowResponse: (message: any) => NativeFlowResponse | null;

export declare class AIRich {
    constructor(client: any);
    static newLayout(name: string, data: unknown): object;
    setTitle(v: string): this; setBody(v: string): this; setFooter(v: string): this;
    setContextInfo(o: object): this; addPayload(o: object): this;
    addSubmessage(s: object | object[]): this;
    addSection(s: object | object[]): this;
    addText(text: string, options?: { hyperlink?: boolean; citation?: boolean; latex?: boolean }): this;
    addCode(language: string, code: string): this;
    addTable(table: string[][]): this;
    addSource(sources: string[] | string[][]): this;
    addReels(reelsItems: object | object[]): this;
    addImage(imageUrl: string | string[]): this;
    addVideo(videoUrl: string | string[]): this;
    addProduct(data: object | object[]): this;
    addPost(data: object | object[]): this;
    addTip(text: string): this;
    addSuggest(suggestion: string | string[]): this;
    build(options?: object): object;
    send(jid: string, options?: object): Promise<any>;
    static tokenizer(code: string, lang?: string): { codeBlock: any[]; unified_codeBlock: any[] };
    static toTableMetadata(arr: string[][]): object;
}
