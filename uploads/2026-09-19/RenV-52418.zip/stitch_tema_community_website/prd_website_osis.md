# PRD — Website Utama OSIS

**Versi:** 1.1 (Revisi)
**Status:** Draft
**Perubahan dari v1.0:**
- Foto pengurus bersifat **opsional**, disimpan sebagai **link URL** (bukan upload file).
- Modul **Kegiatan Aktif** diperluas: bisa menambahkan informasi/update per kegiatan selama berlangsung. Saat kegiatan **dinonaktifkan, seluruh data informasi terkait otomatis terhapus**.

---

## 1. Ringkasan Produk

Website resmi OSIS yang berfungsi sebagai pusat informasi (portal utama), penghubung ke sub-website (Mading, Aspirasi, Pencatat Pelanggaran), dan pusat dokumentasi kegiatan. Website dilengkapi Admin Panel agar pengurus dapat mengelola konten tanpa perlu mengubah kode.

## 2. Tujuan

- Menyediakan satu portal resmi yang memuat seluruh informasi OSIS.
- Memudahkan pengurus mengelola konten (link eksternal, dokumentasi, struktur, kegiatan, laporan) secara mandiri lewat Admin Panel.
- Memberi ruang komunikasi real-time untuk kegiatan yang sedang berlangsung, tanpa menyimpan data usang secara permanen.

## 3. Peran Pengguna (User Roles)

| Role | Akses |
|---|---|
| **Pengunjung (publik)** | Melihat seluruh halaman publik, redirect ke sub-web |
| **Admin** | Login ke Admin Panel, CRUD semua konten |
| **Superadmin** *(opsional)* | Sama seperti admin + kelola akun admin lain |

## 4. Ruang Lingkup Fitur

### 4.1 Navigasi Utama
- Beranda
- Profil OSIS
- Struktur Kepengurusan
- Dokumentasi Kegiatan
- Kegiatan Berlangsung (Aktif)
- Laporan RAB
- Laporan Akhir Kegiatan
- Tombol Mading (redirect)
- Tombol Pencatat Pelanggaran (redirect)
- Tombol Aspirasi (redirect, styling khusus/menonjol)

### 4.2 Beranda
- Menampilkan identitas OSIS.
- Menampilkan sosial media OSIS (icon + link).
- Menampilkan link/embed Spotify Podcast.
- Menampilkan preview kegiatan yang sedang aktif.

### 4.3 Profil OSIS
- Teks: tentang, visi, misi.
- Dapat diedit dari Admin Panel.

### 4.4 Struktur Kepengurusan
- Data per pengurus: nama, jabatan, divisi, urutan tampil.
- **Foto: opsional, disimpan sebagai link URL gambar** (bukan file upload). Jika kosong, tampilkan avatar/placeholder default.

### 4.5 Dokumentasi Kegiatan
- Judul tetap: "DOKUMENTASI KEGIATAN".
- List sub-judul, tiap sub-judul memiliki satu link Google Drive.
- CRUD penuh dari Admin Panel. Data ini **permanen** (tidak terhapus otomatis).

### 4.6 Kegiatan Berlangsung (Aktif) — **[REVISI]**

Modul ini bersifat **sementara/live**, berbeda dari Dokumentasi Kegiatan yang permanen.

**Struktur:**
- Setiap **Kegiatan** memiliki: nama, deskripsi, tanggal, status (`aktif` / `nonaktif`).
- Selama status `aktif`, admin dapat menambahkan **Informasi/Update** terkait kegiatan tersebut secara berulang (misalnya: pengumuman terbaru, info lokasi, perubahan jadwal, catatan panitia). Tiap entri informasi memiliki: judul singkat, isi/detail, waktu dibuat.

**Aturan penghapusan otomatis:**
- Saat admin mengubah status kegiatan dari `aktif` menjadi `nonaktif`, sistem **otomatis menghapus seluruh entri Informasi/Update** yang menempel pada kegiatan tersebut.
- **Asumsi (perlu dikonfirmasi):** kegiatan tersebut juga otomatis dihapus dari daftar publik setelah dinonaktifkan (bukan diarsipkan), karena tujuan modul ini murni untuk info real-time selama kegiatan berjalan. Riwayat kegiatan yang perlu disimpan permanen sebaiknya dipindahkan manual ke Dokumentasi Kegiatan / Laporan Akhir sebelum dinonaktifkan.
- Proses penghapusan dilakukan lewat **Cloud Function** yang terpicu otomatis saat field status berubah (lihat dokumen Setup Firebase), agar konsisten walau admin menonaktifkan dari perangkat manapun.

### 4.7 Laporan RAB
- List entri: nama kegiatan + link Google Drive.
- CRUD dari Admin Panel. Bersifat permanen.

### 4.8 Laporan Akhir Kegiatan
- Sama seperti Laporan RAB: nama kegiatan + link Google Drive. Bersifat permanen.

### 4.9 Link Eksternal (dikelola di Admin Panel)
- URL Web Mading
- URL Web Aspirasi
- URL Web Pencatat Pelanggaran
- URL/embed Spotify Podcast
- Link sosial media (Instagram, TikTok, YouTube, dst — multi-entri)

### 4.10 Admin Panel
- Login admin (Firebase Authentication).
- Dashboard dengan modul-modul sesuai 4.2–4.9.
- Setiap modul: form tambah/edit/hapus (CRUD), termasuk field link foto opsional pada struktur kepengurusan, dan tombol toggle status pada Kegiatan Aktif.

## 5. Model Data (Ringkas)

Lihat detail koleksi & field pada dokumen **Firestore Rules**. Ringkasan koleksi:

- `settings` — url mading, aspirasi, pelanggaran, spotify
- `sosial_media`
- `profil_osis`
- `struktur_pengurus` (foto_url opsional)
- `dokumentasi_kegiatan`
- `kegiatan_aktif` → subkoleksi `informasi` (dihapus otomatis saat nonaktif)
- `laporan_rab`
- `laporan_akhir`
- `admins`

## 6. Kebutuhan Non-Fungsional

- Responsif (mobile & desktop).
- Link eksternal dibuka di tab baru.
- Validasi format URL pada semua input link.
- Admin Panel hanya bisa diakses oleh akun terautentikasi (role admin).
- Penghapusan data kegiatan nonaktif harus konsisten (idealnya via Cloud Function, bukan hanya logic di client).

## 7. Di Luar Cakupan (Out of Scope)

- Sistem upload file gambar (semua foto memakai link eksternal).
- Fitur komentar/interaksi publik di website utama (aspirasi & pelanggaran ada di sub-web terpisah).
- Notifikasi push.

## 8. Pertanyaan Terbuka

1. Saat kegiatan dinonaktifkan, apakah dokumen kegiatan itu sendiri ikut dihapus, atau hanya sub-informasinya saja yang dihapus sedangkan kegiatan disimpan sebagai arsip status "selesai"? (Dokumen ini berasumsi ikut terhapus — mohon dikonfirmasi.)
2. Apakah dibutuhkan histori/log siapa admin yang mengubah status kegiatan?
3. Apakah perlu batas jumlah entri Informasi per kegiatan agar tidak terlalu panjang?
