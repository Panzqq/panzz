---
name: School Spirit & Youthful Leadership
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#2a1700'
  on-tertiary-container: '#b87500'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  slate-surface: '#F8FAFC'
  pure-white: '#FFFFFF'
  border-subtle: '#E2E8F0'
  border-strong: '#CBD5E1'
  aspirasi-magenta: '#EC4899'
  aspirasi-glow: '#F43F5E'
  live-emerald: '#10B981'
  live-emerald-bg: '#ECFDF5'
  spotify-green: '#1DB954'
  gdrive-blue: '#1A73E8'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4.5rem
---

## Brand & Style

The design system embodies the balance between institutional dignity and the energetic, forward-looking pulse of modern youth leadership. Crafted specifically for high school and vocational school student councils (OSIS), the personality conveys credibility, openness, dynamic movement, and approachability. It breaks away from dated bureaucratic school portals in favor of a contemporary, clean, and inspiring civic platform.

The core design style blends **Modern Digital Civic** with subtle **Glassmorphic Accents** and **Tactile Surfaces**:
- **Clean Structure & Air:** Grounded on a crisp slate foundation with intentional white space, making complex school agendas, accountability reports, and executive rosters easy to digest.
- **Vibrant Accent Energy:** High-contrast color bursts denote action, real-time urgency, and open student dialogue.
- **Glassmorphic Layering:** Navigation headers, floating social portals, and live activity badges leverage gentle backdrop-blur effects to convey modern technical polish.
- **Tone of Voice:** Dignified yet relatable Indonesian microcopy (*"Suara Kamu Didengar"*, *"Pantau Kegiatan Terkini"*, *"Keterbukaan & Sinergi"*), fostering mutual respect between student representatives and the student body.

## Colors

The color palette reflects institutional stability coupled with dynamic student participation:

- **Primary (`#0F172A` - Midnight Slate):** Serves as the bedrock color for high-hierarchy typography, core structural cards, footers, and institutional anchors, conveying governance and integrity.
- **Secondary (`#2563EB` - Royal Blue):** Drives primary user flow interactions, link states, active tab markers, and standard call-to-action buttons.
- **Tertiary (`#F59E0B` - Energetic Amber/Gold):** Evokes student spirit, excellence, achievements, milestone badges, and highlighted notices.
- **Neutral (`#64748B` - Slate Neutral):** Provides balanced legibility for secondary descriptions, metadata, timestamps, and subtle framing without visual clutter.

### Contextual Named Accents
- **Aspirasi Magenta (`#EC4899`) & Glow (`#F43F5E`):** Specifically reserved for the student aspiration ("Kotak Aspirasi") redirect button and feature spotlight, providing unmistakable visual weight and inviting direct civic participation.
- **Live Emerald (`#10B981` / `#ECFDF5`):** Reserved for live status indicators, real-time event tickers, and active agenda indicators.
- **Spotify Green (`#1DB954`) & Google Drive Blue (`#1A73E8`):** Preserved for integrated ecosystem external actions (RAB/LPJ spreadsheets, photo cloud archives, and official podcasts).

## Typography

The typographic system relies on **Plus Jakarta Sans** for headers, titles, and body content due to its energetic yet structured geometric terminals, balanced with **Inter** for UI labels, badges, and operational metadata.

- **Headlines & Titles:** Use tight letter-spacing (`-0.02em` to `-0.01em`) and bold weights to project leadership and purpose.
- **Body:** Standardized at 15px/24px on desktop to provide readability across dense informational rosters, activity logs, and mission statements without feeling clinical.
- **Labels & Microcopy:** Built with Inter's legible vertical metric proportions, ensuring quick scannability across timestamps, division tags, document chips, and navigation breadcrumbs.

## Layout & Spacing

The layout is built on a responsive 12-column grid system bounded within a maximum content container of `1280px` for optimal viewing on modern displays, fluidly down-scaling across form factors:

- **Desktop (1024px+):** 12 columns, 24px (`1.5rem`) gutters, 48px (`3rem`) page margins.
- **Tablet (768px - 1023px):** 8 columns, 20px (`1.25rem`) gutters, 32px (`2rem`) page margins.
- **Mobile (320px - 767px):** 4 columns, 16px (`1rem`) gutters, 16px (`1rem`) page margins.

Vertical rhythm adheres strictly to an 8px modular baseline (using spacing tokens `space-xs` through `space-3xl`). Section breaks consistently apply `space-3xl` (72px) on desktop and `space-2xl` (48px) on mobile, sustaining a rhythmic reading experience.

## Elevation & Depth

Visual hierarchy employs a crisp, multi-layered depth strategy centered on translucent frosted panels and fine slate outlines rather than heavy murky drops:

- **Base Layer (Elevation 0):** Pure slate background (`#F8FAFC`) acting as the structural canvas.
- **Layer 1 (Card & Content Container):** Crisp white surface (`#FFFFFF`) with a 1px border (`#E2E8F0`) and an ambient tinted shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.04)`.
- **Layer 2 (Interactive Floating & Hover Surfaces):** Active cards and preview panels elevate slightly on hover (`translate-y: -2px`) with an ambient lift: `0 10px 25px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.03)`.
- **Layer 3 (Glass Header & Modals):** Semi-transparent white (`rgba(255, 255, 255, 0.85)`) paired with `backdrop-filter: blur(12px)` and a subtle bottom border (`rgba(226, 232, 240, 0.8)`).
- **Special Elevation (Aspirasi Standout Glow):** Uses an electric radiant glow: `0 8px 24px -4px rgba(236, 72, 153, 0.35)`.
- **Special Elevation (Live Activity Pulse):** The real-time event badge features an alternating pulse effect between `rgba(16, 185, 129, 0.4)` and `rgba(16, 185, 129, 0.0)`.

## Shapes

The design system implements a balanced **Level 2 (Rounded)** shape personality. This delivers friendly, non-aggressive curvature tailored for school youth while maintaining orderly grid alignments:

- **Standard Elements (Buttons, Inputs, Small Badges):** `8px` (`0.5rem`) corner radius.
- **Content Cards, Tables, Embed Containers:** `16px` (`1rem`) corner radius (`rounded-lg`).
- **Featured Hero Cards, Live Activity Blocks, Modal Sheets:** `24px` (`1.5rem`) corner radius (`rounded-xl`).
- **Interactive Tags, Status Badges, & Avatar Placeholders:** Full pill (`9999px`) or circular contours to contrast against rectangular grids.

## Components

### 1. Navigation Header & Sub-Web Quick Switcher
- **Bar Container:** Fixed glassmorphism bar with blur backdrop, bordered at bottom with `#E2E8F0`.
- **Sub-Web Switchers:** Distinct pill badges for companion portals:
  - *Mading:* Subtle slate hover outline.
  - *Pencatat Pelanggaran:* Subtle slate outline with institutional icon.
  - *Aspirasi Siswa (Standout):* High-energy gradient button (Magenta to Rose `#EC4899` -> `#F43F5E`) with white text, font weight 700, and a soft ambient pink glow.

### 2. Live Activity Card ("Kegiatan Berlangsung")
- **Header:** Features a pulsating green status badge (`Sedang Berlangsung`) with a pinging ring animation beside the real-time event counter.
- **Card Surface:** Clean white with an Emerald-accented top border strip (3px).
- **Sub-info Feed:** Timeline-style items inside the card for dynamic updates (announcements, schedule changes) with timestamp labels. Notice text clearly indicates that live notes expire when the event closes.

### 3. Officer Grid & Avatar Fallbacks ("Struktur Kepengurusan")
- **Card Structure:** Rounded-lg surface showcasing role tag (e.g., "Ketua OSIS", "Sekbid 1"), officer name, and division.
- **Photo Handling:**
  - When URL is valid: high-clarity portrait with `object-cover` and subtle grayscale-to-color hover transition.
  - When photo URL is empty/null: an illustrated geometric fallback avatar featuring student initials rendered in bold primary navy typography over a soft amber/blue tint backdrop.

### 4. Cloud Document Action Cards (RAB, LPJ & Dokumentasi)
- **Design:** List cards with left icon indicator (Google Drive blue folder/sheet icon), activity title, and download/view metadata.
- **Action State:** Right-aligned icon-button (`Buka Dokumen`) with an external link indicator that triggers opening in a new tab securely.

### 5. Media & Social Embeds
- **Spotify Podcast Player Card:** Integrated dark/emerald themed embed frame displaying recent episodes, surrounded by a rounded container with a direct button to Spotify.
- **Floating Social Bar:** Fixed/sticky compact pill dock with icons for Instagram, TikTok, and YouTube with hover scale transitions.

### 6. Buttons & Inputs
- **Primary Button:** `#2563EB` background, white label, 8px radius, height 44px, 16px horizontal padding.
- **Secondary Button:** White background with `#E2E8F0` border and `#0F172A` text.
- **Form Inputs (Admin & Filter):** Crisp white fields, 1px `#CBD5E1` border, transition to `#2563EB` ring on `:focus`, font size 14px.