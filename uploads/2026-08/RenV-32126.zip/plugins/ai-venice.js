const https = require('https')
const crypto = require('crypto')

function generateSession() {
  const distinctId = crypto.randomUUID()
  const deviceId = crypto.randomUUID()
  const sessionId = crypto.randomUUID()
  const now = Date.now()

  const posthogData = encodeURIComponent(JSON.stringify({
    distinct_id: distinctId,
    '$device_id': deviceId,
    '$sesid': [now, sessionId, now],
    '$epp': true,
    '$initial_person_info': {
      r: '$direct',
      u: 'https://venice.ai/'
    }
  }))

  const cookie = [
    'venice-chat-version=v2',
    '_client_uat=0',
    '__client_uat_aKq7rGhf=0',
    `ph_phc_4Yg9V0hm9Lgavwcr6LZACe64tya7UqfyHePVNOzYREF_posthog=${posthogData}`
  ].join('; ')

  return {
    cookie,
    distinctId
  }
}

function createPayload(userMessage) {
  const msgId = crypto.randomBytes(9).toString('base64url').slice(0, 14)

  return JSON.stringify({
    input: {
      messages: [
        {
          content: [
            {
              annotations: [],
              text: userMessage,
              type: 'output_text'
            }
          ],
          id: msgId,
          role: 'user',
          status: 'completed',
          type: 'message'
        }
      ]
    }
  })
}

function askVenice(userMessage) {
  return new Promise((resolve, reject) => {
    const { cookie, distinctId } = generateSession()
    const payload = createPayload(userMessage)

    const options = {
      hostname: 'outerface.venice.ai',
      path: '/api/inference/workflow/chat',
      method: 'POST',
      headers: {
        'Accept': 'text/event-stream',
        'Accept-Encoding': 'identity',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Length': Buffer.byteLength(payload),
        'Content-Type': 'application/json',
        'Origin': 'https://venice.ai',
        'Referer': 'https://venice.ai/',
        'Sec-Ch-Ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
        'Sec-Ch-Ua-Mobile': '?1',
        'Sec-Ch-Ua-Platform': '"Android"',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-site',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
        'X-Venice-Distinct-Id': distinctId,
        'X-Venice-Locale': 'en',
        'X-Venice-Middleface-Version': '0.1.762',
        'X-Venice-Request-Timestamp': Date.now().toString(),
        'Cookie': cookie
      }
    }

    const req = https.request(options, res => {
      let buffer = ''
      let finalText = ''
      let tokens = null
      let errorBody = ''

      if (res.statusCode !== 200) {
        res.on('data', chunk => {
          errorBody += chunk.toString('utf8')
        })

        res.on('end', () => {
          reject(new Error(`HTTP ${res.statusCode}: ${errorBody.slice(0, 300)}`))
        })

        return
      }

      res.on('data', chunk => {
        buffer += chunk.toString('utf8')

        const lines = buffer.split('\n')
        buffer = lines.pop()

        for (const line of lines) {
          if (!line.startsWith('data:')) continue

          const data = line.slice(5).trim()
          if (!data || data === '[DONE]') continue

          try {
            const json = JSON.parse(data)

            if (json.output_index === 1 && json.text !== undefined) {
              finalText = json.text
              tokens = json.context_metadata?.total_tokens || tokens
            }

            if (json.error) {
              reject(new Error(JSON.stringify(json.error)))
            }
          } catch {
            // skip invalid SSE json
          }
        }
      })

      res.on('end', () => {
        if (!finalText) {
          reject(new Error('Tidak ada response dari Venice.'))
          return
        }

        resolve({
          text: finalText,
          tokens
        })
      })
    })

    req.setTimeout(120000, () => {
      req.destroy(new Error('Request timeout.'))
    })

    req.on('error', reject)
    req.write(payload)
    req.end()
  })
}

function splitMessage(text, max = 3500) {
  const result = []
  let str = String(text || '')

  while (str.length > max) {
    result.push(str.slice(0, max))
    str = str.slice(max)
  }

  if (str.trim()) result.push(str)
  return result
}

let handler = async (m, { text }) => {
  try {
    const quotedText =
      m.quoted?.text ||
      m.quoted?.caption ||
      m.quoted?.description ||
      ''

    const prompt = text || quotedText

    if (!prompt) {
      return m.reply(
        'Masukkan pertanyaan.\n\nContoh:\n.venice halo siapa kamu?'
      )
    }

    await m.reply('「 ゲ ◦ Venice AI 」\nSedang memproses jawaban...')

    const res = await askVenice(prompt)

    const caption = [
      '「 ゲ ◦ Venice AI 」',
      '',
      res.text,
      '',
      res.tokens ? `> Tokens: ${res.tokens}` : ''
    ].filter(Boolean).join('\n')

    const chunks = splitMessage(caption)

    for (const chunk of chunks) {
      await m.reply(chunk)
    }
  } catch (e) {
    console.error(e)
    return m.reply(`Gagal menghubungi Venice AI.\n\nError: ${e.message || e}`)
  }
}

handler.help = handler.command = ['venice', 'vai']
handler.tags = ['ai']

module.exports = handler