let handler = async (m, { conn, usedPrefix, command, isAdmin }) => {
  if (!m.quoted)
    throw `*• Example :* ${usedPrefix + command} *[reply Message]*`;
  try {
    m.quoted.delete();
  } catch (e) {
    throw eror;
  }
};
handler.help = ["delete", "del"].map((a) => a + " *[reply message]*");
handler.tags = ["group"];
handler.command = ["del", "delete"];

module.exports = handler;
