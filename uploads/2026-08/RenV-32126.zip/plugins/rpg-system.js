const RPG = require('../lib/rpg-system');

function pickId(map = {}, input = '') {
  input = String(input || '').toLowerCase().trim().replace(/\s+/g, '_');
  const list = Object.values(map || {});
  return list.find((x) => x.id === input)
    || list.find((x) => x.name?.toLowerCase().replace(/\s+/g, '_') === input)
    || list.find((x) => x.name?.toLowerCase().includes(input) || x.id.includes(input));
}

function resolveClass(input = '') {
  input = String(input || '').toLowerCase().trim();
  return Object.values(RPG.CLASSES).find((x) => x.id === input || x.name.toLowerCase() === input || x.name.toLowerCase().includes(input));
}

function inferSub(command = 'rpg', args = []) {
  command = String(command || '').toLowerCase();
  const direct = {
    rprofile: 'profile',
    rinv: 'inventory',
    rquest: 'quests',
    rboard: 'board',
    rtravel: 'travel',
    rexplore: 'explore',
    rhunt: 'explore',
    rgather: 'gather',
    rdungeon: 'dungeon',
    rcraft: 'craft',
    rshop: 'shop',
    rbuy: 'buy',
    rsell: 'sell',
    requip: 'equip',
    ruse: 'use',
    rrest: 'rest',
    rdaily: 'daily',
    rclasses: 'classes',
    rstory: 'story',
    radvance: 'story',
    rcodex: 'codex',
    rleaderboard: 'leaderboard',
    rlb: 'leaderboard'
  };
  if (direct[command]) return direct[command];
  return String(args[0] || 'help').toLowerCase();
}

function lineBreak(lines = []) {
  return lines.filter(Boolean).join('\n');
}

let handler = async (m, { conn, args = [], command = 'rpg', usedPrefix = '.' }) => {
  const sub = inferSub(command, args);
  const user = global.db.data.users[m.sender] || (global.db.data.users[m.sender] = {});
  const rpg = RPG.ensureProfile(user, m.pushName || user.name || 'Wanderer');
  const nextArgs = String(command).toLowerCase() === 'rpg' ? args.slice(1) : args;
  const ensureStarted = async () => {
    if (rpg.started) return true;
    await RPG.send(conn, m, [
      '# RENVY RPG',
      '',
      'Kamu belum mengaktifkan karakter RPG baru.',
      '',
      'Pilih class dulu:',
      `- ${usedPrefix}rpg classes`,
      `- ${usedPrefix}rpg start sentinel`,
      `- ${usedPrefix}rpg start hexcaster`,
      `- ${usedPrefix}rpg start shadeweaver`,
      `- ${usedPrefix}rpg start wayfarer`
    ].join('\n'));
    return false;
  };

  if (['help', 'menu', 'guide'].includes(sub)) {
    return RPG.send(conn, m, RPG.helpText(usedPrefix));
  }

  if (sub === 'classes' || sub === 'class') {
    return RPG.send(conn, m, RPG.classesText());
  }

  if (sub === 'start') {
    const classId = nextArgs[0] || args[1];
    const cls = resolveClass(classId);
    if (!cls) return RPG.send(conn, m, `${RPG.classesText()}\n\nPilih class dengan: *${usedPrefix}rpg start <class>*`);
    const result = RPG.startCharacter(user, cls.id, m.pushName || user.name || 'Wanderer');
    if (!result.ok) return m.reply(result.reason);
    return RPG.send(conn, m, [
      '# CHARACTER AWAKENED',
      '',
      `${cls.emoji} *${cls.name}* berhasil dipilih!`,
      `${cls.desc}`,
      '',
      'Starter gear dan supply sudah diberikan.',
      `- Buka profil: *${usedPrefix}rpg profile*`,
      `- Lihat main story: *${usedPrefix}rpg story*`,
      `- Lihat quest board: *${usedPrefix}rpg board*`,
      `- Mulai eksplorasi: *${usedPrefix}rpg explore*`
    ].join('\n'));
  }

  if (!(await ensureStarted())) return;

  if (sub === 'profile' || sub === 'stats') {
    return RPG.send(conn, m, RPG.profileText(user.name || m.pushName || 'Wanderer', rpg));
  }

  if (sub === 'story' || sub === 'chapter' || sub === 'mainstory') {
    const action = String(nextArgs[0] || '').toLowerCase();
    if (['claim', 'advance', 'lanjut', 'next'].includes(action) || String(command).toLowerCase() === 'radvance') {
      const res = RPG.advanceStory(rpg);
      if (!res.ok) return m.reply(res.reason);
      return RPG.send(conn, m, [
        '# STORY CHAPTER COMPLETE',
        '',
        `Chapter ${res.chapter.id}: *${res.chapter.title}* selesai.`,
        `Reward: +${res.reward.xp || 0} XP • +${res.reward.gold || 0} Gold${Object.keys(res.reward.items || {}).length ? ` • ${Object.entries(res.reward.items).map(([id, qty]) => `${RPG.ITEMS[id]?.name || id} x${qty}`).join(', ')}` : ''}`,
        ...(res.levelNotes || []),
        '',
        `Lihat chapter berikutnya: *${usedPrefix}rpg story*`
      ].join('\n'));
    }
    return RPG.send(conn, m, RPG.storyText(rpg));
  }

  if (sub === 'board') {
    return RPG.send(conn, m, RPG.boardText(rpg));
  }

  if (sub === 'accept') {
    const idx = Math.max(1, Number(nextArgs[0] || args[1] || 0)) - 1;
    const res = RPG.acceptQuest(rpg, idx);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, `# QUEST ACCEPTED\n\n*${res.quest.title}*\n${res.quest.desc}\n\nCek progress: *${usedPrefix}rpg quests*`);
  }

  if (sub === 'quests' || sub === 'quest' || sub === 'log') {
    return RPG.send(conn, m, RPG.activeQuestText(rpg));
  }

  if (sub === 'claim') {
    const res = RPG.claimQuest(rpg);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, lineBreak([
      '# QUEST CLAIMED',
      '',
      ...res.rewardNotes,
      '',
      res.levelNotes.join('\n')
    ]));
  }

  if (sub === 'refresh' || sub === 'reroll') {
    const res = RPG.generateBoard(rpg, true);
    return RPG.send(conn, m, lineBreak(['# QUEST BOARD REFRESHED', '', RPG.boardText(rpg)]));
  }

  if (sub === 'travel' || sub === 'map') {
    if (!nextArgs[0] && String(command).toLowerCase() === 'rtravel') {
      return RPG.send(conn, m, RPG.zonesText(rpg));
    }
    if (!nextArgs[0]) return RPG.send(conn, m, RPG.zonesText(rpg));
    const res = RPG.travel(rpg, nextArgs.join(' '));
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, `# TRAVEL SUCCESS\n\nKamu pindah ke *${res.zone.name}* ${res.zone.emoji}\n${res.zone.desc}\n\nMulai jelajah: *${usedPrefix}rpg explore*`);
  }

  if (sub === 'explore' || sub === 'adventure' || sub === 'hunt' || sub === 'battle') {
    const res = RPG.explore(rpg);
    if (!res.ok) return m.reply(res.reason);
    if (res.type === 'event') return RPG.send(conn, m, `# EXPLORE EVENT\n\n${res.text}`);
    const b = res.battle;
    const summary = [
      `# EXPLORE — ${b.monster.name}`,
      '',
      ...b.logs.slice(0, 8),
      ...(b.logs.length > 8 ? ['...'] : []),
      '',
      b.won
        ? `✅ Menang! +${b.exp} XP • +${b.gold} Gold${b.drops.length ? ` • Loot: ${b.drops.map(id => RPG.ITEMS[id]?.name || id).join(', ')}` : ''}`
        : `❌ Tumbang melawan ${b.monster.name}. HP-mu tersisa sedikit, istirahat dulu.`,
      ...(b.levelNotes || [])
    ];
    return RPG.send(conn, m, summary.join('\n'));
  }

  if (sub === 'gather' || ['mine', 'forage', 'fish'].includes(sub)) {
    const mode = ['mine', 'forage', 'fish'].includes(sub) ? sub : (nextArgs[0] || 'forage');
    const res = RPG.gather(rpg, mode);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, [
      `# GATHER — ${String(res.mode).toUpperCase()}`,
      '',
      ...Object.entries(res.loot).map(([id, qty]) => `• ${RPG.ITEMS[id]?.emoji || '▫️'} ${RPG.ITEMS[id]?.name || id} x${qty}`),
      '',
      `Zona: ${RPG.ZONES[rpg.zone]?.name || rpg.zone}`
    ].join('\n'));
  }

  if (sub === 'dungeon') {
    const res = RPG.dungeon(rpg);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, [
      '# DUNGEON RUN',
      '',
      ...res.logs,
      '',
      res.cleared ? '🏆 Dungeon clear! Semua reward sudah masuk ke inventory/profile.' : '⚠️ Run berakhir sebelum boss tumbang. Tetap ada progres dan codex update.'
    ].join('\n'));
  }

  if (sub === 'inventory' || sub === 'inv' || sub === 'bag') {
    return RPG.send(conn, m, RPG.inventoryText(rpg));
  }

  if (sub === 'use') {
    const item = pickId(RPG.ITEMS, nextArgs.join(' '));
    if (!item) return m.reply(`Item tidak ditemukan. Contoh: ${usedPrefix}rpg use potion`);
    const res = RPG.useItem(rpg, item.id);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, `# ITEM USED\n\nKamu menggunakan *${item.name}* ${item.emoji}\n${item.desc}`);
  }

  if (sub === 'equip') {
    const item = pickId(RPG.ITEMS, nextArgs.join(' '));
    if (!item) return m.reply(`Gear tidak ditemukan. Contoh: ${usedPrefix}rpg equip lunar_blade`);
    const res = RPG.equip(rpg, item.id);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, `# EQUIPPED\n\n*${item.name}* dipasang ke slot *${item.slot}*.`);
  }

  if (sub === 'unequip') {
    const slot = nextArgs[0];
    const res = RPG.unequip(rpg, slot);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, `# UNEQUIPPED\n\n*${res.item.name}* dilepas dari slot gear.`);
  }

  if (sub === 'shop') {
    return RPG.send(conn, m, RPG.shopText(rpg, nextArgs[0]));
  }

  if (sub === 'buy') {
    const item = pickId(RPG.ITEMS, nextArgs[0]);
    const qty = Number(nextArgs[1] || 1);
    if (!item) return m.reply(`Item shop tidak ditemukan. Contoh: ${usedPrefix}rpg buy potion 2`);
    const res = RPG.buy(rpg, item.id, qty);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, `# PURCHASE SUCCESS\n\nMembeli *${item.name}* x${res.qty}\nTotal: ${res.cost} Gold`);
  }

  if (sub === 'sell') {
    const item = pickId(RPG.ITEMS, nextArgs[0]);
    const qty = Number(nextArgs[1] || 1);
    if (!item) return m.reply(`Item tidak ditemukan. Contoh: ${usedPrefix}rpg sell ruin_scrap 3`);
    const res = RPG.sell(rpg, item.id, qty);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, `# ITEM SOLD\n\nMenjual *${item.name}* x${res.qty}\nDapat: ${res.gold} Gold`);
  }

  if (sub === 'craft') {
    if (!nextArgs[0]) return RPG.send(conn, m, RPG.craftText(rpg));
    const recipe = pickId(RPG.RECIPES, nextArgs.join(' '));
    if (!recipe) return m.reply(`Recipe tidak ditemukan. Lihat daftar: ${usedPrefix}rpg craft`);
    const res = RPG.craft(rpg, recipe.id);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, `# CRAFT COMPLETE\n\n${recipe.name} berhasil.\nHasil: ${Object.entries(recipe.out).map(([id, qty]) => `${RPG.ITEMS[id]?.name || id} x${qty}`).join(', ')}`);
  }

  if (sub === 'stat' || sub === 'upgrade') {
    const stat = nextArgs[0];
    const qty = Number(nextArgs[1] || 1);
    const res = RPG.allocateStat(rpg, stat, qty);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, `# STAT UPGRADED\n\n${String(res.stat).toUpperCase()} +${res.points}\nSisa stat point: ${rpg.statPoints}`);
  }

  if (sub === 'daily') {
    const res = RPG.daily(rpg);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, [
      '# DAILY REWARD',
      '',
      `+${res.gold} Gold`,
      `+${res.xp} XP`,
      'HP / Mana / Stamina dipulihkan penuh.',
      ...(res.levelNotes || [])
    ].join('\n'));
  }

  if (sub === 'rest') {
    const res = RPG.rest(rpg);
    if (!res.ok) return m.reply(res.reason);
    return RPG.send(conn, m, `# REST COMPLETE\n\n+${res.hp} HP\n+${res.mana} Mana\n+${res.stamina} Stamina`);
  }

  if (sub === 'codex') {
    return RPG.send(conn, m, RPG.codexText(rpg));
  }

  if (sub === 'leaderboard' || sub === 'lb' || sub === 'top') {
    return RPG.send(conn, m, RPG.leaderboardText(global.db.data.users || {}));
  }

  return RPG.send(conn, m, RPG.helpText(usedPrefix));
};

handler.help = [
  'rpg',
  'rpg classes',
  'rpg start <class>',
  'rpg profile',
  'rpg story',
  'rpg story claim',
  'rpg board',
  'rpg accept <slot>',
  'rpg quests',
  'rpg explore',
  'rpg gather <forage|mine|fish>',
  'rpg dungeon',
  'rpg travel <zone>',
  'rpg inventory',
  'rpg craft <recipe>',
  'rpg shop',
  'rpg daily',
  'rpg rest'
];
handler.command = [
  'rpg', 'rprofile', 'rinv', 'rquest', 'rboard', 'rtravel', 'rexplore', 'rhunt', 'rgather',
  'rdungeon', 'rcraft', 'rshop', 'rbuy', 'rsell', 'requip', 'ruse', 'rrest', 'rdaily', 'rclasses', 'rstory', 'radvance', 'rcodex', 'rleaderboard', 'rlb'
];
handler.tags = ['rpg'];
handler.limit = false;
handler.register = true;
handler.heavy = false;
handler.queue = true;

module.exports = handler;
