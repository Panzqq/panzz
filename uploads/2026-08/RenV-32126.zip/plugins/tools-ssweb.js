/**
 *   SCRAPE NAME  :: SSWEB MICROLINK
 *   
 *   [•] AUTHOR       :: DEFAN
 *   [•] WEB          :: soonex.biz.id
 *   [•] DESCRIPTION  :: Screenshot website menggunakan API Microlink (Desktop, Tablet, Mobile)
 *   [•] BASE         :: api.microlink.io
 *   [•] CHANNEL      :: https://whatsapp.com/channel/0029Vb89qIx1XquQoXgzdd2m
 *   
 *   [!] ATTENTION:
 *   Modification without permission is prohibited.
 *   RESPECT THE AUTHOR, DO NOT REMOVE THIS WATERMARK!
 */

const axios = require('axios');

function normalizeUrl(url) {
  url = String(url || '').trim();

  if (!url) return null;

  if (!/^https?:\/\//i.test(url)) {
    url = 'https://' + url;
  }

  try {
    new URL(url);
    return url;
  } catch {
    return null;
  }
}

function getViewport(device = 'desktop') {
  device = String(device || 'desktop').toLowerCase();

  if (device === 'mobile') {
    return {
      device: 'mobile',
      width: 393,
      height: 852
    };
  }

  if (device === 'tablet') {
    return {
      device: 'tablet',
      width: 768,
      height: 1024
    };
  }

  return {
    device: 'desktop',
    width: 1920,
    height: 1080
  };
}

function parseInput(text) {
  let args = String(text || '').trim().split(/\s+/).filter(Boolean);

  let devices = ['desktop', 'tablet', 'mobile'];
  let device = 'desktop';

  let deviceIndex = args.findIndex(v => devices.includes(v.toLowerCase()));

  if (deviceIndex !== -1) {
    device = args[deviceIndex].toLowerCase();
    args.splice(deviceIndex, 1);
  }

  let targetUrl = args.join(' ');

  return {
    targetUrl,
    device
  };
}

async function ssweb(targetUrl, device = 'desktop') {
  const viewport = getViewport(device);

  const params = new URLSearchParams({
    url: targetUrl,
    meta: 'false',
    'screenshot.type': 'png',
    'screenshot.fullPage': 'false',
    'viewport.width': String(viewport.width),
    'viewport.height': String(viewport.height),
    adblock: 'true',
    force: 'false'
  });

  const apiUrl = `https://api.microlink.io/?${params.toString()}`;

  const response = await axios.get(apiUrl, {
    timeout: 60000,
    headers: {
      accept: 'application/json',
      'user-agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 Chrome/124.0.0.0 Mobile Safari/537.36'
    }
  });

  const json = response.data;

  if (!json || json.status !== 'success') {
    throw new Error(json?.message || 'Gagal mengambil screenshot dari API.');
  }

  const result = json.data?.screenshot;

  if (!result?.url) {
    throw new Error('URL screenshot tidak ditemukan.');
  }

  return {
    status: 'success',
    message: 'Screenshot berhasil diambil',
    data: {
      target_url: targetUrl,
      device: viewport.device,
      screenshot_url: result.url,
      format: result.type || 'png',
      size: result.size_pretty || 'Unknown',
      dimensions: {
        width: result.width || viewport.width,
        height: result.height || viewport.height
      }
    }
  };
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
`乂 S S W E B

\`C A R A  P A K A I\`
> [+] ${usedPrefix + command} https://example.com
> [+] ${usedPrefix + command} https://example.com mobile
> [+] ${usedPrefix + command} https://example.com tablet
> [+] ${usedPrefix + command} https://example.com desktop

\`D E V I C E\`
> [+] desktop
> [+] tablet
> [+] mobile`
    );
  }

  try {
    const { targetUrl, device } = parseInput(text);
    const url = normalizeUrl(targetUrl);

    if (!url) {
      return m.reply('> [!] URL tidak valid.\n\nContoh: .ssweb https://example.com mobile');
    }

    await m.reply(global.wait || '> [!] Sedang mengambil screenshot website...');

    const result = await ssweb(url, device);

    const imageRes = await axios.get(result.data.screenshot_url, {
      responseType: 'arraybuffer',
      timeout: 60000,
      headers: {
        'user-agent': 'Mozilla/5.0'
      }
    });

    const buffer = Buffer.from(imageRes.data);

    const caption =
`乂 S S W E B

\`I N F O\`
> [+] Status: ${result.status}
> [+] Device: ${result.data.device}
> [+] Format: ${result.data.format}
> [+] Size: ${result.data.size}
> [+] Width: ${result.data.dimensions.width}
> [+] Height: ${result.data.dimensions.height}

\`U R L\`
> [+] ${result.data.target_url}

> Source: Microlink API`;

    return conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption
      },
      {
        quoted: m
      }
    );
  } catch (e) {
    console.error(e);
    return m.reply(`> [!] Error: ${e.message || e}`);
  }
};

handler.help = [
  'ssweb *<url>*',
  'ssweb *<url> mobile*',
  'ssweb *<url> tablet*',
  'ssweb *<url> desktop*'
];

handler.tags = ['tools'];

handler.command = /^(ssweb|ss|sswebsite|screenshotweb)$/i;

module.exports = handler;