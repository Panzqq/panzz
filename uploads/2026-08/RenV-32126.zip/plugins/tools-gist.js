const axios = require('axios')
const cheerio = require('cheerio')

let handler = async (m, { text, conn }) => {
  if (!text) return m.reply('🚩 Masukkan URL Gist / file GitHub.')

  const input = text.trim()

  try {
    const data = await getGithubContent(input)

    const code = data.code
    const pluginName = data.fileName || 'github-file.js'
    const sourceType = data.type || 'GitHub'

    let styled =
`> [+] *${sourceType.toUpperCase()} DOWNLOADER*
> [+] \`Status:\` Success ✅
> [+] \`File:\` ${pluginName}
> [+] \`Raw:\` ${data.rawUrl || '-'}

\`\`\`js
${code}
\`\`\`
`

    const msgButton = {
      interactiveMessage: {
        body: {
          text: styled
        },
        footer: {
          text: '🔧 GitHub Fetcher'
        },
        header: {
          hasMediaAttachment: false
        },
        nativeFlowMessage: {
          buttons: [
            {
              name: 'cta_copy',
              buttonParamsJson: JSON.stringify({
                display_text: '📋 Copy Code',
                id: 'copy_plugin_code',
                copy_code: code
              })
            }
          ]
        }
      }
    }

    await conn.relayMessage(m.chat, msgButton, {
      messageId: m.key.id
    })

  } catch (e) {
    console.error(e)
    return m.reply(`🚩 Gagal mengambil data.\n\n${e.message || e}`)
  }
}

handler.help = ['gist <url>', 'githubfile <url>']
handler.tags = ['tools']
handler.command = /^(gist|githubfile|getcode|fetchcode)$/i

module.exports = handler

async function getGithubContent(url) {
  if (!/^https?:\/\//i.test(url)) {
    throw new Error('URL tidak valid.')
  }

  const parsed = new URL(url)
  const host = parsed.hostname.replace(/^www\./, '')

  if (host === 'gist.github.com') {
    return await getGist(url)
  }

  if (host === 'github.com') {
    return await getGithubBlob(url)
  }

  if (host === 'raw.githubusercontent.com') {
    return await getRawGithub(url)
  }

  if (host === 'gist.ditzzzx.my.id') {
    return await getCustomGist(url)
  }

  throw new Error('Hanya support Gist GitHub, file GitHub, atau Custom Gist (gist.ditzzzx.my.id).')
}

async function getGist(url) {
  const regex = /^https:\/\/gist\.github\.com\/[^\/]+\/[a-f0-9]+/i
  if (!regex.test(url)) {
    throw new Error('URL Gist tidak valid.')
  }

  const res = await axios.get(url, {
    timeout: 30000,
    headers: {
      'User-Agent': 'Mozilla/5.0'
    }
  })

  const $ = cheerio.load(res.data)

  const rawLinks = $('a[href*="/raw/"]')
    .map((i, el) => $(el).attr('href'))
    .get()
    .filter(Boolean)

  if (!rawLinks.length) throw new Error('File raw Gist tidak ditemukan.')

  const rawPath = rawLinks[0]
  const rawUrl = rawPath.startsWith('http')
    ? rawPath
    : 'https://gist.githubusercontent.com' + rawPath

  const rawRes = await axios.get(rawUrl, {
    timeout: 30000,
    responseType: 'text',
    headers: {
      'User-Agent': 'Mozilla/5.0'
    }
  })

  const fileName = getFileNameFromUrl(rawUrl) || url.split('/').pop() || 'gist-file.js'

  return {
    type: 'Gist',
    fileName,
    rawUrl,
    code: rawRes.data
  }
}

async function getGithubBlob(url) {
  const parsed = new URL(url)
  const parts = parsed.pathname.split('/').filter(Boolean)

  if (parts.length < 5 || parts[2] !== 'blob') {
    throw new Error('URL GitHub harus berupa link file /blob/, bukan folder/repo.')
  }

  const owner = parts[0]
  const repo = parts[1]
  const branch = parts[3]
  const filePath = parts.slice(4).join('/')

  if (!owner || !repo || !branch || !filePath) {
    throw new Error('URL GitHub tidak lengkap.')
  }

  const rawUrl = `https://raw.githubusercontent.com/\( {owner}/ \){repo}/\( {branch}/ \){filePath}`

  const res = await axios.get(rawUrl, {
    timeout: 30000,
    responseType: 'text',
    headers: {
      'User-Agent': 'Mozilla/5.0'
    }
  })

  return {
    type: 'GitHub',
    fileName: filePath.split('/').pop(),
    rawUrl,
    code: res.data
  }
}

async function getRawGithub(url) {
  const fileName = getFileNameFromUrl(url) || 'github-file.js'

  const res = await axios.get(url, {
    timeout: 30000,
    responseType: 'text',
    headers: {
      'User-Agent': 'Mozilla/5.0'
    }
  })

  return {
    type: 'Raw GitHub',
    fileName,
    rawUrl: url,
    code: res.data
  }
}

async function getCustomGist(url) {
  const fileName = getFileNameFromUrl(url) || 'custom-gist.js'

  const res = await axios.get(url, {
    timeout: 30000,
    responseType: 'text',
    headers: {
      'User-Agent': 'Mozilla/5.0'
    }
  })

  return {
    type: 'Custom Gist',
    fileName,
    rawUrl: url,
    code: res.data
  }
}

function getFileNameFromUrl(url) {
  try {
    const parsed = new URL(url)
    const cleanPath = parsed.pathname.split('/').filter(Boolean)
    return cleanPath.pop()
  } catch {
    return null
  }
}