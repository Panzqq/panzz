let handler = async (m, { usedPrefix, command }) => {
  if (!m.isGroup) return m.reply(`*[!] Fitur ini hanya bisa digunakan di grup.*`);

  let chat = global.db.data.chats[m.chat] || (global.db.data.chats[m.chat] = {});

  if (chat.isBanned) {
    return m.reply(`*[!] Banchat sudah aktif di grup ini.*\n\n> Gunakan *${usedPrefix}unbanchat* untuk membuka akses bot lagi.`);
  }

  chat.isBanned = true;

  await m.reply(`*[ ✓ ] Banchat berhasil diaktifkan.*\n\n> Semua member tidak bisa menggunakan bot di grup ini.\n> Owner tetap bebas menggunakan bot.`);
};

handler.help = handler.command = ['banchat', 'ban-chat'];
handler.tags = ['owner'];
handler.owner = true;
handler.group = true;

module.exports = handler;
