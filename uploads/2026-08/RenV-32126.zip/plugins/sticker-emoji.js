module.exports = {
  help: ["emoji"].map((a) => a + " *[emoji]*"),
  tags: ["sticker"],
  command: ["emoji"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[emoji]*`;
    if (!Func.getEmoji(text))
      throw `*• Example :* ${usedPrefix + command} *[emoji]*`;
    let codePoint = Array.from(text)[0]?.codePointAt(0)?.toString(16);
    let result = codePoint
      ? `https://fonts.gstatic.com/s/e/notoemoji/latest/${codePoint}/512.webp`
      : false;
    if (!result) throw "*[ x ]* Emoji Not found";
    conn.sendMessage(
      m.chat,
      {
        sticker: {
          url: result,
        },
        packname: global.packname,
        author: global.author,
      },
      {
        quoted: m,
      },
    );
  },
};

async function NotoEmoji(emoji) {
  try {
    const codePoint = Array.from(emoji)[0]?.codePointAt(0)?.toString(16);
    return codePoint
      ? `https://fonts.gstatic.com/s/e/notoemoji/latest/${codePoint}/512.webp`
      : null;
  } catch (error) {
    return console.error("Error getting NotoEmoji:", error), null;
  }
}
