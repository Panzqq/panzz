const fetch = global.fetch || ((...args) =>
  import('node-fetch').then(({ default: fetch }) => fetch(...args))
);

async function turnitinCheck(text) {
  const res = await fetch('https://reilaa.com/api/turnitin-match', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ text })
  });

  if (!res.ok) throw new Error(`API Error ${res.status}`);

  return await res.json();
}

function toPercent(num) {
  const n = Number(num || 0);
  if (!isFinite(n)) return '0';
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
}

function rapihinClass(text = '') {
  return String(text)
    .replace(/_/g, ' ')
    .toLowerCase()
    .replace(/\b\w/g, x => x.toUpperCase());
}

function levelSimilarity(score) {
  score = Number(score || 0);

  if (score <= 10) return 'Sangat rendah';
  if (score <= 30) return 'Rendah';
  if (score <= 60) return 'Sedang';
  return 'Tinggi';
}

function levelAI(score) {
  score = Number(score || 0);

  if (score <= 20) return 'Sangat kecil';
  if (score <= 50) return 'Sedang';
  if (score <= 80) return 'Cukup tinggi';
  return 'Sangat tinggi';
}

function levelRisk(score) {
  score = Number(score || 0);

  if (score <= 10) return 'Rendah';
  if (score <= 30) return 'Cukup rendah';
  if (score <= 60) return 'Sedang';
  return 'Tinggi';
}

function buatKesimpulan(similarity, aiScore) {
  similarity = Number(similarity || 0);
  aiScore = Number(aiScore || 0);

  if (similarity <= 10 && aiScore <= 20) {
    return '✅ Aman. Teks terlihat original dan lebih mirip tulisan manusia.';
  }

  if (similarity <= 30 && aiScore <= 50) {
    return '🟡 Cukup aman. Ada sedikit kemiripan atau kemungkinan AI, tapi belum tinggi.';
  }

  if (similarity > 60 || aiScore > 80) {
    return '🔴 Risiko tinggi. Teks sebaiknya diperiksa dan diperbaiki ulang.';
  }

  return '⚠️ Perlu dicek ulang. Ada beberapa bagian yang mungkin perlu diperbaiki.';
}

function formatTurnitin(data) {
  const value = data?.reilaaResult?.value || {};
  const details = value?.details || {};
  const analysis = details?.analysis || {};

  const turnitin = Number(data?.turnitin ?? 0);
  const reilaa = Number(data?.reilaa ?? 0);
  const aiScore = Number(value?.aiScore ?? details?.confidence ?? 0);

  const classification = value?.classification || details?.classification || '-';
  const risk = analysis?.risk || '-';
  const suggestion = analysis?.suggestion || '-';

  const similarity = Math.max(turnitin, reilaa);

  let teks = `乂 C E K  T E K S\n\n`;

  teks += `📌 *Kesimpulan*\n`;
  teks += `${buatKesimpulan(similarity, aiScore)}\n\n`;

  teks += `📊 *Hasil Pemeriksaan*\n`;
  teks += `• Kemiripan Teks: *${toPercent(similarity)}%* (${levelSimilarity(similarity)})\n`;
  teks += `• Deteksi AI: *${toPercent(aiScore)}%* (${levelAI(aiScore)})\n`;
  teks += `• Risiko: *${levelRisk(Math.max(similarity, aiScore))}*\n`;
  teks += `• Kategori: *${rapihinClass(classification)}*\n\n`;

  teks += `📝 *Penjelasan Singkat*\n`;

  if (similarity <= 10) {
    teks += `• Teks hampir tidak mirip dengan sumber lain.\n`;
  } else if (similarity <= 30) {
    teks += `• Ada sedikit kemiripan, tapi masih tergolong rendah.\n`;
  } else if (similarity <= 60) {
    teks += `• Kemiripan cukup terlihat, sebaiknya cek ulang bagian teks.\n`;
  } else {
    teks += `• Kemiripan tinggi, teks berisiko dianggap hasil salinan.\n`;
  }

  if (aiScore <= 20) {
    teks += `• Teks lebih terlihat seperti tulisan manusia.\n`;
  } else if (aiScore <= 50) {
    teks += `• Ada kemungkinan kecil sampai sedang teks terdeteksi AI.\n`;
  } else if (aiScore <= 80) {
    teks += `• Teks cukup berpotensi terdeteksi AI.\n`;
  } else {
    teks += `• Teks sangat berpotensi dianggap buatan AI.\n`;
  }

  if (suggestion && suggestion !== '-') {
    teks += `• Saran sistem: ${suggestion}\n`;
  }

  const sentences = Array.isArray(value?.sentences) ? value.sentences : [];
  const aiSentences = sentences.filter(v => v?.isAI || Number(v?.aiProbability) > 20);

  if (aiSentences.length > 0) {
    teks += `\n🔎 *Kalimat yang Perlu Dicek*\n`;

    aiSentences.slice(0, 5).forEach((item, i) => {
      teks += `\n${i + 1}. ${item.text || '-'}\n`;
      teks += `   Deteksi AI: ${toPercent(item.aiProbability)}%\n`;
    });
  }

  teks += `\n⚠️ *Catatan:* Hasil ini berasal dari API pengecek similarity/AI detector, bukan Turnitin resmi.`;

  return teks;
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    const input =
      text ||
      m.quoted?.text ||
      m.quoted?.caption ||
      m.quoted?.description;

    if (!input) {
      return m.reply(
        `Masukkan teks yang mau dicek.\n\n` +
        `Contoh:\n${usedPrefix + command} Ini adalah teks yang ingin dicek.`
      );
    }

    if (input.length < 5) {
      return m.reply('Teks terlalu pendek untuk dicek.');
    }

    await m.reply('⏳ Sedang mengecek teks...');

    const result = await turnitinCheck(input);
    const output = formatTurnitin(result);

    await m.reply(output);
  } catch (e) {
    console.error(e);
    m.reply(`Gagal mengecek teks.\n\nError: ${e.message || e}`);
  }
};

handler.help = handler.command = ['turnitin', 'cekai', 'similarity'];
handler.tags = ['ai'];

module.exports = handler;