const { WAMessageStubType } = require("baileys");
const { extractRawId } = require("../lib/jid-utils");

// WhatsApp/Baileys terbaru bisa mengirim messageStubParameters berupa object
// {id, lid, ...} atau string JSON dari object itu (bukan JID polos), jadi jangan
// pernah pakai .split("@") langsung ke messageStubParameters[0] mentah-mentah.
function stubParamNumber(param) {
  const raw = extractRawId(param);
  return String(raw || "").split("@")[0].split(":")[0];
}

async function before(m) {
  if (!m.messageStubType || !m.isGroup) return;
  const chat = global.db.data.chats[m.chat];

  // Note: stub type 27 (participant ditambahkan/join) SENGAJA tidak dikirim di sini.
  // Notifikasi join/add sudah ditangani oleh handler.js (event "group-participants.update")
  // yang mengirim card WELCOME bertombol. Kalau tetap dikirim di sini juga, akan dobel:
  // teks polos "Added @..." muncul duluan sebelum card WELCOME.
  const messages = {
    21: `Change Subject Group To:\n *${m.messageStubParameters[0]}*`,
    22: `Change the Group Icon`,
    23: `Change group invite link`,
    24: `Change Description Group To \n\n${m.messageStubParameters[0]}`,
    25: `Set to *${m.messageStubParameters[0] == "on" ? "Admin Only" : "All Participant"}* Can Change Group Description.`,
    26: `Set to *${m.messageStubParameters[0] == "on" ? "Closed" : "Opened"}* Group!\nNow ${m.messageStubParameters[0] == "on" ? "Admin Only" : "All Participant"} can send message.`,
    28: `Kicked @${stubParamNumber(m.messageStubParameters[0])}`,
    29: `Promoted @${stubParamNumber(m.messageStubParameters[0])} To Admin.`,
    30: `Demoted @${stubParamNumber(m.messageStubParameters[0])} From Admin.`,
    70: `Invite Sent To Group`,
    71: `Request to Join the Group`,
    72: `Change Ephemeral To *@${m.messageStubParameters[0]}*`,
    74: `Sent ViewOnce Message`,
  };

  const messageType = messages[m.messageStubType];
  if (messageType) {
    const mentionNumber = stubParamNumber(m.messageStubParameters?.[0]);
    const mentionJid = mentionNumber ? `${mentionNumber}@s.whatsapp.net` : undefined;
    await this.reply(
      m.chat,
      `${messageType}`,
      fakestatus("*[ Group Notification ]*"),
      {
        contextInfo: {
          mentionedJid: mentionJid ? [m.sender, mentionJid] : [m.sender],
        },
      },
    );
  }
}

module.exports = {
  before,
};
