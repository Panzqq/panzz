const crypto = require("crypto");
const webp = require("node-webpmux");

async function addExif(webpSticker, packname, author, categories = [""], extra = {}) {
  const img = new webp.Image();

  const json = {
    "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
    "sticker-pack-name": packname,
    "sticker-pack-publisher": author,
    emojis: categories,
    ...extra,
  };

  const exifAttr = Buffer.from([
    0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
  ]);

  const jsonBuffer = Buffer.from(JSON.stringify(json), "utf8");
  const exif = Buffer.concat([exifAttr, jsonBuffer]);
  exif.writeUIntLE(jsonBuffer.length, 14, 4);

  await img.load(webpSticker);
  img.exif = exif;

  return await img.save(null);
}

let handler = async (m, { conn, text }) => {
  if (!m.quoted) throw "Reply sticker!";

  let sticker = false;

  try {
    let [packname, ...author] = (text || "").split("|");
    author = author.join("|");

    const mime = m.quoted.mimetype || "";
    if (!/webp/i.test(mime)) throw "Reply a webp sticker!";

    const buf = await m.quoted.download();
    if (!buf) throw "Failed to download sticker.";

    sticker = await addExif(
      buf,
      packname?.trim() || "",
      author?.trim() || ""
    );
  } catch (e) {
    console.error(e);
    if (Buffer.isBuffer(e)) sticker = e;
  } finally {
    if (sticker) {
      await conn.sendFile(m.chat, sticker, "wm.webp", "", m, false, {
        asSticker: true,
      });
    } else {
      throw "Conversion failed.";
    }
  }
};

handler.help = ["wm <packname>|<author>"];
handler.tags = ["sticker"];
handler.command = /^wm$/i;
handler.register = true;
handler.premium = false;

module.exports = handler;