const { AIRich } = require('../lib/nixcode.js');

function cleanNumber(input = '') {
    return String(input)
        .split('@')[0]
        .split(':')[0]
        .replace(/\D/g, '')
}

function getOwnerNumber() {
    if (global.nomorown) return global.nomorown

    if (Array.isArray(global.owner)) {
        let owner = global.owner[0]
        if (Array.isArray(owner)) owner = owner[0]
        return owner
    }

    return global.owner || ''
}

function waUrl(number, text = '') {
    number = cleanNumber(number)
    let url = `https://wa.me/${number}`

    if (text) {
        url += `?text=${encodeURIComponent(text)}`
    }

    return url
}

let handler = async (m, { conn }) => {
    const wm = global.namebot || 'Renvy'
    const owner = global.ownername || global.nameown || 'panpan'

    const ownerThumb = 'https://raw.githubusercontent.com/Panzqq/panzz/main/uploads/2026-06-01/RenV-71705.jpeg'
    const botThumb = global.thumb2 || global.thumb || ownerThumb

    const ownerNumber = cleanNumber(getOwnerNumber())
    const botNumber = cleanNumber(conn.user?.id || conn.user?.jid || '')

    if (!ownerNumber) {
        return m.reply('> [!] Nomor owner belum diset di global.nomorown / global.owner')
    }

    if (!botNumber) {
        return m.reply('> [!] Nomor bot tidak terbaca')
    }

    const ownerLink = waUrl(ownerNumber, 'halo')
    const botLink = waUrl(botNumber, 'halo')

    const rich = new AIRich(conn)
        .setTitle(`${wm} Contact`)
        .setSubtitle('Owner & Bot WhatsApp')
        .setFooter(
            `[ ${wm} ] - Contact Center\n` +
            `> [+] Tap card untuk membuka chat\n` +
            `> [+] Owner dan bot resmi ${wm}\n` +
            `> [+] Pesan otomatis: halo`
        )

        .addProduct([
            {
                title: 'Chat Owner',
                brand: owner,
                price: 'Available',
                sale_price: 'Available',
                product_url: ownerLink,
                image_url: ownerThumb,
                icon_url: ownerThumb
            },
            {
                title: 'Chat Bot',
                brand: wm,
                price: 'Online',
                sale_price: 'Online',
                product_url: botLink,
                image_url: botThumb,
                icon_url: botThumb
            }
        ])

    await rich.send(m.chat, {
        quoted: ftroli,
        botJid: conn.user?.id
    })
}

handler.command = handler.help = ['owner', 'creator']
handler.tags = ['info']
handler.limit = true

module.exports = handler