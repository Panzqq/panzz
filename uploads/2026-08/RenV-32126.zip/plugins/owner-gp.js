const fs = require('fs')
const path = require('path')
const { AIRich } = require('../lib/nixcode.js')

const similarity = (s1, s2) => {
  s1 = String(s1 || '').toLowerCase()
  s2 = String(s2 || '').toLowerCase()

  const longer = s1.length > s2.length ? s1 : s2
  const shorter = s1.length > s2.length ? s2 : s1
  const longerLength = longer.length

  if (longerLength === 0) return 1.0

  const match = longerLength - editDistance(longer, shorter)
  return match / parseFloat(longerLength)
}

const editDistance = (s1, s2) => {
  const costs = []

  for (let i = 0; i <= s1.length; i++) {
    let lastValue = i

    for (let j = 0; j <= s2.length; j++) {
      if (i === 0) {
        costs[j] = j
      } else if (j > 0) {
        let newValue = costs[j - 1]

        if (s1.charAt(i - 1) !== s2.charAt(j - 1)) {
          newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1
        }

        costs[j - 1] = lastValue
        lastValue = newValue
      }
    }

    if (i > 0) costs[s2.length] = lastValue
  }

  return costs[s2.length]
}

function pickRegex(code, regex, fallback = '-') {
  const match = String(code || '').match(regex)
  return match ? match[1].trim() : fallback
}

function cleanInfo(text = '-') {
  return String(text || '-')
    .replace(/\n/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function getCommandInfo(code) {
  const command =
    pickRegex(
      code,
      /handler\.command\s*=\s*([^;\n]+)/i,
      pickRegex(code, /handler\.help\s*=\s*handler\.command\s*=\s*([^;\n]+)/i, '-')
    )

  return cleanInfo(command)
}

function getHelpInfo(code) {
  let help = pickRegex(code, /handler\.help\s*=\s*(?!handler\.command)([^;\n]+)/i, null)

  if (!help) {
    help = pickRegex(code, /handler\.help\s*=\s*handler\.command\s*=\s*([^;\n]+)/i, '-')
  }

  return cleanInfo(help)
}

function getTagsInfo(code) {
  return cleanInfo(pickRegex(code, /handler\.tags\s*=\s*([^;\n]+)/i, '-'))
}

function formatBytes(bytes = 0) {
  bytes = Number(bytes) || 0

  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`

  return `${(bytes / 1024 / 1024).toFixed(2)} MB`
}

function analyzePlugin(code, filename) {
  const lineCount = String(code || '').split('\n').length
  const size = Buffer.byteLength(code, 'utf8')

  return [
    ['Patch File', filename],
    ['CMD', getCommandInfo(code)],
    ['Help', getHelpInfo(code)],
    ['Tags', getTagsInfo(code)],
    ['Jumlah Baris', `${lineCount} baris`],
    ['Ukuran File', formatBytes(size)]
  ]
}

let handler = async (m, { conn, isROwner, usedPrefix, command, text }) => {
  if (!isROwner) return

  if (!text) {
    return m.reply(`Masukkan nama plugin.\nContoh: ${usedPrefix}${command} bot`)
  }

  const pluginDir = path.join(__dirname, '../plugins')

  if (!fs.existsSync(pluginDir)) {
    return m.reply('Folder plugins tidak ditemukan.')
  }

  const pluginFiles = fs.readdirSync(pluginDir).filter(file => file.endsWith('.js'))
  const pluginNames = pluginFiles.map(file => file.replace(/\.js$/i, ''))

  const input = text.trim().toLowerCase()
  const exactIndex = pluginNames.findIndex(name => name.toLowerCase() === input)

  if (exactIndex !== -1) {
    const filename = pluginFiles[exactIndex]
    const pluginPath = path.join(pluginDir, filename)

    let code

    try {
      code = fs.readFileSync(pluginPath, 'utf8')
    } catch (err) {
      return m.reply(`Gagal membaca file: ${err.message}`)
    }

    const buffer = Buffer.from(code, 'utf8')
    const infoTable = analyzePlugin(code, filename)
    const lineCount = String(code || '').split('\n').length
    const size = Buffer.byteLength(code, 'utf8')

    await conn.sendMessage(
      m.chat,
      {
        document: buffer,
        mimetype: 'application/javascript',
        fileName: filename,
        caption: `📄 Plugin: ${filename}\n✅ Full kode juga dikirim dalam AIRich.`
      },
      { quoted: ftroli }
    )

    await new AIRich(conn)
      .setTitle(`📦 Plugin Viewer`)
      .setFooter(`📄 ${filename} · ${lineCount} baris · ${formatBytes(size)}`)
      .addTip(`Plugin: ${filename}`)
      .addText(`# 📦 Plugin Viewer\n\n📄 **File:** \`${filename}\``)
      .addCode('javascript', code)
      .addTable([
        ['Bagian', 'Info'],
        ...infoTable
      ])
      .send(m.chat, { quoted: ftroli })

    return
  }

  const matches = pluginNames
    .map((name, i) => ({
      name,
      file: pluginFiles[i],
      score: similarity(input, name)
    }))
    .filter(plugin => plugin.score >= 0.3)
    .sort((a, b) => b.score - a.score)

  if (!matches.length) {
    return m.reply(`Plugin "${text}" tidak ditemukan.`)
  }

  const sections = [
    {
      title: '📦 Plugin Mirip',
      rows: matches.slice(0, 10).map(plugin => ({
        header: `🔧 ${plugin.name}`,
        title: plugin.name,
        description: `Lihat plugin "${plugin.name}"`,
        id: `.${command} ${plugin.name}`
      }))
    }
  ]

  return conn.sendButtonLoc(
    m.chat,
    [
      { id: 'menu', text: '[ Check ]', native: true },
      { id: '.owner', text: '[ Owner ]' }
    ],
    `Plugin "${text}" tidak ditemukan. Pilih salah satu plugin mirip di bawah ini:`,
    ` [ ${global.namebot || 'Bot'} Powered By ${global.nameown || 'Owner'} ] `,
    m,
    {
      mentions: [m.sender],
      nativeSelectData: {
        title: `[ ${global.namebot || 'Bot'} - Plugin Suggestion ]`,
        sections
      },
      thumbUrl: global.thumb,
      name: global.namebot || 'Renvy',
      address: 'Plugin Suggestion'
    }
  )
}

handler.help = ['getplugin'].map(v => v + ' <text>')
handler.tags = ['owner']
handler.command = /^(getplugin|gp)$/i
handler.owner = true

module.exports = handler