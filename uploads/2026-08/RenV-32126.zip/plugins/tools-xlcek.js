const https = require('https');

/*
 * Credit source:
 * XL/AXIS Checker API from https://xl-ku.my.id
 * Original scrape by DEFAN
 */

function normalizeNumber(input = '') {
  let number = String(input).replace(/\D/g, '');

  if (!number) throw new Error('Nomor tidak boleh kosong.');

  if (number.startsWith('0')) {
    number = '62' + number.slice(1);
  }

  if (!number.startsWith('62')) {
    number = '62' + number;
  }

  if (number.length < 10 || number.length > 15) {
    throw new Error('Format nomor tidak valid.');
  }

  return number;
}

function isXlAxis(number = '') {
  return /^(62817|62818|62819|62859|62877|62878|62831|62832|62833|62838)/.test(number);
}

function requestJson(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(
      url,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36',
          'Accept': 'application/json, text/plain, */*'
        },
        timeout: 30000
      },
      (res) => {
        let data = '';

        res.on('data', chunk => {
          data += chunk;
        });

        res.on('end', () => {
          try {
            if (res.statusCode < 200 || res.statusCode >= 300) {
              return reject(new Error(`HTTP ${res.statusCode}`));
            }

            resolve(JSON.parse(data));
          } catch (e) {
            reject(new Error('Gagal membaca response API.'));
          }
        });
      }
    );

    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Request timeout.'));
    });

    req.on('error', err => {
      reject(new Error(err.message));
    });
  });
}

function beautifyKey(key = '') {
  return String(key)
    .replace(/_/g, ' ')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, c => c.toUpperCase());
}

function formatValue(value) {
  if (value === null || value === undefined || value === '') return '-';
  if (typeof value === 'boolean') return value ? 'Ya' : 'Tidak';
  if (typeof value === 'object') return JSON.stringify(value, null, 2);
  return String(value);
}

function formatJson(data, level = 0) {
  if (!data || typeof data !== 'object') return formatValue(data);

  let text = '';
  const indent = '  '.repeat(level);

  if (Array.isArray(data)) {
    data.forEach((item, i) => {
      if (typeof item === 'object') {
        text += `${indent}${i + 1}.\n${formatJson(item, level + 1)}\n`;
      } else {
        text += `${indent}${i + 1}. ${formatValue(item)}\n`;
      }
    });
    return text.trim();
  }

  for (const [key, value] of Object.entries(data)) {
    if (value && typeof value === 'object') {
      text += `${indent}• ${beautifyKey(key)}:\n${formatJson(value, level + 1)}\n`;
    } else {
      text += `${indent}• ${beautifyKey(key)}: ${formatValue(value)}\n`;
    }
  }

  return text.trim();
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    const input = text || m.quoted?.text;

    if (!input) {
      return m.reply(
        `Masukkan nomor XL/AXIS.\n\n` +
        `Contoh:\n` +
        `${usedPrefix + command} 083150850721`
      );
    }

    const number = normalizeNumber(input);

    if (!isXlAxis(number)) {
      return m.reply(
        `Nomor ini sepertinya bukan XL/AXIS.\n\n` +
        `Nomor terdeteksi: ${number}`
      );
    }

    await m.reply('⏳ Sedang mengecek nomor XL/AXIS...');

    const url = `https://xl-ku.my.id/end.php?check=package&number=${number}&version=2`;
    const json = await requestJson(url);

    const resultText = formatJson(json);

    let caption =
      `乂 *XL / AXIS CHECKER*\n\n` +
      `• Nomor: ${number}\n\n` +
      `${resultText}`;

    if (caption.length > 3900) {
      caption = caption.slice(0, 3900) + '\n\n...hasil terlalu panjang, dipotong.';
    }

    await m.reply(caption);
  } catch (e) {
    await m.reply(`Gagal cek nomor.\n\nAlasan: ${e.message}`);
  }
};

handler.help = handler.command = ['xlcek', 'axiscek', 'cekxl'];
handler.tags = ['tools'];

module.exports = handler;