let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!global.db.data.settings) global.db.data.settings = {}

  const input = (args[0] || '').toLowerCase()

  if (!['on', 'off', '1', '0', 'true', 'false'].includes(input)) {
    const status = global.db.data.settings.autoread2 ? 'ON' : 'OFF'
    return m.reply(`乂 R E A D  C M D\n\n> Status: ${status}\n> Fungsi: bot akan read pesan setelah command selesai dikerjakan.\n\n[+] Contoh:\n${usedPrefix + command} on\n${usedPrefix + command} off`)
  }

  const enabled = ['on', '1', 'true'].includes(input)
  global.db.data.settings.autoread2 = enabled
  global.db.data.settings.readcmd = enabled

  return m.reply(`乂 R E A D  C M D\n\n> Status: ${enabled ? 'ON' : 'OFF'}\n> Result: ${enabled ? 'Pesan command akan di-read setelah selesai dikerjakan.' : 'Read setelah command dimatikan.'}`)
}

handler.help = handler.command = ['readcmd', 'autoreadcmd', 'autoread2']
handler.tags = ['owner']
handler.owner = true

module.exports = handler