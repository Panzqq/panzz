const RenvyAI = require('../lib/renvy-ai');
const { AIRich } = require('../lib/nixcode.js');

const sessions = global.renvyAISessions || (global.renvyAISessions = {});

const MAX_REPLY_CHARS = 3600;
const MAX_CODE_CHARS = 60000;

function cut(text = '', len = 140) {
  text = String(text || '').replace(/\s+/g, ' ').trim();
  return text.length > len ? text.slice(0, len - 3) + '...' : text;
}

function formatTime(ts = 0) {
  if (!ts) return '-';
  try {
    return new Date(ts).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  } catch {
    return String(ts);
  }
}

function formatBytes(bytes = 0) {
  bytes = Number(bytes || 0);
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  return `${(mb / 1024).toFixed(1)} GB`;
}

function sessionId(m) {
  return `${m.chat || 'chat'}:${m.sender || 'sender'}`;
}

function limitSession(id) {
  if (!sessions[id]) return;
  if (sessions[id].length > 10) sessions[id] = sessions[id].slice(-10);
}

function isReset(text = '') {
  return /^(reset|clear|hapus)$/i.test(String(text || '').trim());
}

function splitPipe(text = '') {
  const parts = String(text || '').split('|');
  return [parts.shift()?.trim() || '', parts.join('|').trim() || ''];
}

async function react(conn, m, emoji) {
  try {
    if (emoji) await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
  } catch {}
}

function chunkText(text = '', max = MAX_REPLY_CHARS) {
  text = String(text || '');
  if (text.length <= max) return [text];

  const chunks = [];
  let rest = text;
  while (rest.length > max) {
    let idx = rest.lastIndexOf('\n', max);
    if (idx < max * 0.45) idx = rest.lastIndexOf(' ', max);
    if (idx < max * 0.45) idx = max;
    chunks.push(rest.slice(0, idx).trim());
    rest = rest.slice(idx).trim();
  }
  if (rest) chunks.push(rest);
  return chunks;
}

async function replyLong(m, text = '') {
  const chunks = chunkText(text || '-');
  let res;
  for (let i = 0; i < chunks.length; i++) {
    res = await m.reply(chunks[i]);
  }
  return res;
}

function formatTable(table = []) {
  if (!Array.isArray(table) || table.length < 2) return '';
  const rows = table.slice(1).map(row => {
    const cells = Array.isArray(row) ? row : [row];
    return `- ${cells.map(x => String(x ?? '-')).join(' : ')}`;
  });
  return rows.join('\n');
}

function formatPlain(payload = {}, fallback = '') {
  const out = [];
  if (payload.title) out.push(`乂 *${payload.title}*`);
  if (payload.subtitle) out.push(`_${payload.subtitle}_`);
  if (payload.text) out.push(String(payload.text).trim());
  if (payload.table && !String(payload.text || '').includes('Module')) {
    const table = formatTable(payload.table);
    if (table) out.push(table);
  }
  if (payload.tip) out.push(`Catatan: ${payload.tip}`);
  if (Array.isArray(payload.suggest) && payload.suggest.length) {
    out.push(`Saran:\n${payload.suggest.slice(0, 4).map(x => `- ${x}`).join('\n')}`);
  }
  return out.filter(Boolean).join('\n\n').trim() || fallback || 'Renvy AI';
}

async function sendPlain(conn, m, payload, fallback) {
  return replyLong(m, formatPlain(payload, fallback));
}

function extractCodeBlocks(text = '') {
  const blocks = [];
  const re = /```([a-zA-Z0-9_+#.-]*)\s*\n([\s\S]*?)```/g;
  let match;
  while ((match = re.exec(String(text || '')))) {
    blocks.push({
      full: match[0],
      language: match[1] || 'text',
      content: match[2] || ''
    });
  }
  return blocks;
}

function guessLanguage(text = '', code = '') {
  const all = `${text}\n${code}`.toLowerCase();
  if (/\b(node|javascript|commonjs|baileys|handler|module\.exports|require\(|const\s|let\s|async\s+function)\b/.test(all)) return 'javascript';
  if (/\bpython\b|def\s+\w+\(|import\s+\w+/.test(all)) return 'python';
  if (/\bhtml\b|<html|<div|<script/i.test(all)) return 'html';
  if (/\bcss\b|\.[\w-]+\s*\{/.test(all)) return 'css';
  if (/\bjson\b|^\s*[\[{]/.test(code)) return 'json';
  return 'text';
}

function wantsCode(text = '') {
  const s = String(text || '').toLowerCase();
  return /(buat|bikin|tulis|generate|kirim|kasih|perbaiki|fix|ubah|update|edit|ambil|baca|lihat|open|read|tampilkan).*?(kode|code|script|plugin|source|handler|javascript|js|file)/i.test(s)
    || /\b(kode|code|script|source)\b/i.test(s)
    || /```/.test(s);
}

function removeFirstCodeBlock(text = '', block) {
  if (!block?.full) return String(text || '').trim();
  return String(text || '').replace(block.full, '').trim();
}

async function sendCodeRich(conn, m, payload = {}, fallback = '') {
  const text = String(payload.text || fallback || '').trim();
  const blocks = payload.code
    ? [{ language: payload.code.language || 'text', content: payload.code.content || '' }]
    : extractCodeBlocks(text);

  const first = blocks[0];
  const intro = payload.intro || (first ? removeFirstCodeBlock(text, first) : '');
  const codeContent = String(first?.content || text || '').slice(0, MAX_CODE_CHARS);
  const language = first?.language || guessLanguage(payload.question || '', codeContent);
  const botJid = conn.user?.id || '0@bot';

  if (AIRich && codeContent) {
    try {
      const rich = new AIRich(conn)
        .setTitle(payload.title || 'Renvy Code')
        .setFooter(payload.footer || `[ ${global.namebot || 'Renvy'} ] - Renvy AI`);

      if (intro) rich.addText(intro.slice(0, 1800));
      rich.addCode(language, codeContent);
      if (payload.tip && typeof rich.addTip === 'function') rich.addTip(payload.tip);
      return await rich.send(m.chat, { quoted: m, botJid });
    } catch {}
  }

  const fallbackText = intro
    ? `${intro}\n\n\`\`\`${language}\n${codeContent}\n\`\`\``
    : `\`\`\`${language}\n${codeContent}\n\`\`\``;
  return replyLong(m, fallbackText);
}

async function sendSmart(conn, m, payload = {}, fallback = '', opts = {}) {
  if (opts.forceCode || payload.code || wantsCode(payload.question || payload.text || fallback)) {
    return sendCodeRich(conn, m, payload, fallback);
  }
  return sendPlain(conn, m, payload, fallback);
}

function helpText(prefix, cmd) {
  return [
    '*Renvy AI*',
    '',
    'Renvy adalah AI utama bot yang menggabungkan chat, memory grup, runtime auto-tuner, knowledge base, flow builder, dan akses baca source plugin.',
    '',
    '*Command utama*',
    `- ${prefix + cmd} <pertanyaan>`,
    `- ${prefix + cmd} reset`,
    `- ${prefix + cmd} status`,
    `- ${prefix + cmd} memory`,
    `- ${prefix + cmd} know <pertanyaan source bot>`,
    `- ${prefix + cmd} tune`,
    `- ${prefix + cmd} flow create nama | deskripsi`,
    `- ${prefix}flow <nama>`,
    '',
    '*Akses plugin*',
    `- ${prefix + cmd} plugin list`,
    `- ${prefix + cmd} plugin info menu`,
    `- ${prefix + cmd} plugin read menu`,
    `- ${prefix + cmd} plugin search downloader`,
    `- ${prefix + cmd} deps plugin menu`,
    `- ${prefix + cmd} debug plugin menu`,
    `- ${prefix + cmd} review plugin menu`,
    '',
    'Catatan: read source plugin, tune/apply, dan flow create/delete khusus owner.'
  ].join('\n');
}

function detectPluginReadRequest(text = '') {
  const s = String(text || '').trim();
  const patterns = [
    /(?:ambil|baca|lihat|open|read|tampilkan|kirim|kasih)\s+(?:isi\s+)?(?:file\s+)?plugin\s+([\w.-]+)/i,
    /(?:source|kode|script|isi)\s+(?:file\s+)?plugin\s+([\w.-]+)/i,
    /plugin\s+([\w.-]+)\s+(?:source|kode|script|isinya|isi|file)/i,
    /(?:buka|read)\s+([\w.-]+\.js)/i
  ];
  for (const re of patterns) {
    const m = s.match(re);
    if (m?.[1]) return m[1].replace(/^\.+/, '').trim();
  }
  return '';
}


function detectPluginToolRequest(text = '') {
  const s = String(text || '').trim();
  const patterns = [
    ['deps', /(?:dependency|dependencies|dep|deps|map|peta).*?(?:plugin|source|kode)\s+([\w.-]+)/i],
    ['debug', /(?:debug|cek\s+error|check\s+error|periksa).*?(?:plugin|source|kode)\s+([\w.-]+)/i],
    ['review', /(?:review|code\s+review|cek\s+kualitas|analisa|analisis).*?(?:plugin|source|kode)\s+([\w.-]+)/i],
    ['deps', /(?:plugin|source|kode)\s+([\w.-]+).*?(?:dependency|dependencies|dep|deps|map|peta)/i],
    ['debug', /(?:plugin|source|kode)\s+([\w.-]+).*?(?:debug|cek\s+error|check\s+error|periksa)/i],
    ['review', /(?:plugin|source|kode)\s+([\w.-]+).*?(?:review|code\s+review|cek\s+kualitas|analisa|analisis)/i]
  ];

  for (const [mode, re] of patterns) {
    const m = s.match(re);
    if (m?.[1]) return { mode, target: m[1].replace(/^\.+/, '').trim() };
  }
  return null;
}

async function handleStatus(m, { conn, usedPrefix, command }) {
  const status = RenvyAI.status(m);
  const mem = status.memory;
  const text = [
    '*Renvy AI Status*',
    '',
    `Status: ${status.enabled ? 'ON' : 'OFF'}`,
    `Memory scope: ${mem?.type || '-'}`,
    `Memory interactions: ${mem?.interactions || 0}`,
    `Knowledge entries: ${status.knowledge.entries}`,
    `Knowledge indexed: ${formatTime(status.knowledge.indexedAt)}`,
    `Saved flows: ${status.flows}`,
    `Tuning suggestions: ${status.tuning.last}`,
    `Tuning applied: ${status.tuning.applied}`,
    '',
    RenvyAI.memory.formatMemory(mem)
  ].join('\n');

  return sendPlain(conn, m, {
    title: 'Renvy AI',
    subtitle: 'Core status',
    text,
    suggest: [
      `${usedPrefix + command} memory`,
      `${usedPrefix + command} know fitur airich`,
      `${usedPrefix + command} plugin list`,
      `${usedPrefix + command} tune`
    ]
  }, text);
}

async function handleMemory(m, { conn, args, isOwner, isAdmin, usedPrefix, command }) {
  const sub = String(args[1] || 'status').toLowerCase();

  if (['reset', 'clear', 'hapus'].includes(sub)) {
    if (m.isGroup && !isAdmin && !isOwner) return m.reply('Memory grup hanya bisa direset oleh admin/owner.');
    RenvyAI.memory.reset(m);
    return m.reply('Memory Renvy untuk chat ini sudah direset.');
  }

  if (['remember', 'ingat', 'note'].includes(sub)) {
    const note = args.slice(2).join(' ').trim();
    if (!note) return m.reply(`Contoh: ${usedPrefix + command} memory remember grup ini suka coding dan downloader`);
    if (m.isGroup && !isAdmin && !isOwner) return m.reply('Catatan memory grup hanya bisa ditambah oleh admin/owner.');
    const mem = RenvyAI.memory.rememberManual(m, note);
    return m.reply(`Catatan memory disimpan.\n\n${RenvyAI.memory.formatMemory(mem)}`);
  }

  if (['update', 'summarize', 'ringkas'].includes(sub)) {
    const mem = RenvyAI.memory.getMemory(m);
    if (!mem.recent || !mem.recent.length) return m.reply('Belum ada interaksi terbaru untuk diringkas.');
    await react(conn, m, '🧠');
    const updated = await RenvyAI.memory.summarizeMemory(mem);
    await react(conn, m, '✅');
    return m.reply(`Memory diperbarui.\n\n${RenvyAI.memory.formatMemory(updated)}`);
  }

  const mem = RenvyAI.memory.getMemory(m);
  const text = [
    '*Renvy Memory*',
    '',
    RenvyAI.memory.formatMemory(mem),
    '',
    'Command:',
    `${usedPrefix + command} memory remember <catatan>`,
    `${usedPrefix + command} memory update`,
    `${usedPrefix + command} memory reset`
  ].join('\n');

  return sendPlain(conn, m, {
    title: 'Renvy Memory',
    text,
    suggest: [
      `${usedPrefix + command} memory update`,
      `${usedPrefix + command} memory remember grup ini suka coding`,
      `${usedPrefix + command} memory reset`
    ]
  }, text);
}

async function handleKnowledge(m, { conn, args, text, usedPrefix, command }) {
  const sub = String(args[1] || '').toLowerCase();

  if (sub === 'scan' || sub === 'index') {
    const entries = RenvyAI.knowledge.buildIndex(true);
    return m.reply(`Knowledge Base berhasil diindex ulang.\nEntries: ${entries.length}`);
  }

  const question = args.slice(1).join(' ').trim() || String(text || '').replace(/^know\s*/i, '').trim();
  if (!question) return m.reply(`Contoh: ${usedPrefix + command} know cara kerja Renvy Guard`);

  await react(conn, m, '📚');
  try {
    const result = await RenvyAI.knowledge.answer(question);
    const answer = [
      '*Renvy Knowledge Base*',
      '',
      `> ${question}`,
      '',
      result.answer,
      '',
      result.hits.length ? '*Source yang dipakai*' : '',
      ...result.hits.map((x, i) => `${i + 1}. ${x.file}${(x.commands || []).length ? ` | command: ${(x.commands || []).join(', ')}` : ''}`)
    ].filter(Boolean).join('\n');

    await sendPlain(conn, m, {
      title: 'Renvy Knowledge Base',
      text: answer,
      suggest: [
        `${usedPrefix + command} know fitur airich`,
        `${usedPrefix + command} plugin info menu`,
        `${usedPrefix + command} plugin read menu`
      ]
    }, answer);
    await react(conn, m, '✅');
  } catch (e) {
    await react(conn, m, '❌');
    return m.reply(`Renvy Knowledge Base error: ${e.message || e}`);
  }
}


function pluginTargetFromArgs(args = [], start = 1) {
  const list = Array.isArray(args) ? args.slice(start) : [];
  if (['plugin', 'plugins', 'source', 'kode', 'file'].includes(String(list[0] || '').toLowerCase())) list.shift();
  return list.join(' ').trim();
}

async function handlePluginInspect(m, { conn, args, isOwner, usedPrefix, command, mode = 'deps', forcedTarget = '' }) {
  if (!isOwner) return m.reply('Fitur inspeksi plugin hanya untuk owner. Ini untuk mencegah struktur/source bot bocor ke user/grup.');

  const target = forcedTarget || pluginTargetFromArgs(args, 1);
  const label = mode === 'review' ? 'review plugin' : mode === 'debug' ? 'debug plugin' : 'deps plugin';
  if (!target) return m.reply(`Contoh: ${usedPrefix + command} ${label} menu`);

  if (mode === 'review') {
    await react(conn, m, '🧪');
    const result = await RenvyAI.inspector.reviewPlugin(target, { useAI: true });
    await react(conn, m, result.ok ? '✅' : '❌');
    return sendPlain(conn, m, { title: 'Renvy Code Review', text: RenvyAI.inspector.formatReview(result) }, RenvyAI.inspector.formatReview(result));
  }

  const report = mode === 'debug'
    ? RenvyAI.inspector.debugPlugin(target)
    : RenvyAI.inspector.dependencyMap(target);

  const output = mode === 'debug'
    ? RenvyAI.inspector.formatDebugReport(report)
    : RenvyAI.inspector.formatDependencyMap(report);

  return sendPlain(conn, m, { title: mode === 'debug' ? 'Renvy Debug Mode' : 'Renvy Dependency Map', text: output }, output);
}

async function handlePluginAccess(m, { conn, args, text, isOwner, usedPrefix, command, forcedTarget = '' }) {
  const sub = forcedTarget ? 'read' : String(args[1] || 'help').toLowerCase();
  const query = forcedTarget || args.slice(2).join(' ').trim();

  if (['help', 'menu', 'bantuan'].includes(sub)) {
    return m.reply([
      '*Renvy Plugin Access*',
      '',
      `${usedPrefix + command} plugin list`,
      `${usedPrefix + command} plugin search <query>`,
      `${usedPrefix + command} plugin info <nama/command>`,
      `${usedPrefix + command} plugin read <nama/command>`,
      `${usedPrefix + command} plugin deps <nama/command>`,
      `${usedPrefix + command} plugin debug <nama/command>`,
      `${usedPrefix + command} plugin review <nama/command>`,
      '',
      'Contoh:',
      `${usedPrefix + command} plugin read menu`,
      `${usedPrefix + command} ambil isi plugin menu`
    ].join('\n'));
  }

  if (['list', 'ls', 'daftar'].includes(sub)) {
    const plugins = RenvyAI.knowledge.listPlugins();
    const grouped = {};
    for (const p of plugins) {
      const tag = p.tags?.[0] || 'other';
      grouped[tag] = grouped[tag] || [];
      grouped[tag].push(p);
    }

    const lines = ['*Daftar Plugin Renvy*', '', `Total: ${plugins.length} plugin`, ''];
    for (const tag of Object.keys(grouped).sort()) {
      lines.push(`*${tag}*`);
      lines.push(grouped[tag].slice(0, 20).map(p => `- ${p.name}${p.commands.length ? ` (${p.commands.join(', ')})` : ''}`).join('\n'));
      if (grouped[tag].length > 20) lines.push(`- ...${grouped[tag].length - 20} plugin lain`);
      lines.push('');
    }
    return replyLong(m, lines.join('\n').trim());
  }

  if (['search', 'cari', 'find'].includes(sub)) {
    if (!query) return m.reply(`Contoh: ${usedPrefix + command} plugin search downloader`);
    const hits = RenvyAI.knowledge.search(query, 15).filter(x => x.type === 'plugin');
    if (!hits.length) return m.reply(`Plugin dengan query "${query}" tidak ditemukan.`);
    return m.reply([
      `*Hasil pencarian plugin: ${query}*`,
      '',
      ...hits.map((x, i) => `${i + 1}. ${x.file}\n   Command: ${(x.commands || []).join(', ') || '-'}\n   Tags: ${(x.tags || []).join(', ') || '-'}`)
    ].join('\n'));
  }

  if (['info', 'detail', 'show'].includes(sub)) {
    if (!query) return m.reply(`Contoh: ${usedPrefix + command} plugin info menu`);
    const result = RenvyAI.knowledge.readPlugin(query, { includeContent: false });
    if (!result.ok) return m.reply(result.reason);
    const p = result.plugin;
    return m.reply([
      '*Plugin Info*',
      '',
      `File: ${p.file}`,
      `Name: ${p.name}`,
      `Size: ${formatBytes(p.size)}`,
      `Command: ${(p.commands || []).join(', ') || '-'}`,
      `Tags: ${(p.tags || []).join(', ') || '-'}`,
      '',
      `Baca source: ${usedPrefix + command} plugin read ${p.name}`
    ].join('\n'));
  }

  if (['deps', 'dep', 'dependency', 'dependencies', 'map', 'peta'].includes(sub)) {
    return handlePluginInspect(m, { conn, args: [args[0], ...args.slice(2)], isOwner, usedPrefix, command, mode: 'deps' });
  }

  if (['debug', 'cek', 'check', 'periksa'].includes(sub)) {
    return handlePluginInspect(m, { conn, args: [args[0], ...args.slice(2)], isOwner, usedPrefix, command, mode: 'debug' });
  }

  if (['review', 'code-review', 'codereview', 'analisa', 'analisis'].includes(sub)) {
    return handlePluginInspect(m, { conn, args: [args[0], ...args.slice(2)], isOwner, usedPrefix, command, mode: 'review' });
  }

  if (['read', 'baca', 'open', 'source', 'src', 'kode', 'isi', 'raw'].includes(sub)) {
    if (!isOwner) return m.reply('Akses baca source plugin hanya untuk owner. Ini untuk mencegah source bot bocor ke user/grup.');
    if (!query) return m.reply(`Contoh: ${usedPrefix + command} plugin read menu`);

    const result = RenvyAI.knowledge.readPlugin(query, { includeContent: true });
    if (!result.ok) return m.reply(result.reason);

    const p = result.plugin;
    const intro = [
      `*Source Plugin*`,
      '',
      `File: ${p.file}`,
      `Size: ${formatBytes(p.size)}`,
      `Command: ${(p.commands || []).join(', ') || '-'}`,
      `Tags: ${(p.tags || []).join(', ') || '-'}`
    ].join('\n');

    return sendCodeRich(conn, m, {
      title: `Plugin: ${p.name}`,
      intro,
      code: {
        language: 'javascript',
        content: p.content
      },
      tip: p.truncated ? 'File terlalu besar, source dipotong.' : ''
    }, p.content);
  }

  return handlePluginAccess(m, { conn, args, text, isOwner, usedPrefix, command, forcedTarget: '' });
}

async function handleTune(m, { conn, args, isOwner, usedPrefix, command }) {
  if (!isOwner) return m.reply('Runtime Auto-Tuner hanya untuk owner.');

  const action = String(args[1] || 'analyze').toLowerCase();
  if (action === 'apply') {
    const id = args[2];
    if (!id) return m.reply(`Contoh: ${usedPrefix + command} tune apply queue-safe-mode`);
    const result = RenvyAI.autotune.apply(id, m.sender);
    if (!result.ok) return m.reply(`Gagal apply: ${result.reason}`);
    const changes = result.applied.changes.map(x => `- ${x.path}: ${x.from} → ${x.to}`).join('\n');
    return m.reply(`Auto-Tuner applied.\n\n${result.applied.title}\n${changes}\n\nCatatan: ini runtime override. Untuk permanen, pindahkan ke config.js.`);
  }

  await react(conn, m, '🛠️');
  const result = await RenvyAI.autotune.analyze();
  await react(conn, m, '✅');

  const textOut = [
    '*Renvy Runtime Auto-Tuner*',
    '',
    result.ai,
    '',
    result.suggestions.length ? '*Rekomendasi yang bisa di-apply*' : 'Tidak ada rekomendasi kuat untuk saat ini.',
    ...result.suggestions.map((s, i) => [
      `${i + 1}. ${s.title}`,
      `ID: ${s.id}`,
      `Risk: ${s.risk}`,
      `Reason: ${s.reason}`,
      `Impact: ${s.impact}`,
      `Apply: ${usedPrefix + command} tune apply ${s.id}`
    ].join('\n'))
  ].join('\n\n');

  return sendPlain(conn, m, {
    title: 'Renvy Auto-Tuner',
    text: textOut,
    suggest: result.suggestions.slice(0, 3).map(s => `${usedPrefix + command} tune apply ${s.id}`).concat([`${usedPrefix + command} status`]).slice(0, 4)
  }, textOut);
}

async function handleFlow(m, { conn, args, text, isOwner, usedPrefix, command }) {
  const sub = String(args[1] || (command === 'flow' ? 'show' : 'list')).toLowerCase();

  if (command === 'flow') {
    const name = args[0] || 'main';
    if (!args.length || ['list', 'ls'].includes(String(args[0]).toLowerCase())) {
      const flows = RenvyAI.flow.list();
      if (!flows.length) return m.reply(`Belum ada flow. Buat dengan: ${usedPrefix}renvy flow create main | menu utama bot`);
      return m.reply(flows.map((f, i) => `${i + 1}. ${f.name} — ${f.title}`).join('\n'));
    }
    const rendered = await RenvyAI.flow.render(conn, m, name, false);
    if (!rendered.ok) return m.reply(rendered.reason);
    return;
  }

  if (['create', 'buat', 'new'].includes(sub)) {
    if (!isOwner) return m.reply('Flow Builder hanya untuk owner.');
    const payload = args.slice(2).join(' ').trim();
    const [name, desc] = splitPipe(payload);
    if (!name || !desc) return m.reply(`Contoh: ${usedPrefix + command} flow create downloader | buat menu downloader tiktok, ig, youtube, spotify`);

    await react(conn, m, '🎛️');
    const flow = await RenvyAI.flow.create(name, desc, m.sender);
    await react(conn, m, '✅');

    await m.reply(`Flow berhasil dibuat: ${flow.name}\nCommand: ${usedPrefix}flow ${flow.name}`);
    return RenvyAI.flow.render(conn, m, flow.name, false);
  }

  if (['delete', 'del', 'hapus'].includes(sub)) {
    if (!isOwner) return m.reply('Hapus flow hanya untuk owner.');
    const name = args[2];
    if (!name) return m.reply(`Contoh: ${usedPrefix + command} flow delete downloader`);
    const ok = RenvyAI.flow.remove(name);
    return m.reply(ok ? `Flow ${name} dihapus.` : `Flow ${name} tidak ditemukan.`);
  }

  if (['list', 'ls'].includes(sub)) {
    const flows = RenvyAI.flow.list();
    if (!flows.length) return m.reply(`Belum ada flow. Buat dengan: ${usedPrefix + command} flow create main | menu utama bot`);
    const textOut = [
      '*Renvy Flow List*',
      '',
      ...flows.map((f, i) => `${i + 1}. ${f.name}\n   Title: ${f.title}\n   Show: ${usedPrefix}flow ${f.name}`)
    ].join('\n');
    return sendPlain(conn, m, {
      title: 'Renvy Flow Builder',
      text: textOut,
      suggest: flows.slice(0, 4).map(f => `${usedPrefix}flow ${f.name}`)
    }, textOut);
  }

  if (['show', 'open', 'view'].includes(sub)) {
    const name = args[2] || 'main';
    const rendered = await RenvyAI.flow.render(conn, m, name, false);
    if (!rendered.ok) return m.reply(rendered.reason);
    return;
  }

  return m.reply(`Command flow:\n${usedPrefix + command} flow create nama | deskripsi\n${usedPrefix + command} flow list\n${usedPrefix + command} flow show nama\n${usedPrefix}flow nama`);
}

async function handleChat(m, { conn, text, usedPrefix, command, isOwner }) {
  const prefix = usedPrefix || '.';
  const cmd = command || 'renvy';
  const wm = global.namebot || 'Renvy';
  const id = sessionId(m);

  if (isReset(text)) {
    delete sessions[id];
    return sendPlain(conn, m, {
      title: 'Renvy AI',
      text: 'Sesi chat berhasil direset.',
      tip: 'Memory grup tidak dihapus. Gunakan memory reset untuk menghapus memory chat.',
      suggest: [`${prefix + cmd} halo`, `${prefix + cmd} status`, `${prefix + cmd} memory`]
    }, 'Sesi chat Renvy berhasil direset.');
  }

  const forcedTool = detectPluginToolRequest(text);
  if (forcedTool) {
    return handlePluginInspect(m, { conn, args: [], isOwner, usedPrefix: prefix, command: cmd, mode: forcedTool.mode, forcedTarget: forcedTool.target });
  }

  const forcedTarget = detectPluginReadRequest(text);
  if (forcedTarget) {
    return handlePluginAccess(m, { conn, args: [], text, isOwner, usedPrefix: prefix, command: cmd, forcedTarget });
  }

  const mem = RenvyAI.memory.getMemory(m);
  if (!sessions[id]) sessions[id] = [];

  const rawUserText = String(text || '').trim();
  sessions[id].push({ role: 'user', content: rawUserText });
  limitSession(id);

  await react(conn, m, '⏱️');

  try {
    const messages = sessions[id].slice();
    const pluginContext = isOwner ? RenvyAI.knowledge.pluginContextForQuestion(rawUserText, {
      maxFiles: 3,
      maxChars: Number(global.renvyAI?.pluginContextChars || 12000)
    }) : '';

    if (pluginContext && messages.length) {
      messages[messages.length - 1] = {
        role: 'user',
        content: [
          rawUserText,
          '',
          '[Konteks source plugin Renvy yang boleh dipakai untuk menjawab]',
          pluginContext
        ].join('\n')
      };
    }

    const result = await RenvyAI.provider.ask(messages, {
      prompt: RenvyAI.buildSystemPrompt(mem),
      temperature: Number(global.renvyAI?.temperature ?? 0.5),
      timeoutMs: Number(global.renvyAI?.timeoutMs || 60000),
      enableConversationPrompt: true
    });

    sessions[id].push({ role: 'assistant', content: result });
    limitSession(id);

    const suggestRaw = await RenvyAI.provider.requestSuggest(rawUserText, result).catch(() => '');
    const suggest = RenvyAI.provider.parseSuggest(suggestRaw, prefix, cmd);
    const sessionLen = Math.floor((sessions[id]?.length || 0) / 2);

    await sendSmart(conn, m, {
      title: 'Renvy AI',
      footer: `[ ${wm} ] - Renvy AI`,
      question: rawUserText,
      text: result,
      tip: `Sesi ke-${sessionLen} | memory ${mem.type} aktif | ketik "${prefix + cmd} reset" untuk reset sesi`,
      suggest
    }, result, { forceCode: wantsCode(rawUserText) || extractCodeBlocks(result).length > 0 });

    RenvyAI.memory.updateAfterChat(m, rawUserText, result);
    await react(conn, m, '✅');
  } catch (err) {
    await react(conn, m, '❌');
    return sendPlain(conn, m, {
      title: 'Renvy AI',
      text: `Terjadi kesalahan.\n\nError: ${err.message || err}`,
      suggest: [`${prefix + cmd} ${rawUserText}`, `${prefix + cmd} reset`, `${prefix + cmd} status`]
    }, `Renvy AI error: ${err.message || err}`);
  }
}

let handler = async (m, ctx) => {
  const { conn, text, args = [], usedPrefix = '.', command = 'renvy', isOwner, isAdmin } = ctx;
  const cmd = String(command || '').toLowerCase();

  if (global.renvyAI?.enabled === false) return m.reply('Renvy AI sedang dinonaktifkan.');

  if (cmd === 'flow') return handleFlow(m, { conn, args, text, isOwner, usedPrefix, command: cmd });

  const raw = String(text || '').trim();
  const sub = String(args[0] || '').toLowerCase();

  if (!raw || ['help', 'menu', 'bantuan'].includes(sub)) {
    return sendPlain(conn, m, {
      title: 'Renvy AI',
      text: helpText(usedPrefix, cmd),
      suggest: [`${usedPrefix + cmd} status`, `${usedPrefix + cmd} memory`, `${usedPrefix + cmd} plugin list`, `${usedPrefix + cmd} tune`]
    }, helpText(usedPrefix, cmd));
  }

  RenvyAI.memory.trackCommand(m, sub || cmd);

  if (['status', 'dashboard', 'core'].includes(sub)) return handleStatus(m, { conn, usedPrefix, command: cmd });
  if (['memory', 'memori', 'ingat'].includes(sub)) return handleMemory(m, { conn, args, isOwner, isAdmin, usedPrefix, command: cmd });
  if (['know', 'kb', 'knowledge'].includes(sub)) return handleKnowledge(m, { conn, args, text: raw, usedPrefix, command: cmd });
  if (['plugin', 'plugins', 'source', 'src'].includes(sub)) return handlePluginAccess(m, { conn, args, text: raw, isOwner, usedPrefix, command: cmd });
  if (['deps', 'dep', 'dependency', 'dependencies', 'map', 'peta'].includes(sub)) return handlePluginInspect(m, { conn, args, isOwner, usedPrefix, command: cmd, mode: 'deps' });
  if (['debug', 'cekdebug'].includes(sub)) return handlePluginInspect(m, { conn, args, isOwner, usedPrefix, command: cmd, mode: 'debug' });
  if (['review', 'codereview', 'code-review'].includes(sub)) return handlePluginInspect(m, { conn, args, isOwner, usedPrefix, command: cmd, mode: 'review' });
  if (['tune', 'autotune', 'tuner'].includes(sub)) return handleTune(m, { conn, args, isOwner, usedPrefix, command: cmd });
  if (['flow', 'alur'].includes(sub)) return handleFlow(m, { conn, args, text: raw, isOwner, usedPrefix, command: cmd });

  return handleChat(m, { conn, text: raw, usedPrefix, command: cmd, isOwner });
};

handler.help = handler.command = ['renvy', 'ai'];
handler.tags = ['ai'];
handler.limit = true;
handler.register = true;
handler.heavy = true;
handler.queue = true;
handler.noCache = true;
handler.intelligenceCache = false;

module.exports = handler;