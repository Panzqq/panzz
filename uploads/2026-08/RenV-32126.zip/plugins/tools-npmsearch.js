const fs = require('fs/promises');
const path = require('path');
const os = require('os');

let fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// Jangan hapus '.tmp' karena dipakai Baileys saat upload media.
const CACHE_FOLDER_NAMES = ['.cache', '.npm'];

function uniq(array) {
  return [...new Set(array.filter(Boolean))];
}

async function removeCacheFolder(folderPath) {
  const target = path.resolve(folderPath);

  if (!CACHE_FOLDER_NAMES.includes(path.basename(target))) {
    return { target, deleted: false, reason: 'Folder tidak termasuk target cache.' };
  }

  const stat = await fs.stat(target).catch(() => null);
  if (!stat) return { target, deleted: false, reason: 'Tidak ada.' };
  if (!stat.isDirectory()) return { target, deleted: false, reason: 'Bukan folder.' };

  await fs.rm(target, {
    recursive: true,
    force: true,
    maxRetries: 3,
    retryDelay: 300
  });

  return { target, deleted: true };
}

async function cleanModuleCacheFolders() {
  const baseDirs = uniq([
    process.cwd(),
    os.homedir(),
    process.env.HOME,
    process.env.PWD
  ]);

  const targets = uniq(
    baseDirs.flatMap(base => CACHE_FOLDER_NAMES.map(name => path.join(base, name)))
  );

  const results = await Promise.all(targets.map(removeCacheFolder));
  const deleted = results.filter(v => v.deleted).map(v => v.target);

  if (deleted.length) {
    console.log('[CLEAN MODULE CACHE] Folder terhapus:');
    for (const dir of deleted) console.log(' - ' + dir);
  }

  return results;
}

function getPerson(person) {
  if (!person) return 'N/A';
  if (typeof person === 'string') return person;
  return person.name || person.email || 'N/A';
}

function getUrl(data) {
  if (!data) return '-';
  if (typeof data === 'string') return data;
  return data.url || '-';
}

function cleanRepo(repo) {
  let url = getUrl(repo);
  if (!url || url === '-') return 'N/A';
  return url.replace(/^git\+/, '').replace(/\.git$/, '');
}

function formatBytes(bytes = 0) {
  if (!bytes) return 'Unknown';
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
}

function encodePackageName(name) {
  return encodeURIComponent(name.trim());
}

function parsePackageSpec(input) {
  let text = String(input || '').trim();

  if (!text) return { name: '', version: '' };

  if (text.startsWith('@')) {
    let lastAt = text.lastIndexOf('@');

    if (lastAt > 0 && text.slice(0, lastAt).includes('/')) {
      return {
        name: text.slice(0, lastAt),
        version: text.slice(lastAt + 1)
      };
    }

    return {
      name: text,
      version: ''
    };
  }

  let lastAt = text.lastIndexOf('@');

  if (lastAt > 0) {
    return {
      name: text.slice(0, lastAt),
      version: text.slice(lastAt + 1)
    };
  }

  return {
    name: text,
    version: ''
  };
}

async function getNpmPackage(input) {
  let { name, version } = parsePackageSpec(input);

  if (!name) throw new Error('Nama package kosong.');

  let res = await fetch(`https://registry.npmjs.org/${encodePackageName(name)}`);

  if (!res.ok) throw new Error('Package tidak ditemukan.');

  let data = await res.json();

  let selectedVersion;

  if (version) {
    if (data.versions?.[version]) {
      selectedVersion = data.versions[version];
    } else if (data['dist-tags']?.[version]) {
      selectedVersion = data.versions[data['dist-tags'][version]];
    } else {
      throw new Error(`Versi "${version}" tidak ditemukan.`);
    }
  } else {
    let latestTag = data['dist-tags']?.latest;
    selectedVersion = latestTag ? data.versions?.[latestTag] : null;
  }

  if (!selectedVersion) throw new Error('Versi package tidak ditemukan.');

  return {
    data,
    latest: selectedVersion
  };
}

async function downloadNpmPackage(input) {
  let { data, latest } = await getNpmPackage(input);

  let tarball = latest.dist?.tarball;
  if (!tarball) throw new Error('Link tarball tidak ditemukan.');

  let check = await fetch(tarball, {
    method: 'GET',
    headers: {
      'User-Agent': 'Mozilla/5.0',
      'Accept': '*/*'
    }
  });

  if (!check.ok) throw new Error('Gagal download tarball.');

  let length = Number(check.headers.get('content-length') || 0);
  let maxSize = 95 * 1024 * 1024;

  if (length && length > maxSize) {
    throw new Error(`Package terlalu besar: ${formatBytes(length)}`);
  }

  let arrayBuffer = await check.arrayBuffer();
  let buffer = Buffer.from(arrayBuffer);

  if (!buffer.length) throw new Error('File kosong.');

  if (buffer.length > maxSize) {
    throw new Error(`Package terlalu besar: ${formatBytes(buffer.length)}`);
  }

  let safeName = data.name.replace(/[\/\\]/g, '-');
  let fileName = `${safeName}-${latest.version}.tgz`;

  return {
    buffer,
    fileName,
    packageName: data.name,
    version: latest.version,
    size: formatBytes(buffer.length),
    tarball,
    description: latest.description || 'No description.'
  };
}

let handler = async (m, { text, conn, command, usedPrefix }) => {
  try {
    if (command === 'downloadnpm') {
      if (!text) {
        return m.reply(`📦 *Contoh:* ${usedPrefix + command} express`);
      }

      await m.reply(global.wait || '⏳ Sedang mengambil package NPM...');

      let result;

      try {
        result = await downloadNpmPackage(text);

        let caption =
`📦 *NPM Package Download*

📝 *Name:* ${result.packageName}
🔖 *Version:* ${result.version}
📁 *Size:* ${result.size}
📄 *Description:* ${result.description}

🔗 https://www.npmjs.com/package/${result.packageName}`;

        return await conn.sendMessage(
          m.chat,
          {
            document: result.buffer,
            mimetype: 'application/gzip',
            fileName: result.fileName,
            caption
          },
          {
            quoted: m
          }
        );
      } finally {
        await cleanModuleCacheFolders().catch(err => {
          console.error('[CLEAN MODULE CACHE] Gagal membersihkan cache:', err.message || err);
        });
      }
    }

    if (text && text.startsWith('npm-detail:')) {
      let pkgName = text.slice(11).trim();
      if (!pkgName) return m.reply('❗ Nama package tidak boleh kosong.');

      let { data, latest } = await getNpmPackage(pkgName);

      let dependencies = latest.dependencies
        ? Object.keys(latest.dependencies).slice(0, 30).join(', ')
        : 'None';

      if (latest.dependencies && Object.keys(latest.dependencies).length > 30) {
        dependencies += ', dan lainnya...';
      }

      let maintainers = data.maintainers?.length
        ? data.maintainers.map(v => v.name).join(', ')
        : 'N/A';

      let unpackedSize = latest.dist?.unpackedSize
        ? formatBytes(latest.dist.unpackedSize)
        : 'Unknown';

      let info =
`📦 *${data.name}* (v${latest.version})

📝 *Description:* ${latest.description || 'No description.'}
🧑‍💻 *Author:* ${getPerson(latest.author)}
📄 *License:* ${latest.license || 'N/A'}
🌐 *Homepage:* ${latest.homepage || '-'}
🔗 *Repository:* ${cleanRepo(latest.repository)}
🐛 *Bugs:* ${getUrl(latest.bugs)}
📦 *Dependencies:* ${dependencies}
📁 *Unpacked Size:* ${unpackedSize}
👤 *Maintainers:* ${maintainers}
🕒 *Last Modified:* ${data.time?.modified || 'Unknown'}

🔗 https://www.npmjs.com/package/${data.name}`;

      return conn.sendButtonLoc(
        m.chat,
        [
          {
            id: `${usedPrefix}downloadnpm ${data.name}`,
            text: '[ Send Package ]'
          }
        ],
        info,
        ` [ ${global.namebot || 'Bot'} Powered By ${global.nameown || 'Owner'} ] `,
        m,
        {
          mentions: [m.sender],
          thumbUrl: global.thumb || 'https://files.catbox.moe/toarxh.jpg',
          name: global.namebot || 'Renvy',
          address: 'NPM Package Detail'
        }
      );
    }

    if (!text) {
      return conn.reply(m.chat, `📦 *Contoh:* ${usedPrefix + command} express`, m);
    }

    let res = await fetch(`https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(text)}&size=10`);

    if (!res.ok) throw new Error('Gagal menghubungi NPM Registry.');

    let json = await res.json();
    let objects = json.objects || [];

    if (!objects.length) {
      return m.reply(`📦 Tidak ditemukan hasil untuk *"${text}"*.`);
    }

    let results = objects.slice(0, 10).map(({ package: pkg }, index) => {
      return `*${index + 1}. ${pkg.name}* (v${pkg.version})
${pkg.description || 'No description'}
🔗 ${pkg.links?.npm || `https://www.npmjs.com/package/${pkg.name}`}`;
    }).join('\n\n');

    const datas = {
      title: `[ ${global.namebot || 'Bot'} - NPM Result ]`,
      sections: [
        {
          title: '📦 Top Matching Packages',
          rows: objects.slice(0, 10).map(({ package: pkg }) => ({
            header: `📦 ${pkg.name}`,
            title: `${pkg.name} (v${pkg.version})`,
            description: pkg.description || 'No description available.',
            id: `${usedPrefix + command} npm-detail:${pkg.name}`
          }))
        }
      ]
    };

    return conn.sendButtonLoc(
      m.chat,
      [
        {
          id: 'gada',
          text: '[ Check ]',
          native: true
        },
        {
          id: `${usedPrefix}menu`,
          text: '[ Menu ]'
        }
      ],
      results,
      ` [ ${global.namebot || 'Bot'} Powered By ${global.nameown || 'Owner'} ] `,
      m,
      {
        mentions: [m.sender],
        nativeSelectData: datas,
        thumbUrl: global.thumb || 'https://files.catbox.moe/toarxh.jpg',
        name: global.namebot || 'Renvy',
        address: 'NPM Search Result'
      }
    );
  } catch (e) {
    return m.reply(`❌ Error: ${e.message || e}`);
  }
};

handler.help = [
  'npmsearch *<query>*',
  'npmjs *<query>*',
  'downloadnpm *<package>*'
];

handler.tags = ["tools"];

handler.command = /^(npm|npmjs|npmsearch|downloadnpm)$/i;

module.exports = handler;