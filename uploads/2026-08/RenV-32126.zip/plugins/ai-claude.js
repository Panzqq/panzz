const axios = require("axios");

const generateApiKey = () => {
    const r = Math.floor(Math.random() * 1e11);
    return `tryit-${r}-a3edf17b505349f1794bcdbc7290a045`;
};

const generateUUID = () => {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0;
        const v = c === "x" ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
};

async function askClaude(question) {
    const apiKey = generateApiKey();
    const sessionUuid = generateUUID();

    const prompt = `Gunakan bahasa Indonesia yang natural, asik, dan mudah dipahami untuk menjawab. Jika pertanyaannya santai, jawablah dengan santai juga.

Pertanyaan user:
${question}`;

    const payload = new URLSearchParams({
        chat_style: "claudeai_0",
        chatHistory: JSON.stringify([
            {
                role: "user",
                content: prompt
            }
        ]),
        model: "standard",
        session_uuid: sessionUuid,
        hacker_is_stinky: "very_stinky"
    });

    const { data } = await axios.post(
        "https://api.deepai.org/hacking_is_a_serious_crime",
        payload.toString(),
        {
            headers: {
                "api-key": apiKey,
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
                "Referer": "https://deepai.org/chat/claude-3-haiku",
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "*/*"
            }
        }
    );

    let result = "";

    if (typeof data === "string") {
        result = data;
    } else {
        result =
            data.output ||
            data.text ||
            data.response ||
            data.result ||
            JSON.stringify(data);
    }

    if (typeof result === "string") {
        result = result
            .replace(/\u001c[\s\S]*$/, "")
            .replace(/\{[\s\S]*?"character_cooldown"[\s\S]*?\}$/, "")
            .trim();
    }

    return result;
}

let handler = async (m, { text }) => {
    if (!text) return m.reply("Masukkan pertanyaan.");

    try {
        const res = await askClaude(text);
        m.reply(res || "Tidak ada respon.");
    } catch (e) {
        console.error(e);
        m.reply(e.response?.data || e.message);
    }
};

handler.help = ["claude <pertanyaan>"];
handler.tags = ["ai"];
handler.command = ["claude"];

module.exports = handler;