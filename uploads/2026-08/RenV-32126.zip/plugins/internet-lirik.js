const fetch = global.fetch || ((...args) =>
  import("node-fetch").then(({ default: fetch }) => fetch(...args))
);

function cleanText(str = "") {
  return String(str || "")
    .replace(/\d{1,2}:\d{2}(?:\.\d{1,3})?/g, "")
    .replace(/\r/g, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function formatDuration(seconds = 0) {
  seconds = Number(seconds) || 0;
  const min = Math.floor(seconds / 60);
  const sec = Math.floor(seconds % 60).toString().padStart(2, "0");
  return `${min}:${sec}`;
}

function cutText(text = "", max = 3500) {
  const result = [];
  let str = String(text || "");

  while (str.length > max) {
    let cut = str.lastIndexOf("\n", max);
    if (cut < 1) cut = max;
    result.push(str.slice(0, cut).trim());
    str = str.slice(cut).trim();
  }

  if (str) result.push(str);
  return result;
}

let handler = async (m, { conn, text, command, usedPrefix }) => {
  usedPrefix = usedPrefix || ".";

  if (!text) {
    return m.reply(
      [
        "`[ CARA PAKAI ]`",
        "",
        `> ${usedPrefix}${command} judul lagu`,
        "",
        "`[ CONTOH ]`",
        `> ${usedPrefix}${command} the fate of ophelia`
      ].join("\n")
    );
  }

  await m.reply("> [+] mencari lirik...");

  try {
    const query = encodeURIComponent(text.trim());

    const res = await fetch(`https://lrclib.net/api/search?q=${query}`, {
      headers: {
        Accept: "application/json",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36"
      }
    });

    if (!res.ok) throw new Error(`LRCLIB HTTP ${res.status}`);

    const data = await res.json();

    if (!Array.isArray(data) || data.length < 1) {
      return m.reply("> [!] lirik tidak ditemukan");
    }

    const song = data[0];

    const title = song.trackName || "-";
    const artist = song.artistName || "-";
    const album = song.albumName || "-";
    const duration = formatDuration(song.duration);
    const playCmd = `${usedPrefix}play ${title} ${artist}`;

    let lyrics = song.syncedLyrics || song.plainLyrics || "";

    if (!lyrics) {
      return m.reply("> [!] lirik tidak tersedia untuk lagu ini");
    }

    lyrics = cleanText(lyrics);

    const header = [
      "`[ FULL LIRIK ]`",
      "",
      `> [+] Judul  : ${title}`,
      `> [+] Artis  : ${artist}`,
      `> [+] Album  : ${album}`,
      `> [+] Durasi : ${duration}`,
      "",
      "`[ LIRIK ]`",
      ""
    ].join("\n");

    const footerText = [
      "",
      "`[ INFO ]`",
      "> [+] Sumber : LRCLIB",
      `> [+] Play   : ${playCmd}`
    ].join("\n");

    const caption = `${header}${lyrics}${footerText}`;

    const buttons = [
      {
        id: playCmd,
        text: "[ Play Song ]"
      }
    ];

    const footer = "`[ lrclib lyrics ]`";

    if (caption.length > 3500) {
      const chunks = cutText(lyrics, 3000);

      await conn.sendMessage(
        m.chat,
        {
          text: header,
          mentions: [m.sender]
        },
        { quoted: m }
      );

      for (let i = 0; i < chunks.length; i++) {
        await conn.sendMessage(
          m.chat,
          {
            text: [
              `\`[ LIRIK ${i + 1}/${chunks.length} ]\``,
              "",
              chunks[i]
            ].join("\n")
          },
          { quoted: m }
        );
      }

      const endText = [
        "`[ SELESAI ]`",
        "",
        `> [+] Judul  : ${title}`,
        `> [+] Artis  : ${artist}`,
        `> [+] Sumber : LRCLIB`,
        `> [+] Play   : ${playCmd}`
      ].join("\n");

      if (typeof conn.sendButtonLoc === "function") {
        return conn.sendButtonLoc(
          m.chat,
          buttons,
          endText,
          footer,
          m,
          {
            mentions: [m.sender],
            name: title,
            address: artist
          }
        );
      }

      return conn.sendMessage(
        m.chat,
        {
          text: endText,
          mentions: [m.sender]
        },
        { quoted: m }
      );
    }

    if (typeof conn.sendButtonLoc === "function") {
      return conn.sendButtonLoc(
        m.chat,
        buttons,
        caption,
        footer,
        m,
        {
          mentions: [m.sender],
          name: title,
          address: artist
        }
      );
    }

    return conn.sendMessage(
      m.chat,
      {
        text: caption,
        mentions: [m.sender]
      },
      { quoted: m }
    );
  } catch (e) {
    return m.reply(
      [
        "`[ ERROR ]`",
        "",
        `> [!] ${e.message || e}`
      ].join("\n")
    );
  }
};

handler.help = ["lirik", "lyrics"].map(v => v + " <judul lagu>");
handler.tags = ["search", "tools"];
handler.command = /^(lirik|lyrics|lyric)$/i;

module.exports = handler;