const Crypto = require('crypto');
const AdmZip = require('adm-zip');
const fs = require('fs');
const sharp = require('sharp');
const axios = require('axios');
const { proto } = require('baileys');

const UA = 'androidapp.stickerly/3.31.0 (M2006C3LG; U; Android 29; in-ID; id;)';


function waHkdf(key, length, info) {
    const salt = Buffer.alloc(32, 0);
    const prk = Crypto.createHmac('sha256', salt).update(key).digest();
    let t = Buffer.alloc(0), okm = Buffer.alloc(0);
    const infoBytes = Buffer.from(info);
    for (let i = 1; i <= Math.ceil(length / 32); i++) {
        const input = Buffer.concat([t, infoBytes, Buffer.from([i])]);
        t = Crypto.createHmac('sha256', prk).update(input).digest();
        okm = Buffer.concat([okm, t]);
    }
    return okm.slice(0, length);
}

function encryptWithLabel(buf, label) {
    const mediaKey = Crypto.randomBytes(32);
    const exp = waHkdf(mediaKey, 112, `WhatsApp ${label} Keys`);
    const [iv, cipherKey, macKey] = [exp.slice(0, 16), exp.slice(16, 48), exp.slice(48, 80)];
    const cipher = Crypto.createCipheriv('aes-256-cbc', cipherKey, iv);
    const ciphertext = Buffer.concat([cipher.update(buf), cipher.final()]);
    const mac = Crypto.createHmac('sha256', macKey).update(iv).update(ciphertext).digest().slice(0, 10);
    const encBuf = Buffer.concat([ciphertext, mac]);
    return {
        mediaKey,
        fileLength: buf.length,
        fileSha256: Crypto.createHash('sha256').update(buf).digest(),
        fileEncSha256: Crypto.createHash('sha256').update(encBuf).digest(),
        encBuf,
    };
}

async function uploadEncBuf(conn, encResult, uploadType) {
    const tmpPath = `/tmp/spack-${Crypto.randomBytes(8).toString('hex')}.enc`;
    fs.writeFileSync(tmpPath, encResult.encBuf);
    try {
        const uploaded = await conn.waUploadToServer(tmpPath, {
            mediaType: uploadType,
            fileEncSha256B64: encResult.fileEncSha256.toString('base64'),
        });
        return { ...encResult, ...uploaded };
    } finally {
        try { fs.unlinkSync(tmpPath); } catch (_) {}
    }
}

async function resizeFromUrl(url, w, h, format, opts = {}) {
    const { data } = await axios.get(url, {
        responseType: 'arraybuffer',
        headers: { 'User-Agent': UA },
    });
    return sharp(data)
        .resize(w, h, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        [format](opts)
        .toBuffer();
}

async function sendStickerPack(conn, m, { packId, packName, imageUrls, trayUrl, thumbUrl }) {
    const [trayBuf, thumbBuf] = await Promise.all([
        resizeFromUrl(trayUrl, 96, 96, 'png'),
        resizeFromUrl(thumbUrl, 300, 300, 'jpeg', { quality: 90 }),
    ]);

    const zip = new AdmZip();
    const stickersProto = [];
    let totalSize = trayBuf.length;

    for (let i = 0; i < imageUrls.length; i++) {
        try {
            const webpBuf = await resizeFromUrl(imageUrls[i], 512, 512, 'webp', { quality: 80 });
            const fileName = `sticker_${String(i + 1).padStart(2, '0')}.webp`;
            zip.addFile(fileName, webpBuf);
            totalSize += webpBuf.length;
            stickersProto.push(proto.Message.StickerPackMessage.Sticker.fromObject({
                fileName, isAnimated: false, isLottie: false, mimetype: 'image/webp',
            }));
        } catch (_) {}
    }

    zip.addFile(`${packId}.png`, trayBuf);

    const [packCdn, thumbCdn] = await Promise.all([
        uploadEncBuf(conn, encryptWithLabel(zip.toBuffer(), 'Sticker Pack'), 'image'),
        uploadEncBuf(conn, encryptWithLabel(thumbBuf, 'thumbnail-image'), 'image'),
    ]);

    await conn.relayMessage(m.chat, proto.Message.fromObject({
        stickerPackMessage: {
            stickerPackId: packId,
            name: packName,
            publisher: '',
            stickers: stickersProto,
            fileLength: packCdn.fileLength,
            fileSha256: packCdn.fileSha256,
            fileEncSha256: packCdn.fileEncSha256,
            mediaKey: packCdn.mediaKey,
            directPath: packCdn.directPath,
            mediaKeyTimestamp: Math.floor(Date.now() / 1000),
            trayIconFileName: `${packId}.png`,
            thumbnailDirectPath: thumbCdn.directPath,
            thumbnailSha256: thumbCdn.fileSha256,
            thumbnailEncSha256: thumbCdn.fileEncSha256,
            thumbnailHeight: 300,
            thumbnailWidth: 300,
            stickerPackSize: totalSize,
            stickerPackOrigin: 2,
        },
    }), { messageId: Crypto.randomBytes(8).toString('hex').toUpperCase() });
}

// ── Stickerly API ──────────────────────────────────────────────────────────────

async function searchStickerLy(keyword, options = {}) {
    const {
        page = 1, limit = 10, extendSearchResult = false,
        sortBy = 'RECOMMENDED', languages = ['ALL'],
        minStickerCount = 5, searchBy = 'ALL', stickerType = 'ALL',
    } = options;

    const q = String(keyword || '').trim();
    if (!q) throw new Error('Keyword tidak boleh kosong.');

    try {
        const { data } = await axios.post(
            'https://api.sticker.ly/v4/stickerPack/smartSearch',
            { keyword: q, enabledKeywordSearch: true, page, limit,
              filter: { extendSearchResult, sortBy, languages, minStickerCount, searchBy, stickerType } },
            { headers: { 'User-Agent': UA, 'Content-Type': 'application/json' } }
        );
        return { status: true, query: q, result: data?.result || data };
    } catch (e) {
        return { status: false, error: e.response?.data || e.message };
    }
}

function getPackTitle(p = {}) {
    return p.name || p.title || p.stickerPackName || p.displayName || 'No title';
}

function getPackCount(p = {}) {
    if (Array.isArray(p.resourceFiles)) return p.resourceFiles.length;
    const n = p.stickerCount ?? p.totalStickerCount ?? p.totalStickers ?? p.stickerTotal ?? p.stickersCount ?? p.itemCount ?? p.count;
    return Number.isFinite(Number(n)) ? Number(n) : null;
}

function getPackId(p = {}) {
    const fromShare = String(p.shareUrl || '').match(/sticker\.ly\/s\/([A-Z0-9]+)/i)?.[1];
    return p.packId || p.stickerPackId || p.stickerPackCode || p.packCode || p.id || p.code || p._id || fromShare || '';
}

function buildStickerUrls(pack = {}) {
    const prefix = String(pack.resourceUrlPrefix || '').trim();
    const files = Array.isArray(pack.resourceFiles) ? pack.resourceFiles : [];
    if (!prefix || !files.length) return [];
    const base = prefix.endsWith('/') ? prefix : `${prefix}/`;
    return files.map(f => `${base}${f}`);
}

// ── Handler ────────────────────────────────────────────────────────────────────

let handler = async (m, { text, usedPrefix, command }) => {
    const q = String(text || '').trim();
    if (!q) return m.reply(`Masukkan kata kunci.\nContoh: ${usedPrefix + command} anime`);

    const res = await searchStickerLy(q, { limit: 10 });
    const packs = res.result?.stickerPacks || [];
    if (!packs.length) return m.reply(`Tidak ada hasil untuk: ${q}`);

    global.db.data.stickerlySession = global.db.data.stickerlySession || {};

    const items = packs.slice(0, 10).map((p, i) => ({
        no: i + 1,
        id: getPackId(p),
        title: getPackTitle(p),
        count: getPackCount(p),
        raw: p,
    }));

    global.db.data.stickerlySession[m.chat] = { sender: m.sender, query: q, items, time: Date.now() };

    const list = items.map(v => `${v.no}. ${v.title}${v.count === null ? '' : ` (${v.count} sticker)`}`).join('\n');
    return m.reply(`Hasil pencarian untuk "${q}"\n\n${list}\n\nBalas angka 1-10 untuk memilih pack.`);
};

handler.before = async function (m, { conn }) {
    try {
        global.db.data.stickerlySession = global.db.data.stickerlySession || {};
        const session = global.db.data.stickerlySession?.[m.chat];
        if (!session) return;

        if (Date.now() - session.time > 5 * 60 * 1000) {
            delete global.db.data.stickerlySession[m.chat];
            return;
        }

        if (session.sender !== m.sender) return;

        const msg = String(m.text || m.body || m.message?.conversation || '').trim();
        if (!/^\d+$/.test(msg)) return;

        const idx = Number(msg);
        if (!idx || idx < 1 || idx > session.items.length) return m.reply(`Pilih angka 1-${session.items.length}.`);

        const chosen = session.items[idx - 1];
        const imageUrls = buildStickerUrls(chosen.raw || {}).slice(0, 30);
        delete global.db.data.stickerlySession[m.chat];

        if (!imageUrls.length) return m.reply(`Pack "${chosen.title}" tidak punya data sticker.`);

        const packId = (chosen.id || Crypto.randomBytes(4).toString('hex')).toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 16);

        await m.reply(`Memproses pack "${chosen.title}" (${imageUrls.length} sticker)...`);
        await sendStickerPack(conn, m, { packId, packName: chosen.title, imageUrls, trayUrl: imageUrls[0], thumbUrl: imageUrls[0] });
    } catch (e) {
        await m.reply(`Gagal mengirim sticker pack: ${e.message}`).catch(() => {});
    }
    return false;
};

handler.command = /^(stickerly|stly)$/i;
handler.help = ['stickerly <kata kunci>'];
handler.tags = ['search'];

module.exports = handler;