const fs = require('fs');
const Runtime = require('../lib/runtime');

function formatBytes(bytes = 0) {
  bytes = Number(bytes || 0);
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  return `${(mb / 1024).toFixed(1)} GB`;
}

function formatTime(ts = Date.now()) {
  try {
    return new Date(ts).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  } catch {
    return String(ts);
  }
}

let handler = async (m, { conn, args }) => {
  const mode = ['light', 'data', 'full'].includes(String(args[0] || '').toLowerCase())
    ? String(args[0]).toLowerCase()
    : 'full';

  await m.reply(`⏳ Membuat Smart Backup mode ${mode}...`);

  try {
    const result = await Runtime.smartBackup.createBackup(mode, {
      force: true,
      forceManual: true,
      trigger: 'manual-backupsc',
      reason: `owner-command-backupsc-${mode}`
    });

    if (!result.ok) {
      return m.reply(`❌ Backup gagal/skip: ${result.reason || 'unknown'}`);
    }

    const caption = [
      '✅ Smart Backup selesai.',
      '',
      `Mode: ${result.mode}`,
      `File: ${result.fileName}`,
      `Ukuran: ${formatBytes(result.bytes)}`,
      `Source Files: ${result.sourceFiles}`,
      `Waktu: ${formatTime(result.createdAt)}`,
      '',
      'Folder cache besar, session, node_modules, tmp, logs, dan backup lama tidak ikut dimasukkan.',
      'File tetap disimpan di backups/smart untuk retention harian/mingguan.'
    ].join('\n');

    return conn.sendMessage(m.chat, {
      document: fs.readFileSync(result.path),
      mimetype: 'application/zip',
      fileName: result.fileName,
      caption
    }, { quoted: m });
  } catch (error) {
    console.error('Smart backup error:', error);
    return m.reply(`❌ Terjadi kesalahan saat backup:\n${error.message || error}`);
  }
};

handler.help = handler.command = ['backupsc'];
handler.tags = ['owner'];
handler.owner = true;
handler.heavy = true;
handler.queue = true;

module.exports = handler;
