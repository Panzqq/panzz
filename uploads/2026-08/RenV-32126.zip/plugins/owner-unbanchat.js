let handler = async (m, { usedPrefix, command }) => {
  if (!m.isGroup) return m.reply(`*[!] Fitur ini hanya bisa digunakan di grup.*`);

  let chat = global.db.data.chats[m.chat] || (global.db.data.chats[m.chat] = {});

  if (!chat.isBanned) {
    return m.reply(`*[!] Banchat belum aktif di grup ini.*\n\n> Gunakan *${usedPrefix}banchat* untuk menutup akses bot.`);
  }

  chat.isBanned = false;

  await m.reply(`*[ ✓ ] Banchat berhasil dinonaktifkan.*\n\n> Semua member sudah bisa menggunakan bot lagi.`);
};

handler.help = handler.command = ['unbanchat', 'unban-chat'];
handler.tags = ['owner'];
handler.owner = true;
handler.group = true;

module.exports = handler;
