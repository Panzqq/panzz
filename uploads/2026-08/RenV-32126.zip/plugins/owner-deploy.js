const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');
const AdmZip = require('adm-zip');

/*
  Vercel Deploy Wizard for WhatsApp Bot
  Flow:
  reply ZIP -> scan -> project name -> scope/team -> env -> confirm -> link -> env add -> deploy

  Requirements on the bot server:
  - Node.js 18+ (for stable child_process + modern APIs)
  - npm dependency: adm-zip
  - VERCEL_TOKEN environment variable
  - Optional: VERCEL_SCOPE / VERCEL_TEAM
*/

const VERCEL_TOKEN = process.env.VERCEL_TOKEN || 'vcp_10MwRCYsJjcA3YrcZh4fsoMktdMZimekWD1HN53FfMjjCO3R7x1y4DMf';
const DEFAULT_SCOPE = process.env.VERCEL_SCOPE || process.env.VERCEL_TEAM_ID || 'pan-pans-projects';
const SESSION_TTL = 25 * 60 * 1000;

const sessions = new Map();

function now() {
  return Date.now();
}

function uid(bytes = 8) {
  return crypto.randomBytes(bytes).toString('hex');
}

function cleanText(text = '') {
  return String(text || '').trim();
}

function safeProjectName(name = '') {
  const n = cleanText(name)
    .toLowerCase()
    .replace(/[^a-z0-9-_]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
  return n || `project-${Date.now()}`;
}

function formatBytes(bytes = 0) {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let value = Number(bytes) || 0;
  let i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i++;
  }
  return `${value.toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}

function fileExists(file) {
  try {
    return fs.existsSync(file);
  } catch {
    return false;
  }
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function safeReadJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

function rel(file, base) {
  return path.relative(base, file).split(path.sep).join('/');
}

function isZipMime(mime = '', fileName = '') {
  const m = String(mime).toLowerCase();
  const f = String(fileName).toLowerCase();
  return (
    f.endsWith('.zip') ||
    m.includes('zip') ||
    m.includes('x-zip-compressed') ||
    m.includes('octet-stream')
  );
}

function getQuotedMeta(m) {
  const q = m.quoted || m;
  const mime =
    q.mimetype ||
    q.msg?.mimetype ||
    q.message?.documentMessage?.mimetype ||
    q.message?.imageMessage?.mimetype ||
    q.message?.videoMessage?.mimetype ||
    '';
  const fileName =
    q.fileName ||
    q.msg?.fileName ||
    q.message?.documentMessage?.fileName ||
    q.message?.imageMessage?.fileName ||
    q.message?.videoMessage?.fileName ||
    'project.zip';
  return { q, mime, fileName };
}

async function downloadBuffer(conn, q) {
  if (typeof q.download === 'function') return await q.download();
  if (typeof conn.downloadMediaMessage === 'function') return await conn.downloadMediaMessage(q);
  throw new Error('Metode download media tidak tersedia pada base bot ini.');
}

function countTree(dir) {
  const result = { files: 0, folders: 0, list: [] };

  function walk(current) {
    const entries = fs.readdirSync(current, { withFileTypes: true });
    for (const ent of entries) {
      const fp = path.join(current, ent.name);
      if (ent.isDirectory()) {
        result.folders++;
        walk(fp);
      } else if (ent.isFile()) {
        result.files++;
        if (result.list.length < 100) result.list.push(fp);
      }
    }
  }

  walk(dir);
  return result;
}

function sumFileSize(dir) {
  let total = 0;

  function walk(current) {
    const entries = fs.readdirSync(current, { withFileTypes: true });
    for (const ent of entries) {
      const fp = path.join(current, ent.name);
      if (ent.isDirectory()) walk(fp);
      else if (ent.isFile()) total += fs.statSync(fp).size;
    }
  }

  walk(dir);
  return total;
}

function findDirectoryByPredicate(startDir, predicate, maxDepth = 8) {
  const queue = [{ dir: startDir, depth: 0 }];

  while (queue.length) {
    const { dir, depth } = queue.shift();
    if (depth > maxDepth) continue;

    try {
      if (predicate(dir)) return dir;
    } catch {}

    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }

    for (const ent of entries) {
      if (ent.isDirectory()) {
        queue.push({ dir: path.join(dir, ent.name), depth: depth + 1 });
      }
    }
  }

  return null;
}

function hasAnyHtmlFile(dir) {
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    return entries.some(ent => ent.isFile() && /\.html?$/i.test(ent.name));
  } catch {
    return false;
  }
}

function findProjectRoot(extractDir) {
  const pkgRoot = findDirectoryByPredicate(extractDir, dir => fileExists(path.join(dir, 'package.json')), 8);
  if (pkgRoot) return { rootDir: pkgRoot, mode: 'app' };

  const indexHtmlRoot = findDirectoryByPredicate(extractDir, dir => fileExists(path.join(dir, 'index.html')), 8);
  if (indexHtmlRoot) return { rootDir: indexHtmlRoot, mode: 'static' };

  const anyHtmlRoot = findDirectoryByPredicate(extractDir, dir => hasAnyHtmlFile(dir), 8);
  if (anyHtmlRoot) return { rootDir: anyHtmlRoot, mode: 'static' };

  return null;
}

function detectFramework(pkg, rootDir) {
  const deps = {
    ...(pkg?.dependencies || {}),
    ...(pkg?.devDependencies || {}),
    ...(pkg?.peerDependencies || {}),
  };

  const has = name => Boolean(deps[name]);

  if (has('next')) return 'Next.js';
  if (has('nuxt')) return 'Nuxt.js';
  if (has('astro')) return 'Astro';
  if (has('vite')) return 'Vite';
  if (has('react')) return 'React';
  if (has('express')) return 'Express';
  if (has('fastify')) return 'Fastify';
  if (has('koa')) return 'Koa';
  if (has('hono')) return 'Hono';
  if (has('@nestjs/core')) return 'NestJS';
  if (has('@sveltejs/kit')) return 'SvelteKit';
  if (has('remix')) return 'Remix';
  if (has('vue')) return 'Vue';

  if (fileExists(path.join(rootDir, 'next.config.js')) || fileExists(path.join(rootDir, 'next.config.mjs'))) return 'Next.js';
  if (fileExists(path.join(rootDir, 'nuxt.config.ts')) || fileExists(path.join(rootDir, 'nuxt.config.js'))) return 'Nuxt.js';
  if (fileExists(path.join(rootDir, 'astro.config.mjs')) || fileExists(path.join(rootDir, 'astro.config.js'))) return 'Astro';
  if (fileExists(path.join(rootDir, 'vite.config.ts')) || fileExists(path.join(rootDir, 'vite.config.js'))) return 'Vite';
  if (fileExists(path.join(rootDir, 'svelte.config.js'))) return 'SvelteKit';
  if (fileExists(path.join(rootDir, 'angular.json'))) return 'Angular';

  return 'Other';
}

function detectEntry(rootDir, pkg) {
  const candidates = [
    pkg?.main,
    'index.js',
    'app.js',
    'server.js',
    'main.js',
    'index.ts',
    'app.ts',
    'server.ts',
    'main.ts',
    'src/index.js',
    'src/app.js',
    'src/server.js',
    'src/main.js',
    'src/index.ts',
    'src/app.ts',
    'src/server.ts',
    'src/main.ts',
  ].filter(Boolean);

  for (const c of candidates) {
    if (fileExists(path.join(rootDir, c))) return c;
  }

  return null;
}

function guessOutputDir(framework) {
  switch (framework) {
    case 'Next.js':
      return '.next';
    case 'Nuxt.js':
      return '.output';
    case 'Astro':
    case 'Vite':
    case 'React':
    case 'SvelteKit':
    case 'Remix':
    case 'Angular':
      return 'dist';
    default:
      return null;
  }
}

function defaultBuildInfo(framework, pkg) {
  const scripts = pkg?.scripts || {};
  const buildCmd = scripts.build || scripts.vercel_build || null;

  const install =
    pkg?.packageManager?.includes('yarn') ? 'yarn install'
      : pkg?.packageManager?.includes('pnpm') ? 'pnpm install'
      : 'npm install';

  if (buildCmd) {
    return {
      install,
      build: buildCmd,
      output: guessOutputDir(framework),
    };
  }

  switch (framework) {
    case 'Next.js':
      return { install, build: 'npm run build', output: '.next' };
    case 'Nuxt.js':
      return { install, build: 'npm run build', output: '.output' };
    case 'Astro':
      return { install, build: 'npm run build', output: 'dist' };
    case 'Vite':
      return { install, build: 'npm run build', output: 'dist' };
    case 'React':
      return { install, build: 'npm run build', output: 'build' };
    case 'SvelteKit':
      return { install, build: 'npm run build', output: 'build' };
    case 'Remix':
      return { install, build: 'npm run build', output: 'public/build' };
    case 'Angular':
      return { install, build: 'npm run build', output: 'dist' };
    default:
      return { install, build: null, output: null };
  }
}

function scanProject(rootDir, mode) {
  const pkgPath = path.join(rootDir, 'package.json');
  const pkg = fileExists(pkgPath) ? safeReadJson(pkgPath) : null;

  const htmlFiles = [];
  function collectHtml(current) {
    let entries = [];
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      return;
    }

    for (const ent of entries) {
      const fp = path.join(current, ent.name);
      if (ent.isDirectory()) collectHtml(fp);
      else if (ent.isFile() && /\.html?$/i.test(ent.name)) htmlFiles.push(rel(fp, rootDir));
    }
  }
  collectHtml(rootDir);

  const framework = mode === 'static' ? 'Static HTML' : detectFramework(pkg, rootDir);
  const entry = mode === 'static'
    ? (fileExists(path.join(rootDir, 'index.html')) ? 'index.html' : htmlFiles[0] || null)
    : detectEntry(rootDir, pkg);

  const buildInfo = mode === 'static'
    ? { install: null, build: null, output: null }
    : defaultBuildInfo(framework, pkg);

  const tree = countTree(rootDir);
  const sizeBytes = sumFileSize(rootDir);

  const envFiles = [
    '.env',
    '.env.local',
    '.env.production',
    '.env.development',
    '.env.test',
    '.env.example',
  ].filter(x => fileExists(path.join(rootDir, x)));

  const sensitiveHints = [];
  const hintWords = ['secret', 'token', 'apikey', 'api-key', 'private', 'password', 'credential'];

  for (const f of tree.list) {
    const base = path.basename(f).toLowerCase();
    if (hintWords.some(w => base.includes(w))) {
      sensitiveHints.push(rel(f, rootDir));
    }
  }

  return {
    mode,
    pkg,
    framework,
    entry,
    buildInfo,
    tree,
    sizeBytes,
    envFiles,
    sensitiveHints,
    hasPackageJson: Boolean(pkg),
    hasIndexHtml: fileExists(path.join(rootDir, 'index.html')),
    hasAnyHtml: htmlFiles.length > 0,
    htmlFiles: htmlFiles.slice(0, 15),
    hasNodeModules: fileExists(path.join(rootDir, 'node_modules')),
    hasVercelJson: fileExists(path.join(rootDir, 'vercel.json')),
    nodeVersion: pkg?.engines?.node || '-',
    rootDir,
  };
}

function parseEnvBlock(text) {
  const env = {};
  const lines = String(text || '')
    .split('\n')
    .map(s => s.trim())
    .filter(Boolean);

  for (const line of lines) {
    if (/^(selesai|skip|batal)$/i.test(line)) continue;
    const idx = line.indexOf('=');
    if (idx <= 0) continue;
    const key = line.slice(0, idx).trim();
    const value = line.slice(idx + 1).trim();
    if (!key) continue;
    env[key] = value;
  }

  return env;
}

function compactObject(obj) {
  const out = {};
  for (const [k, v] of Object.entries(obj || {})) {
    if (v !== undefined && v !== null && v !== '') out[k] = v;
  }
  return out;
}

function buildProjectSettings(scan) {
  const pkg = scan.pkg || {};
  const scripts = pkg.scripts || {};

  const install =
    pkg.packageManager?.includes('yarn') ? 'yarn install'
      : pkg.packageManager?.includes('pnpm') ? 'pnpm install'
      : 'npm install';

  const build =
    scripts.build ||
    scripts.vercel_build ||
    (scan.framework === 'Next.js' ? 'npm run build'
      : scan.framework === 'Nuxt.js' ? 'npm run build'
      : scan.framework === 'Astro' ? 'npm run build'
      : scan.framework === 'Vite' ? 'npm run build'
      : scan.framework === 'React' ? 'npm run build'
      : scan.framework === 'SvelteKit' ? 'npm run build'
      : scan.framework === 'Remix' ? 'npm run build'
      : scan.framework === 'Angular' ? 'npm run build'
      : null);

  const settings = {
    installCommand: install,
    buildCommand: build,
    nodeVersion: pkg.engines?.node || null,
  };

  if (scan.mode !== 'static' && scan.buildInfo?.output) {
    settings.outputDirectory = scan.buildInfo.output;
  }

  return compactObject(settings);
}

function shouldIgnoreEntry(name, isDir = false) {
  const lower = String(name || '').toLowerCase();

  const dirIgnores = new Set([
    'node_modules',
    '.git',
    '.vercel',
    '.cache',
    'coverage',
    '.idea',
    '.vscode',
  ]);

  const fileIgnores = new Set([
    '.ds_store',
    'thumbs.db',
  ]);

  if (isDir && dirIgnores.has(lower)) return true;
  if (!isDir && fileIgnores.has(lower)) return true;

  return false;
}

function shouldSkipEnvFile(relPath) {
  const p = relPath.toLowerCase();
  return (
    p === '.env' ||
    p === '.env.local' ||
    p === '.env.production' ||
    p === '.env.development' ||
    p === '.env.test' ||
    p.endsWith('/.env') ||
    p.endsWith('/.env.local') ||
    p.endsWith('/.env.production') ||
    p.endsWith('/.env.development') ||
    p.endsWith('/.env.test')
  );
}

function collectDeploymentFiles(rootDir) {
  const files = [];

  function walk(current, base) {
    const entries = fs.readdirSync(current, { withFileTypes: true });
    for (const ent of entries) {
      if (shouldIgnoreEntry(ent.name, ent.isDirectory())) continue;

      const fp = path.join(current, ent.name);
      const relPath = rel(fp, base);

      if (ent.isDirectory()) {
        walk(fp, base);
      } else if (ent.isFile()) {
        if (shouldSkipEnvFile(relPath)) continue;

        const buf = fs.readFileSync(fp);
        files.push({
          file: relPath,
          data: buf.toString('base64'),
          encoding: 'base64',
        });
      }
    }
  }

  walk(rootDir, rootDir);
  return files;
}

function apiUrl(apiPath, scope, extraParams = {}) {
  const url = new URL(`https://api.vercel.com${apiPath}`);

  const teamId = process.env.VERCEL_TEAM_ID || '';
  if (teamId) {
    url.searchParams.set('teamId', teamId);
  } else if (scope) {
    url.searchParams.set('slug', scope);
  }

  for (const [k, v] of Object.entries(extraParams || {})) {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, String(v));
  }

  return url;
}

async function apiRequest(method, apiPath, { scope = '', body = null, extraParams = {} } = {}) {
  if (typeof fetch !== 'function') throw new Error('Node.js 18+ dibutuhkan karena global fetch belum tersedia.');

  const res = await fetch(apiUrl(apiPath, scope, extraParams), {
    method,
    headers: {
      Authorization: `Bearer ${VERCEL_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const raw = await res.text();
  let data = null;
  if (raw) {
    try {
      data = JSON.parse(raw);
    } catch {
      data = raw;
    }
  }

  if (!res.ok) {
    const msg =
      (data && typeof data === 'object' && (data.error?.message || data.message || data.error || data.err)) ||
      (typeof data === 'string' && data) ||
      `HTTP ${res.status}`;
    const err = new Error(msg);
    err.status = res.status;
    err.data = data;
    throw err;
  }

  return data;
}

async function getProject(projectName, scope) {
  try {
    return await apiRequest('GET', `/v9/projects/${encodeURIComponent(projectName)}`, { scope });
  } catch (e) {
    if (e.status === 404) return null;
    throw e;
  }
}

async function createProject(projectName, scope) {
  return await apiRequest('POST', '/v11/projects', {
    scope,
    body: { name: projectName },
  });
}

async function ensureProject(projectName, scope) {
  let project = await getProject(projectName, scope);
  if (project) return project;

  try {
    project = await createProject(projectName, scope);
    return project;
  } catch (e) {
    if (e.status === 409 || /already exists|exists/i.test(String(e.message || ''))) {
      project = await getProject(projectName, scope);
      if (project) return project;
    }
    throw e;
  }
}

async function upsertEnvVars(projectName, scope, envObj) {
  const entries = Object.entries(envObj || {});
  if (!entries.length) return { created: [], failed: [] };

  const created = [];
  const failed = [];

  for (const [key, value] of entries) {
    try {
      const res = await apiRequest('POST', `/v10/projects/${encodeURIComponent(projectName)}/env`, {
        scope,
        extraParams: { upsert: 'true' },
        body: {
          key,
          value,
          type: 'plain',
          target: ['production'],
        },
      });
      created.push(res);
    } catch (e) {
      failed.push({ key, message: e.message || 'gagal' });
    }
  }

  return { created, failed };
}

function buildCliEnv(extra = {}) {
  return {
    ...process.env,
    VERCEL_TOKEN,
    CI: '1',
    FORCE_COLOR: '0',
    ...extra,
  };
}

function runCmd(command, args, { cwd, input = null, env = {}, onChunk = null } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd,
      env: buildCliEnv(env),
      stdio: input ? ['pipe', 'pipe', 'pipe'] : ['ignore', 'pipe', 'pipe'],
      shell: false,
      windowsHide: true,
    });

    let stdout = '';
    let stderr = '';
    let finished = false;

    const done = (err, result) => {
      if (finished) return;
      finished = true;
      if (err) reject(err);
      else resolve(result);
    };

    child.stdout.on('data', chunk => {
      const text = chunk.toString();
      stdout += text;
      if (onChunk) onChunk('stdout', text, stdout, stderr);
    });

    child.stderr.on('data', chunk => {
      const text = chunk.toString();
      stderr += text;
      if (onChunk) onChunk('stderr', text, stdout, stderr);
    });

    child.on('error', err => {
      done(err);
    });

    child.on('close', code => {
      if (code === 0) {
        done(null, { code, stdout, stderr });
        return;
      }

      const err = new Error(
        [stdout.trim(), stderr.trim()].filter(Boolean).join('\n').trim() ||
          `Command failed with exit code ${code}`
      );
      err.code = code;
      err.stdout = stdout;
      err.stderr = stderr;
      done(err);
    });

    if (input !== null && input !== undefined) {
      child.stdin.write(String(input));
      child.stdin.end();
    }
  });
}

function parseDeploymentUrl(output) {
  const matches = String(output || '').match(/https?:\/\/[^\s"'()<>]+/g) || [];
  const vercelLinks = matches.filter(u => /vercel\.app|vercel\.dev/i.test(u));
  return vercelLinks[vercelLinks.length - 1] || matches[matches.length - 1] || '';
}

function extractUsefulTail(text, maxLines = 20) {
  const lines = String(text || '').split('\n').map(s => s.trimEnd());
  const tail = lines.slice(Math.max(0, lines.length - maxLines));
  return tail.filter(Boolean).join('\n');
}

function scannerText(scan, defaultName, scope) {
  const lines = [];
  lines.push('🔍 *Project Scanner*');
  lines.push('');
  lines.push(`• Mode: *${scan.mode === 'static' ? 'Static HTML' : 'App / Framework'}*`);
  lines.push(`• Framework: *${scan.framework}*`);
  lines.push(`• Entry: *${scan.entry || '-'}*`);
  lines.push(`• File: *${scan.tree.files}*`);
  lines.push(`• Folder: *${scan.tree.folders}*`);
  lines.push(`• Size: *${formatBytes(scan.sizeBytes)}*`);
  lines.push(`• Node version: *${scan.nodeVersion}*`);
  lines.push(`• Install: *${scan.buildInfo.install || '-'}*`);
  lines.push(`• Build: *${scan.buildInfo.build || '-'}*`);
  lines.push(`• Output: *${scan.buildInfo.output || '-'}*`);
  lines.push(`• node_modules: *${scan.hasNodeModules ? 'ada' : 'tidak'}*`);
  if (scope) lines.push(`• Scope: *${scope}*`);
  if (scan.envFiles.length) lines.push(`• Env file: *${scan.envFiles.join(', ')}*`);
  if (scan.sensitiveHints.length) lines.push(`• File sensitif: *${scan.sensitiveHints.slice(0, 6).join(', ')}*`);
  if (scan.mode === 'static' && scan.htmlFiles.length) lines.push(`• HTML terdeteksi: *${scan.htmlFiles.slice(0, 6).join(', ')}*`);
  lines.push('');
  lines.push(`Nama project default: *${defaultName}*`);
  lines.push('Balas dengan nama project baru, atau ketik *skip* untuk pakai default.');
  return lines.join('\n');
}

function scopePromptText(current) {
  return [
    '🌐 *Vercel Scope / Team*',
    '',
    'Masukkan scope/team yang akan dipakai.',
    'Contoh:',
    '`pan-pans-projects`',
    '',
    `Scope sekarang: *${current || '-'}*`,
    'Ketik *skip* kalau mau pakai scope yang sudah diset di server.',
  ].join('\n');
}

function envPromptText() {
  return [
    '⚙️ *Environment Variable*',
    '',
    'Kirim env dengan format:',
    '`KEY=value`',
    '',
    'Contoh:',
    '`API_KEY=xxxxx`',
    '`DATABASE_URL=xxxxx`',
    '',
    'Ketik *selesai* kalau sudah.',
    'Ketik *skip* kalau tidak mau menambah env.',
  ].join('\n');
}

function confirmText(session) {
  const envCount = Object.keys(session.env || {}).length;
  return [
    '🚀 *Konfirmasi Deploy*',
    '',
    `• Project: *${session.projectName}*`,
    `• Scope: *${session.scope || '-'}*`,
    `• Mode: *${session.scan.mode === 'static' ? 'Static HTML' : 'App / Framework'}*`,
    `• Framework: *${session.scan.framework}*`,
    session.scan.mode === 'static'
      ? '• Env: *tidak dipakai untuk static site*'
      : `• Env: *${envCount}*`,
    '',
    'Ketik *ya* untuk lanjut.',
    'Ketik *batal* untuk membatalkan.',
  ].join('\n');
}

function doneText(session, deploymentUrl, projectUrl) {
  return [
    '✅ *DEPLOY BERHASIL*',
    '',
    `• Project: *${session.projectName}*`,
    `• Scope: *${session.scope || '-'}*`,
    `• Mode: *${session.scan.mode === 'static' ? 'Static HTML' : 'App / Framework'}*`,
    `• Framework: *${session.scan.framework}*`,
    `• Deployment URL: ${deploymentUrl || '(tidak terdeteksi)'}`,
    '',
    'Sesi selesai.',
  ].join('\n');
}

function errorText(e) {
  return [
    '❌ *Deploy gagal*',
    '',
    String(e?.message || e || 'Terjadi kesalahan'),
  ].join('\n');
}

function extractZip(zipBuffer, tempDir) {
  const zipPath = path.join(tempDir, `upload-${uid(8)}.zip`);
  fs.writeFileSync(zipPath, zipBuffer);

  const extractDir = path.join(tempDir, 'extracted');
  ensureDir(extractDir);

  try {
    const zip = new AdmZip(zipPath);
    zip.extractAllTo(extractDir, true);
  } catch (e) {
    throw new Error(`ZIP gagal diekstrak: ${e.message}`);
  }

  return { zipPath, extractDir };
}

function getSession(userId) {
  const s = sessions.get(userId);
  if (!s) return null;
  if (now() - s.updatedAt > SESSION_TTL) {
    cleanupSession(userId);
    return null;
  }
  return s;
}

function setSession(userId, session) {
  session.updatedAt = now();
  sessions.set(userId, session);
}

function touchSession(userId) {
  const s = sessions.get(userId);
  if (s) s.updatedAt = now();
}

function cleanupSession(userId) {
  const s = sessions.get(userId);
  if (!s) return;

  try {
    if (s.tempDir && fs.existsSync(s.tempDir)) {
      fs.rmSync(s.tempDir, { recursive: true, force: true });
    }
  } catch {}

  sessions.delete(userId);
}

async function sendStage(conn, m, text) {
  return await conn.sendMessage(m.chat, { text }, { quoted: m });
}

async function linkProject({ rootDir, projectName, scope }) {
  // Use Vercel CLI project linking. Docs: vercel link --yes --project <name> plus global --scope/--team options.
  const args = [
    '-y',
    'vercel',
    'link',
    '--yes',
    '--project',
    projectName,
    '--scope',
    scope,
    '--non-interactive',
  ];

  const result = await runCmd('npx', args, {
    cwd: rootDir,
  });

  return result;
}

async function addEnvVars({ rootDir, scope, envObj, onProgress }) {
  const entries = Object.entries(envObj || {});
  if (!entries.length) return { ok: true, results: [] };

  const results = [];
  for (const [key, value] of entries) {
    onProgress?.(`Menambahkan env: ${key} ...`);
    const args = [
      '-y',
      'vercel',
      'env',
      'add',
      key,
      'production',
      '--scope',
      scope,
      '--non-interactive',
    ];

    // vercel env add [name] [environment] can accept stdin for value
    const res = await runCmd('npx', args, {
      cwd: rootDir,
      input: `${value}\n`,
    });

    results.push({ key, ...res });
  }

  return { ok: true, results };
}

async function deployProduction({ rootDir, scope, onProgress }) {
  const args = [
    '-y',
    'vercel',
    'deploy',
    '--prod',
    '--yes',
    '--scope',
    scope,
    '--non-interactive',
  ];

  const result = await runCmd('npx', args, {
    cwd: rootDir,
    onChunk: (_kind, chunk, stdout, stderr) => {
      const combined = `${stdout}\n${stderr}`;
      if (/upload|building|bundling|deploy/i.test(chunk)) {
        onProgress?.(extractUsefulTail(combined, 10));
      }
    },
  });

  return result;
}

function shouldIgnoreEntry(name, isDir = false) {
  const lower = String(name || '').toLowerCase();

  const dirIgnores = new Set([
    'node_modules',
    '.git',
    '.vercel',
    '.cache',
    'coverage',
    '.idea',
    '.vscode',
  ]);

  const fileIgnores = new Set([
    '.ds_store',
    'thumbs.db',
  ]);

  if (isDir && dirIgnores.has(lower)) return true;
  if (!isDir && fileIgnores.has(lower)) return true;

  return false;
}

function shouldSkipEnvFile(relPath) {
  const p = relPath.toLowerCase();
  return (
    p === '.env' ||
    p === '.env.local' ||
    p === '.env.production' ||
    p === '.env.development' ||
    p === '.env.test' ||
    p.endsWith('/.env') ||
    p.endsWith('/.env.local') ||
    p.endsWith('/.env.production') ||
    p.endsWith('/.env.development') ||
    p.endsWith('/.env.test')
  );
}

function prepareUploadFolder(rootDir) {
  // We keep everything as-is for Vercel CLI. This function exists for future hooks.
  // For static HTML or app frameworks, the extracted root directory is already the deploy root.
  return rootDir;
}

async function startDeployFlow(m, { conn }) {
  const userId = m.sender;
  const { q, mime, fileName } = getQuotedMeta(m);

  if (!isZipMime(mime, fileName)) {
    return await conn.sendMessage(
      m.chat,
      {
        text:
          '⚡ *Vercel Deploy*\n\n' +
          'Reply file *.zip* project kamu, lalu ketik *.deploy*.\n\n' +
          'Contoh:\n' +
          '1. Kirim `project.zip`\n' +
          '2. Reply file itu dengan `.deploy`',
      },
      { quoted: m }
    );
  }

  if (getSession(userId)) {
    return await conn.sendMessage(
      m.chat,
      { text: 'Masih ada sesi deploy yang berjalan. Selesaikan dulu atau tunggu timeout.' },
      { quoted: m }
    );
  }

  if (!VERCEL_TOKEN) {
    return await conn.sendMessage(
      m.chat,
      { text: '❌ `VERCEL_TOKEN` belum diset di server.' },
      { quoted: m }
    );
  }

  const tempDir = path.join(os.tmpdir(), `vercel-deploy-${userId}-${Date.now()}-${uid(4)}`);
  ensureDir(tempDir);

  try {
    await sendStage(conn, m, '⏳ Mengunduh ZIP...');

    const zipBuffer = await downloadBuffer(conn, q);
    if (!zipBuffer || !Buffer.isBuffer(zipBuffer)) {
      throw new Error('Buffer ZIP tidak valid.');
    }

    const { extractDir } = extractZip(zipBuffer, tempDir);
    const found = findProjectRoot(extractDir);

    if (!found) {
      throw new Error('Tidak menemukan package.json ataupun file HTML di dalam ZIP.');
    }

    const { rootDir, mode } = found;
    const scan = scanProject(rootDir, mode);
    const defaultProjectName = safeProjectName(
      (scan.pkg && (scan.pkg.name || path.basename(rootDir))) || path.basename(rootDir)
    );

    const session = {
      userId,
      chatId: m.chat,
      tempDir,
      extractDir,
      rootDir,
      scan,
      projectName: defaultProjectName,
      scope: DEFAULT_SCOPE || '',
      env: {},
      stage: 'WAIT_NAME',
      updatedAt: now(),
    };

    setSession(userId, session);

    await conn.sendMessage(
      m.chat,
      { text: scannerText(scan, defaultProjectName, session.scope) },
      { quoted: m }
    );
  } catch (e) {
    await conn.sendMessage(m.chat, { text: errorText(e) }, { quoted: m });
    cleanupSession(userId);
  }
}

async function handleSessionText(m, { conn }) {
  const userId = m.sender;
  const session = getSession(userId);
  if (!session) return false;

  const text = cleanText(m.text || m.body || '');
  if (!text) return true;

  touchSession(userId);

  if (/^batal$/i.test(text)) {
    await conn.sendMessage(m.chat, { text: '❌ Deploy dibatalkan.' }, { quoted: m });
    cleanupSession(userId);
    return true;
  }

  if (session.stage === 'WAIT_NAME') {
    if (/^skip$/i.test(text)) {
      session.projectName = session.projectName || `project-${Date.now()}`;

      if (!session.scope) {
        session.stage = 'WAIT_SCOPE';
        await conn.sendMessage(m.chat, { text: scopePromptText(session.scope) }, { quoted: m });
        return true;
      }

      session.stage = session.scan.mode === 'static' ? 'WAIT_CONFIRM' : 'WAIT_ENV';
      if (session.scan.mode === 'static') {
        await conn.sendMessage(m.chat, { text: confirmText(session) }, { quoted: m });
      } else {
        await conn.sendMessage(m.chat, { text: envPromptText() }, { quoted: m });
      }
      return true;
    }

    session.projectName = safeProjectName(text);

    if (!session.scope) {
      session.stage = 'WAIT_SCOPE';
      await conn.sendMessage(m.chat, { text: scopePromptText(session.scope) }, { quoted: m });
      return true;
    }

    if (session.scan.mode === 'static') {
      session.stage = 'WAIT_CONFIRM';
      await conn.sendMessage(m.chat, { text: confirmText(session) }, { quoted: m });
      return true;
    }

    session.stage = 'WAIT_ENV';
    await conn.sendMessage(m.chat, { text: envPromptText() }, { quoted: m });
    return true;
  }

  if (session.stage === 'WAIT_SCOPE') {
    if (/^skip$/i.test(text)) {
      if (!session.scope) {
        await conn.sendMessage(
          m.chat,
          { text: 'Scope belum ada. Set `VERCEL_SCOPE` / `VERCEL_TEAM` di server atau kirim scope team sekarang.' },
          { quoted: m }
        );
        return true;
      }

      session.stage = session.scan.mode === 'static' ? 'WAIT_CONFIRM' : 'WAIT_ENV';
      if (session.scan.mode === 'static') {
        await conn.sendMessage(m.chat, { text: confirmText(session) }, { quoted: m });
      } else {
        await conn.sendMessage(m.chat, { text: envPromptText() }, { quoted: m });
      }
      return true;
    }

    session.scope = cleanText(text);
    if (!session.scope) {
      await conn.sendMessage(m.chat, { text: 'Scope kosong. Kirim nama scope/team yang benar.' }, { quoted: m });
      return true;
    }

    session.stage = session.scan.mode === 'static' ? 'WAIT_CONFIRM' : 'WAIT_ENV';
    if (session.scan.mode === 'static') {
      await conn.sendMessage(m.chat, { text: confirmText(session) }, { quoted: m });
    } else {
      await conn.sendMessage(m.chat, { text: envPromptText() }, { quoted: m });
    }
    return true;
  }

  if (session.stage === 'WAIT_ENV') {
    if (/^skip$/i.test(text) || /^selesai$/i.test(text)) {
      session.stage = 'WAIT_CONFIRM';
      await conn.sendMessage(m.chat, { text: confirmText(session) }, { quoted: m });
      return true;
    }

    const parsed = parseEnvBlock(text);
    const keys = Object.keys(parsed);

    if (keys.length === 0) {
      await conn.sendMessage(
        m.chat,
        { text: 'Format env belum valid. Kirim `KEY=value` atau ketik `skip` / `selesai`.' },
        { quoted: m }
      );
      return true;
    }

    session.env = { ...(session.env || {}), ...parsed };

    await conn.sendMessage(
      m.chat,
      {
        text:
          `✅ Env tersimpan: *${keys.length}* key.\n` +
          `Kirim lagi jika masih ada, atau ketik *selesai* untuk lanjut.`,
      },
      { quoted: m }
    );
    return true;
  }

  if (session.stage === 'WAIT_CONFIRM') {
    if (/^(ya|lanjut|ok|oke)$/i.test(text)) {
      session.stage = 'DEPLOYING';

      await conn.sendMessage(m.chat, { text: '📦 Menyiapkan deploy...' }, { quoted: m });

      try {
        const deployRoot = prepareUploadFolder(session.rootDir);

        await conn.sendMessage(m.chat, { text: '🔗 Menautkan project ke Vercel...' }, { quoted: m });
        await linkProject({
          rootDir: deployRoot,
          projectName: session.projectName,
          scope: session.scope,
        });

        if (session.scan.mode !== 'static' && session.env && Object.keys(session.env).length) {
          await conn.sendMessage(m.chat, { text: '⚙️ Menambahkan environment variables...' }, { quoted: m });
          const envResult = await addEnvVars({
            rootDir: deployRoot,
            scope: session.scope,
            envObj: session.env,
            onProgress: async (msg) => {
              if (msg) {
                await conn.sendMessage(m.chat, { text: `⚙️ ${msg}` }, { quoted: m });
              }
            },
          });

          if (envResult?.results?.length) {
            await conn.sendMessage(
              m.chat,
              { text: `✅ Env berhasil ditambahkan: *${envResult.results.length}* item.` },
              { quoted: m }
            );
          }
        }

        await conn.sendMessage(m.chat, { text: '🚀 Menjalankan production deploy...' }, { quoted: m });

        const result = await deployProduction({
          rootDir: deployRoot,
          scope: session.scope,
          onProgress: async (msg) => {
            if (msg) {
              await conn.sendMessage(m.chat, { text: `⏳ ${msg}` }, { quoted: m });
            }
          },
        });

        const deploymentUrl = parseDeploymentUrl(result.stdout + '\n' + result.stderr);
        const projectUrl = session.projectName ? `https://${session.projectName}.vercel.app` : deploymentUrl;

        await conn.sendMessage(
          m.chat,
          { text: doneText(session, deploymentUrl, projectUrl) },
          { quoted: m }
        );

        cleanupSession(userId);
        return true;
      } catch (e) {
        const detail = extractUsefulTail([e.stdout, e.stderr, e.message].filter(Boolean).join('\n'), 25);
        await conn.sendMessage(
          m.chat,
          {
            text:
              '❌ *Deploy gagal*\n\n' +
              detail +
              '\n\nKalau mau mencoba lagi, kirim ZIP ulang lalu ulangi proses.',
          },
          { quoted: m }
        );
        cleanupSession(userId);
        return true;
      }
    }

    await conn.sendMessage(
      m.chat,
      { text: 'Ketik *ya* untuk lanjut atau *batal* untuk membatalkan.' },
      { quoted: m }
    );
    return true;
  }

  return false;
}

let handler = async (m, opts) => {
  const { conn, command } = opts;
  if (/^deploy$/i.test(command || '')) {
    return startDeployFlow(m, { conn });
  }
};

handler.before = async function (m, opts) {
  const { conn } = opts;
  if (!m || !m.sender) return false;
  return handleSessionText(m, { conn });
};

handler.help = ['deploy'];
handler.tags = ['owner'];
handler.command = /^deploy$/i;
handler.owner = true
module.exports = handler;