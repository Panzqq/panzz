const handler = async (m, { conn, text, command, usedPrefix, isOwner }) => {
    if (!isOwner) return m.reply("Fitur ini khusus owner!");

    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype || "";
    const caption = text || q.text || "";

    if (!mime && !caption) {
        return m.reply(
`[+] Upload WhatsApp Status

Masukkan media atau teks terlebih dahulu.

Contoh penggunaan:

[+] Teks
${usedPrefix + command} Halo semuanya!

[+] Reply Foto
Reply foto lalu ketik:
${usedPrefix + command}

[+] Reply Video
Reply video lalu ketik:
${usedPrefix + command}

[+] Reply Audio
Reply audio lalu ketik:
${usedPrefix + command}

[+] Reply Media + Caption
Reply media lalu ketik:
${usedPrefix + command} Caption status`
        );
    }

    try {
        const jids = Object.keys(conn.chats || {}).filter(v => v.endsWith("@s.whatsapp.net"));
        const statusJidList = jids.length ? jids : [m.sender];

        let msg = {};

        if (/image/i.test(mime)) {
            msg = {
                image: await q.download(),
                caption
            };
        } else if (/video/i.test(mime)) {
            msg = {
                video: await q.download(),
                caption
            };
        } else if (/audio/i.test(mime)) {
            msg = {
                audio: await q.download(),
                mimetype: "audio/mp4",
                ptt: true
            };
        } else {
            msg = {
                text: caption
            };
        }

        await conn.sendMessage("status@broadcast", msg, {
            backgroundColor: "#000000",
            font: 1,
            statusJidList
        });

        m.reply("[+] Status berhasil diunggah.");
    } catch (e) {
        console.error(e);
        m.reply("[-] " + e.message);
    }
};

handler.help = ["upsw"];
handler.tags = ["owner"];
handler.command = /^upsw$/i;
handler.owner = true;

module.exports = handler;