const axios = require("axios");
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");
let moment = require("moment-timezone");
const { tmpFolder, tmpFile, safeRmSync, safeUnlinkSync } = require("../lib/tmpManager");

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`*• Example :* ${usedPrefix + command} *[input text]*`);
  }
  try {
    const words = text.split(" ");
    const tempDir = tmpFolder({ dir: "sticker/bratvid", prefix: "bratvid" });
    const framePaths = [];

    for (let i = 0; i < words.length; i++) {
      const currentText = words.slice(0, i + 1).join(" ");

      const res = await axios
        .get(
          `https://rest-api.nazirganz.space/maker/brat?text=${encodeURIComponent(currentText)}`,
          {
            responseType: "arraybuffer",
          },
        )
        .catch((e) => e.response);

      const framePath = path.join(tempDir, `frame${i}.mp4`);
      fs.writeFileSync(framePath, res.data);
      framePaths.push(framePath);
    }

    const fileListPath = path.join(tempDir, "filelist.txt");
    let fileListContent = "";

    for (let i = 0; i < framePaths.length; i++) {
      fileListContent += `file '${framePaths[i]}'\n`;
      fileListContent += `duration 0.5\n`; // Durasi setiap frame 500 milidetik
    }

    fileListContent += `file '${framePaths[framePaths.length - 1]}'\n`;
    fileListContent += `duration 3\n`; // Frame terakhir memiliki durasi 3 detik

    fs.writeFileSync(fileListPath, fileListContent);

    const outputVideoPath = tmpFile({ dir: "sticker/bratvid", prefix: "output", ext: "mp4" });
    execSync(
      `ffmpeg -y -f concat -safe 0 -i ${fileListPath} -vf "fps=30" -c:v libx264 -preset veryfast -pix_fmt yuv420p -t 00:00:10 ${outputVideoPath}`,
    );

    await conn.sendImageAsSticker(m.chat, outputVideoPath, m, {
      packname: namebot,
      author: `Created By ${m.name}\nAkiraaBot By © Nazir`,
    });

    framePaths.forEach((filePath) => safeUnlinkSync(filePath));
    safeUnlinkSync(fileListPath);
    safeUnlinkSync(outputVideoPath);
    safeRmSync(tempDir);
  } catch (err) {
    console.error(err);
    m.reply("Maaf, terjadi kesalahan saat memproses permintaan.");
  }
};

handler.help = ["bratvid", "bratvideo"].map((a) => a + " *[text]*");
handler.tags = ["sticker"];
handler.command = ["bratvid", "bratvideo"];
handler.premium = false;
handler.limit = 30;

module.exports = handler;
