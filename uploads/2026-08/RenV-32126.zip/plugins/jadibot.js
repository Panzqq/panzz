'use strict';

/**
 * plugins/jadibot.js
 * Command wrapper untuk lib/jadibot.js.
 *
 * Manager koneksi clone/sub-bot dipindah ke ../lib/jadibot.js supaya tidak
 * bentrok dengan loader plugin, dan path require menjadi benar.
 */

const Jadibot = require('../lib/jadibot.js');

function pickTargetNumber(m, text = '') {
  const raw = String(text || '').trim();
  if (raw) return Jadibot.sanitizeNumber(raw);

  const quotedSender = m?.quoted?.sender || m?.quoted?.participant;
  if (quotedSender) return Jadibot.sanitizeNumber(quotedSender);

  return Jadibot.sanitizeNumber(m?.sender || '');
}

function formatTime(ts = 0) {
  if (!ts) return '-';
  try {
    return new Date(ts).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  } catch {
    return String(ts);
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const cmd = String(command || '').toLowerCase();

  if (cmd === 'jadibot') {
    if (conn.isChild) {
      return m.reply('Fitur jadibot tidak bisa dijalankan dari sesi clone. Gunakan bot utama.');
    }

    const number = pickTargetNumber(m, text);
    if (!number || number.length < 8) {
      return m.reply(`Masukkan nomor yang valid.\nContoh: ${usedPrefix}${command} 6281234567890`);
    }

    await m.reply(`⏳ Menyiapkan sesi jadibot untuk +${number}...`);

    try {
      const result = await Jadibot.startJadibot({
        number,
        requesterJid: m.sender,
        notifyChat: m.chat
      });

      if (result.pairingCode) {
        return m.reply([
          '*Kode Pairing Jadibot*',
          '',
          `Nomor: +${result.number}`,
          `Kode : ${result.pairingCode}`,
          '',
          'Buka WhatsApp di nomor target → Perangkat tertaut → Tautkan dengan nomor telepon, lalu masukkan kode di atas.',
          'Kode otomatis dibatalkan jika tidak dipakai dalam beberapa menit.'
        ].join('\n'));
      }

      return m.reply(`✅ Sesi jadibot +${result.number} sudah punya auth tersimpan dan sedang disambungkan ulang.`);
    } catch (e) {
      return m.reply(`❌ Gagal menjalankan jadibot: ${e?.message || e}`);
    }
  }

  if (cmd === 'unjadibot' || cmd === 'stopjadibot') {
    const number = pickTargetNumber(m, text) || Jadibot.sanitizeNumber(conn.childNumber || '');
    if (!number) return m.reply(`Masukkan nomor.\nContoh: ${usedPrefix}${command} 6281234567890`);

    try {
      const ok = await Jadibot.stopJadibot(number);
      return m.reply(ok ? `✅ Sesi jadibot +${number} sudah dihentikan dan auth-nya dihapus.` : `Sesi jadibot +${number} tidak aktif.`);
    } catch (e) {
      return m.reply(`❌ Gagal menghentikan jadibot: ${e?.message || e}`);
    }
  }

  if (cmd === 'jadibotlist' || cmd === 'listjadibot') {
    const list = Jadibot.listActive();
    if (!list.length) return m.reply('Tidak ada sesi jadibot aktif.');

    return m.reply([
      '*Daftar Jadibot Aktif*',
      '',
      ...list.map((x, i) => `${i + 1}. +${x.number}\n   Status: ${x.connected ? 'connected' : 'reconnecting'}\n   Requester: ${x.requesterJid || '-'}\n   Start: ${formatTime(x.startedAt)}`)
    ].join('\n'));
  }
};

handler.help = ['jadibot <nomor>', 'unjadibot <nomor>', 'listjadibot'];
handler.tags = ['owner'];
handler.command = /^(jadibot|unjadibot|stopjadibot|jadibotlist|listjadibot)$/i;
handler.owner = true;

// Backward compatibility kalau ada file lama yang masih require plugins/jadibot.js
Object.assign(handler, Jadibot);

module.exports = handler;
