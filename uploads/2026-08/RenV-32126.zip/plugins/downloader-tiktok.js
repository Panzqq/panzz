const axios = require("axios");
const { sleep, formatCompactNumber, sanitizeFileName } = require("../lib/utils");

const safeFileName = (name = "tiktok-video") =>
  sanitizeFileName(name, { fallback: "tiktok-video", max: 50 });

const TIKWM_ENDPOINTS = [
  "https://www.tikwm.com/api/",
  "https://tikwm.com/api/",
];

function fullTikwmUrl(url) {
  if (!url) return null;
  if (/^https?:\/\//i.test(url)) return url;
  return `https://tikwm.com${url.startsWith("/") ? url : "/" + url}`;
}

async function requestTikwmDownload(tiktokUrl) {
  let lastError = "Request gagal";

  for (const endpoint of TIKWM_ENDPOINTS) {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const body = new URLSearchParams();
        body.set("url", tiktokUrl);
        body.set("hd", "1");

        const res = await axios.post(endpoint, body.toString(), {
          timeout: 60000,
          validateStatus: () => true,
          headers: {
            accept: "application/json, text/plain, */*",
            "content-type": "application/x-www-form-urlencoded",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "user-agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
            origin: "https://www.tikwm.com",
            referer: "https://www.tikwm.com/",
          },
        });

        if (res.status >= 500) {
          lastError = `HTTP ${res.status}`;
          await sleep(1000 * attempt);
          continue;
        }

        if (res.status !== 200) {
          return {
            status: false,
            error: `HTTP ${res.status}`,
          };
        }

        const json = res.data;

        if (!json || json.code !== 0) {
          lastError = json?.msg || "TikWM gagal mengambil data";
          await sleep(1000 * attempt);
          continue;
        }

        return {
          status: true,
          data: json.data,
        };
      } catch (e) {
        lastError = e.message || String(e);
        await sleep(1000 * attempt);
      }
    }
  }

  return {
    status: false,
    error: lastError,
  };
}

async function tiktokDownload(tiktokUrl) {
  const res = await requestTikwmDownload(tiktokUrl);

  if (!res.status) {
    return res;
  }

  const d = res.data || {};

  const video =
    fullTikwmUrl(d.hdplay) ||
    fullTikwmUrl(d.play) ||
    fullTikwmUrl(d.wmplay);

  const images = Array.isArray(d.images)
    ? d.images
        .map((img) => {
          if (typeof img === "string") return img;
          return img?.url || img?.display_image?.url_list?.[0] || null;
        })
        .filter(Boolean)
    : [];

  const audio =
    fullTikwmUrl(d.music) ||
    fullTikwmUrl(d.music_info?.play) ||
    fullTikwmUrl(d.music_info?.url) ||
    null;

  return {
    status: true,
    title: d.title || "-",
    duration: Number(d.duration) || 0,
    video,
    images,
    audio,
    cover: fullTikwmUrl(d.cover || d.origin_cover),
    music: {
      title: d.music_info?.title || "-",
      author: d.music_info?.author || "-",
      url: fullTikwmUrl(d.music || d.music_info?.play),
    },
    author: {
      username: d.author?.unique_id || "-",
      nickname: d.author?.nickname || "-",
      avatar: fullTikwmUrl(d.author?.avatar),
    },
    stats: {
      play_count: Number(d.play_count) || 0,
      digg_count: Number(d.digg_count) || 0,
      comment_count: Number(d.comment_count) || 0,
      share_count: Number(d.share_count) || 0,
      download_count: Number(d.download_count) || 0,
    },
  };
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    if (!text) {
      return m.reply(
        `乂 *T I K T O K  D O W N L O A D E R*\n\nContoh:\n${usedPrefix + command} https://vt.tiktok.com/ZSxaLQToh/`
      );
    }

    if (!/tiktok\.com|vt\.tiktok\.com|vm\.tiktok\.com/i.test(text)) {
      return m.reply("Masukkan link TikTok yang valid.");
    }

    await m.reply(global.wait || "Sedang mengambil video TikTok...");

    const result = await tiktokDownload(text);

    if (!result.status) {
      return m.reply(`Gagal mengambil video.\n\nError: ${result.error}`);
    }

    const caption = `乂 *T I K T O K*

*Judul:* ${result.title}
*Durasi:* ${result.duration}s

*Views:* ${formatCompactNumber(result.stats.play_count)}
*Likes:* ${formatCompactNumber(result.stats.digg_count)}
*Komentar:* ${formatCompactNumber(result.stats.comment_count)}
*Share:* ${formatCompactNumber(result.stats.share_count)}

*Musik:* ${result.music.title}
*Artist:* ${result.music.author}`;

    const audioz = result.audio || result.music?.url || result.video;

    if (result.images && result.images.length) {
      const imgs = result.images.slice(0, 10);

      for (let i = 0; i < imgs.length; i++) {
        await conn.sendMessage(
          m.chat,
          {
            image: { url: imgs[i] },
            caption: i === 0 ? caption : "",
          },
          { quoted: m }
        );
      }

      if (audioz) {
        await conn.sendMessage(
          m.chat,
          {
            audio: { url: audioz },
            mimetype: "audio/mpeg",
            ptt: false,
          },
          { quoted: m }
        );
      }

      return;
    }

    if (result.video) {
      await conn.sendMessage(
        m.chat,
        {
          video: { url: result.video },
          caption,
          mimetype: "video/mp4",
        },
        { quoted: m }
      );

      if (audioz) {
        await conn.sendMessage(
          m.chat,
          {
            audio: { url: audioz },
            mimetype: "audio/mpeg",
            ptt: false,
          },
          { quoted: m }
        );
      }

      return;
    }

    return m.reply("Media tidak ditemukan.");
  } catch (e) {
    return m.reply(`Error: ${e.message || e}`);
  }
};

handler.help = ["tt *<link>*", "ttv *<link>*", "tiktokvideo *<link>*"];
handler.tags = ["download"];
handler.command = /^(tt|ttv|tiktokvideo)$/i;

module.exports = handler;