const { tebakkata } = require("@bochilteam/scraper");

let timeout = 60000;

let handler = async (m, { conn, usedPrefix, command }) => {
  conn.tebakkata = conn.tebakkata || {};
  let id = m.chat;

  if (id in conn.tebakkata) {
    return conn.reply(
      m.chat,
      "⚠️ Masih ada soal yang belum dijawab!\nSilakan jawab atau ketik *nyerah*.",
      conn.tebakkata[id][0]
    );
  }

  let json = await tebakkata();

  let caption = `
🎮 *TEBAK KATA*

⏳ Waktu: *60 detik*
❓ Soal: *${json.soal}*
💡 Petunjuk: *${json.jawaban.replace(/[AIUEOaiueo]/g, "_")}*

Balas pesan ini untuk menjawab
Ketik *nyerah* untuk menyerah
`.trim();

  conn.tebakkata[id] = [
    await conn.reply(m.chat, caption, m),
    json,
    setTimeout(() => {
      if (conn.tebakkata[id]) {
        conn.sendMessage(m.chat, {
          text: `⏰ *WAKTU HABIS!*\n\nJawaban: *${json.jawaban}*`
        }, { quoted: m });
        delete conn.tebakkata[id];
      }
    }, timeout)
  ];
};

handler.before = async (m, { conn }) => {
  conn.tebakkata = conn.tebakkata || {};
  let id = m.chat;

  if (!m.text) return;
  if (m.isCommand) return;
  if (!conn.tebakkata[id]) return;

  let json = conn.tebakkata[id][1];

  let reward = db.data.users[m.sender] || { money: 0, limit: 0 };
  db.data.users[m.sender] = reward;

  let jawaban = m.text.toLowerCase().trim();

  if (jawaban === "nyerah" || jawaban === "surrender") {
    clearTimeout(conn.tebakkata[id][2]);

    await conn.sendMessage(m.chat, {
      text: `🏳️ *MENYERAH!*\n\nJawaban: *${json.jawaban}*`
    }, { quoted: conn.tebakkata[id][0] });

    delete conn.tebakkata[id];

  } else if (jawaban === json.jawaban.toLowerCase()) {
    reward.money += 10000;
    reward.limit += 10;

    clearTimeout(conn.tebakkata[id][2]);

    await conn.sendMessage(m.chat, {
      text: `🎉 *BENAR!*

💰 +10.000 Money
🎟️ +10 Limit

🔥 Mantap! Soal berikutnya...`
    }, { quoted: conn.tebakkata[id][0] });

    delete conn.tebakkata[id];

    await conn.sendMessage(m.chat, { text: '.tebakkata' });

  } else {
    conn.sendMessage(m.chat, {
      react: {
        text: "❌",
        key: m.key
      }
    });
  }
};

handler.help = ["tebakkata"];
handler.tags = ["game"];
handler.command = ["tebakkata"];
handler.group = true;

module.exports = handler;