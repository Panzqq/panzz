'use strict';

const Theme = require('../lib/theme');

function formatTheme(theme) {
  return [
    `Nama      : ${theme.name}`,
    `Primary   : ${theme.primary}`,
    `Secondary : ${theme.secondary}`,
    `Accent    : ${theme.accent}`,
    `Success   : ${theme.success}`,
    `Warning   : ${theme.warning}`,
    `Error     : ${theme.error}`
  ].join('\n');
}

let handler = async (m, { args, usedPrefix, command }) => {
  const settings = global.db?.data?.settings || (global.db.data.settings = {});
  const current = Theme.getTheme();
  const presets = Object.keys(Theme.PRESETS);
  const input = String(args[0] || '').toLowerCase();

  if (!input) {
    return m.reply(`
「 BOT THEME 」

${formatTheme(current)}

Preset tersedia:
${presets.map(v => `> ◈ ${v}`).join('\n')}

Cara pakai:
> ${usedPrefix + command} neon
> ${usedPrefix + command} purple
> ${usedPrefix + command} gold
> ${usedPrefix + command} dark
> ${usedPrefix + command} rose
`.trim());
  }

  if (!Theme.PRESETS[input]) {
    return m.reply(`Preset *${input}* tidak ditemukan.\n\nPreset tersedia:\n${presets.map(v => `> ◈ ${v}`).join('\n')}`);
  }

  const selected = Theme.PRESETS[input];
  settings.botTheme = selected;
  Theme.setRuntimeTheme(selected);
  global.db?.markDirty?.();

  return m.reply(`Tema bot berhasil diganti ke *${selected.name}*\n\n${formatTheme(selected)}\n\nRestart tidak wajib, tapi banner terminal akan ikut berubah penuh setelah bot restart.`);
};

handler.help = ['theme', 'settheme'];
handler.tags = ['owner'];
handler.command = /^(theme|settheme)$/i;
handler.owner = true;

module.exports = handler;
