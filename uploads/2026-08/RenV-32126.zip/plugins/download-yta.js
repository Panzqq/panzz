function extractVideoId(input) {
  if (!input) return null;

  const text = String(input).trim();

  if (/^[a-zA-Z0-9_-]{11}$/.test(text)) return text;

  try {
    const url = new URL(text);

    if (url.hostname.includes("youtu.be")) {
      const id = url.pathname.split("/").filter(Boolean)[0];
      return /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
    }

    if (url.hostname.includes("youtube.com")) {
      const v = url.searchParams.get("v");
      if (/^[a-zA-Z0-9_-]{11}$/.test(v)) return v;

      const parts = url.pathname.split("/").filter(Boolean);
      const index = parts.findIndex(v =>
        ["shorts", "embed", "v", "live"].includes(v)
      );

      if (index !== -1 && parts[index + 1]) {
        const id = parts[index + 1];
        return /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
      }
    }
  } catch {}

  const match = text.match(
    /(?:v=|\/shorts\/|youtu\.be\/|embed\/|\/v\/|\/live\/)([a-zA-Z0-9_-]{11})/
  );

  return match ? match[1] : null;
}

function formatDuration(seconds) {
  if (!seconds) return "Unknown";

  seconds = Number(seconds);
  if (isNaN(seconds)) return "Unknown";

  const m = Math.floor(seconds / 60);
  const s = seconds % 60;

  return `${m}:${String(s).padStart(2, "0")}`;
}

function cleanFileName(name = "download") {
  return String(name)
    .replace(/[\\/:*?"<>|]/g, "")
    .replace(/\s+/g, "_")
    .slice(0, 80);
}

function errorText(e) {
  if (!e) return "Unknown error";
  if (typeof e === "string") return e;
  if (typeof e === "object") return e.message || JSON.stringify(e, null, 2);
  return String(e);
}

const download = async (url, quality = "320kbps") => {
  const res = await fetch("https://ytapi.jaky.dev/api/v1/mp3", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      url,
      quality
    })
  });

  if (!res.ok) {
    throw new Error(`HTTP Error: ${res.status} ${res.statusText}`);
  }

  const result = await res.json();

  if (!result.success || !result.data?.downloadUrl) {
    throw result.message || "Gagal mengonversi audio MP3";
  }

  const data = result.data;

  return {
    title: data.title || "YouTube Audio",
    author: data.author || "Unknown",
    link: data.downloadUrl,
    thumbnail: data.thumbnailUrl || `https://i.ytimg.com/vi/${extractVideoId(url)}/hqdefault.jpg`,
    duration: formatDuration(data.duration),
    quality: data.quality || quality,
    filename: `${cleanFileName(data.title || "audio")}.mp3`
  };
};

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`
> [+] *YOUTUBE AUDIO DOWNLOADER*

Gunakan format:
${usedPrefix + command} https://youtube.com/watch?v=xxxx
`.trim());
  }

  if (!extractVideoId(text)) {
    return m.reply("> [!] Link YouTube tidak valid");
  }

  try {
    const result = await download(text);

    const caption = `
> [+] *YTA DOWNLOADER (MP3)*

> [ JUDUL   ] ${result.title}
> [ CHANNEL ] ${result.author}
> [ KUALITAS] ${result.quality}
> [ DURASI  ] ${result.duration}
> [ LINK    ] ${text}

> [+] Sedang mengirim audio...
`.trim();

    await conn.sendButtonLoc(
      m.chat,
      [{ id: `.ytmp4 ${text}`, text: "[ Video ]" }],
      caption,
      `[ ${namebot} :: ${nameown || "Owner"} ]`,
      m,
      {
        mentions: [m.sender],
        thumbUrl: result.thumbnail || global.thumb,
        name: namebot || "Renvy",
        address: "YouTube Audio"
      }
    );

    // Kirim langsung sebagai file Audio MP3 murni
    await conn.sendMessage(
      m.chat,
      {
        audio: { url: result.link },
        mimetype: "audio/mpeg",
        fileName: result.filename,
        ptt: false
      },
      { quoted: typeof ftroli !== "undefined" ? ftroli : m }
    );

  } catch (e) {
    console.error(e);

    m.reply(`
> [!] Gagal mengambil audio
> ${errorText(e)}
`.trim());
  }
};

handler.help = ["yta"];
handler.tags = ["download"];
handler.command = ["yta", "ytmp3"];
handler.limit = true;

module.exports = handler;