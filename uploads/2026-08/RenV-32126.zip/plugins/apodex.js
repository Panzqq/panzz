/**
 * main.js - Apodex.ai Full SDK Single File - 100% NO BROWSER HEADLESS
 * Gabungan apodex_full_sdk.js (72 endpoints) + apodex_auto_cookie.js (TempMail 7 endpoints + auto fresh)
 * Pure Node.js: hanya https/http/crypto/fs/path
 * Usage:
 *   const {ApodexClient, createFreshAccount, scrapeApodex} = require("./main.js");
 *   // atau CLI: node main.js [domains|generate|inbox|fresh|chat "prompt"]
 *   // auto-refresh: new ApodexClient({autoRefresh:true})
 */
const https = require("https");
const http = require("http");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

const TEMPMail_BASE = "https://api.justlann.my.id/api/tools/tempmail";
const DEFAULT_DEVICE_ID = "01a04765-c7fb-74ca-a840-cd562144e213";

// --- SDK Helpers & Client ---


// ---------------------------------------------------------------------------
// Error
// ---------------------------------------------------------------------------
class ApiError extends Error {
  constructor({ message, status, endpoint, code, data }) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.endpoint = endpoint;
    this.code = code;
    this.data = data;
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function genUUID() { return crypto.randomUUID(); }
function getDefaultDeviceId(cookieDeviceId) {
  if (cookieDeviceId) return cookieDeviceId;
  // emulate FingerprintJS: visitorId padded 32 hex -> uuid format `1480z_1wsqmrc.js:658138:ey()`
  // fallback to randomUUID
  return genUUID();
}
function buildQuery(params) {
  if (!params) return '';
  const o = {};
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null) o[k] = String(v);
  const qs = new URLSearchParams(o).toString();
  return qs ? `?${qs}` : '';
}
function createMultipart(fields, files) {
  const boundary = '----ApodexFormBoundary' + crypto.randomBytes(12).toString('hex');
  const parts = [];
  for (const [k, v] of Object.entries(fields || {})) {
    if (v === undefined) continue;
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
  }
  for (const f of files || []) {
    // f: {field, filename, contentType, data: Buffer}
    parts.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${f.field}"; filename="${f.filename}"\r\nContent-Type: ${f.contentType || 'application/octet-stream'}\r\n\r\n`));
    parts.push(Buffer.isBuffer(f.data) ? f.data : Buffer.from(f.data));
    parts.push(Buffer.from(`\r\n`));
  }
  parts.push(Buffer.from(`--${boundary}--\r\n`));
  return { body: Buffer.concat(parts), boundary };
}

// ---------------------------------------------------------------------------
// Core Client - mirrors 1480z_1wsqmrc.js:365270 buildRequestConfig + b()
// ---------------------------------------------------------------------------
class ApodexClient {
  constructor(options = {}) {
    this.baseHostname = options.hostname || 'www.apodex.ai';
    this.basePath = options.basePath || '/api';
    this.cookie = options.cookie || '';
    this.token = options.token || null; // Bearer from mirage-auth-store `2q7821z2r-s6w.js:348340`
    this.deviceID = options.deviceID || getDefaultDeviceId(options.deviceID);
    this.deviceType = options.deviceType || '7';
    this.userAgent = options.userAgent || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36';
    this.timeoutMs = options.timeoutMs || 30000;
    // load token from env/localStorage file fallback if not provided
    if (!this.token && options.tokenFile) {
      try { const j = JSON.parse(fs.readFileSync(options.tokenFile, 'utf8')); this.token = j.state?.token || j.token || null; } catch {}
    }
    // AUTO-REFRESH: jika true, setiap 401 / limit / expired langsung generate cookie baru via TempMail (no headless)
    this.autoRefresh = options.autoRefresh || false;
    this.autoRefreshOptions = options.autoRefreshOptions || {};
    // default simpan ke file ini jika autoRefresh tanpa saveTo
    if (this.autoRefresh && !this.autoRefreshOptions.saveTo) {
      this.autoRefreshOptions.saveTo = options.saveTo || path.join(__dirname, 'apodex_account.json');
    }
    this._refreshing = null; // dedup concurrent refresh
  }

  setToken(t) { this.token = t; }
  setCookie(c) { this.cookie = c; }
  setDeviceID(d) { this.deviceID = d; }

  _headers(extra = {}, requireAuth = true) {
    const h = {
      'User-Agent': this.userAgent,
      'Accept': 'application/json, text/event-stream, */*',
      'deviceType': this.deviceType,
      'deviceID': this.deviceID,
      ...extra
    };
    if (this.cookie) h['Cookie'] = this.cookie;
    if (requireAuth && this.token) h['Authorization'] = `Bearer ${this.token}`;
    return h;
  }

  // --- auto-refresh helpers (NO HEADLESS) ---
  _isRetryableError(err){
    if(!err) return false;
    const code = String(err.code || err.data?.code || err.data?.data?.code || '');
    const status = err.status;
    const msg = String(err.message || '');
    
    // Heavy access denied is institutional/preview only, fresh account won't grant heavy
    if (code === 'HEAVY_ACCESS_DENIED' || /HEAVY_ACCESS_DENIED/i.test(msg)) return false;

    // 1. Expired / Unauthorized (401)
    if (status === 401) return true;
    if (/UNAUTHORIZED|TOKEN_EXPIRED|SESSION_EXPIRED|AUTH_REQUIRED|ORG_CONTEXT_INVALID|AUTHENTICATION_REQUIRED/i.test(code)) return true;
    if (/Authorization header missing|Unauthorized|session.*expired|token.*expired|login required|not authenticated/i.test(msg)) return true;

    // 2. Rate limits or Quota / Trial exhausted (429)
    if (status === 429) {
      if (/PASSWORDLESS_SEND_RATE_LIMITED/i.test(code) || /PASSWORDLESS_SEND_RATE_LIMITED/i.test(msg)) return false;
      return true;
    }

    // 3. Quota / Trial / Usage exhausted in error codes or messages
    if (/LIMIT_EXCEEDED|EXHAUSTED|TRIAL_ENDED|TRIAL_USED|QUOTA_EXCEEDED|USAGE_LIMIT/i.test(code)) return true;
    if (/rate limit|limit exceeded|trial.*used up|usage limit|quota exceeded|exceeded daily/i.test(msg)) return true;

    return false;
  }

  async _doAutoRefresh(){
    if(this._refreshing) return this._refreshing;
    this._refreshing = (async()=>{
      console.log('[AUTO] Cookie/token expired atau limit habis -> generate fresh via TempMail (no headless)...');
      const account = await createFreshAccount({
        deviceID: this.deviceID,
        verbose: this.autoRefreshOptions.verbose || false,
        timeoutMs: this.autoRefreshOptions.timeoutMs || 60000,
        saveTo: this.autoRefreshOptions.saveTo,
        domain: this.autoRefreshOptions.domain,
      });
      this.token = account.token;
      this.cookie = account.fullCookie;
      this.deviceID = account.deviceID;
      this._account = account;
      console.log(`[AUTO] Fresh account: ${account.email} | token ${account.token.slice(0,12)}... | saved to ${this.autoRefreshOptions.saveTo}`);
      return account;
    })();
    try{ const r=await this._refreshing; return r; } finally{ this._refreshing=null; }
  }

  /**
   * Generic request - mirrors 365270:b() error mapping
   * Jika autoRefresh=true dan error retryable -> auto generate baru lalu retry 1x
   */
  async request(endpoint, opts = {}) {
    const method = (opts.method || 'GET').toUpperCase();
    const requireAuth = opts.requireAuth !== undefined ? opts.requireAuth : true;
    const params = opts.params;
    const body = opts.body;
    const extraHeaders = opts.headers || {};
    const timeoutMs = opts.timeoutMs || this.timeoutMs;
    const isFormData = opts.isFormData;
    const _attempt = opts._attempt || 0;

    let fullPath = this.basePath + endpoint + buildQuery(params);
    let headers = this._headers(extraHeaders, requireAuth);
    let payload = null;

    if (body !== undefined && body !== null && method !== 'GET') {
      if (isFormData) {
        // body is {fields, files} -> multipart
        const mp = createMultipart(body.fields, body.files);
        payload = mp.body;
        headers['Content-Type'] = `multipart/form-data; boundary=${mp.boundary}`;
        headers['Content-Length'] = payload.length;
      } else if (Buffer.isBuffer(body) || typeof body === 'string') {
        payload = Buffer.isBuffer(body) ? body : Buffer.from(body);
        if (!headers['Content-Type']) headers['Content-Type'] = 'application/octet-stream';
        headers['Content-Length'] = payload.length;
      } else {
        const json = JSON.stringify(body);
        payload = Buffer.from(json);
        headers['Content-Type'] = 'application/json';
        headers['Content-Length'] = payload.length;
      }
    } else {
      // ensure json accept for GET
      if (!headers['Content-Type']) headers['Content-Type'] = 'application/json';
    }

    const doRequest = () => new Promise((resolve, reject) => {
      const reqOptions = {
        hostname: this.baseHostname,
        port: 443,
        path: fullPath,
        method,
        headers
      };
      const req = https.request(reqOptions, (res) => {
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          let parsed = null;
          try { parsed = data ? JSON.parse(data) : null; } catch { parsed = data; }
          if (!res.statusCode || res.statusCode < 200 || res.statusCode >= 300) {
            // map error like 365270:g()
            let message = `HTTP ${res.statusCode}`;
            let code = undefined;
            if (parsed && typeof parsed === 'object') {
              if (typeof parsed.code === 'string') { code = parsed.code; message = parsed.message || message; }
              else if (typeof parsed.detail === 'string') message = parsed.detail;
              else if (Array.isArray(parsed.detail) && parsed.detail[0]?.msg) message = parsed.detail[0].msg;
              else if (typeof parsed.message === 'string') message = parsed.message;
            } else if (typeof parsed === 'string' && parsed) message = parsed.slice(0, 500);
            // handle ORG_CONTEXT_INVALID side-effect note
            return reject(new ApiError({ message, status: res.statusCode, endpoint, code, data: parsed }));
          }
          // unwrap {success:true, data:...} like 365270:b()
          if (parsed && typeof parsed === 'object' && parsed.success === true && 'data' in parsed) {
            return resolve(parsed.data);
          }
          if (parsed && typeof parsed === 'object' && parsed.success === false) {
            const code = parsed.code;
            const msg = parsed.detail || parsed.message || 'API error';
            return reject(new ApiError({ message: msg, status: res.statusCode, endpoint, code, data: parsed }));
          }
          resolve(parsed);
        });
      });
      req.on('error', e => reject(new ApiError({ message: e.message, status: 0, endpoint })));
      if (timeoutMs) {
        req.setTimeout(timeoutMs, () => {
          req.destroy(new Error(`Request timeout after ${timeoutMs}ms`));
        });
      }
      if (payload) req.write(payload);
      req.end();
    });

    try {
      return await doRequest();
    } catch (err) {
      if (this.autoRefresh && _attempt===0 && this._isRetryableError(err)) {
        try {
          await this._doAutoRefresh();
          // rebuild headers with new token/cookie
          const newHeaders = this._headers(extraHeaders, requireAuth);
          // re-prepare payload headers if needed
          if (payload && !isFormData && typeof body === 'object' && !(Buffer.isBuffer(body))) {
            // headers already set above, reuse
          }
          // retry once
          return await this.request(endpoint, { ...opts, _attempt: 1, headers: newHeaders });
        } catch (refreshErr) {
          // if refresh itself fails, throw original error with context
          err.message += ` | auto-refresh failed: ${refreshErr.message}`;
          throw err;
        }
      }
      throw err;
    }
  }

  // convenience wrappers mirrors 365270:get/post/put/patch/del
  get(ep, opts) { return this.request(ep, { ...opts, method: 'GET' }); }
  post(ep, body, opts) { return this.request(ep, { ...opts, method: 'POST', body }); }
  put(ep, body, opts) { return this.request(ep, { ...opts, method: 'PUT', body }); }
  patch(ep, body, opts) { return this.request(ep, { ...opts, method: 'PATCH', body }); }
  del(ep, opts) { return this.request(ep, { ...opts, method: 'DELETE' }); }

  // ---------------------------------------------------------------------------
  // App Config `06c9-jbblwde8.js:946634`
  // ---------------------------------------------------------------------------
  appConfig = {
    get: () => this.get('/config', { requireAuth: false }),
  };

  // ---------------------------------------------------------------------------
  // Chat - core SSE `apodex_scraper.js:27-104` enhanced
  // ---------------------------------------------------------------------------
  chat = {
    /**
     * Stream chat - full featured. Mirrors frontend `2ri6vq7_7gkwp.js` pendingMessage + `apodex_scraper.js:9`
     * options: {mode, version, files, libraryItems, sceneId, useMemory, chatId, messageId, onDelta, onEvent}
     */
    stream: (prompt, options = {}) => {
      const chatId = options.chatId || genUUID();
      const messageId = options.messageId || genUUID();
      const modeMap = { standard: 'standard', pro: 'pro', heavy: 'agent-swarm-gv', 'agent-swarm': 'agent-swarm', 'agent-swarm-gv': 'agent-swarm-gv' };
      const rawMode = options.mode || 'standard';
      const apiMode = modeMap[rawMode] || rawMode;
      const version = options.version || '1.1';
      // Build payload compatible with both old scraper and new frontend
      const payloadObj = {
        messages: [{ role: 'user', content: prompt }],
        chat_id: chatId,
        message_id: messageId,
        mode: apiMode,
        version: version,
      };
      // optional extras discovered in 2ri6...js
      if (options.files && options.files.length) payloadObj.files = options.files; // [{file_id, ...}] legacy
      if (options.file_ids && options.file_ids.length) payloadObj.file_ids = options.file_ids; // correct for vision (probe: file_ids works)
      if (options.fileIds && options.fileIds.length) payloadObj.file_ids = options.fileIds;
      if (options.libraryItems) payloadObj.library_items = options.libraryItems;
      if (options.sceneId) payloadObj.scene_id = options.sceneId;
      if (options.useMemory !== undefined) payloadObj.use_memory = options.useMemory;
      // allow extra passthrough
      if (options.extra) Object.assign(payloadObj, options.extra);

      const payload = JSON.stringify(payloadObj);
      // chat/stream: guest OK (session cookie only) but pro/heavy requires Bearer if logged in.
      // Kirim Authorization jika token tersedia, tanpa memaksa requireAuth.
      const baseHeaders = {
        'Content-Type': 'application/json',
        'Accept': 'text/event-stream, application/json, text/plain, */*',
        'Origin': 'https://www.apodex.ai',
        'Referer': `https://www.apodex.ai/chat/${chatId}`,
        'Content-Length': Buffer.byteLength(payload)
      };
      if (this.token) baseHeaders['Authorization'] = `Bearer ${this.token}`;
      const headers = this._headers(baseHeaders, false); // false = tidak wajib token, tapi sudah inject manual di atas

      const doChatRequest = (hdrs) => new Promise((resolve, reject) => {
        const req = https.request({
          hostname: this.baseHostname,
          port: 443,
          path: this.basePath + '/chat/stream',
          method: 'POST',
          headers: hdrs
        }, (res) => {
          if (res.statusCode !== 200) {
            let errBody = '';
            res.on('data', c => errBody += c);
            res.on('end', () => {
              let parsed=null; try{parsed=JSON.parse(errBody);}catch{}
              const code = parsed?.code || parsed?.data?.code;
              reject(new ApiError({ message: `chat/stream HTTP ${res.statusCode}: ${errBody.slice(0,800)}`, status: res.statusCode, endpoint: '/chat/stream', code, data: parsed || errBody }));
            });
            return;
          }
          let buffer = '';
          let finalAnswer = '';
          let assembled = '';
          let events = [];

          res.on('data', (chunk) => {
            buffer += chunk.toString();
            // SSE frames separated by \n\n, but we handle line by line robustly like 365270
            // Keep incomplete tail
            const parts = buffer.split('\n');
            buffer = parts.pop(); // incomplete

            // state machine: lines may contain "event: X" then "data: Y"
            let pendingEvent = null;
            for (let i = 0; i < parts.length; i++) {
              const line = parts[i].trim();
              if (!line) { pendingEvent = null; continue; }
              if (line.startsWith('event:')) {
                pendingEvent = line.slice(6).trim();
              } else if (line.startsWith('data:')) {
                const dataStr = line.slice(5).trim();
                if (dataStr === '[DONE]') {
                  // ignore
                  continue;
                }
                try {
                  const parsed = JSON.parse(dataStr);
                  const ev = { event: pendingEvent || 'message', data: parsed };
                  events.push(ev);
                  if (options.onEvent) options.onEvent(ev);
                  if (pendingEvent === 'final_answer' && parsed.content) {
                    finalAnswer = parsed.content;
                  } else if (pendingEvent === 'message' && parsed.delta?.content) {
                    assembled += parsed.delta.content;
                    if (options.onDelta) options.onDelta(parsed.delta.content, parsed);
                    else process.stdout.write(parsed.delta.content);
                  } else if (pendingEvent === 'end_of_agent' && parsed.run_result?.final_content) {
                    finalAnswer = parsed.run_result.final_content;
                  } else if (!pendingEvent && parsed.delta?.content) {
                    // fallback if server omits event
                    assembled += parsed.delta.content;
                    if (options.onDelta) options.onDelta(parsed.delta.content, parsed);
                  }
                } catch (e) {
                  // non-json data, treat as text
                  if (pendingEvent === 'message') {
                    assembled += dataStr;
                    if (options.onDelta) options.onDelta(dataStr, {});
                  }
                }
                pendingEvent = null;
              } else if (line.startsWith(':')) {
                // heartbeat comment
              }
            }
          });

          res.on('end', () => {
            // flush remaining buffer if it contains a complete data line
            if (buffer.trim().startsWith('data:')) {
              try {
                const dataStr = buffer.trim().slice(5).trim();
                const parsed = JSON.parse(dataStr);
                if (parsed.delta?.content) assembled += parsed.delta.content;
                if (parsed.content) finalAnswer = parsed.content;
              } catch {}
            }
            const result = finalAnswer || assembled;
            resolve({ chatId, messageId, content: result, rawEvents: events, assembled, finalAnswer });
          });
        });
        req.on('error', e => reject(new ApiError({ message: e.message, status: 0, endpoint: '/chat/stream' })));
        if (this.timeoutMs) req.setTimeout(this.timeoutMs, () => req.destroy(new Error('chat/stream timeout')));
        req.write(payload);
        req.end();
      });

      // wrapper dengan auto-refresh untuk chat
      const exec = (hdrs, attempt=0) => doChatRequest(hdrs).catch(async (err)=>{
        if(this.autoRefresh && attempt===0 && this._isRetryableError(err)){
          await this._doAutoRefresh();
          const newHdrs = { ...hdrs };
          if(this.token) newHdrs['Authorization'] = `Bearer ${this.token}`;
          if(this.cookie) newHdrs['Cookie'] = this.cookie;
          return exec(newHdrs, 1);
        }
        throw err;
      });
      return exec(headers);
    },
    // Alias legacy
    scrape: function(prompt, opts) { return this.stream(prompt, opts).then(r => r.content); }
  };

  // ---------------------------------------------------------------------------
  // Auth `19il4rvdics5g.js:160293`
  // ---------------------------------------------------------------------------
  auth = {
    login: (email, password) => this.post('/auth/login', { email, password }, { requireAuth: false }),
    logout: () => this.post('/auth/logout', {}),
    getUserInfo: () => this.get('/auth/get_user_info'),
    exchangeOauthCode: (code, state) => this.post('/auth/oauth/exchange', { code, state }, { requireAuth: false }),
    loginWithOAuth: (provider) => { // redirects: `+ `19il4rvdics5g.js:loginWithOAuth`
      // In browser: window.location.href = `${base}/auth/oauth/authorize?provider=${provider}`
      return `${'https://' + this.baseHostname + this.basePath}/auth/oauth/authorize?provider=${provider}`;
    },
    updateProfile: (data) => this.post('/auth/profile', data),
    uploadAvatar: async (filePath, filename = 'avatar.jpg') => {
      const data = fs.readFileSync(filePath);
      const ext = path.extname(filename).toLowerCase();
      const ct = ext === '.png' ? 'image/png' : ext === '.jpg' || ext === '.jpeg' ? 'image/jpeg' : 'application/octet-stream';
      return this.request('/auth/avatar', {
        method: 'POST',
        body: { fields: {}, files: [{ field: 'file', filename, contentType: ct, data }] },
        isFormData: true,
        requireAuth: true
      });
    },
    sendDeleteAccountCode: (email) => this.post('/app/auth/send-code', { email, type: 'delete_account' }, { requireAuth: false, headers: { 'Accept-Language': 'en' } }),
    deleteAccount: (code) => this.post('/app/auth/delete-account', { code }),
    sendResetPasswordCode: (email) => this.post('/app/auth/send-code', { email, type: 'reset_password' }, { requireAuth: false, headers: { 'Accept-Language': 'en' } }),
    verifyResetCode: (email, code) => this.post('/app/auth/v2/verify-reset-code', { email, code }, { requireAuth: false, headers: { 'Accept-Language': 'en' } }),
    resetPassword: (reset_token, password) => this.post('/app/auth/v2/reset-password', { reset_token, password }, { requireAuth: false, headers: { 'Accept-Language': 'en' } }),
    sendPasswordlessCode: (email) => this.post('/auth/passwordless/send-code', { email }, { requireAuth: false }),
    verifyPasswordless: (email, code) => this.post('/auth/passwordless/verify-login', { email, code }, { requireAuth: false }),
    switchOrgContext: (org_id) => this.post('/auth/switch-context', { org_id }),
  };

  // ---------------------------------------------------------------------------
  // Account linking `1ecq2qpav_ree.js`
  // ---------------------------------------------------------------------------
  account = {
    linkOAuthAuthorize: (provider) => this.post('/account/link-oauth/authorize', { provider }),
    linkOAuthExchange: (code, state) => this.post('/account/link-oauth/exchange', { code, state }),
    getLinkedAccounts: () => this.get('/account/linked-accounts'),
    getMergeableAccounts: () => this.get('/account/mergeable-accounts'),
    mergeAllAccounts: () => this.post('/account/merge-all', {}),
    sendBindEmailCode: (email) => this.post('/account/link-email/send-code', { email }),
    verifyBindEmailCode: (email, code) => this.post('/account/link-email/verify', { email, code }),
    mergeFromBinding: (merge_token) => this.post('/account/merge-from-binding', { merge_token }),
    unlinkOAuth: (provider) => this.del(`/account/link-oauth/${provider}`),
  };

  // ---------------------------------------------------------------------------
  // Upload `2lmtqrc4rkmbl.js:323149`
  // ---------------------------------------------------------------------------
  upload = {
    presigned: (filename, content_type, file_size) => this.post('/upload/presigned', { filename, content_type, file_size }),
    confirm: (file_id) => this.post('/upload/confirm', { file_id }),
    getDownloadUrl: (file_id) => this.post('/upload/download', { file_id }).then(r => r.download_url || r),
    /**
     * Full upload pipeline: presigned -> PUT -> confirm
     * options: {onProgress}
     */
    uploadFile: async (filePath, onProgress) => {
      const stat = fs.statSync(filePath);
      const filename = path.basename(filePath);
      const ext = path.extname(filename).toLowerCase();
      const mimeMap = { '.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.pdf':'application/pdf','.txt':'text/plain','.md':'text/markdown','.docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','.doc':'application/msword','.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','.xls':'application/vnd.ms-excel','.pptx':'application/vnd.openxmlformats-officedocument.presentationml.presentation','.ppt':'application/vnd.ms-powerpoint' };
      const content_type = mimeMap[ext] || 'application/octet-stream';
      const pres = await this.upload.presigned(filename, content_type, stat.size);
      const upload_url = pres.upload_url;
      const file_id = pres.file_id;
      // PUT to TOS via https
      await new Promise((resolve, reject) => {
        const data = fs.readFileSync(filePath);
        const u = new URL(upload_url);
        const req = https.request({
          hostname: u.hostname,
          path: u.pathname + u.search,
          method: 'PUT',
          headers: { 'Content-Type': content_type, 'Content-Length': data.length }
        }, (res) => {
          let body = '';
          res.on('data', c => body += c);
          res.on('end', () => {
            if (res.statusCode >= 200 && res.statusCode < 300) resolve();
            else reject(new ApiError({ message: `TOS upload failed ${res.statusCode}: ${body.slice(0,500)}`, status: res.statusCode, endpoint: '/upload/presigned:PUT' }));
          });
        });
        req.on('error', reject);
        if (onProgress) onProgress({ loaded: data.length, total: data.length, percentage: 100 });
        req.write(data);
        req.end();
      });
      const confirmed = await this.upload.confirm(file_id);
      return confirmed;
    }
  };

  // ---------------------------------------------------------------------------
  // Library `06in9e177xd48.js` + 401331
  // ---------------------------------------------------------------------------
  library = {
    list: (opts = {}) => this.post('/library/items', { scope: opts.scope, limit: opts.limit, offset: opts.offset, quotaOnly: opts.quotaOnly, sleeping_only: opts.sleeping_only }),
    picker: (opts = {}) => this.post('/library/picker', { query: opts.query, limit: opts.limit }),
    /**
     * upload: POST /library/upload {file_id, filename} - both required (spesifik: 422 if missing filename)
     * contoh: await client.upload.uploadFile(localPath) -> {file_id, filename}; await client.library.upload(file_id, filename)
     */
    upload: (fileId, filename) => {
      if (typeof fileId === 'object' && fileId !== null) {
        // allow {file_id, filename}
        return this.post('/library/upload', fileId);
      }
      // require filename spesifik - probe: 422 Field required filename
      if (!filename) throw new Error('library.upload requires filename: client.library.upload(file_id, filename)');
      return this.post('/library/upload', { file_id: fileId, filename });
    },
    save: (data) => this.post('/library/save', data),
    remove: (itemId, scope) => this.post(`/library/items/${itemId}/remove`, scope ? { scope } : {}),
    download: (scope, filePath) => this.post('/library/files/download', { scope, path: filePath }),
    // coach store not needed server-side
  };

  // ---------------------------------------------------------------------------
  // Memory `3-8t1ygv6xy62.js:148320`
  // ---------------------------------------------------------------------------
  memory = {
    list: () => this.get('/memory/items'),
    create: (text, version) => this.post('/memory/items', { text, version }),
    update: (id, text, version) => this.patch(`/memory/items/${id}`, { text, version }),
    delete: (id, version) => this.del(`/memory/items/${id}?version=${version}`),
    status: () => this.get('/memory/status'),
    pauseBatch: () => this.post('/memory/batch/pause', {}),
    resumeBatch: () => this.post('/memory/batch/resume', {}),
    reprocess: () => this.post('/memory/reprocess', {}),
    getSettings: () => this.get('/memory/settings'),
    updateSettings: (data) => this.put('/memory/settings', data),
    citations: (id) => this.get(`/memory/citations/${id}`),
  };

  // ---------------------------------------------------------------------------
  // History `3-8t1ygv6xy62.js:850167`
  // ---------------------------------------------------------------------------
  history = {
    list: (opts = {}) => this.get('/auth/history', { params: { page: opts.page || 1, page_size: opts.page_size || 30, filter: opts.filter || 'active', project_id: opts.project_id } }),
    batch: (data) => this.post('/auth/history/batch', data),
    pin: (chatIds) => this.post('/auth/history/batch', { action: 'pin', chatIds }),
    unpin: (chatIds) => this.post('/auth/history/batch', { action: 'unpin', chatIds }),
    archive: (chatIds) => this.post('/auth/history/batch', { action: 'archive', chatIds }),
    unarchive: (chatIds) => this.post('/auth/history/batch', { action: 'unarchive', chatIds }),
    moveToProject: (chatIds, project_id) => this.post('/auth/history/batch', { action: 'move_to_project', chatIds, project_id }),
    delete: (chatId) => this.del(`/auth/history/${chatId}`),
    rename: (chatId, title) => this.patch(`/auth/history/${chatId}`, { title }),
    copy: (chatId) => this.post(`/auth/history/${chatId}/copy`, {}),
    copyPartial: (chatId, messageIndex, title) => this.post(`/auth/history/${chatId}/copy-partial`, { messageIndex, title }),
    /**
     * search: GET /auth/history/search?q=... (spesifik: param harus 'q' bukan 'query', 422 Field required if missing)
     * contoh: await client.history.search({q:"test"}) atau {query:"test"} akan di-map ke q
     */
    search: (params={}) => {
      const p = { ...params };
      if (p.query && !p.q) { p.q = p.query; delete p.query; }
      if (p.keyword && !p.q) { p.q = p.keyword; delete p.keyword; }
      if (!p.q) throw new Error("history.search requires param 'q' (contoh: {q:'test'})");
      return this.get('/auth/history/search', { params: p });
    },
  };

  // ---------------------------------------------------------------------------
  // Scenes `95170` + `410478`
  // ---------------------------------------------------------------------------
  scene = {
    configs: (locale) => this.get('/scene/configs', { headers: locale ? { 'Accept-Language': locale } : {}, requireAuth: false }),
  };

  // ---------------------------------------------------------------------------
  // Org `06in9e177xd48.js` - all POST with {org_id?}
  // ---------------------------------------------------------------------------
  org = {
    listContexts: () => this.post('/org/list-org-contexts', {}),
    getInviteInfo: (data) => this.post('/org/get-invite-info', data),
    acceptInvite: (data) => this.post('/org/accept-invite', data),
    listPendingConfirmations: () => this.post('/org/list-pending-confirmations', {}),
    confirmPending: (data) => this.post('/org/confirm-pending-org', data),
    leave: (data) => this.post('/org/leave-org', data || {}),
    getCurrent: () => this.post('/org/get-current-org', {}),
    listMembers: (data) => this.post('/org/list-org-members', data || {}),
    updateMemberQuota: (data) => this.post('/org/update-member-quota', data),
    removeMember: (data) => this.post('/org/remove-member', data),
    createInvite: (data) => this.post('/org/create-org-invite', data),
    revokeInvite: (data) => this.post('/org/revoke-org-invite', data),
    usageOverview: (data) => this.post('/org/get-org-usage-overview', data || {}),
  };

  // ---------------------------------------------------------------------------
  // VIP / Billing `3-8t1ygv6xy62.js`
  // ---------------------------------------------------------------------------
  vip = {
    info: () => this.get('/vip/info'),
    plans: () => this.get('/vip/plans'),
    subscribe: (data) => this.post('/vip/subscribe', data || {}),
    unsubscribe: (data) => this.post('/vip/unsubscribe', data || {}),
    boost: (data) => this.post('/vip/boost', data || {}),
    creditTransactions: (data) => this.post('/vip/credit-transactions', data || {}),
    invoices: (data) => this.post('/vip/invoices', data || {}),
  };

  // ---------------------------------------------------------------------------
  // Projects `1e7rb2vwra55i.js`
  // ---------------------------------------------------------------------------
  project = {
    list: () => this.get('/auth/projects'),
    create: (data) => this.post('/auth/projects', data),
  };

  // ---------------------------------------------------------------------------
  // ASR `0pdf0ep0fcda9.js:908390`
  // ---------------------------------------------------------------------------
  asr = {
    transcribe: async (filePath, opts = {}) => {
      const data = fs.readFileSync(filePath);
      const filename = path.basename(filePath) || 'recording.webm';
      return this.request('/asr/transcribe', {
        method: 'POST',
        body: { fields: opts.language ? { language: opts.language } : {}, files: [{ field: 'file', filename, contentType: 'audio/webm', data }] },
        isFormData: true
      }).then(r => r.text || r);
    }
  };

  // ---------------------------------------------------------------------------
  // General Feedback `1e7rb2vwra55i.js` - spesifik: butuh {category, title, description}
  // category: feature_request|bug_report|experience|billing|other ; billing butuh billing_subcategory
  // ---------------------------------------------------------------------------
  feedback = {
    /**
     * send: POST /general-feedback {category, title, description, billing_subcategory?}
     * contoh sukses: {category:"feature_request", title:"SDK Test", description:"test feedback SDK"}
     */
    send: (data) => {
      if(!data.category) throw new Error("feedback.send requires category: feature_request|bug_report|experience|billing|other");
      if(!data.title) throw new Error("feedback.send requires title");
      if(!data.description) throw new Error("feedback.send requires description");
      return this.post('/general-feedback', data);
    },
    uploadImage: async (filePath, filename) => {
      const data = fs.readFileSync(filePath);
      const fn = filename || path.basename(filePath);
      return this.request('/general-feedback/upload-image', {
        method: 'POST',
        body: { fields: {}, files: [{ field: 'file', filename: fn, contentType: 'image/png', data }] },
        isFormData: true
      });
    }
  };

  // ---------------------------------------------------------------------------
  // User settings `1e7rb2vwra55i.js`
  // ---------------------------------------------------------------------------
  user = {
    getNotificationSettings: () => this.get('/user/notification-settings'),
    updateNotificationSettings: (data) => this.put('/user/notification-settings', data),
    getPrivacySettings: () => this.get('/user/privacy-settings'),
    updatePrivacySettings: (data) => this.put('/user/privacy-settings', data),
    getVapidKey: () => this.get('/user/vapid-public-key', { requireAuth: false }),
    createPushSubscription: (data) => this.post('/user/push-subscription', data),
    deletePushSubscription: (data) => this.del('/user/push-subscription', { body: data }),
  };
}

// ---------------------------------------------------------------------------
// Legacy compat wrapper for apodex_scraper.js
// ---------------------------------------------------------------------------
async function scrapeApodex(prompt, options = {}, clientOptions = {}) {
  const cookie = options.cookie || clientOptions.cookie || process.env.APODEX_COOKIE || `_fbp=fb.1.1787904248638.720618595950320098.AQYAAQIB; _ga=GA1.1.1985936803.1787904248; apx-signed-in=1; guest_id=812d63c3abb74950a6967d92b579d836; session=94b42cbe-3fbc-43cd-9944-7d8199c679aa`;
  const deviceID = options.deviceID || clientOptions.deviceID || process.env.APODEX_DEVICE_ID || '01a04765-c7fb-74ca-a840-cd562144e213';
  const client = new ApodexClient({ cookie, deviceID, token: options.token || clientOptions.token, timeoutMs: options.timeoutMs });
  const res = await client.chat.stream(prompt, options);
  return res.content;
}


// --- TempMail + Auto Fresh (no headless) ---
/**
 * Apodex Auto Cookie - Fresh session generator via TempMail + Apodex Passwordless - NO HEADLESS
 * Base TempMail: https://api.justlann.my.id/api/tools/tempmail  (provided by user)
 * Apodex: https://www.apodex.ai/api
 * Flow: generate tempmail -> send-code -> poll inbox OTP -> verify-login -> token + cookie
 * 100% HTTP API murni (https/http + crypto) - TANPA puppeteer/playwright/browser/chromium/jsdom/headless
 * Sesuai request: pastikan nanti no browser headless yaaa
 */

const APODEX_HOST = 'www.apodex.ai';
const APODEX_BASE = '/api';

// ---------------------------------------------------------------------------
// tiny fetch helper (no external deps)
// ---------------------------------------------------------------------------
function fetchJson(url, opts = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'https:' ? https : http;
    const method = opts.method || 'GET';
    const headers = opts.headers || {};
    const body = opts.body;
    if (body) headers['Content-Length'] = Buffer.byteLength(body);
    if (!headers['User-Agent']) headers['User-Agent'] = 'Mozilla/5.0';
    const req = lib.request({ hostname: u.hostname, path: u.pathname + u.search, port: u.port || (u.protocol === 'https:' ? 443 : 80), method, headers }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        let parsed = null;
        try { parsed = JSON.parse(data); } catch { parsed = data; }
        resolve({ status: res.statusCode, headers: res.headers, body: parsed, raw: data });
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

function apodexRequest(endpoint, { method='GET', body, cookie, deviceID, token } = {}) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'User-Agent': 'Mozilla/5.0',
      'deviceType': '7',
      'deviceID': deviceID || DEFAULT_DEVICE_ID,
    };
    if (cookie) headers['Cookie'] = cookie;
    if (token) headers['Authorization'] = `Bearer ${token}`;
    if (payload) headers['Content-Length'] = Buffer.byteLength(payload);
    const opts = { hostname: APODEX_HOST, path: APODEX_BASE + endpoint, port: 443, method, headers };
    const req = https.request(opts, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        let parsed = null;
        try { parsed = JSON.parse(data); } catch { parsed = data; }
        resolve({ status: res.statusCode, headers: res.headers, body: parsed, raw: data });
      });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// ---------------------------------------------------------------------------
// TempMail helpers
// ---------------------------------------------------------------------------
async function getDomains() {
  const r = await fetchJson(`${TEMPMail_BASE}/domains`);
  if (r.body?.data?.domains) return r.body.data.domains;
  throw new Error('Failed to get domains: ' + JSON.stringify(r.body).slice(0,500));
}

async function generateEmail(domain) {
  const url = domain ? `${TEMPMail_BASE}/generate?domain=${encodeURIComponent(domain)}` : `${TEMPMail_BASE}/generate`;
  const r = await fetchJson(url);
  if (r.body?.data?.email) return r.body.data;
  throw new Error('Generate failed: ' + JSON.stringify(r.body).slice(0,500));
}

async function checkInbox(email) {
  const r = await fetchJson(`${TEMPMail_BASE}/inbox?email=${encodeURIComponent(email)}`);
  // r.body.data may contain otp directly (as seen) or messages array
  return r.body;
}

async function extractOtp(email) {
  const r = await fetchJson(`${TEMPMail_BASE}/otp?email=${encodeURIComponent(email)}`);
  return r.body;
}

async function extractLink(email) {
  const r = await fetchJson(`${TEMPMail_BASE}/link?email=${encodeURIComponent(email)}`);
  return r.body;
}

async function readMessage(email, id) {
  const r = await fetchJson(`${TEMPMail_BASE}/message?email=${encodeURIComponent(email)}&id=${encodeURIComponent(id)}`);
  return r.body;
}

async function liveListen(email, timeoutMs = 30000) {
  // GET /api/tools/tempmail/listen?email=...  - long poll SSE-like, server holds until new mail
  const r = await fetchJson(`${TEMPMail_BASE}/listen?email=${encodeURIComponent(email)}`, { method: 'GET' });
  return r.body;
}

// poll until otp found or timeout - supports all 7 TempMail endpoints
async function waitForOtp(email, { timeoutMs = 60000, intervalMs = 2500, useListen = false } = {}) {
  const start = Date.now();
  // optionally try live listen first (blocks until mail arrives)
  if (useListen) {
    try {
      const listenRes = await liveListen(email, timeoutMs);
      const otp = listenRes?.data?.otp || (listenRes?.data?.body || '').match?.(/\b(\d{6})\b/)?.[1];
      if (otp) return { otp, source: 'listen', inbox: listenRes };
    } catch {}
  }
  while (Date.now() - start < timeoutMs) {
    try {
      const inbox = await checkInbox(email);
      // inbox structure observed: {data:{otp:"551832", body:"...", total_messages:1}}
      if (inbox?.data?.otp && /^\d{4,8}$/.test(inbox.data.otp)) {
        return { otp: inbox.data.otp, source: 'inbox.otp', inbox };
      }
      // try readMessage if inbox has messages ids
      const msgs = inbox?.data?.messages || inbox?.data?.inbox || [];
      if (Array.isArray(msgs) && msgs.length) {
        for (const msg of msgs) {
          const id = msg.id || msg._id || msg.uid;
          if (id) {
            try {
              const detail = await readMessage(email, id);
              const body = detail?.data?.body || detail?.data?.text || JSON.stringify(detail);
              const m2 = body.match(/\b(\d{6})\b/);
              if (m2) return { otp: m2[1], source: 'message:'+id, inbox: detail };
              if (detail?.data?.otp) return { otp: detail.data.otp, source: 'message.otp', inbox: detail };
            } catch {}
          }
          const txt = JSON.stringify(msg);
          const mm = txt.match(/\b(\d{6})\b/);
          if (mm) return { otp: mm[1], source: 'messages', inbox };
        }
      }
      // fallback: try extract otp/link endpoints
      const otpRes = await extractOtp(email);
      if (otpRes?.data?.otp) return { otp: otpRes.data.otp, source: 'otp', inbox: otpRes };
      const linkRes = await extractLink(email);
      if (linkRes?.data?.otp) return { otp: linkRes.data.otp, source: 'link', inbox: linkRes };
      const body = inbox?.data?.body || inbox?.data?.text || '';
      const m = body.match(/\b(\d{6})\b/);
      if (m) return { otp: m[1], source: 'body-regex', inbox };
    } catch (e) {
      // ignore polling errors
    }
    await new Promise(r => setTimeout(r, intervalMs));
  }
  throw new Error(`Timeout waiting OTP for ${email} after ${timeoutMs}ms`);
}

// ---------------------------------------------------------------------------
// Apodex passwordless flow
// ---------------------------------------------------------------------------
async function sendApodexCode(email, deviceID) {
  const r = await apodexRequest('/auth/passwordless/send-code', { method: 'POST', body: { email }, deviceID });
  if (r.status !== 200) throw new Error(`send-code failed ${r.status}: ${JSON.stringify(r.body).slice(0,600)}`);
  const cookieHeader = r.headers['set-cookie'];
  let session = null;
  if (Array.isArray(cookieHeader)) {
    const m = cookieHeader.join(';').match(/session=([^;]+)/);
    if (m) session = `session=${m[1]}`;
  } else if (typeof cookieHeader === 'string') {
    const m = cookieHeader.match(/session=([^;]+)/);
    if (m) session = `session=${m[1]}`;
  }
  return { body: r.body, cookie: session, headers: r.headers };
}

async function verifyApodexCode(email, code, deviceID, sessionCookie) {
  const r = await apodexRequest('/auth/passwordless/verify-login', { method: 'POST', body: { email, code }, deviceID, cookie: sessionCookie });
  if (r.status !== 200) throw new Error(`verify-login failed ${r.status}: ${JSON.stringify(r.body).slice(0,800)}`);
  // extract token and possibly new session cookie
  const token = r.body?.data?.access_token || r.body?.access_token;
  const cookieHeader = r.headers['set-cookie'];
  let session = sessionCookie;
  if (Array.isArray(cookieHeader)) {
    const m = cookieHeader.join(';').match(/session=([^;]+)/);
    if (m) session = `session=${m[1]}`;
  } else if (typeof cookieHeader === 'string') {
    const m = cookieHeader.match(/session=([^;]+)/);
    if (m) session = `session=${m[1]}`;
  }
  return { body: r.body, token, cookie: session, user: r.body?.data?.user, isNewUser: r.body?.data?.is_new_user };
}

// ---------------------------------------------------------------------------
// High level: create fresh Apodex client
// ---------------------------------------------------------------------------
async function createFreshAccount(options = {}) {
  const deviceID = options.deviceID || DEFAULT_DEVICE_ID;
  const domain = options.domain; // optional pick one of 15
  const verbose = options.verbose !== false;

  if (verbose) console.log('[*] Generating TempMail...');
  const gen = await generateEmail(domain);
  const email = gen.email;
  if (verbose) console.log(`[+] TempMail: ${email} (${gen.domain})`);

  if (verbose) console.log('[*] Sending Apodex OTP code...');
  const send = await sendApodexCode(email, deviceID);
  let sessionCookie = send.cookie;
  if (verbose) console.log(`[+] send-code OK: ${send.body.message} | session=${sessionCookie} | expires_in=${send.body.data?.expires_in}s`);

  if (verbose) console.log('[*] Polling inbox for OTP (max 60s)...');
  const { otp, source } = await waitForOtp(email, { timeoutMs: options.timeoutMs || 60000, intervalMs: 2500 });
  if (verbose) console.log(`[+] OTP found (${source}): ${otp}`);

  if (verbose) console.log('[*] Verifying OTP with Apodex...');
  const verify = await verifyApodexCode(email, otp, deviceID, sessionCookie);
  if (!verify.token) throw new Error('No access_token in verify response: ' + JSON.stringify(verify.body).slice(0,600));
  if (verbose) console.log(`[+] Verify OK: user=${verify.user?.id} new=${verify.isNewUser} token=${verify.token.slice(0,20)}...`);

  // Compose full cookie string like apodex_scraper.js:7
  const guest_id = 'guest_' + crypto.randomBytes(6).toString('hex');
  const fullCookieParts = [
    `guest_id=${guest_id}`,
    `apx-signed-in=1`,
    verify.cookie, // session=...
  ];
  // add _fbp/_ga placeholders if desired (optional)
  if (options.includeGa) {
    fullCookieParts.unshift(`_ga=GA1.1.${Math.floor(Math.random()*1e10)}.${Math.floor(Date.now()/1000)}`);
  }

  const fullCookie = fullCookieParts.filter(Boolean).join('; ');
  // Build headers to use for future requests
  const result = {
    email,
    domain: gen.domain,
    otp,
    token: verify.token,
    sessionCookie: verify.cookie,
    fullCookie,
    deviceID,
    guest_id,
    user: verify.user,
    isNewUser: verify.isNewUser,
    raw: verify.body,
    createdAt: new Date().toISOString(),
    inboxUrl: gen.inbox_url
  };

  // optionally persist
  if (options.saveTo) {
    fs.writeFileSync(options.saveTo, JSON.stringify(result, null, 2), 'utf8');
    if (verbose) console.log(`[+] Saved to ${options.saveTo}`);
  }

  return result;
}

// ---------------------------------------------------------------------------
// Integration with ApodexClient (full SDK)
// ---------------------------------------------------------------------------
function createApodexClientFromAccount(account, extraOpts={}) {
  const client = new ApodexClient({
    cookie: account.fullCookie || account.sessionCookie,
    token: account.token,
    deviceID: account.deviceID,
    ...extraOpts
  });
  // stash account for refresh
  client._account = account;
  return client;
}

async function createFreshApodexClient(options = {}) {
  const account = await createFreshAccount(options);
  const client = createApodexClientFromAccount(account, options.clientOpts);
  return { account, client };
}

// Auto refresh wrapper: if token expires (401) generate new account
class AutoRefreshingApodexClient {
  constructor(options = {}) {
    this.options = options;
    this.account = null;
    this.client = null;
    this.deviceID = options.deviceID || DEFAULT_DEVICE_ID;
  }
  async init() {
    const { account, client } = await createFreshApodexClient({ deviceID: this.deviceID, verbose: this.options.verbose, saveTo: this.options.saveTo });
    this.account = account;
    this.client = client;
    return this;
  }
  _isRetryable(e){
    if(!e) return false;
    const code=e.code||e.data?.code||e.data?.data?.code;
    if(e.status===401) return true;
    if(code==='UNAUTHORIZED'||code==='TOKEN_EXPIRED'||code==='SESSION_EXPIRED') return true;
    if(e.status===429 && code==='MODE_RATE_LIMIT_EXCEEDED') {
      if(code==='HEAVY_ACCESS_DENIED') return false;
      return true;
    }
    if(e.status===429 && /requires login/.test(e.message||'')) return true;
    return false;
  }
  async ensureValid() {
    if (!this.client) await this.init();
    try {
      await this.client.get('/config', { requireAuth: false });
      if (this.account.token) {
        await this.client.get('/auth/get_user_info').catch(e=>{
          if (this._isRetryable(e)) throw e;
        });
      }
    } catch (e) {
      if (this._isRetryable(e)) {
        console.log('[!] Token expired/limit -> regenerating fresh account (no headless)...');
        await this.init();
      }
    }
    return this.client;
  }
  async chatStream(prompt, opts={}) {
    const c = await this.ensureValid();
    try {
      return await c.chat.stream(prompt, opts);
    } catch (e) {
      if (this._isRetryable(e)) {
        console.log('[!] chat limit/expired -> auto refresh...');
        await this.init();
        return await this.client.chat.stream(prompt, opts);
      }
      throw e;
    }
  }
}

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------
module.exports = { ApodexClient, ApiError, scrapeApodex, genUUID, createFreshAccount, getDomains, generateEmail, checkInbox, extractOtp, extractLink, readMessage, liveListen, waitForOtp, createFreshApodexClient, AutoRefreshingApodexClient };


if (require.main === module) {
  const readline = require('readline');
  const args = process.argv.slice(2);
  
  // Minimalist Colors (Claude Code inspired)
  const colors = {
    dim: '\x1b[2m',
    reset: '\x1b[0m',
    blue: '\x1b[34m',
    cyan: '\x1b[36m',
    gray: '\x1b[90m',
    white: '\x1b[37m',
    green: '\x1b[32m',
    red: '\x1b[31m',
    yellow: '\x1b[33m',
  };

  function loadExisting() {
    for (const name of ["apodex_account.json", "apodex_account_autorefresh.json", "apodex_account_final.json", "apodex_account_test_all.json"]) {
      const p = path.join(__dirname, name);
      if (fs.existsSync(p)) {
        try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch {}
      }
    }
    return null;
  }

  function colorizeJson(jsonStr) {
    return jsonStr.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
      let cls = colors.green; // string
      if (/^"/.test(match)) {
        if (/:$/.test(match)) {
          cls = colors.cyan; // key
        }
      } else if (/true|false/.test(match)) {
        cls = colors.blue; // boolean
      } else if (/null/.test(match)) {
        cls = colors.gray; // null
      } else {
        cls = colors.yellow; // number
      }
      return cls + match + colors.reset;
    });
  }

  function getClient(autoRefresh=true){
    const acct=loadExisting();
    if(acct) return new ApodexClient({cookie:acct.fullCookie, token:acct.token, deviceID:acct.deviceID, autoRefresh});
    return new ApodexClient({autoRefresh});
  }

  // ---------- Path with spaces resolver ----------
  function resolveFilePathAndPrompt(cargs) {
    if (!cargs || cargs.length === 0) return { filePath: null, prompt: "" };

    let clean0 = cargs[0].replace(/^["']|["']$/g, "");
    if (fs.existsSync(clean0)) {
      return { filePath: clean0, prompt: cargs.slice(1).join(" ") };
    }

    for (let i = cargs.length; i >= 1; i--) {
      let cand = cargs.slice(0, i).join(" ").replace(/^["']|["']$/g, "");
      if (fs.existsSync(cand)) {
        return { filePath: cand, prompt: cargs.slice(i).join(" ") };
      }
    }

    return { filePath: clean0, prompt: cargs.slice(1).join(" ") };
  }

  // ---------- Selected model state ----------
  let selectedModel = { mode: 'standard', version: '1.1' };

  // ---------- Arrow key interactive selector ----------
  function selectWithArrows(items, labelFn, rl) {
    return new Promise((resolve) => {
      let idx = 0;
      const { stdin, stdout } = process;

      if (rl) rl.pause();
      stdin.setRawMode(true);
      stdin.resume();
      stdin.setEncoding('utf8');

      function render(initial) {
        if (!initial) stdout.write(`\x1b[${items.length}A`);
        for (let i = 0; i < items.length; i++) {
          stdout.write('\x1b[2K');
          const prefix = i === idx ? `${colors.cyan}  ❯${colors.reset}` : '   ';
          const label = labelFn(items[i], i);
          const text = i === idx
            ? `${colors.white}${label}${colors.reset}`
            : `${colors.dim}${label}${colors.reset}`;
          stdout.write(`${prefix} ${text}\n`);
        }
      }

      render(true);

      let buf = '';
      function onData(chunk) {
        buf += chunk;
        while (buf.length > 0) {
          if (buf.startsWith('\x1b[A')) {
            idx = (idx - 1 + items.length) % items.length;
            render(false);
            buf = buf.slice(3);
          } else if (buf.startsWith('\x1b[B')) {
            idx = (idx + 1) % items.length;
            render(false);
            buf = buf.slice(3);
          } else if (buf[0] === '\r' || buf[0] === '\n') {
            cleanup();
            resolve(items[idx]);
            return;
          } else if (buf[0] === '\x03') {
            cleanup();
            process.exit(0);
            return;
          } else if (buf[0] === '\x1b') {
            if (buf.length < 3) return;
            buf = buf.slice(3);
          } else {
            buf = buf.slice(1);
          }
        }
      }

      function cleanup() {
        stdin.removeListener('data', onData);
        try { stdin.setRawMode(false); } catch {}
        if (rl) rl.resume();
      }

      stdin.on('data', onData);
    });
  }

  async function executeMenu(cmd, cargs, isInteractive = false, rl = null) {
    let result = null;
    try {

      // =====================================================================
      // /chat - Chat langsung, support --model --version --file --memory
      // =====================================================================
      if (cmd === "chat") {
        let mode = selectedModel.mode, version = selectedModel.version;
        let filePath = null, useMemory = undefined;
        const promptParts = [];

        for (let i = 0; i < cargs.length; i++) {
          const a = cargs[i];
          if (a === "--model" && cargs[i + 1]) { mode = cargs[++i]; }
          else if (a === "--version" && cargs[i + 1]) { version = cargs[++i]; }
          else if ((a === "--file" || a === "--vision") && cargs[i + 1]) { filePath = cargs[++i]; }
          else if (a === "--memory") useMemory = true;
          else if (a === "--no-memory") useMemory = false;
          else promptParts.push(a);
        }

        const prompt = promptParts.join(" ");
        if (!prompt) throw new Error("Prompt required. Usage: /chat <prompt> or just type your message.");

        const client = getClient();
        client.timeoutMs = filePath ? 240000 : 60000;
        let files = null, file_ids = null;

        if (filePath) {
          const { filePath: resolvedFp } = resolveFilePathAndPrompt([filePath]);
          const actualFp = resolvedFp || filePath;
          if (!fs.existsSync(actualFp)) throw new Error(`File not found: ${actualFp}`);
          if (isInteractive) process.stdout.write(`${colors.gray}  Uploading file...${colors.reset}\r`);
          const up = await client.upload.uploadFile(actualFp);
          files = [{ file_id: up.file_id, filename: up.filename, file_type: up.content_type }];
          file_ids = [up.file_id];
          try { await client.library.upload(up.file_id, up.filename); } catch {}
          if (isInteractive) process.stdout.write(`\r\x1b[2K`);
        }

        if (isInteractive) process.stdout.write(`${colors.dim}  thinking...${colors.reset}\r`);
        const r = await client.chat.stream(prompt, {
          mode, version, files, file_ids, useMemory,
          onDelta: () => {}
        });
        if (isInteractive) process.stdout.write(`\r\x1b[2K`);

        result = {
          command: "/chat",
          model: { mode, version },
          prompt,
          response: r.content,
          chat_id: r.chatId,
          message_id: r.messageId || null
        };

      // =====================================================================
      // /models - Arrow key selector (interactive) atau list (non-interactive)
      // =====================================================================
      } else if (cmd === "models") {
        const client = getClient();
        const cfg = await client.appConfig.get();
        const modelList = [];

        for (const [mode, arr] of Object.entries(cfg.model_config || {})) {
          for (const m of arr) {
            modelList.push({
              mode,
              version: m.version,
              tag: m.tag || null,
              description: m.description || "",
              access: m.access,
              max_input_chars: m.max_input_chars,
              is_default: !!m.default
            });
          }
        }

        if (isInteractive && rl) {
          console.log(`\n${colors.gray}  Select model (↑↓ arrows, Enter to confirm):${colors.reset}\n`);

          const picked = await selectWithArrows(modelList, (m) => {
            const def = m.is_default ? ' (default)' : '';
            const access = m.access === 'granted' ? '✓' : '✗';
            return `${m.mode} v${m.version} ${m.tag || ''}${def}  [${access}]  ${m.description}`;
          }, rl);

          selectedModel = { mode: picked.mode, version: picked.version };

          result = {
            command: "/models",
            action: "selected",
            selected: {
              mode: picked.mode,
              version: picked.version,
              tag: picked.tag,
              description: picked.description,
              access: picked.access
            }
          };
        } else {
          result = {
            command: "/models",
            current_model: selectedModel,
            available: modelList
          };
        }

      // =====================================================================
      // /vision - Chat + gambar
      // =====================================================================
      } else if (cmd === "vision") {
        const { filePath: imgPath, prompt: rawPrompt } = resolveFilePathAndPrompt(cargs);
        if (!imgPath) throw new Error("Usage: /vision <image_path> [prompt]");
        if (!fs.existsSync(imgPath)) throw new Error(`Image not found: ${imgPath}`);
        const prompt = rawPrompt || "Jelaskan isi gambar ini secara detail.";

        if (isInteractive) process.stdout.write(`${colors.gray}  Uploading image...${colors.reset}\r`);
        const client = getClient();
        client.timeoutMs = 240000;
        const up = await client.upload.uploadFile(imgPath);

        if (isInteractive) process.stdout.write(`${colors.gray}  Analyzing image with Apodex Vision...${colors.reset}\r`);
        const r = await client.chat.stream(prompt, {
          mode: selectedModel.mode,
          version: selectedModel.version,
          files: [{ file_id: up.file_id, filename: up.filename }],
          file_ids: [up.file_id],
          onDelta: () => {}
        });
        if (isInteractive) process.stdout.write(`\r\x1b[2K`);

        result = {
          command: "/vision",
          file: { file_id: up.file_id, filename: up.filename },
          model: selectedModel,
          prompt,
          response: r.content,
          chat_id: r.chatId
        };

      // =====================================================================
      // /upload - Upload file ke Apodex
      // =====================================================================
      } else if (cmd === "upload") {
        const { filePath: fp } = resolveFilePathAndPrompt(cargs);
        if (!fp) throw new Error("Usage: /upload <file_path>");
        if (!fs.existsSync(fp)) throw new Error(`File not found: ${fp}`);

        if (isInteractive) process.stdout.write(`${colors.gray}  Uploading file...${colors.reset}\r`);
        const client = getClient();
        const up = await client.upload.uploadFile(fp);
        if (isInteractive) process.stdout.write(`\r\x1b[2K`);
        let downloadUrl = null;
        try { downloadUrl = await client.upload.getDownloadUrl(up.file_id); } catch {}

        result = {
          command: "/upload",
          file: {
            file_id: up.file_id,
            filename: up.filename,
            content_type: up.content_type || null
          },
          download_url: downloadUrl
        };

      // =====================================================================
      // /library - Kelola file library (list|picker|remove|download)
      // =====================================================================
      } else if (cmd === "library") {
        const sub = cargs[0] || "list";
        const client = getClient();

        if (sub === "list") {
          const limit = parseInt(cargs[1] || "20", 10);
          const data = await client.library.list({ limit });
          result = { command: "/library", action: "list", limit, data };
        } else if (sub === "picker") {
          const query = cargs.slice(1).join(" ") || "";
          const data = await client.library.picker({ query, limit: 10 });
          result = { command: "/library", action: "picker", query, data };
        } else if (sub === "remove") {
          if (!cargs[1]) throw new Error("Usage: /library remove <item_id>");
          const data = await client.library.remove(cargs[1]);
          result = { command: "/library", action: "remove", item_id: cargs[1], data };
        } else if (sub === "download") {
          if (!cargs[1]) throw new Error("Usage: /library download <scope> [path]");
          const data = await client.library.download(cargs[1], cargs[2] || "");
          result = { command: "/library", action: "download", scope: cargs[1], data };
        } else {
          throw new Error("Usage: /library list [limit]|picker [query]|remove <id>|download <scope> [path]");
        }

      // =====================================================================
      // /memory - Kelola memory (list|create|delete|settings|enable|disable|status)
      // =====================================================================
      } else if (cmd === "memory") {
        const sub = cargs[0] || "list";
        const client = getClient();

        if (sub === "list") {
          const data = await client.memory.list();
          result = { command: "/memory", action: "list", data };
        } else if (sub === "create") {
          const text = cargs.slice(1).join(" ");
          if (!text) throw new Error("Usage: /memory create <text>");
          const data = await client.memory.create(text, "1");
          result = { command: "/memory", action: "create", text, data };
        } else if (sub === "delete") {
          if (!cargs[1] || !cargs[2]) throw new Error("Usage: /memory delete <id> <version>");
          const data = await client.memory.delete(cargs[1], cargs[2]);
          result = { command: "/memory", action: "delete", id: cargs[1], data };
        } else if (sub === "settings") {
          const data = await client.memory.getSettings();
          result = { command: "/memory", action: "settings", data };
        } else if (sub === "enable") {
          const data = await client.memory.updateSettings({ enabled: true });
          result = { command: "/memory", action: "enable", data };
        } else if (sub === "disable") {
          const data = await client.memory.updateSettings({ enabled: false });
          result = { command: "/memory", action: "disable", data };
        } else if (sub === "status") {
          const data = await client.memory.status();
          result = { command: "/memory", action: "status", data };
        } else {
          throw new Error("Usage: /memory list|create <text>|delete <id> <ver>|settings|enable|disable|status");
        }

      // =====================================================================
      // /history - Kelola history (list|search|pin|rename|delete)
      // =====================================================================
      } else if (cmd === "history") {
        const sub = cargs[0] || "list";
        const client = getClient();

        if (sub === "list") {
          const pageSize = parseInt(cargs[1] || "10", 10);
          const data = await client.history.list({ page: 1, page_size: pageSize });
          result = { command: "/history", action: "list", page_size: pageSize, data };
        } else if (sub === "search") {
          const q = cargs.slice(1).join(" ");
          if (!q) throw new Error("Usage: /history search <query>");
          const data = await client.history.search({ q });
          result = { command: "/history", action: "search", query: q, data };
        } else if (sub === "pin") {
          if (!cargs[1]) throw new Error("Usage: /history pin <chatId>");
          const data = await client.history.pin([cargs[1]]);
          result = { command: "/history", action: "pin", chat_id: cargs[1], data };
        } else if (sub === "rename") {
          if (!cargs[1] || !cargs[2]) throw new Error("Usage: /history rename <chatId> <new_title>");
          const title = cargs.slice(2).join(" ");
          const data = await client.history.rename(cargs[1], title);
          result = { command: "/history", action: "rename", chat_id: cargs[1], title, data };
        } else if (sub === "delete") {
          if (!cargs[1]) throw new Error("Usage: /history delete <chatId>");
          const data = await client.history.delete(cargs[1]);
          result = { command: "/history", action: "delete", chat_id: cargs[1], data };
        } else {
          throw new Error("Usage: /history list [count]|search <q>|pin <id>|rename <id> <title>|delete <id>");
        }

      // =====================================================================
      // Hidden commands (still functional, not shown in /menu)
      // =====================================================================
      } else if (cmd === "domains") {
        result = { command: "/domains", domains: await getDomains() };
      } else if (cmd === "generate") {
        const data = await generateEmail(cargs[0]);
        result = { command: "/generate", data };
      } else if (cmd === "inbox") {
        if (!cargs[0]) throw new Error("Usage: /inbox <email>");
        const data = await checkInbox(cargs[0]);
        result = { command: "/inbox", email: cargs[0], data };
      } else if (cmd === "otp") {
        if (!cargs[0]) throw new Error("Usage: /otp <email>");
        const data = await extractOtp(cargs[0]);
        result = { command: "/otp", email: cargs[0], data };
      } else if (cmd === "message") {
        if (!cargs[0] || !cargs[1]) throw new Error("Usage: /message <email> <id>");
        const data = await readMessage(cargs[0], cargs[1]);
        result = { command: "/message", data };
      } else if (cmd === "link") {
        if (!cargs[0]) throw new Error("Usage: /link <email>");
        const data = await extractLink(cargs[0]);
        result = { command: "/link", data };
      } else if (cmd === "listen") {
        if (!cargs[0]) throw new Error("Usage: /listen <email>");
        const data = await liveListen(cargs[0]);
        result = { command: "/listen", data };
      } else if (cmd === "fresh") {
        const saveTo = cargs[0] || path.join(__dirname, "apodex_account.json");
        const acc = await createFreshAccount({ verbose: false, saveTo });
        result = { command: "/fresh", action: "account_created", email: acc.email, token_preview: acc.token.slice(0, 16) + "...", saved_to: saveTo };
      } else if (cmd === "vip") {
        const client = getClient();
        const info = await client.vip.info();
        const plans = await client.vip.plans();
        result = { command: "/vip", info, plans: plans.plans?.slice(0, 3) };
      } else if (cmd === "feedback") {
        if (cargs.length < 3) throw new Error("Usage: /feedback <category> <title> <description>");
        const [category, title, ...descParts] = cargs;
        const client = getClient();
        const data = await client.feedback.send({ category, title, description: descParts.join(" ") });
        result = { command: "/feedback", data };
      } else if (cmd === "appconfig") {
        const client = getClient();
        const data = await client.appConfig.get();
        result = { command: "/appconfig", data };
      } else if (cmd === "scene") {
        const client = getClient();
        const data = await client.scene.configs();
        result = { command: "/scene", data };
      } else if (cmd === "org") {
        const client = getClient();
        const data = await client.org.listContexts();
        result = { command: "/org", data };

      // =====================================================================
      // /help | /menu
      // =====================================================================
      } else if (cmd === "help" || cmd === "menu") {
        const menus = [
          { cmd: "/chat",    args: '"prompt"',                 desc: "Chat dengan AI (default model: " + selectedModel.mode + " " + selectedModel.version + ")" },
          { cmd: "/models",  args: null,                       desc: "Pilih model AI (arrow keys)" },
          { cmd: "/vision",  args: "<image> [prompt]",         desc: "Chat dengan gambar" },
          { cmd: "/upload",  args: "<file>",                   desc: "Upload file" },
          { cmd: "/library", args: "list|picker|remove|download", desc: "Kelola file library" },
          { cmd: "/memory",  args: "list|create|delete|enable",   desc: "Kelola memory" },
          { cmd: "/history", args: "list|search|pin|rename|delete", desc: "Kelola history chat" },
          { cmd: "/exit",    args: null,                       desc: "Keluar dari CLI" },
        ];

        if (isInteractive) {
          console.log(`\n${colors.gray}  Supported Commands:${colors.reset}`);
          console.log(`${colors.gray}  Ketik langsung tanpa '/' untuk chat.${colors.reset}\n`);
          menus.forEach(m => {
            const a = m.args ? `${colors.gray}${m.args}${colors.reset}` : '';
            console.log(`  ${colors.cyan}${m.cmd.padEnd(12)}${colors.reset} ${a.padEnd(40)} ${colors.dim}—${colors.reset} ${colors.white}${m.desc}${colors.reset}`);
          });
          console.log("");
          return null;
        } else {
          result = { command: "/help", current_model: selectedModel, menus };
        }

      // =====================================================================
      // Unknown command
      // =====================================================================
      } else {
        throw new Error(`Unknown command: /${cmd}. Type '/help' for available commands.`);
      }

      // --- Output JSON ---
      if (result !== null) {
        const jsonOutput = JSON.stringify(result, null, 2);
        if (isInteractive) {
          console.log(`\n${colors.dim}──────────────────────────────${colors.reset}`);
          console.log(colorizeJson(jsonOutput));
          console.log(`${colors.dim}──────────────────────────────${colors.reset}\n`);
        } else {
          console.log(jsonOutput);
        }
      }
    } catch (e) {
      const errResult = { success: false, error: e.message };
      const errOutput = JSON.stringify(errResult, null, 2);
      if (isInteractive) {
        console.log(`\n${colors.red}──────────────────────────────${colors.reset}`);
        console.log(colorizeJson(errOutput));
        console.log(`${colors.red}──────────────────────────────${colors.reset}\n`);
      } else {
        console.log(errOutput);
      }
    }
  }

  // =========================================================================
  // Entry Point
  // =========================================================================
  if (args.length > 0) {
    (async () => {
      let cmd = args[0].toLowerCase();
      let cargs = [];

      if (!cmd.startsWith('/')) {
        cmd = "chat";
        cargs = args;
      } else {
        cmd = cmd.slice(1);
        cargs = args.slice(1);
      }

      await executeMenu(cmd, cargs, false, null);
    })().catch(e => {
      console.log(JSON.stringify({ success: false, error: e.message }, null, 2));
      process.exit(1);
    });
  } else {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
      prompt: `${colors.cyan}❯${colors.reset} `
    });

    console.log(`${colors.dim}Apodex CLI${colors.reset}`);
    console.log(`${colors.gray}Type '/help' for commands, or just type to chat.${colors.reset}\n`);

    rl.prompt();

    rl.on('line', async (line) => {
      const input = line.trim();
      if (!input) { rl.prompt(); return; }

      const parts = input.match(/(?:[^\s"]+|"[^"]*")+/g) || [];
      let cmd = parts[0].toLowerCase();
      let cargs = [];

      if (!cmd.startsWith('/')) {
        cmd = "chat";
        cargs = parts.map(p => p.replace(/^"|"$/g, ''));
      } else {
        cmd = cmd.slice(1);
        cargs = parts.slice(1).map(p => p.replace(/^"|"$/g, ''));
      }

      if (cmd === 'exit' || cmd === 'quit') { rl.close(); return; }

      await executeMenu(cmd, cargs, true, rl);
      rl.prompt();
    });

    rl.on('close', () => {
      console.log(`${colors.dim}\nbye.${colors.reset}`);
      process.exit(0);
    });
  }
}