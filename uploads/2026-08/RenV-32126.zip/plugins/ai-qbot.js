const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');
const axios = require('axios');

const BASE = 'https://quillbot.com';
const SESSION_FILE = path.join(process.cwd(), 'database', 'quillbot-sessions.json');
const MAX_MESSAGES_PER_SESSION = 5;

const USER_AGENT =
  'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36';

let CookieJarClass = null;
let cookieWrapper = null;

function uuid() {
  if (crypto.randomUUID) return crypto.randomUUID();
  return `${hex(4)}-${hex(2)}-${hex(2)}-${hex(2)}-${hex(6)}`;
}

function hex(bytes) {
  return crypto.randomBytes(bytes).toString('hex');
}

function nowIso() {
  return new Date().toISOString();
}

async function loadCookieJar() {
  if (CookieJarClass) return CookieJarClass;

  try {
    const mod = require('tough-cookie');
    CookieJarClass = mod.CookieJar || mod.default?.CookieJar;
  } catch {
    try {
      const mod = await import('tough-cookie');
      CookieJarClass = mod.CookieJar || mod.default?.CookieJar;
    } catch {
      throw new Error('Module tough-cookie belum terinstall. Jalankan: npm i tough-cookie');
    }
  }

  if (!CookieJarClass) {
    throw new Error('CookieJar tidak ditemukan dari module tough-cookie.');
  }

  return CookieJarClass;
}

async function loadWrapper() {
  if (cookieWrapper) return cookieWrapper;

  try {
    const mod = require('axios-cookiejar-support');
    cookieWrapper = mod.wrapper || mod.default?.wrapper;
  } catch {
    try {
      const mod = await import('axios-cookiejar-support');
      cookieWrapper = mod.wrapper || mod.default?.wrapper;
    } catch {
      throw new Error('Module axios-cookiejar-support belum terinstall. Jalankan: npm i axios-cookiejar-support');
    }
  }

  if (!cookieWrapper) {
    throw new Error('Wrapper tidak ditemukan dari module axios-cookiejar-support.');
  }

  return cookieWrapper;
}

async function ensureDir(file) {
  await fs.mkdir(path.dirname(file), { recursive: true });
}

async function readJson(file, fallback) {
  try {
    const raw = await fs.readFile(file, 'utf8');
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

async function writeJson(file, data) {
  await ensureDir(file);
  await fs.writeFile(file, JSON.stringify(data, null, 2));
}

function normalizeStore(data) {
  if (data && data.users && typeof data.users === 'object') return data;

  if (data && Array.isArray(data.sessions)) {
    return {
      version: 1,
      users: {
        default: {
          current: data.current || null,
          sessions: data.sessions || [],
        },
      },
    };
  }

  return {
    version: 1,
    users: {},
  };
}

function createSession() {
  return {
    conversation_id: uuid(),
    device_id: uuid(),
    message_count: 0,
    created_at: nowIso(),
    updated_at: nowIso(),
  };
}

function getUserKey(m) {
  return String(m.sender || m.chat || 'default');
}

async function getSession(userKey) {
  const store = normalizeStore(
    await readJson(SESSION_FILE, {
      version: 1,
      users: {},
    })
  );

  if (!store.users[userKey]) {
    store.users[userKey] = {
      current: null,
      sessions: [],
    };
  }

  const user = store.users[userKey];
  let current = user.current;

  if (!current || current.message_count >= MAX_MESSAGES_PER_SESSION) {
    current = createSession();
    user.current = current;
    user.sessions.push(current);

    await writeJson(SESSION_FILE, store);

    return {
      store,
      session: current,
      new_session: true,
    };
  }

  const exists = user.sessions.some((v) => v.conversation_id === current.conversation_id);
  if (!exists) user.sessions.push(current);

  return {
    store,
    session: current,
    new_session: false,
  };
}

async function updateSession(store, userKey, conversationId) {
  if (!store.users[userKey]) return;

  const user = store.users[userKey];
  const session = user.sessions.find((v) => v.conversation_id === conversationId);

  if (session) {
    session.message_count += 1;
    session.updated_at = nowIso();
    user.current = session;
  }

  await writeJson(SESSION_FILE, store);
}

async function resetUserSession(userKey) {
  const store = normalizeStore(
    await readJson(SESSION_FILE, {
      version: 1,
      users: {},
    })
  );

  store.users[userKey] = {
    current: null,
    sessions: [],
  };

  await writeJson(SESSION_FILE, store);
}

async function getSessionStatus(userKey) {
  const store = normalizeStore(
    await readJson(SESSION_FILE, {
      version: 1,
      users: {},
    })
  );

  const user = store.users[userKey];

  if (!user || !user.current) {
    return {
      active: false,
      current: null,
      total: 0,
    };
  }

  return {
    active: true,
    current: user.current,
    total: Array.isArray(user.sessions) ? user.sessions.length : 0,
  };
}

async function setCookie(jar, name, value) {
  await jar.setCookie(
    `${name}=${value}; Path=/; Domain=.quillbot.com; Secure; SameSite=None`,
    BASE
  );
}

async function initCookies(jar, deviceId) {
  await setCookie(jar, 'qbDeviceId', deviceId);
  await setCookie(jar, 'ajs_anonymous_id', uuid());
  await setCookie(jar, 'anonID', hex(8));
  await setCookie(jar, 'authenticated', 'false');
  await setCookie(jar, 'premium', 'false');
  await setCookie(jar, 'acceptedPremiumModesTnc', 'false');
  await setCookie(jar, 'qdid', hex(16));

  if (process.env.QB_COOKIE) {
    for (const part of process.env.QB_COOKIE.split(';')) {
      const clean = part.trim();
      if (!clean) continue;

      try {
        if (/;\s*path=/i.test(clean)) {
          await jar.setCookie(clean, BASE);
        } else {
          await jar.setCookie(`${clean}; Path=/; Domain=.quillbot.com`, BASE);
        }
      } catch {}
    }
  }
}

async function createClient(jar) {
  const wrapper = await loadWrapper();

  return wrapper(
    axios.create({
      jar,
      withCredentials: true,
      decompress: true,
      validateStatus: () => true,
      timeout: 120000,
    })
  );
}

function collectContent(json, chunks) {
  if (!json || typeof json !== 'object') return;

  if (json.type === 'content' && typeof json.content === 'string') {
    chunks.push(json.content);
    return;
  }

  if (typeof json.content === 'string') {
    chunks.push(json.content);
    return;
  }

  if (json.delta && typeof json.delta.content === 'string') {
    chunks.push(json.delta.content);
    return;
  }

  if (json.message && typeof json.message.content === 'string') {
    chunks.push(json.message.content);
    return;
  }

  if (json.data && typeof json.data.content === 'string') {
    chunks.push(json.data.content);
  }
}

function parseNdjson(text) {
  const chunks = [];

  for (const line of String(text || '').split(/\r?\n/)) {
    let clean = line.trim();
    if (!clean) continue;

    if (clean.startsWith('data:')) {
      clean = clean.slice(5).trim();
    }

    if (!clean || clean === '[DONE]') continue;
    if (!clean.startsWith('{')) continue;

    try {
      const json = JSON.parse(clean);
      collectContent(json, chunks);
    } catch {}
  }

  return chunks.join('').replace(/\n{3,}/g, '\n\n').trim();
}

function shortError(raw, max = 900) {
  const text = String(raw || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!text) return 'Tidak ada detail error dari server.';
  return text.length > max ? `${text.slice(0, max).trim()}...` : text;
}

async function askQuillBot(prompt, userKey) {
  const { store, session, new_session } = await getSession(userKey);

  const CookieJar = await loadCookieJar();
  const jar = new CookieJar();

  await initCookies(jar, session.device_id);

  const client = await createClient(jar);

  await client.get(`${BASE}/`, {
    headers: {
      'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
      'sec-ch-ua-mobile': '?1',
      'sec-ch-ua-platform': '"Android"',
      'upgrade-insecure-requests': '1',
      'user-agent': USER_AGENT,
      accept:
        'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
      'sec-fetch-site': 'none',
      'sec-fetch-mode': 'navigate',
      'sec-fetch-user': '?1',
      'sec-fetch-dest': 'document',
      'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    },
  });

  const traceId = hex(16);
  const spanId = hex(8);
  const sampleRand = Math.random();

  const body = {
    message: {
      content: `${prompt}\n\n`,
    },
    context: {
      editorContext: '',
      selectionContext: '',
      userDialect: 'en-us',
      apiVersion: 2,
    },
    origin: {
      name: 'ai-chat.chat',
      url: BASE,
    },
  };

  const res = await client.post(
    `${BASE}/api/ai-chat/chat/conversation/${session.conversation_id}`,
    body,
    {
      responseType: 'text',
      headers: {
        'cache-control': 'max-age=0',
        'sec-ch-ua-platform': '"Android"',
        'platform-type': 'webapp',
        'qb-product': 'AI-CHAT',
        'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
        'sec-ch-ua-mobile': '?1',
        useridtoken: 'empty-token',
        baggage: `sentry-environment=prod,sentry-release=v42.51.6,sentry-public_key=5743ef12f4887fc460c7968ebb2de54d,sentry-trace_id=${traceId},sentry-sampled=false,sentry-sample_rand=${sampleRand},sentry-sample_rate=0.01`,
        'sentry-trace': `${traceId}-${spanId}-0`,
        'user-agent': USER_AGENT,
        accept: 'text/event-stream',
        'webapp-version': '42.51.6',
        'content-type': 'application/json',
        origin: BASE,
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
        referer: `${BASE}/ai-chat/c/${session.conversation_id}`,
        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
      },
    }
  );

  const raw = typeof res.data === 'string' ? res.data : JSON.stringify(res.data);
  const result = parseNdjson(raw);
  const success = res.status >= 200 && res.status < 300 && Boolean(result);

  if (success) {
    await updateSession(store, userKey, session.conversation_id);
  }

  const updated =
    store.users[userKey]?.sessions?.find((v) => v.conversation_id === session.conversation_id) ||
    session;

  return {
    status: success,
    code: res.status,
    input: prompt,
    conversation_id: session.conversation_id,
    new_session,
    message_count: updated.message_count,
    max_messages_per_session: MAX_MESSAGES_PER_SESSION,
    result: result || null,
    error: success ? null : shortError(raw),
  };
}

function getQuotedText(m) {
  if (!m || !m.quoted) return '';

  return (
    m.quoted.text ||
    m.quoted.caption ||
    m.quoted.description ||
    m.quoted.body ||
    ''
  );
}

function formatHelp(prefix, command) {
  return [
    '> [+] QuillBot AI Chat',
    '',
    '> Fitur ini memakai AI Chat dari QuillBot.',
    '> Setiap user punya session sendiri.',
    `> Session otomatis diganti setelah ${MAX_MESSAGES_PER_SESSION} pesan agar tidak terlalu berat.`,
    '',
    '> [+] Command:',
    `> ${prefix + command} halo bro`,
    `> ${prefix + command} jelaskan apa itu closure javascript`,
    `> ${prefix + command} session`,
    `> ${prefix + command} reset`,
    '',
    '> [+] Alias:',
    `> ${prefix}qb <teks>`,
    `> ${prefix}quill <teks>`,
    '',
    '> [+] Catatan:',
    '> Jika balasan gagal, biasanya server QuillBot sedang limit, timeout, atau struktur response berubah.',
  ].join('\n');
}

function formatSessionStatus(info) {
  if (!info.active) {
    return [
      '> [+] QuillBot Session',
      '> Status: belum ada session aktif.',
      '> Kirim prompt dulu untuk membuat session baru.',
    ].join('\n');
  }

  return [
    '> [+] QuillBot Session',
    `> Status: aktif`,
    `> Conversation ID: ${info.current.conversation_id}`,
    `> Message: ${info.current.message_count}/${MAX_MESSAGES_PER_SESSION}`,
    `> Total Session: ${info.total}`,
    `> Dibuat: ${info.current.created_at}`,
    `> Update: ${info.current.updated_at}`,
  ].join('\n');
}

function formatResult(data) {
  if (!data.status) {
    return [
      '> [+] QuillBot AI Error',
      `> Status: gagal`,
      `> Code: ${data.code}`,
      `> Session: ${data.conversation_id || '-'}`,
      '',
      '> [+] Detail:',
      `> ${data.error || 'Tidak diketahui.'}`,
      '',
      '> Coba ulangi beberapa saat lagi.',
    ].join('\n');
  }

  return [
    '> [+] QuillBot AI',
    `> Status: berhasil`,
    `> Session: ${data.new_session ? 'baru' : 'lanjutan'}`,
    `> Message: ${data.message_count}/${data.max_messages_per_session}`,
    '',
    data.result,
  ].join('\n');
}

function splitText(text, max = 3500) {
  text = String(text || '');

  if (text.length <= max) return [text];

  const chunks = [];

  while (text.length > max) {
    const slice = text.slice(0, max);

    let cut = Math.max(
      slice.lastIndexOf('\n\n'),
      slice.lastIndexOf('\n'),
      slice.lastIndexOf('. '),
      slice.lastIndexOf(' ')
    );

    if (cut < max * 0.5) cut = max;

    chunks.push(text.slice(0, cut).trim());
    text = text.slice(cut).trim();
  }

  if (text) chunks.push(text);

  return chunks;
}

async function replyLong(m, text) {
  const chunks = splitText(text);

  for (const chunk of chunks) {
    await m.reply(chunk);
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const prefix = usedPrefix || '.';
  const cmd = command || 'quillbot';
  const userKey = getUserKey(m);

  try {
    const input = String(text || '').trim();
    const sub = input.toLowerCase();

    if (!input) {
      return m.reply(formatHelp(prefix, cmd));
    }

    if (['help', 'menu', 'bantuan'].includes(sub)) {
      return m.reply(formatHelp(prefix, cmd));
    }

    if (['reset', 'clear', 'new', 'baru'].includes(sub)) {
      await resetUserSession(userKey);

      return m.reply(
        [
          '> [+] QuillBot Session',
          '> Session berhasil direset.',
          '> Prompt berikutnya akan memakai conversation baru.',
        ].join('\n')
      );
    }

    if (['session', 'status', 'info'].includes(sub)) {
      const info = await getSessionStatus(userKey);
      return m.reply(formatSessionStatus(info));
    }

    const quoted = getQuotedText(m);
    const prompt = input || quoted;

    if (!prompt) {
      return m.reply(formatHelp(prefix, cmd));
    }

    if (conn && typeof conn.sendPresenceUpdate === 'function') {
      await conn.sendPresenceUpdate('composing', m.chat).catch(() => {});
    }

    const data = await askQuillBot(prompt, userKey);
    return replyLong(m, formatResult(data));
  } catch (err) {
    console.error(err);

    return m.reply(
      [
        '> [+] QuillBot AI Error',
        '> Gagal menjalankan fitur.',
        `> Detail: ${err.message || err}`,
        '',
        '> Pastikan dependensi sudah diinstall:',
        '> npm i axios tough-cookie axios-cookiejar-support',
      ].join('\n')
    );
  }
};

handler.help = [
  'quillbot <teks>',
  'qb <teks>',
  'quill <teks>',
  'quillbot session',
  'quillbot reset',
];

handler.command = ['quillbot', 'qb', 'quill', 'qbot'];
handler.tags = ['ai'];

module.exports = handler;