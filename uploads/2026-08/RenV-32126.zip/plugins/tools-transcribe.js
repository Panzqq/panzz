const axios = require("axios");
const crypto = require("node:crypto");
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const https = require("node:https");
const { pipeline } = require("node:stream/promises");
const { tmpDirAsync, tmpFileAsync, safeUnlink: tmpSafeUnlink } = require("../lib/tmpManager");
const { execFile } = require("node:child_process");
const { promisify } = require("node:util");
const { sleep } = require("../lib/utils");

const execFileAsync = promisify(execFile);

const BASE = "https://audioconvert.ai";
const PAGE_URL = `${BASE}/id`;

const JWT_SECRET = "auc995cx6se";

const LANGUAGE_CODE = "";
const SCENARIO = "auto";

const USER_AGENT =
  "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";

function base64url(input) {
  return Buffer.from(input)
    .toString("base64")
    .replace(/=+$/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");
}

function createGuestBearer(userId = crypto.randomUUID()) {
  const header = {
    alg: "HS256",
    typ: "JWT"
  };

  const payload = {
    userId
  };

  const encodedHeader = base64url(JSON.stringify(header));
  const encodedPayload = base64url(JSON.stringify(payload));
  const data = `${encodedHeader}.${encodedPayload}`;

  const signature = crypto
    .createHmac("sha256", JWT_SECRET)
    .update(data)
    .digest("base64")
    .replace(/=+$/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");

  return {
    userId,
    token: `${data}.${signature}`
  };
}

function cleanUploadUrl(uploadUrl) {
  return String(uploadUrl).split("?")[0];
}

function isUrl(text) {
  return /^https?:\/\//i.test(String(text || "").trim());
}

function contentTypeToExt(type) {
  const clean = String(type || "").split(";")[0].trim().toLowerCase();

  if (clean === "audio/mpeg") return ".mp3";
  if (clean === "audio/mp3") return ".mp3";
  if (clean === "audio/wav") return ".wav";
  if (clean === "audio/x-wav") return ".wav";
  if (clean === "audio/ogg") return ".ogg";
  if (clean === "audio/aac") return ".aac";
  if (clean === "audio/mp4") return ".m4a";
  if (clean === "audio/x-m4a") return ".m4a";
  if (clean === "video/mp4") return ".mp4";
  if (clean === "video/webm") return ".webm";
  if (clean === "video/quicktime") return ".mov";

  return "";
}

function getExtFromUrl(url) {
  try {
    const pathname = new URL(url).pathname;
    const ext = path.extname(pathname).toLowerCase();

    if (
      [
        ".mp3",
        ".wav",
        ".ogg",
        ".aac",
        ".m4a",
        ".mp4",
        ".webm",
        ".mov",
        ".flac"
      ].includes(ext)
    ) {
      return ext;
    }
  } catch {}

  return "";
}

function headersBase(token) {
  return {
    "user-agent": USER_AGENT,
    authorization: `Bearer ${token}`,
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    referer: PAGE_URL,
    "sec-ch-ua": `"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"`,
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-platform": `"Android"`
  };
}

async function getDurationMinutes(filePath) {
  try {
    const { stdout } = await execFileAsync("ffprobe", [
      "-v",
      "error",
      "-show_entries",
      "format=duration",
      "-of",
      "default=noprint_wrappers=1:nokey=1",
      filePath
    ]);

    const seconds = Number(stdout.trim());

    if (!Number.isFinite(seconds) || seconds <= 0) return 1;

    return Math.max(1, Math.ceil(seconds / 60));
  } catch {
    return 1;
  }
}

class AudioConvertAI {
  constructor() {
    this.guest = createGuestBearer();
    this.client = axios.create({
      timeout: 30000,
      validateStatus: () => true
    });
  }

  get baseHeaders() {
    return headersBase(this.guest.token);
  }

  async warmup() {
    await this.client.get(PAGE_URL, {
      headers: {
        "user-agent": USER_AGENT,
        accept:
          "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        referer: BASE,
        "upgrade-insecure-requests": "1",
        "sec-ch-ua": `"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"`,
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": `"Android"`,
        "sec-fetch-site": "none",
        "sec-fetch-mode": "navigate",
        "sec-fetch-user": "?1",
        "sec-fetch-dest": "document"
      }
    });
  }

  async presign(filename) {
    const url = `${BASE}/api/resource/upload/presign?filename=${encodeURIComponent(filename)}`;

    const { data, status } = await this.client.get(url, {
      headers: {
        ...this.baseHeaders,
        accept: "*/*",
        "sec-fetch-site": "same-origin",
        "sec-fetch-mode": "cors",
        "sec-fetch-dest": "empty"
      }
    });

    if (
      status < 200 ||
      status >= 300 ||
      data?.code !== 100000 ||
      !data?.data?.upload_url
    ) {
      throw new Error(`Presign gagal HTTP ${status}: ${JSON.stringify(data)}`);
    }

    return data.data.upload_url;
  }

  async uploadToOss(uploadUrl, filePath) {
    const fileSize = fs.statSync(filePath).size;
    const url = new URL(uploadUrl);

    await new Promise((resolve, reject) => {
      const req = https.request(
        url,
        {
          method: "PUT",
          headers: {
            "Content-Length": fileSize
          }
        },
        res => {
          let body = "";

          res.setEncoding("utf8");

          res.on("data", chunk => {
            body += chunk;
          });

          res.on("end", () => {
            if (res.statusCode >= 200 && res.statusCode < 300) {
              resolve();
            } else {
              reject(new Error(`Upload OSS gagal HTTP ${res.statusCode}: ${body}`));
            }
          });
        }
      );

      req.on("error", reject);

      fs.createReadStream(filePath)
        .on("error", reject)
        .pipe(req);
    });

    return cleanUploadUrl(uploadUrl);
  }

  async checkGuestQuota(durationMinutes) {
    const { data, status } = await this.client.post(
      `${BASE}/api/transcribe/check-guest-quota`,
      {
        duration_minutes: durationMinutes
      },
      {
        headers: {
          ...this.baseHeaders,
          accept: "application/json",
          "content-type": "application/json",
          origin: BASE,
          "sec-fetch-site": "same-origin",
          "sec-fetch-mode": "cors",
          "sec-fetch-dest": "empty"
        }
      }
    );

    if (status < 200 || status >= 300 || data?.code !== 100000) {
      throw new Error(`Check quota gagal HTTP ${status}: ${JSON.stringify(data)}`);
    }

    if (!data?.data?.allowed) {
      throw new Error(`Quota tidak allowed: ${JSON.stringify(data)}`);
    }

    return data.data.allowed;
  }

  async createTranscribe(audioUrl, fileName) {
    const payload = {
      audio_url: audioUrl,
      language_code: LANGUAGE_CODE,
      file_name: fileName,
      scenario: SCENARIO
    };

    const { data, status } = await this.client.post(`${BASE}/api/transcribe/`, payload, {
      headers: {
        ...this.baseHeaders,
        accept: "application/json",
        "content-type": "application/json",
        origin: BASE,
        "sec-fetch-site": "same-origin",
        "sec-fetch-mode": "cors",
        "sec-fetch-dest": "empty"
      }
    });

    if (status < 200 || status >= 300 || data?.code !== 100000 || !data?.data?.id) {
      throw new Error(`Submit transcribe gagal HTTP ${status}: ${JSON.stringify(data)}`);
    }

    return data.data;
  }

  async getTranscribe(taskId) {
    const { data, status } = await this.client.get(`${BASE}/api/transcribe/${taskId}`, {
      headers: {
        ...this.baseHeaders,
        accept: "*/*",
        "sec-fetch-site": "same-origin",
        "sec-fetch-mode": "cors",
        "sec-fetch-dest": "empty"
      }
    });

    return { status, data };
  }

  extractText(data) {
    const d = data?.data ?? data;

    if (!d) return null;

    if (typeof d === "string") return d;

    const value =
      d.text ??
      d.transcript ??
      d.result ??
      d.content ??
      d.transcription ??
      d.segments?.map(x => x.text).filter(Boolean).join(" ") ??
      null;

    if (typeof value === "string") return value;

    if (value && typeof value === "object") {
      return (
        value.text ??
        value.transcript ??
        value.result ??
        value.content ??
        value.transcription ??
        null
      );
    }

    return null;
  }

  async pollResult(taskId) {
    for (let i = 0; i < 40; i++) {
      const { status, data } = await this.getTranscribe(taskId);

      if (data?.code === 100001 || data?.message === "Need Login") {
        return {
          done: false,
          need_login: true,
          text: null
        };
      }

      if (status >= 200 && status < 300 && data?.code === 100000) {
        const task = data.data;
        const text = this.extractText(data);

        if (
          task?.status === "succeeded" ||
          task?.status === "success" ||
          task?.status === "completed" ||
          text
        ) {
          return {
            done: true,
            need_login: false,
            text
          };
        }

        if (task?.status === "failed" || task?.status === "error") {
          throw new Error(task?.error ?? data?.message ?? "Transcribe failed");
        }
      }

      await sleep(3000);
    }

    return {
      done: false,
      need_login: false,
      text: null
    };
  }

  async transcribe(filePath) {
    await this.warmup();

    const fileName = path.basename(filePath);
    const durationMinutes = await getDurationMinutes(filePath);

    const uploadUrl = await this.presign(fileName);
    const audioUrl = await this.uploadToOss(uploadUrl, filePath);

    await this.checkGuestQuota(durationMinutes);

    const task = await this.createTranscribe(audioUrl, fileName);
    const poll = await this.pollResult(task.id);

    if (poll.need_login) {
      throw new Error("Need login / token guest ditolak");
    }

    if (!poll.text) {
      throw new Error("Transkrip belum selesai atau hasil kosong");
    }

    return poll.text;
  }
}

async function downloadFromUrl(url) {
  const tmpDir = await tmpDirAsync("audio/transcribe");

  const res = await axios.get(url, {
    responseType: "stream",
    timeout: 120000,
    maxRedirects: 5,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    validateStatus: () => true,
    headers: {
      accept: "audio/*,video/*,*/*",
      "user-agent": USER_AGENT,
      referer: url
    }
  });

  if (res.status >= 400) {
    throw new Error(`Gagal download URL HTTP ${res.status}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  const ext =
    contentTypeToExt(contentType) ||
    getExtFromUrl(url) ||
    ".mp3";

  const allowed =
    contentType.startsWith("audio/") ||
    contentType.startsWith("video/") ||
    contentType.includes("application/octet-stream") ||
    contentType.includes("binary/octet-stream") ||
    !!getExtFromUrl(url);

  if (!allowed) {
    throw new Error(`URL bukan direct audio/video. Content-Type: ${contentType || "-"}`);
  }

  const filePath = await tmpFileAsync({
    dir: "audio/transcribe",
    prefix: `input-${crypto.randomBytes(4).toString("hex")}`,
    ext
  });

  await pipeline(res.data, fs.createWriteStream(filePath));

  const stat = await fsp.stat(filePath);
  if (!stat.size) throw new Error("File hasil download kosong");

  return filePath;
}

async function downloadQuotedMedia(conn, m, q) {
  const tmpDir = await tmpDirAsync("audio/transcribe");

  let buffer;

  if (typeof q.download === "function") {
    buffer = await q.download();
  }

  if (!buffer && conn.downloadMediaMessage) {
    buffer = await conn.downloadMediaMessage(q);
  }

  if (!buffer) {
    throw new Error("Gagal download media dari pesan yang direply");
  }

  const mimetype = q.mimetype || q.msg?.mimetype || "";
  const ext = contentTypeToExt(mimetype) || ".mp3";

  const filePath = await tmpFileAsync({
    dir: "audio/transcribe",
    prefix: `quoted-${crypto.randomBytes(4).toString("hex")}`,
    ext
  });

  await fsp.writeFile(filePath, buffer);

  const stat = await fsp.stat(filePath);
  if (!stat.size) throw new Error("File media kosong");

  return filePath;
}

async function safeUnlink(filePath) {
  if (!filePath) return;

  try {
    await tmpSafeUnlink(filePath);
  } catch {}
}

function splitText(text, max = 3500) {
  const parts = [];
  let current = "";

  for (const line of String(text).split("\n")) {
    if ((current + "\n" + line).length > max) {
      if (current.trim()) parts.push(current.trim());
      current = line;
    } else {
      current += (current ? "\n" : "") + line;
    }
  }

  if (current.trim()) parts.push(current.trim());

  return parts.length ? parts : [String(text).slice(0, max)];
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let filePath = "";

  try {
    const q = m.quoted || m;
    const mime = q.mimetype || q.msg?.mimetype || "";

    if (!text && !/audio|video|octet-stream/i.test(mime)) {
      return m.reply(
        `乂 T R A N S C R I B E\n\n` +
          `Kirim/reply audio atau video, lalu ketik:\n` +
          `${usedPrefix + command}\n\n` +
          `Atau pakai direct URL:\n` +
          `${usedPrefix + command} https://example.com/audio.mp3`
      );
    }

    await conn.sendMessage(m.chat, {
      react: {
        text: "⏳",
        key: m.key
      }
    });

    await m.reply(
      `乂 T R A N S C R I B E\n\n` +
        `> [+] Status: Memproses audio/video\n` +
        `> [+] Note: Mengubah suara menjadi teks.`
    );

    if (text && isUrl(text.trim())) {
      filePath = await downloadFromUrl(text.trim());
    } else if (/audio|video|octet-stream/i.test(mime)) {
      filePath = await downloadQuotedMedia(conn, m, q);
    } else {
      return m.reply(
        `乂 T R A N S C R I B E\n\n` +
          `> [!] Input tidak valid.\n` +
          `> Reply audio/video atau masukkan direct URL.`
      );
    }

    const ai = new AudioConvertAI();
    const result = await ai.transcribe(filePath);

    const chunks = splitText(result, 3500);

    for (let i = 0; i < chunks.length; i++) {
      await m.reply(
        `乂 T R A N S C R I B E\n\n` +
          `> [+] Status: Berhasil\n` +
          `> [+] Part: ${i + 1}/${chunks.length}\n\n` +
          `${chunks[i]}`
      );
    }

    await conn.sendMessage(m.chat, {
      react: {
        text: "✅",
        key: m.key
      }
    });
  } catch (e) {
    await conn.sendMessage(m.chat, {
      react: {
        text: "❌",
        key: m.key
      }
    });

    await m.reply(
      `乂 T R A N S C R I B E\n\n` +
        `> [!] Terjadi error.\n` +
        `> ${e.message || e}`
    );
  } finally {
    await tmpSafeUnlink(filePath);
  }
};

handler.help = handler.command = ["transcribe", "audiotext", "suarateks", "audiototext", "voicetotext"];
handler.tags = ["tools"];
handler.limit = true;

module.exports = handler;