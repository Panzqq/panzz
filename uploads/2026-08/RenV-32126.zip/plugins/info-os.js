const os = require("os");
const { execSync } = require("child_process");

function formatUptime(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    const hrs = Math.floor((seconds % (3600 * 24)) / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return `${days} hari, ${hrs} jam, ${mins} menit, ${secs} detik`;
}

module.exports = {
    help: ["os *[info sistem]*"],
    tags: ["info"],
    command: ["os"],
    code: async (m, { conn }) => {
        let timestamp = Date.now();
        let latency = Date.now() - timestamp;

        let hostname = os.hostname();
        let platform = os.platform();
        let release = os.release();
        let osVersion = os.version();
        let uptimeStr = formatUptime(os.uptime());

        let cpus = os.cpus();
        let cpuModel = cpus[0]?.model || "Unknown";
        let cpuCores = cpus.length;
        let loadAvg = os.loadavg().map(n => n.toFixed(2)).join(", ");

        let totalMem = (os.totalmem() / 1024 / 1024).toFixed(0);
        let usedMem = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

        let disk = "Tidak tersedia";
        try {
            let rawDisk = execSync("df -h /").toString().split("\n")[1];
            let parts = rawDisk.split(/\s+/);
            disk = `${parts[2]} / ${parts[1]} (${parts[4]})`;
        } catch {}

        let proses = 0;
        try {
            proses = execSync("ps -e | wc -l").toString().trim();
        } catch {}

        let packages = 0;
        try {
            packages = execSync("dpkg --list | wc -l").toString().trim();
        } catch {}

        let teks = `
> \`[+] Hardware Information\`
> [+] Hostname     : ${hostname}
> [+] CPU          : ${cpuModel} (${cpuCores} cores)
> [+] Disk (/)     : ${disk}
> [+] Memory       : ${usedMem}MiB / ${totalMem}MiB
> [+] Load Average : ${loadAvg}

> \`[+] Software Information\`
> [+] OS           : ${release} (${platform})
> [+] Kernel       : ${osVersion}
> [+] Uptime       : ${uptimeStr}
> [+] Packages     : ${packages} (dpkg)
> [+] Active Proc  : ${proses}
> [+] Bot Latency  : ${latency.toFixed(2)} ms
        `;

        m.reply(teks.trim());
    }
};