const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const crypto = require("node:crypto");

const { AIRich } = require('../lib/nixcode.js')

const CRM_DIR = path.join(process.cwd(), "database");
const HISTORY_FILE = path.join(CRM_DIR, "crm-history.json");

const MAX_HISTORY = 100;

function stringify(obj, space = 2) {
    return JSON.stringify(obj, null, space);
}

function now() {
    return new Date().toISOString();
}

function shortId() {
    return crypto.randomBytes(4).toString("hex");
}

async function ensureDb() {
    await fsp.mkdir(CRM_DIR, { recursive: true });
    if (!fs.existsSync(HISTORY_FILE)) {
        await fsp.writeFile(HISTORY_FILE, stringify({ history: [] }));
    }
}

async function readHistory() {
    await ensureDb();
    try {
        const raw = await fsp.readFile(HISTORY_FILE, "utf8");
        const json = JSON.parse(raw);
        return Array.isArray(json.history) ? json : { history: [] };
    } catch {
        return { history: [] };
    }
}

async function writeHistory(db) {
    await ensureDb();
    await fsp.writeFile(HISTORY_FILE, stringify(db));
}

async function addHistory(entry) {
    const db = await readHistory();
    db.history.unshift({
        id: shortId(),
        created_at: now(),
        ...entry
    });
    db.history = db.history.slice(0, MAX_HISTORY);
    await writeHistory(db);
}

// ==================== HELPER FUNCTIONS ====================

function unwrapMessage(message) {
    let msg = message || {};
    let changed = true;
    while (changed) {
        changed = false;
        if (msg.ephemeralMessage?.message) { msg = msg.ephemeralMessage.message; changed = true; }
        if (msg.viewOnceMessage?.message) { msg = msg.viewOnceMessage.message; changed = true; }
        if (msg.viewOnceMessageV2?.message) { msg = msg.viewOnceMessageV2.message; changed = true; }
        if (msg.viewOnceMessageV2Extension?.message) { msg = msg.viewOnceMessageV2Extension.message; changed = true; }
        if (msg.documentWithCaptionMessage?.message) { msg = msg.documentWithCaptionMessage.message; changed = true; }
    }
    return msg;
}

function getMessageType(message) {
    const msg = unwrapMessage(message);
    return Object.keys(msg || {})[0] || "unknown";
}

function fixPayload(fullMsg) {
    if (!fullMsg.message) return fullMsg;
    const fixed = JSON.parse(JSON.stringify(fullMsg));
    const type = getMessageType(fixed.message);

    if (/^pollCreationMessage/i.test(type)) {
        fixed.message.messageContextInfo = fixed.message.messageContextInfo || {};
        fixed.message.messageContextInfo.messageSecret = 
            fixed.message.messageContextInfo.messageSecret || crypto.randomBytes(32).toString("base64");
    }
    return fixed;
}

function buildRelayOptions(type) {
    if (/interactiveMessage|buttonsMessage|templateMessage|listMessage/i.test(type)) {
        return {
            additionalNodes: [{
                tag: "biz",
                attrs: {},
                content: [{
                    tag: "interactive",
                    attrs: { type: "native_flow", v: "1" },
                    content: [{ tag: "native_flow", attrs: { v: "9", name: "mixed" } }]
                }]
            }]
        };
    }
    if (/^pollCreationMessage/i.test(type)) {
        return { additionalNodes: [{ tag: "meta", attrs: { polltype: "creation" } }] };
    }
    return {};
}

async function getQuotedFullMessage(conn, m) {
    if (!m.quoted) return null;

    let msg = null;
    if (conn.loadMessage && m.quoted.id) {
        try { msg = await conn.loadMessage(m.chat, m.quoted.id); } catch {}
    }
    if (!msg && typeof m.getQuotedObj === "function") {
        try { msg = await m.getQuotedObj(); } catch {}
    }
    if (!msg && m.quoted.fakeObj) msg = m.quoted.fakeObj;
    if (!msg && m.quoted.message) {
        msg = { key: m.quoted.key || {}, message: m.quoted.message };
    }
    return msg;
}

function getPayloadInfo(fullMsg) {
    const message = fullMsg.message || {};
    const type = getMessageType(message);
    const size = Buffer.byteLength(JSON.stringify(message));
    return { type, size };
}

function makeSnippet(message, options) {
    return `=> await conn.relayMessage(m.chat, ${stringify(message, 2)}, ${stringify(options, 2)});`;
}

// ==================== MAIN HANDLER ====================

let handler = async (m, { conn }) => {
    try {
        const fullMsgRaw = await getQuotedFullMessage(conn, m);
        
        if (!fullMsgRaw) {
            return m.reply(`乂 *CRM SNIP*\n\n> [!] Reply pesan yang ingin dijadikan snippet.`);
        }

        const fullMsg = fixPayload(fullMsgRaw);
        const info = getPayloadInfo(fullMsg);
        const options = buildRelayOptions(info.type);
        const snippetCode = makeSnippet(fullMsg.message, options);

        await addHistory({
            action: "snip",
            type: info.type,
            message: fullMsg.message,
            options
        });

        await new AIRich(conn)
            .setTitle("📦 CRM SNIPPET")
            .setFooter(`${info.type} • ${info.size} bytes`)
            .addText(`**Type:** ${info.type}\n**Size:** ${info.size} bytes`)
            .addCode("javascript", snippetCode)
            .send(m.chat, { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply(`乂 *CRM ERROR*\n\n> ${e.message || e}`);
    }
};

handler.help = handler.command = ["crm"];
handler.tags = ["owner"];
handler.owner = true;

module.exports = handler;