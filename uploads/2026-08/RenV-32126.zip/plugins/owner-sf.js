/*
Ini Weem Gweh Mbud Jan Di Hapus
WhatsApp: wa.me/62857021072505
Jangan Perjual Belikan Esce Ini MeGMeG.
*/

const fs = require("fs");
const path = require("path");
const syntaxerror = require("syntax-error");

function cleanNamePart(name = "") {
  name = String(name || "").trim();
  name = name.replace(/\\/g, "/");
  name = path.basename(name);
  return name.replace(/[<>:"|?*]/g, "_");
}

function hasExtension(fileName = "") {
  return /\.[a-z0-9]+$/i.test(path.basename(fileName));
}

function ensureJsExtension(fileName = "") {
  const base = path.basename(fileName);
  if (/\.js\.js$/i.test(base)) return base.replace(/\.js\.js$/i, ".js");
  if (/\.cjs\.js$/i.test(base)) return base.replace(/\.js$/i, "");
  if (/\.mjs\.js$/i.test(base)) return base.replace(/\.js$/i, "");

  if (/\.(js|cjs|mjs|txt)$/i.test(base)) return base;
  return base + ".js";
}

function normalizeTargetPath(input = "") {
  let raw = String(input || "").trim().replace(/\\/g, "/");
  if (!raw) raw = "menu";

  // Kalau user cuma tulis nama file tanpa folder, default ke plugins/
  const hasFolder = raw.includes("/");
  const last = raw.split("/").pop() || "";

  // Kalau tidak ada ekstensi, auto .js
  if (!hasExtension(last)) {
    raw = raw.endsWith("/") ? raw.slice(0, -1) : raw;
    raw = raw + ".js";
  }

  // Kalau user tulis "menu.js" tanpa folder, taruh ke plugins/
  if (!hasFolder) {
    raw = path.join("plugins", raw);
  }

  // Rapikan basename agar tidak dobel aneh
  const dir = path.dirname(raw);
  const base = cleanNamePart(path.basename(raw));
  const finalBase = ensureJsExtension(base);

  return path.normalize(path.join(dir, finalBase));
}

function isCodeFileByPath(filePath = "", mime = "") {
  return (
    /\.(js|cjs|mjs|txt)$/i.test(filePath) ||
    /javascript|text|plain|octet-stream/i.test(mime)
  );
}

async function hotloadPlugin(savePath) {
  if (typeof global.loadPlugin !== "function") {
    return { ok: false, error: "global.loadPlugin belum tersedia" };
  }

  let source;
  try {
    source = fs.readFileSync(savePath);
  } catch (e) {
    return { ok: false, error: `Gagal baca file: ${e.message}` };
  }

  const rel = path.relative(process.cwd(), savePath);
  const synErr = syntaxerror(source, rel, { sourceType: "module" });

  if (synErr) {
    return { ok: false, error: `Syntax error: ${synErr.message}` };
  }

  try {
    await global.loadPlugin(savePath);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

async function readQuotedText(q) {
  if (!q) return null;

  if (typeof q.text === "string" && q.text.trim()) return q.text;

  const msg = q.msg || q.message || {};
  const text =
    msg.conversation ||
    msg.extendedTextMessage?.text ||
    msg.imageMessage?.caption ||
    msg.videoMessage?.caption ||
    msg.documentMessage?.caption ||
    "";

  return text && text.trim() ? text : null;
}

async function readQuotedBuffer(q, conn) {
  if (!q) return null;

  if (typeof q.download === "function") {
    const buf = await q.download().catch(() => null);
    if (buf) return buf;
  }

  if (conn?.downloadMediaMessage) {
    const buf = await conn.downloadMediaMessage(q).catch(() => null);
    if (buf) return buf;
  }

  return null;
}

function getQuotedFileName(q = {}) {
  return (
    q.fileName ||
    q.msg?.fileName ||
    q.message?.documentMessage?.fileName ||
    q.message?.imageMessage?.fileName ||
    q.message?.videoMessage?.fileName ||
    ""
  );
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    const q = m.quoted || null;
    const input = String(text || "").trim();
    const quotedText = q ? await readQuotedText(q) : null;

    if (!input && !q) {
      return conn.reply(
        m.chat,
        `> [-] Input tidak ditemukan
> [+] Example: \`${usedPrefix + command} menu\`
> [+] Example: \`${usedPrefix + command} lib/p.js\`
> [+] Atau reply teks / file lalu ketik: \`${usedPrefix + command}\``,
        m
      );
    }

    const quotedFileName = q ? getQuotedFileName(q) : "";
    const targetInput = input || quotedFileName || "menu";
    const savePath = normalizeTargetPath(targetInput);
    const fullSavePath = path.join(process.cwd(), savePath);

    const pluginsDir = path.dirname(fullSavePath);
    if (!fs.existsSync(pluginsDir)) {
      fs.mkdirSync(pluginsDir, { recursive: true });
    }

    // 1) Kalau reply teks
    if (quotedText) {
      fs.writeFileSync(fullSavePath, quotedText, "utf8");

      const shouldHotload = isCodeFileByPath(fullSavePath, "text/plain");
      let loadResult = { ok: true };

      if (shouldHotload) {
        loadResult = await hotloadPlugin(fullSavePath);
      }

      const statusLine = shouldHotload
        ? loadResult.ok
          ? `> [+] Plugin   : ✅ Aktif sekarang (tanpa restart)`
          : `> [-] Plugin   : ⚠ ${loadResult.error}\n> [!] Note    : Cek syntax, plugin belum aktif`
        : `> [+] Plugin   : ℹ Tidak di-hotload karena bukan file plugin`;

      return m.reply(
        `> [+] Status   : Success
> [+] File     : \`${path.basename(fullSavePath)}\`
> [+] Path     : \`${savePath}\`
> [+] Sumber   : Dari teks
${statusLine}`
      );
    }

    // 2) Kalau reply file / document / media
    if (q) {
      const mime = q.mimetype || q.msg?.mimetype || q.message?.mimetype || "";

      const buffer = await readQuotedBuffer(q, conn);
      if (!buffer) {
        return conn.reply(
          m.chat,
          `> [-] Status   : Error
> [+] Result   : Gagal download file`,
          m
        );
      }

      // Kalau user kasih nama tanpa ekstensi, file hasil tetap ikut .js untuk teks/code
      // kalau file media non-code, tetap pakai nama target apa adanya
      const finalExt = path.extname(fullSavePath);
      const isCodeTarget = isCodeFileByPath(fullSavePath, mime);

      let writePath = fullSavePath;

      // Jika target tidak punya ekstensi dan isi file adalah code/text, paksa .js
      if (!finalExt && isCodeTarget) {
        writePath = fullSavePath + ".js";
      }

      if (!fs.existsSync(path.dirname(writePath))) {
        fs.mkdirSync(path.dirname(writePath), { recursive: true });
      }

      fs.writeFileSync(writePath, buffer);

      const shouldHotload = isCodeFileByPath(writePath, mime);
      let loadResult = { ok: true };

      if (shouldHotload) {
        loadResult = await hotloadPlugin(writePath);
      }

      const statusLine = shouldHotload
        ? loadResult.ok
          ? `> [+] Plugin   : ✅ Aktif sekarang (tanpa restart)`
          : `> [-] Plugin   : ⚠ ${loadResult.error}\n> [!] Note    : Cek syntax, plugin belum aktif`
        : `> [+] Plugin   : ℹ Tidak di-hotload karena bukan file plugin`;

      return m.reply(
        `> [+] Status   : Success
> [+] File     : \`${path.basename(writePath)}\`
> [+] Path     : \`${path.relative(process.cwd(), writePath)}\`
> [+] Size     : ${(buffer.length / 1024).toFixed(2)} KB
> [+] Sumber   : Dari file
${statusLine}`
      );
    }

    return conn.reply(
      m.chat,
      `> [-] Tidak ada data
> [+] Info: Reply pesan berisi teks atau file`,
      m
    );
  } catch (error) {
    console.log(error);

    return conn.reply(
      m.chat,
      `> [-] Status   : Error
> [+] Result   : Gagal menyimpan file
> [+] Error    : ${error.message || error}`,
      m
    );
  }
};

handler.help = ["sf"].map(v => v + " *<nama_file|path>*");
handler.tags = ["owner"];
handler.command = /^sf$/i;

handler.rowner = true;
handler.owner = true;

module.exports = handler;