const { fetch } = require("undici");
const { extension } = require("mime-types");
const { html: beautifyHtml } = require("js-beautify");

function isUrl(string) {
    return String(string || "")
        .match(/https?:\/\/[^\s<>"']+/gi)
        ?.map(v => v.replace(/[),.]+$/g, "")) || [];
}

function cleanFileName(name) {
    return String(name || "result")
        .replace(/[\\/:*?"<>|]/g, "_")
        .trim();
}

function getExtFromMime(mime = "") {
    return extension(mime) || "bin";
}

function getFileNameFromUrl(url, mime = "application/octet-stream") {
    try {
        const u = new URL(url);
        let name = decodeURIComponent(u.pathname.split("/").pop() || "");

        name = cleanFileName(name);

        if (!name || !name.includes(".")) {
            name = `result.${getExtFromMime(mime)}`;
        }

        return name;
    } catch {
        return `result.${getExtFromMime(mime)}`;
    }
}

function getFileNameFromDisposition(disposition = "") {
    if (!disposition) return null;

    let match =
        disposition.match(/filename\*=UTF-8''([^;]+)/i) ||
        disposition.match(/filename="?([^"]+)"?/i);

    if (!match) return null;

    try {
        return cleanFileName(decodeURIComponent(match[1]));
    } catch {
        return cleanFileName(match[1]);
    }
}

function detectMime(buffer, fallback = "application/octet-stream") {
    if (!buffer || buffer.length < 12) return fallback;

    const hex = buffer.slice(0, 12).toString("hex");

    if (hex.startsWith("89504e47")) return "image/png";
    if (hex.startsWith("ffd8ff")) return "image/jpeg";
    if (hex.startsWith("47494638")) return "image/gif";
    if (buffer.slice(0, 4).toString() === "RIFF" && buffer.slice(8, 12).toString() === "WEBP") return "image/webp";
    if (buffer.slice(0, 4).toString() === "%PDF") return "application/pdf";
    if (hex.startsWith("504b0304")) return "application/zip";

    return fallback;
}

function isTextMime(mime = "", url = "") {
    mime = String(mime || "").toLowerCase();
    url = String(url || "").toLowerCase();

    return (
        mime.startsWith("text/") ||
        mime.includes("json") ||
        mime.includes("xml") ||
        mime.includes("javascript") ||
        mime.includes("ecmascript") ||
        /\.(txt|md|csv|log|ini|conf|env|html|htm|css|scss|sass|less|js|mjs|cjs|ts|tsx|jsx|json|xml|yaml|yml|py|php|java|c|cpp|cc|h|hpp|go|rs|sh|bash|zsh|ps1|bat|cmd|sql|rb|pl|lua|dart|kt|kts|swift|vue|svelte|sveltejs|toml|lock)$/i.test(url)
    );
}

function isCodeFile(mime = "", url = "", fileName = "") {
    mime = String(mime || "").toLowerCase();
    url = String(url || "").toLowerCase();
    fileName = String(fileName || "").toLowerCase();

    return (
        mime.includes("json") ||
        mime.includes("javascript") ||
        mime.includes("ecmascript") ||
        mime.includes("xml") ||
        mime.includes("html") ||
        mime.includes("css") ||
        mime.includes("text/") ||
        /\.(js|mjs|cjs|ts|tsx|jsx|json|html|htm|css|scss|sass|less|xml|yml|yaml|md|txt|py|php|java|c|cpp|cc|h|hpp|go|rs|sh|bash|zsh|ps1|bat|cmd|sql|rb|pl|lua|dart|kt|kts|swift|vue|svelte|toml|ini|conf|env|log)$/i.test(url) ||
        /\.(js|mjs|cjs|ts|tsx|jsx|json|html|htm|css|scss|sass|less|xml|yml|yaml|md|txt|py|php|java|c|cpp|cc|h|hpp|go|rs|sh|bash|zsh|ps1|bat|cmd|sql|rb|pl|lua|dart|kt|kts|swift|vue|svelte|toml|ini|conf|env|log)$/i.test(fileName)
    );
}

function getCodeLanguage(fileName = "", mime = "", url = "") {
    const name = String(fileName || "").toLowerCase();
    const m = String(mime || "").toLowerCase();
    const u = String(url || "").toLowerCase();

    if (name.endsWith(".mjs") || name.endsWith(".cjs") || name.endsWith(".js") || m.includes("javascript") || m.includes("ecmascript")) return "javascript";
    if (name.endsWith(".ts") || name.endsWith(".tsx")) return "typescript";
    if (name.endsWith(".jsx")) return "javascript";
    if (name.endsWith(".json") || m.includes("json")) return "json";
    if (name.endsWith(".html") || name.endsWith(".htm") || m.includes("html")) return "html";
    if (name.endsWith(".css") || m.includes("css")) return "css";
    if (name.endsWith(".xml") || m.includes("xml")) return "xml";
    if (name.endsWith(".yml") || name.endsWith(".yaml")) return "yaml";
    if (name.endsWith(".md")) return "markdown";
    if (name.endsWith(".py")) return "python";
    if (name.endsWith(".php")) return "php";
    if (name.endsWith(".java")) return "java";
    if (name.endsWith(".go")) return "go";
    if (name.endsWith(".rs")) return "rust";
    if (name.endsWith(".sh") || name.endsWith(".bash") || name.endsWith(".zsh")) return "bash";
    if (name.endsWith(".sql")) return "sql";
    if (name.endsWith(".dart")) return "dart";
    if (name.endsWith(".kt") || name.endsWith(".kts")) return "kotlin";
    if (name.endsWith(".swift")) return "swift";
    if (name.endsWith(".c")) return "c";
    if (name.endsWith(".cpp") || name.endsWith(".cc") || name.endsWith(".hpp") || name.endsWith(".h")) return "cpp";
    if (name.endsWith(".lua")) return "lua";
    if (name.endsWith(".rb")) return "ruby";
    if (name.endsWith(".ps1")) return "powershell";
    if (name.endsWith(".bat") || name.endsWith(".cmd")) return "batch";
    if (name.endsWith(".toml")) return "toml";
    if (name.endsWith(".ini") || name.endsWith(".conf") || name.endsWith(".env")) return "ini";

    if (u.includes("javascript") || u.includes("js")) return "javascript";
    return "text";
}

function getHeaders(url) {
    const headers = {
        "user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36",
        "accept": "*/*",
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"
    };

    if (/sparkpix\.ai/i.test(url)) {
        headers.accept = "image/avif,image/webp,image/apng,image/png,image/jpeg,image/*,*/*;q=0.8";
        headers.origin = "https://sparkpix.ai";
        headers.referer = "https://sparkpix.ai/aitools/free-hd-upscaler";
    }

    return headers;
}

async function fetchBody(url, timeout = 120000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);

    try {
        const res = await fetch(url, {
            method: "GET",
            redirect: "follow",
            signal: controller.signal,
            headers: getHeaders(url)
        });

        const buffer = Buffer.from(await res.arrayBuffer());

        return {
            res,
            buffer
        };
    } finally {
        clearTimeout(timer);
    }
}

async function ensureAIRich(conn) {
    let AIRich;
    let installAIRich;
    let installNixcode;

    try {
        const airich = require("../lib/airich.js");
        AIRich = airich.AIRich;
        installAIRich = airich.installAIRich;
        installNixcode = airich.installNixcode;
    } catch {
        try {
            const airich = require("./lib/airich.js");
            AIRich = airich.AIRich;
            installAIRich = airich.installAIRich;
            installNixcode = airich.installNixcode;
        } catch {}
    }

    if (typeof conn.sendAIRich !== "function") {
        if (typeof installAIRich === "function") installAIRich(conn);
        else if (typeof installNixcode === "function") installNixcode(conn);
    }

    return AIRich;
}

async function sendCodeRich(conn, m, {
    title,
    footer,
    caption,
    code,
    language
}) {
    const AIRich = await ensureAIRich(conn);

    if (typeof conn.sendAIRich === "function") {
        return conn.sendAIRich(m.chat, {
            title,
            footer,
            text: [caption],
            code: [{
                language,
                content: code
            }],
            suggest: [".menu", ".ping", ".owner"]
        }, m);
    }

    if (!AIRich) {
        throw new Error("Class AIRich tidak ditemukan");
    }

    const rich = new AIRich(conn)
        .setTitle(title)
        .setFooter(footer);

    rich.addText(caption);
    rich.addCode(language, code);
    rich.addSuggest([".menu", ".ping", ".owner"]);

    await rich.send(m.chat, {
        quoted: m,
        forwarded: true
    });
}

module.exports = {
    help: ["get"].map(a => a + " *[url]*"),
    tags: ["downloader"],
    command: ["get"],
    code: async (m, {
        conn,
        usedPrefix,
        command,
        text
    }) => {
        const urls = isUrl(text);

        if (!urls.length) {
            throw `*• Example :* ${usedPrefix + command} *[url]*`;
        }

        await m.reply(typeof wait !== "undefined" ? wait : "⏳ Sedang mengambil data URL...");

        for (let url of urls) {
            try {
                const { res, buffer } = await fetchBody(url);

                let mime = res.headers.get("content-type") || "application/octet-stream";
                mime = mime.split(";")[0].trim().toLowerCase();

                mime = detectMime(buffer, mime);

                const disposition = res.headers.get("content-disposition") || "";
                const fileName =
                    getFileNameFromDisposition(disposition) ||
                    getFileNameFromUrl(url, mime);

                const size = buffer.length;

                const cap = `乂 *F E T C H  -  U R L*
◦ Request : ${url}
◦ Status : ${res.status} ${res.statusText || ""}
◦ Mimetype : ${mime}
◦ Size : ${(size / 1024 / 1024).toFixed(2)} MB`;

                if (!res.ok) {
                    let errText = buffer.toString("utf8");

                    if (errText.length > 3000) {
                        errText = errText.slice(0, 3000) + "\n\n...";
                    }

                    await conn.reply(
                        m.chat,
                        `${cap}\n\n❌ Gagal mengambil URL.\n\n${errText}`,
                        m
                    );
                    continue;
                }

                const language = getCodeLanguage(fileName, mime, url);
                const isCode = isCodeFile(mime, url, fileName);

                if (isCode) {
                    let result = buffer.toString("utf8");

                    if (/\.html?$|text\/html|application\/xhtml\+xml/i.test(`${fileName} ${mime}`)) {
                        try {
                            result = beautifyHtml(result);
                        } catch {}
                    }

                    try {
                        await sendCodeRich(conn, m, {
                            title: "Fetch URL - Code File",
                            footer: `Mimetype: ${mime} • Size: ${(size / 1024 / 1024).toFixed(2)} MB`,
                            caption: cap,
                            code: result,
                            language
                        });
                    } catch (e) {
                        await conn.sendMessage(m.chat, {
                            document: Buffer.from(result),
                            caption: cap,
                            fileName: fileName.endsWith(".txt") ? fileName : fileName,
                            mimetype: mime.startsWith("text/") ? mime : "text/plain"
                        }, { quoted: m });
                    }

                    continue;
                }

                if (mime.includes("html")) {
                    const result = beautifyHtml(buffer.toString("utf8"));

                    try {
                        await sendCodeRich(conn, m, {
                            title: "Fetch URL - HTML",
                            footer: `Mimetype: ${mime} • Size: ${(size / 1024 / 1024).toFixed(2)} MB`,
                            caption: cap,
                            code: result,
                            language: "html"
                        });
                    } catch {
                        await conn.sendMessage(m.chat, {
                            document: Buffer.from(result),
                            caption: cap,
                            fileName: fileName.endsWith(".html") ? fileName : "result.html",
                            mimetype: "text/html"
                        }, { quoted: m });
                    }

                    continue;
                }

                if (mime.includes("json")) {
                    let result = buffer.toString("utf8");

                    try {
                        result = JSON.stringify(JSON.parse(result), null, 2);
                    } catch {}

                    try {
                        await sendCodeRich(conn, m, {
                            title: "Fetch URL - JSON",
                            footer: `Mimetype: ${mime} • Size: ${(size / 1024 / 1024).toFixed(2)} MB`,
                            caption: cap,
                            code: result,
                            language: "json"
                        });
                    } catch {
                        if (result.length <= 3500) {
                            await conn.reply(m.chat, `${cap}\n\n${result}`, m);
                        } else {
                            await conn.sendMessage(m.chat, {
                                document: Buffer.from(result),
                                caption: cap,
                                fileName: fileName.endsWith(".json") ? fileName : "result.json",
                                mimetype: "application/json"
                            }, { quoted: m });
                        }
                    }

                    continue;
                }

                if (isTextMime(mime, url)) {
                    const result = buffer.toString("utf8");

                    await conn.sendMessage(m.chat, {
                        document: Buffer.from(result),
                        caption: cap,
                        fileName,
                        mimetype: mime.startsWith("text/") ? mime : "text/plain"
                    }, { quoted: m });

                    continue;
                }

                if (mime.startsWith("image/")) {
                    if (size <= 8 * 1024 * 1024) {
                        await conn.sendMessage(m.chat, {
                            image: buffer,
                            caption: cap,
                            mimetype: mime
                        }, { quoted: m });
                    } else {
                        await conn.sendMessage(m.chat, {
                            document: buffer,
                            caption: cap,
                            fileName,
                            mimetype: mime
                        }, { quoted: m });
                    }

                    continue;
                }

                if (mime.startsWith("video/")) {
                    await conn.sendMessage(m.chat, {
                        video: buffer,
                        caption: cap,
                        mimetype: mime
                    }, { quoted: m });

                    continue;
                }

                if (mime.startsWith("audio/")) {
                    await conn.sendAudioMessage(m.chat, buffer, ftroli, {
                        mimetype: mime,
                        fileName
                    });

                    continue;
                }

                await conn.sendMessage(m.chat, {
                    document: buffer,
                    caption: cap,
                    fileName,
                    mimetype: mime
                }, { quoted: m });

            } catch (e) {
                let msg = e && e.message ? e.message : String(e);

                if (/aborted/i.test(msg)) {
                    msg = "Request timeout. URL terlalu lama merespon.";
                }

                await conn.reply(
                    m.chat,
                    `❌ Gagal fetch URL:\n${url}\n\n*Error:*\n${msg}`,
                    m
                );
            }
        }
    }
};