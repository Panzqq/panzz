'use strict';

/**
 * plugins/mydrive.js
 * ─────────────────────────────────────────────────────────────────
 * Statistik Google Drive: sisa/terpakai storage, dan rekap file
 * yang udah diupload lewat bot (.tourl).
 * Self-contained, baca token yang sama kayak uploader-tourl.js
 * (data/google-drive-tokens.json).
 *
 * PERINTAH:
 *   .mydrive — tampilkan status storage + statistik upload
 */

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '../data');
const TOKENS_FILE = path.join(DATA_DIR, 'google-drive-tokens.json');

const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const ABOUT_API = 'https://www.googleapis.com/drive/v3/about?fields=user(emailAddress),storageQuota(limit,usage,usageInDrive,usageInDriveTrash)';
const FILES_API = 'https://www.googleapis.com/drive/v3/files';

fs.mkdirSync(DATA_DIR, { recursive: true });

// ───────────────────────── Token (sama pattern kayak uploader-tourl.js) ─────────────────────────

function _loadTokens() {
  try { return JSON.parse(fs.readFileSync(TOKENS_FILE, 'utf-8')); }
  catch { return {}; }
}

function _saveTokens(data) {
  fs.writeFileSync(TOKENS_FILE, JSON.stringify(data, null, 2));
}

function hasToken() {
  return !!_loadTokens().refresh_token;
}

async function getAccessToken(force = false) {
  const tokens = _loadTokens();
  if (!tokens.refresh_token) {
    throw new Error('Belum setup token Drive. Kirim `.tourlauth` dulu.');
  }
  if (!force && tokens.access_token && tokens.expiry > Date.now() + 30_000) {
    return tokens.access_token;
  }

  const cid = "764004159674-anpgq6apgl2fc1o8gbe5pgi46fg1habl.apps.googleusercontent.com"
  const secret = "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";
  if (!cid || !secret) throw new Error('GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET belum di-set di .env');

  const body =
    `client_id=${encodeURIComponent(cid)}` +
    `&client_secret=${encodeURIComponent(secret)}` +
    `&refresh_token=${encodeURIComponent(tokens.refresh_token)}` +
    `&grant_type=refresh_token`;

  const resp = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body
  });

  const data = await resp.json();
  if (!resp.ok || !data.access_token) {
    throw new Error('Gagal refresh token Drive: ' + (data.error_description || data.error || JSON.stringify(data)));
  }

  _saveTokens({ ...tokens, access_token: data.access_token, expiry: Date.now() + (data.expires_in - 60) * 1000 });
  return data.access_token;
}

// ───────────────────────── Data fetch ─────────────────────────

async function getStorageInfo(token) {
  const res = await fetch(ABOUT_API, { headers: { Authorization: `Bearer ${token}` } });
  const data = await res.json();
  if (!res.ok) throw new Error('Gagal ambil info storage: ' + (data.error?.message || JSON.stringify(data)));
  return data;
}

async function getAllUploadedFiles(token) {
  let files = [];
  let pageToken = null;

  do {
    const url = new URL(FILES_API);
    url.searchParams.set('fields', 'nextPageToken,files(id,name,mimeType,size,createdTime)');
    url.searchParams.set('pageSize', '1000');
    url.searchParams.set('orderBy', 'createdTime desc');
    if (pageToken) url.searchParams.set('pageToken', pageToken);

    const res = await fetch(url.toString(), { headers: { Authorization: `Bearer ${token}` } });
    const data = await res.json();
    if (!res.ok) throw new Error('Gagal ambil daftar file: ' + (data.error?.message || JSON.stringify(data)));

    files = files.concat(data.files || []);
    pageToken = data.nextPageToken || null;
  } while (pageToken);

  return files;
}

// ───────────────────────── Helper ─────────────────────────

function detectFileType(mime = '') {
  if (/^image/.test(mime)) return 'Image';
  if (/^video/.test(mime)) return 'Video';
  if (/^audio/.test(mime)) return 'Audio';
  if (/pdf|word|excel|presentation|officedocument|text/.test(mime)) return 'Document';
  if (/zip|rar|7z|tar/.test(mime)) return 'Archive';
  return 'Other';
}

function fmtBytes(bytesLike) {
  const bytes = Number(bytesLike || 0);
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  let val = bytes;
  while (val >= 1024 && i < units.length - 1) {
    val /= 1024;
    i++;
  }
  return `${val.toFixed(2)} ${units[i]}`;
}

function fmtDate(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
}

function bar(percent, len = 10) {
  const filled = Math.round((percent / 100) * len);
  return '='.repeat(Math.min(filled, len)) + '-'.repeat(Math.max(len - filled, 0));
}

// ───────────────────────── Handler ─────────────────────────

let handler = async (m, { conn }) => {
  if (!hasToken()) {
    throw new Error('Drive belum disetup. Kirim `.tourlauth` dulu buat panduan setup.');
  }

  const token = await getAccessToken();
  const [about, files] = await Promise.all([
    getStorageInfo(token),
    getAllUploadedFiles(token)
  ]);

  const quota = about.storageQuota || {};
  const limit = Number(quota.limit || 0);
  const usage = Number(quota.usage || 0);
  const usageInDrive = Number(quota.usageInDrive || 0);
  const usageInTrash = Number(quota.usageInDriveTrash || 0);
  const sisa = limit ? limit - usage : null;
  const persen = limit ? (usage / limit) * 100 : 0;

  const totalFiles = files.length;
  const totalSize = files.reduce((sum, f) => sum + Number(f.size || 0), 0);

  const byType = {};
  for (const f of files) {
    const t = detectFileType(f.mimeType);
    byType[t] = (byType[t] || 0) + 1;
  }

  const terakhir = files[0];

  const lines = [];

  lines.push('`GOOGLE DRIVE`');
  lines.push('');
  lines.push(`> [+] Akun        > ${about.user?.emailAddress || '-'}`);
lines.push(`> [+] Kapasitas   > ${limit ? fmtBytes(limit) : 'Unlimited'}`);
lines.push(`> [+] Terpakai    > ${fmtBytes(usage)}`);
lines.push(`> [+] Sisa        > ${sisa !== null ? fmtBytes(sisa) : '-'}`);
if (limit) {
  lines.push(`> [+] Progress    > [${bar(persen)}] ${persen.toFixed(2)}%`);
}
lines.push(`> [+] Di Drive    > ${fmtBytes(usageInDrive)}`);
lines.push(`> [+] Di Trash    > ${fmtBytes(usageInTrash)}`);
  lines.push('');
  lines.push('`STATISTIK UPLOAD BOT`');
  lines.push('');
  lines.push(`> [+] Total file  > ${totalFiles}`);
lines.push(`> [+] Total size  > ${fmtBytes(totalSize)}`);
for (const [type, count] of Object.entries(byType)) {
  lines.push(`> [+] ${type.padEnd(11, ' ')} > ${count}`);
}
  lines.push('');
  lines.push('`UPLOAD TERAKHIR`');
  lines.push('');
  if (terakhir) {
    lines.push(`> [+] Nama        > ${terakhir.name}`);
lines.push(`> [+] Ukuran      > ${fmtBytes(terakhir.size)}`);
lines.push(`> [+] Tipe        > ${detectFileType(terakhir.mimeType)}`);
lines.push(`> [+] Waktu       > ${fmtDate(terakhir.createdTime)}`);
  } else {
    lines.push('[+] Belum ada file yang diupload lewat bot.');
  }

  await conn.reply(m.chat, lines.join('\n'), m);
};

handler.help = ['mydrive'];
handler.tags = ['uploader'];
handler.command = /^mydrive$/i;
handler.limit = true;

module.exports = handler;