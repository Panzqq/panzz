const MAX_ROW_TITLE = 34;
const DEFAULT_FOOTER = () => `[ ${global.namebot || "Renvy"} :: ${global.nameown || "Owner"} ]`;

let handler = async (m, { conn, args, usedPrefix, command }) => {
  const prefix = usedPrefix || ".";
  const sub = (args[0] || "").toLowerCase();

  if (!global.db.data.chats) global.db.data.chats = {};

  if (!sub) return sendGroupList(m, conn, prefix, command);

  if (["refresh", "list", "daftar"].includes(sub)) {
    return sendGroupList(m, conn, prefix, command);
  }

  if (["info", "detail", "select", "pilih"].includes(sub)) {
    const jid = normalizeGroupJid(args[1]);
    if (!jid) return m.reply(`*[!] ID grup tidak valid.*\n\n> Contoh: *${prefix + command} info 120xxxxx@g.us*`);
    return sendGroupInfo(m, conn, jid, prefix, command);
  }

  if (["actions", "menu", "opsi"].includes(sub)) {
    const jid = normalizeGroupJid(args[1]);
    if (!jid) return m.reply(`*[!] ID grup tidak valid.*`);
    return sendActionMenu(m, conn, jid, prefix, command);
  }

  if (["action", "act", "aksi"].includes(sub)) {
    const action = (args[1] || "").toLowerCase();
    const jid = normalizeGroupJid(args[2]);
    if (!action || !jid) return m.reply(`*[!] Format salah.*\n\n> Contoh: *${prefix + command} action banchat 120xxxxx@g.us*`);
    return runGroupAction(m, conn, action, jid, prefix, command);
  }

  if (/^\d+$/.test(sub)) {
    const groups = await getAllGroups(conn);
    const index = Number(sub) - 1;
    const target = groups[index];
    if (!target) return m.reply(`*[!] Grup nomor ${sub} tidak ditemukan.*`);
    return sendGroupInfo(m, conn, target.jid, prefix, command);
  }

  return sendGroupList(m, conn, prefix, command);
};

handler.help = ["listgc"];
handler.tags = ["owner"];
handler.command = /^(listgc|gclist|totalgc)$/i;
handler.owner = true;

module.exports = handler;

async function sendGroupList(m, conn, prefix, command) {
  const groups = await getAllGroups(conn);

  if (!groups.length) {
    return m.reply("*[!] Bot belum terdeteksi masuk ke grup mana pun.*");
  }

  const rows = groups.map((group, i) => {
    const chat = ensureChat(group.jid);
    const name = cutText(group.subject || group.name || `Group ${i + 1}`, MAX_ROW_TITLE);
    const total = group.memberCount ? `${group.memberCount} member` : "member tidak terbaca";
    const status = chat.isBanned ? "Banchat ON" : "Banchat OFF";

    return {
      header: `${chat.isBanned ? "🔒" : "🟢"} Grup ${i + 1}`,
      title: name,
      description: `${total} • ${status}`,
      id: `${prefix + command} info ${group.jid}`
    };
  });

  const sections = chunkArray(rows, 10).map((part, i) => ({
    title: `Daftar Grup ${i * 10 + 1}-${i * 10 + part.length}`,
    rows: part
  }));

  const banned = groups.filter((v) => ensureChat(v.jid).isBanned).length;
  const text = `
> *[ LIST GROUP CONTROL ]*

> Total Grup : *${groups.length}*
> Banchat ON : *${banned}*
> Banchat OFF : *${groups.length - banned}*

`.trim();

  return conn.sendButtonLoc(
    m.chat,
    [
      { id: `${prefix + command} refresh`, text: "[ List Group ]", native: true }
    ],
    text,
    DEFAULT_FOOTER(),
    m,
    {
      mentions: [m.sender],
      nativeSelectData: {
        title: "Pilih Grup",
        sections
      },
      thumbUrl: global.thumb,
      name: global.namebot || "Renvy",
      address: "Group Control"
    }
  );
}

async function sendGroupInfo(m, conn, jid, prefix, command) {
  const meta = await getGroupMetadata(conn, jid);
  const chat = ensureChat(jid);
  const subject = meta?.subject || await safeGetName(conn, jid) || jid;
  const participants = Array.isArray(meta?.participants) ? meta.participants : [];
  const admins = participants.filter(isAdminParticipant);
  const superAdmins = participants.filter((p) => p.admin === "superadmin");
  const botAdmin = isBotAdmin(conn, participants);
  const owner = meta?.owner || superAdmins[0]?.id || "-";
  const desc = cleanText(meta?.desc || meta?.description || "Tidak ada deskripsi.");

  const text = `
> *[ GROUP CONTROL PANEL ]*

> *Nama* : ${subject}
> *ID* : ${jid}
> *Owner* : ${formatJid(owner)}
> *Dibuat* : ${formatTime(meta?.creation)}
> *Member* : ${participants.length || "-"}
> *Admin* : ${admins.length || "-"}
> *Bot Admin* : ${botAdmin ? "Ya" : "Tidak"}

> *Banchat* : ${chat.isBanned ? "ON / Grup diblokir" : "OFF / Grup aktif"}
> *Mute Bot* : ${chat.mute ? "ON" : "OFF"}
> *Welcome* : ${chat.welcome ? "ON" : "OFF"}
> *Anti Link* : ${chat.antiLink ? "ON" : "OFF"}
> *Mode Grup* : ${meta?.announce ? "Tertutup / admin only" : "Terbuka"}
> *Edit Info* : ${meta?.restrict ? "Admin only" : "Semua member"}

> *Deskripsi* :
${desc.length > 450 ? desc.slice(0, 450) + "..." : desc}
`.trim();

  const toggleAction = chat.isBanned ? "unbanchat" : "banchat";
  const toggleText = chat.isBanned ? "[ Unban Chat ]" : "[ Ban Chat ]";

  return conn.sendButtonLoc(
    m.chat,
    [
      { id: `${prefix + command} actions ${jid}`, text: "[ Aksi Grup ]", native: true },
      { id: `${prefix + command} action ${toggleAction} ${jid}`, text: toggleText },
      { id: `${prefix + command} action leave ${jid}`, text: "[ Leave ]" }
    ],
    text,
    DEFAULT_FOOTER(),
    m,
    {
      mentions: collectMentions([owner, ...admins.map((v) => v.id)]),
      nativeSelectData: buildActionSelect(chat, jid, prefix, command),
      thumbUrl: global.thumb,
      name: subject,
      address: chat.isBanned ? "Banchat Active" : "Group Active"
    }
  );
}

async function sendActionMenu(m, conn, jid, prefix, command) {
  const meta = await getGroupMetadata(conn, jid);
  const chat = ensureChat(jid);
  const subject = meta?.subject || await safeGetName(conn, jid) || jid;

  return conn.sendButtonLoc(
    m.chat,
    [
      { id: `${prefix + command} actions ${jid}`, text: "[ Pilih Aksi ]", native: true },
      { id: `${prefix + command} info ${jid}`, text: "[ Detail ]" },
      { id: `${prefix + command} refresh`, text: "[ List Grup ]" }
    ],
    `> *[ AKSI GRUP ]*\n\n> Grup: *${subject}*\n> Banchat: *${chat.isBanned ? "ON" : "OFF"}*\n\nPilih aksi yang mau dijalankan melalui list button.`,
    DEFAULT_FOOTER(),
    m,
    {
      mentions: [m.sender],
      nativeSelectData: buildActionSelect(chat, jid, prefix, command),
      thumbUrl: global.thumb,
      name: subject,
      address: "Action Menu"
    }
  );
}

async function runGroupAction(m, conn, action, jid, prefix, command) {
  const chat = ensureChat(jid);
  const meta = await getGroupMetadata(conn, jid).catch(() => null);
  const subject = meta?.subject || await safeGetName(conn, jid) || jid;
  const participants = Array.isArray(meta?.participants) ? meta.participants : [];
  const botAdmin = isBotAdmin(conn, participants);

  try {
    switch (action) {
      case "banchat":
      case "ban":
        chat.isBanned = true;
        await m.reply(`*[ ✓ ] Banchat berhasil diaktifkan.*\n\n> Grup: *${subject}*\n> Member grup ini tidak bisa memakai bot.\n> Owner tetap bebas memakai bot.`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "unbanchat":
      case "unban":
      case "umbanchat":
        chat.isBanned = false;
        await m.reply(`*[ ✓ ] Banchat berhasil dinonaktifkan.*\n\n> Grup: *${subject}*\n> Member sudah bisa memakai bot lagi.`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "mute":
        chat.mute = true;
        await m.reply(`*[ ✓ ] Mute bot aktif.*\n\n> Grup: *${subject}*`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "unmute":
        chat.mute = false;
        await m.reply(`*[ ✓ ] Mute bot nonaktif.*\n\n> Grup: *${subject}*`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "welcome-on":
      case "welcomeon":
        chat.welcome = true;
        await m.reply(`*[ ✓ ] Welcome diaktifkan.*\n\n> Grup: *${subject}*`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "welcome-off":
      case "welcomeoff":
        chat.welcome = false;
        await m.reply(`*[ ✓ ] Welcome dinonaktifkan.*\n\n> Grup: *${subject}*`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "antilink-on":
      case "antilinkon":
        chat.antiLink = true;
        await m.reply(`*[ ✓ ] Anti Link diaktifkan.*\n\n> Grup: *${subject}*`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "antilink-off":
      case "antilinkoff":
        chat.antiLink = false;
        await m.reply(`*[ ✓ ] Anti Link dinonaktifkan.*\n\n> Grup: *${subject}*`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "open":
      case "buka":
        if (!botAdmin) return m.reply(`*[!] Bot harus menjadi admin untuk membuka grup.*\n\n> Grup: *${subject}*`);
        await conn.groupSettingUpdate(jid, "not_announcement");
        await m.reply(`*[ ✓ ] Grup berhasil dibuka.*\n\n> Grup: *${subject}*`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "close":
      case "tutup":
        if (!botAdmin) return m.reply(`*[!] Bot harus menjadi admin untuk menutup grup.*\n\n> Grup: *${subject}*`);
        await conn.groupSettingUpdate(jid, "announcement");
        await m.reply(`*[ ✓ ] Grup berhasil ditutup.*\n\n> Grup: *${subject}*`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "lockinfo":
      case "lock-info":
        if (!botAdmin) return m.reply(`*[!] Bot harus menjadi admin untuk mengunci edit info grup.*\n\n> Grup: *${subject}*`);
        await conn.groupSettingUpdate(jid, "locked");
        await m.reply(`*[ ✓ ] Edit info grup dikunci untuk admin only.*\n\n> Grup: *${subject}*`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "unlockinfo":
      case "unlock-info":
        if (!botAdmin) return m.reply(`*[!] Bot harus menjadi admin untuk membuka edit info grup.*\n\n> Grup: *${subject}*`);
        await conn.groupSettingUpdate(jid, "unlocked");
        await m.reply(`*[ ✓ ] Edit info grup dibuka untuk semua member.*\n\n> Grup: *${subject}*`);
        return sendGroupInfo(m, conn, jid, prefix, command);

      case "link":
      case "linkgc":
        if (!botAdmin) return m.reply(`*[!] Bot harus menjadi admin untuk mengambil link grup.*\n\n> Grup: *${subject}*`);
        return m.reply(`*[ LINK GROUP ]*\n\n> Grup: *${subject}*\n> https://chat.whatsapp.com/${await conn.groupInviteCode(jid)}`);

      case "revoke":
      case "resetlink":
        if (!botAdmin) return m.reply(`*[!] Bot harus menjadi admin untuk reset link grup.*\n\n> Grup: *${subject}*`);
        await conn.groupRevokeInvite(jid);
        return m.reply(`*[ ✓ ] Link grup berhasil di-reset.*\n\n> Grup: *${subject}*\n> Link baru: https://chat.whatsapp.com/${await conn.groupInviteCode(jid)}`);

      case "leave":
      case "keluar":
        return confirmLeave(m, conn, jid, subject, prefix, command);

      case "confirmleave":
      case "confirm-leave":
      case "yaleave":
        await m.reply(`*[ ✓ ] Bot akan keluar dari grup.*\n\n> Grup: *${subject}*`);
        await delay(1200);
        return conn.groupLeave(jid);

      case "info":
      case "detail":
        return sendGroupInfo(m, conn, jid, prefix, command);

      default:
        return m.reply(`*[!] Aksi tidak dikenal:* ${action}\n\n> Gunakan tombol *Aksi Grup* dari menu listgc.`);
    }
  } catch (e) {
    console.error(e);
    return m.reply(`*[!] Gagal menjalankan aksi.*\n\n> Grup: *${subject}*\n> Error: ${e.message || e}`);
  }
}

async function confirmLeave(m, conn, jid, subject, prefix, command) {
  return conn.sendButtonLoc(
    m.chat,
    [
      { id: `${prefix + command} action confirmleave ${jid}`, text: "[ Ya Leave ]" },
      { id: `${prefix + command} info ${jid}`, text: "[ Batal ]" },
      { id: `${prefix + command} refresh`, text: "[ List Grup ]" }
    ],
    `> *[ KONFIRMASI LEAVE ]*\n\n> Grup: *${subject}*\n\nYakin bot mau keluar dari grup ini?`,
    DEFAULT_FOOTER(),
    m,
    {
      mentions: [m.sender],
      thumbUrl: global.thumb,
      name: subject,
      address: "Confirm Leave"
    }
  );
}

function buildActionSelect(chat, jid, prefix, command) {
  return {
    title: "Aksi Grup",
    sections: [
      {
        title: "Banchat & Bot",
        rows: [
          {
            header: chat.isBanned ? "🔓 Buka akses bot" : "🔒 Blokir akses bot",
            title: chat.isBanned ? "Unban Chat" : "Ban Chat",
            description: chat.isBanned ? "Member bisa memakai bot lagi" : "Member tidak bisa memakai bot",
            id: `${prefix + command} action ${chat.isBanned ? "unbanchat" : "banchat"} ${jid}`
          },
          {
            header: chat.mute ? "🔊 Aktifkan bot" : "🔇 Diamkan bot",
            title: chat.mute ? "Unmute Bot" : "Mute Bot",
            description: chat.mute ? "Bot merespon lagi di grup" : "Bot tidak merespon member grup",
            id: `${prefix + command} action ${chat.mute ? "unmute" : "mute"} ${jid}`
          }
        ]
      },
      {
        title: "Setting Grup",
        rows: [
          {
            header: "🔓 Grup terbuka",
            title: "Open Group",
            description: "Semua member bisa chat",
            id: `${prefix + command} action open ${jid}`
          },
          {
            header: "🔒 Grup tertutup",
            title: "Close Group",
            description: "Hanya admin yang bisa chat",
            id: `${prefix + command} action close ${jid}`
          },
          {
            header: "🛡️ Admin only",
            title: "Lock Edit Info",
            description: "Edit info grup hanya admin",
            id: `${prefix + command} action lockinfo ${jid}`
          },
          {
            header: "👥 Semua member",
            title: "Unlock Edit Info",
            description: "Member bisa edit info grup",
            id: `${prefix + command} action unlockinfo ${jid}`
          }
        ]
      },
      {
        title: "Fitur Grup",
        rows: [
          {
            header: chat.welcome ? "👋 Welcome aktif" : "👋 Welcome mati",
            title: chat.welcome ? "Welcome Off" : "Welcome On",
            description: chat.welcome ? "Matikan pesan welcome" : "Aktifkan pesan welcome",
            id: `${prefix + command} action ${chat.welcome ? "welcome-off" : "welcome-on"} ${jid}`
          },
          {
            header: chat.antiLink ? "🔗 Anti Link aktif" : "🔗 Anti Link mati",
            title: chat.antiLink ? "Anti Link Off" : "Anti Link On",
            description: chat.antiLink ? "Matikan anti link" : "Aktifkan anti link",
            id: `${prefix + command} action ${chat.antiLink ? "antilink-off" : "antilink-on"} ${jid}`
          }
        ]
      },
      {
        title: "Link & Keluar",
        rows: [
          {
            header: "🔗 Undangan grup",
            title: "Get Link",
            description: "Ambil link invite grup",
            id: `${prefix + command} action link ${jid}`
          },
          {
            header: "♻️ Reset link",
            title: "Revoke Link",
            description: "Reset link undangan grup",
            id: `${prefix + command} action revoke ${jid}`
          },
          {
            header: "🚪 Keluar grup",
            title: "Leave Group",
            description: "Butuh konfirmasi sebelum keluar",
            id: `${prefix + command} action leave ${jid}`
          },
          {
            header: "📊 Informasi",
            title: "Refresh Detail",
            description: "Lihat ulang informasi grup",
            id: `${prefix + command} info ${jid}`
          }
        ]
      }
    ]
  };
}

async function getAllGroups(conn) {
  const map = new Map();

  for (const [jid, chat] of Object.entries(conn.chats || {})) {
    if (!jid.endsWith("@g.us")) continue;
    const meta = chat.metadata || chat;
    const subject = meta.subject || chat.subject || chat.name;
    const memberCount = Array.isArray(meta.participants) ? meta.participants.length : 0;
    map.set(jid, { jid, subject, memberCount, chat, metadata: meta });
  }

  if (typeof conn.groupFetchAllParticipating === "function") {
    const all = await conn.groupFetchAllParticipating().catch(() => null);
    if (all && typeof all === "object") {
      for (const [jid, meta] of Object.entries(all)) {
        if (!jid.endsWith("@g.us")) continue;
        map.set(jid, {
          jid,
          subject: meta.subject,
          memberCount: Array.isArray(meta.participants) ? meta.participants.length : 0,
          chat: conn.chats?.[jid] || {},
          metadata: meta
        });
      }
    }
  }

  return [...map.values()].sort((a, b) => String(a.subject || a.jid).localeCompare(String(b.subject || b.jid)));
}

async function getGroupMetadata(conn, jid) {
  const cached = conn.chats?.[jid]?.metadata || conn.chats?.[jid];
  if (typeof conn.groupMetadata === "function") {
    const meta = await conn.groupMetadata(jid).catch(() => null);
    if (meta) return meta;
  }
  return cached || { id: jid, subject: jid, participants: [] };
}

function ensureChat(jid) {
  if (!global.db.data.chats[jid]) global.db.data.chats[jid] = {};
  const chat = global.db.data.chats[jid];
  if (typeof chat.isBanned !== "boolean") chat.isBanned = false;
  if (typeof chat.mute !== "boolean") chat.mute = false;
  if (typeof chat.welcome !== "boolean") chat.welcome = false;
  if (typeof chat.antiLink !== "boolean") chat.antiLink = false;
  return chat;
}

function normalizeGroupJid(input = "") {
  const jid = String(input || "").trim();
  return jid.endsWith("@g.us") ? jid : null;
}

function isAdminParticipant(p = {}) {
  return p.admin === "admin" || p.admin === "superadmin";
}

function isBotAdmin(conn, participants = []) {
  const botId = decode(conn, conn.user?.jid || conn.user?.id || "");
  const botNum = cleanNumber(botId);
  return participants.some((p) => {
    const id = decode(conn, p.id || p.jid || "");
    return cleanNumber(id) === botNum && isAdminParticipant(p);
  });
}

function decode(conn, jid) {
  try {
    return conn.decodeJid ? conn.decodeJid(jid) : jid;
  } catch {
    return jid;
  }
}

function cleanNumber(jid = "") {
  return String(jid).replace(/\D/g, "");
}

function formatJid(jid = "") {
  if (!jid || jid === "-") return "-";
  const num = cleanNumber(jid);
  return num ? `@${num}` : jid;
}

function collectMentions(list = []) {
  return [...new Set(list.filter(Boolean).filter((v) => String(v).includes("@s.whatsapp.net")))];
}

function formatTime(timestamp) {
  if (!timestamp) return "-";
  const date = new Date(Number(timestamp) * 1000);
  if (isNaN(date.getTime())) return "-";
  return date.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
}

async function safeGetName(conn, jid) {
  try {
    return await conn.getName(jid);
  } catch {
    return jid;
  }
}

function cleanText(text = "") {
  return String(text || "-").replace(/\s+/g, " ").trim();
}

function cutText(text = "", max = 34) {
  text = cleanText(text);
  return text.length > max ? text.slice(0, max - 3) + "..." : text;
}

function chunkArray(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}