const { AIRich } = require('../lib/nixcode.js');

function fmtMs(ms) {
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(2)}s`;
}

function fmtNum(n) {
  return Number(n || 0).toLocaleString('id-ID');
}

function getPluginShortName(name) {
  return name
    .replace(/^plugins[\\/]/, '')
    .replace(/\.js$/, '')
    .replace(/[\\/]/g, '/')
}

function buildHourlyBar(hourly = []) {
  const max = Math.max(...hourly, 1);
  const bars = ['▁','▂','▃','▄','▅','▆','▇','█'];
  return hourly.map(v => bars[Math.round((v / max) * (bars.length - 1))]).join('');
}

function getPeakHour(hourly = []) {
  let peak = 0, peakHour = 0;
  hourly.forEach((v, h) => { if (v > peak) { peak = v; peakHour = h; } });
  return { hour: peakHour, count: peak };
}

let handler = async (m, { conn, isROwner }) => {
  if (!isROwner) return m.reply('> [!] Owner only.');

  const wm = global.namebot || 'Bot';
  const usage = global.db?.data?.usage || {};
  const stats = global.db?.data?.stats || {};
  const analytics = global._pluginAnalytics || new Map();

  // ── 1. Command paling sering dipakai
  const topCommands = Object.entries(stats)
    .filter(([, v]) => v.total > 0)
    .sort(([, a], [, b]) => b.total - a.total)
    .slice(0, 10)
    .map(([cmd, v]) => [
      `.${cmd}`,
      String(fmtNum(v.total)),
      String(fmtNum(v.success)),
      String(v.total > 0 ? Math.round((v.success / v.total) * 100) + '%' : '0%')
    ]);

  const topCmdTable = [
    ['Command', 'Total', 'Sukses', 'Rate'],
    ...(topCommands.length ? topCommands : [['(belum ada)', '0', '0', '0%']])
  ];

  // ── 2. Response time rata-rata per plugin
  const pluginTimes = [...analytics.entries()]
    .filter(([, v]) => v.total > 0)
    .map(([name, v]) => ({
      name: getPluginShortName(name),
      avg: v.total > 0 ? Math.round(v.totalMs / v.total) : 0,
      total: v.total,
      error: v.error
    }))
    .sort((a, b) => b.avg - a.avg)
    .slice(0, 10);

  const speedTable = [
    ['Plugin', 'Avg Time', 'Calls', 'Error'],
    ...(pluginTimes.length
      ? pluginTimes.map(p => [p.name, fmtMs(p.avg), String(p.total), String(p.error)])
      : [['(belum ada)', '-', '0', '0']])
  ];

  // ── 3. Plugin paling sering error
  const errorPlugins = [...analytics.entries()]
    .filter(([, v]) => v.error > 0)
    .sort(([, a], [, b]) => b.error - a.error)
    .slice(0, 5)
    .map(([name, v]) => ({
      name: getPluginShortName(name),
      error: v.error,
      total: v.total,
      lastError: v.lastError || '-'
    }));

  // ── 4. Hourly usage data
  const hourly = usage.hourly || Array(24).fill(0);
  const bar = buildHourlyBar(hourly);
  const peak = getPeakHour(hourly);
  const now = new Date();
  const todayKey = now.toISOString().slice(0, 10);
  const todayData = usage.today?.[todayKey] || { total: 0, success: 0, error: 0 };

  const hourlyTable = [
    ['Rentang', 'Pesan'],
    ['00:00 - 05:59', String(hourly.slice(0, 6).reduce((a, b) => a + b, 0))],
    ['06:00 - 11:59', String(hourly.slice(6, 12).reduce((a, b) => a + b, 0))],
    ['12:00 - 17:59', String(hourly.slice(12, 18).reduce((a, b) => a + b, 0))],
    ['18:00 - 23:59', String(hourly.slice(18, 24).reduce((a, b) => a + b, 0))],
    ['Peak Hour', `${String(peak.hour).padStart(2,'0')}:00 (${fmtNum(peak.count)} msg)`]
  ];

  // ── 5. Speed average (terakhir 50 command)
  const speeds = usage.speed || [];
  const avgSpeed = speeds.length
    ? Math.round(speeds.reduce((a, b) => a + b, 0) / speeds.length)
    : 0;

  // Sources untuk error plugin
  const errorSources = errorPlugins.length
    ? errorPlugins.map(p => [
        global.thumb || '',
        `https://wa.me/${global.nomorown}`,
        `${p.name} — ${p.error}x error`
      ])
    : null;

  const rich = new AIRich(conn)
    .setTitle('Command Analytics')
    .setFooter(`[ ${wm} ] - Analytics Dashboard`)
    .addText(
      `# Command Analytics\n\n` +
      `> Dashboard statistik real-time bot.\n\n` +
      `[+] Uptime       : ${fmtMs(process.uptime() * 1000)}\n` +
      `[+] Total Pesan  : ${fmtNum(usage.total)}\n` +
      `[+] Sukses       : ${fmtNum(usage.success)}\n` +
      `[+] Error        : ${fmtNum(usage.error)}\n` +
      `[+] Grup         : ${fmtNum(usage.group)}\n` +
      `[+] Private      : ${fmtNum(usage.private)}\n` +
      `[+] Avg Speed    : ${fmtMs(avgSpeed)}`
    )
    .addTip('Command paling sering dipakai')
    .addTable(topCmdTable)
    .addTip('Response time rata-rata per plugin')
    .addTable(speedTable)
    .addTip('Penggunaan per rentang jam (hari ini)')
    .addTable(hourlyTable)
    .addText(
      `# Grafik Per Jam\n\n` +
      `> Setiap karakter mewakili 1 jam (00:00 - 23:00)\n\n` +
      `\`${bar}\``
    );

  if (errorSources) {
    rich.addTip('Plugin yang paling sering error');
    rich.addSource(errorSources);
  }

  rich.addTable([
    ['Info Hari Ini', 'Nilai'],
    ['Total', fmtNum(todayData.total)],
    ['Sukses', fmtNum(todayData.success)],
    ['Error', fmtNum(todayData.error)],
    ['Plugin loaded', String(Object.keys(global.plugins || {}).length)],
    ['Plugin tracked', String(analytics.size)]
  ]);

  rich.addSuggest([`.stats`, `.ping`, `.os`]);

  await rich.send(m.chat, { quoted: m });
};

handler.help = ['stats'];
handler.tags = ['owner'];
handler.command = /^(stats|analytics)$/i;
handler.owner = true;

module.exports = handler;