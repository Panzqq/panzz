const axios = require("axios");
const { exec } = require("child_process");
const { promisify } = require("util");
const fs = require("fs");
const path = require("path");
const execPromise = promisify(exec);
const { sleep } = require("../lib/utils");
const { tmpFile, safeUnlink } = require("../lib/tmpManager");
const base = "https://c.blahaj.ca/";
const format = {
  audio: ["320", "256", "128", "96", "64", "8"],
  video: [
    "max",
    "4320",
    "2160",
    "1440",
    "1080",
    "720",
    "480",
    "360",
    "240",
    "144",
  ],
};
async function converter(inputBuffer, inputFormat, outputFormat) {
  if (!Buffer.isBuffer(inputBuffer)) {
    throw new Error("Input must be a Buffer");
  }
  if (typeof inputFormat !== "string" || typeof outputFormat !== "string") {
    throw new Error("Input and output formats must be strings");
  }

  const inputFilePath = tmpFile({ dir: "ffmpeg/autodl", prefix: "input", ext: inputFormat });
  const outputFilePath = tmpFile({ dir: "ffmpeg/autodl", prefix: "output", ext: outputFormat });

  try {
    await fs.promises.writeFile(inputFilePath, inputBuffer);
    console.log("Input file written successfully.");

    console.log("Starting conversion...");
    await execPromise(`ffmpeg -i ${inputFilePath} ${outputFilePath}`);
    console.log("Conversion completed successfully.");

    const outputBuffer = await fs.promises.readFile(outputFilePath);
    return outputBuffer;
  } catch (error) {
    console.error("Error while converting file:", error);
    throw error; // Re-throw error for higher-level handling
  } finally {
    // Cleanup temporary files
    try {
      await safeUnlink(inputFilePath);
      await safeUnlink(outputFilePath);
    } catch (cleanupError) {
      console.error("Error while cleaning up temp files:", cleanupError);
    }
  }
}

async function cobalt(url, mode, quality) {
  if (!mode) throw "Mau Mode Apa video/audio";
  try {
    let payload = {
      url: url,
      filenameStyle: "pretty",
    };
    if (mode === "video") {
      if (!format.video.includes(quality)) {
        return {
          message: `Maaf Bre Kualitas Mu Salah Deh!`,
          Kualitas: format.video.map((a) => a),
        };
      }
      const cobalt = await axios
        .post(
          base,
          {
            ...payload,
            videoQuality: quality,
            downloadMode: "auto",
          },
          {
            headers: {
              Accept: "application/json",
              "Content-type": "application/json",
            },
          },
        )
        .then((x) => x.data);

      const x = await axios.get(cobalt.url, {
        responseType: "arraybuffer",
      });
      const hasil = await converter(x.data, "webp", "mp4");
      return {
        status: true,
        data: {
          buffer: hasil,
          mode,
          quality,
          fileName: cobalt.filename,
        },
      };
    } else if (mode === "audio") {
      if (!format.audio.includes(quality)) {
        return {
          message: `Maaf Bre Kualitas Mu Salah Deh!`,
          Kualitas: format.audio.map((a) => a),
        };
      }
      const cobalt = await axios
        .post(
          base,
          {
            ...payload,
            audioBitrate: quality,
            audioFormat: "mp3",
            downloadMode: "audio",
          },
          {
            headers: {
              Accept: "application/json",
              "Content-type": "application/json",
            },
          },
        )
        .then((x) => x.data);

      const x = await axios.get(cobalt.url, {
        responseType: "arraybuffer",
      });

      const hasil = await converter(x.data, "ogg", "mp3");
      return {
        status: true,
        data: {
          buffer: hasil,
          mode,
          quality,
          fileName: cobalt.filename,
        },
      };
    }
  } catch (e) {
    console.error("error: " + e);
    return {
      status: false,
      data: {
        message: e,
      },
    };
  }
}
const tiktokRegex =
  /^(?:https?:\/\/)?(?:www\.|vt\.|vm\.|t\.)?(?:tiktok\.com\/)(?:\S+)?$/i;
const instagramRegex =
  /^(?:https?:\/\/)?(?:www\.)?(?:instagram\.com\/)(?:tv\/|p\/|reel\/)(?:\S+)?$/i;
const youtubeRegex =
  /^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|v\/|shorts\/)|youtu\.be\/)([\w\-]{11})(?:\?[\S]*)?$/i;
const pinterestRegex = /^(?:https?:\/\/)?(?:pin\.it)\/([a-zA-Z0-9]+)$/i;
const spotifyRegex =
  /^(?:https?:\/\/)?(?:open\.spotify\.com\/track\/)([a-zA-Z0-9]+)(?:\S+)?$/i;
const twitterRegex =
  /^(?:https?:\/\/)?(?:www\.)?(?:twitter\.com|x\.com)\/([A-Za-z0-9_]+)\/status\/(\d+)(?:\?[^#]*)?(?:#.*)?$/i;

async function before(m) {
  if (m.isBaileys) return;
  if (m.isCommand) return;
  try {
    if (tiktokRegex.test(m.text)) {
      let res = await cobalt(m.text, "video", "720");
      await conn.sendFile(
        m.chat,
        res.data.buffer,
        null,
        `Auto Downloader\n*Type: Tiktok*`,
        m,
      );
      await sleep(3000);
    } else if (instagramRegex.test(m.text)) {
      let res = await cobalt(m.text, "video", "720");
      await conn.sendFile(
        m.chat,
        res.data.buffer,
        null,
        `Auto Downloader\n*Type: instagram*`,
        m,
      );
      await sleep(3000);
    } else if (spotifyRegex.test(m.text)) {
      let { download } = await Scraper["Tools"].SpotifyApi.download(m.text);
      await conn.sendAudioMessage(m.chat, download, ftroli);
      await sleep(3000);
    } else if (pinterestRegex.test(m.text)) {
      let res = await cobalt(m.text, "video", "720");
      await conn.sendFile(
        m.chat,
        res.data.buffer,
        null,
        `Auto Downloader\n*Type: pinterest*`,
        m,
      );
      await sleep(3000);
    } else if (twitterRegex.test(m.text)) {
      let res = await cobalt(m.text, "video", "720");
      await conn.sendFile(
        m.chat,
        res.data.buffer,
        null,
        `Auto Downloader\n*Type: twiter*`,
        m,
      );
      await sleep(3000);
    } else if (youtubeRegex.test(m.text)) {
      let res = await cobalt(m.text, "video", "720");
      let result = await cobalt(m.text, "audio", "128");
      await conn.sendFile(
        m.chat,
        res.data.buffer,
        null,
        `Auto Downloader\n*Type: Youtube*`,
        m,
      );
      await conn.sendFile(
        m.chat,
        res.data.buffer,
        null,
        `Auto Downloader\n*Type: Youtube*`,
        m,
      );
      await sleep(3000);
    }
  } catch (e) {
    m.reply(e);
  }
}
module.exports = { before };
