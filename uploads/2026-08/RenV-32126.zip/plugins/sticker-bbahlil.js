const { createCanvas, loadImage } = require('canvas');
const axios = require('axios');
const moment = require('moment-timezone');

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = text.split(' ');
  let line = '';
  let testLine = '';
  let lines = [];

  for (let n = 0; n < words.length; n++) {
    testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    const testWidth = metrics.width;

    if (testWidth > maxWidth && n > 0) {
      lines.push(line.trim());
      line = words[n] + ' ';
    } else {
      line = testLine;
    }
  }
  lines.push(line.trim());

  const totalHeight = lines.length * lineHeight;
  let startY = y - totalHeight / 2 + lineHeight / 2;

  for (const l of lines) {
    ctx.fillText(l, x, startY);
    startY += lineHeight;
  }
}

const handler = async (m, { conn, text, usedPrefix }) => {
  if (!text) {
    throw `Gunakan perintah ini dengan format: ${usedPrefix}bratbahlil <teks>`;
  }

  if (text.length >= 150) {
    throw `[❗] Maksimum 150 karakter teks.`;
  }

  await conn.sendMessage(m.chat, {
    react: {
      text: "✔️",
      key: m.key,
    },
  });

  try {
    const imgUrl = 'https://raw.githubusercontent.com/Panzqq/panzz/main/uploads/2026-06-23/RenV-21578.jpeg';
    const response = await axios.get(imgUrl, { responseType: 'arraybuffer' });
    const bufferImg = Buffer.from(response.data);

    const baseImage = await loadImage(bufferImg);
    const canvas = createCanvas(baseImage.width, baseImage.height);
    const ctx = canvas.getContext('2d');

    ctx.drawImage(baseImage, 0, 0);

    // Mengatur ukuran font & jeda baris otomatis berdasarkan panjang teks
    let fontSize = 70;
    if (text.length > 50) fontSize = 40;
    else if (text.length > 20) fontSize = 55;
    
    let lineHeight = fontSize + 10; // Jarak baris selalu lebih besar dari font agar tidak tabrakan

    ctx.font = `bold ${fontSize}px Arial`;
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const paperX = 260 + (500 / 2);
    const paperY = 500 + (500 / 2);

    wrapText(ctx, text, paperX, paperY, 420, lineHeight);

    const stickerBuffer = canvas.toBuffer('image/png');
    const time = moment().tz("Asia/Makassar").format("HH:mm:ss");

    await conn.sendImageAsSticker(m.chat, stickerBuffer, m, {
      packname: `Dibuat Oleh: ${m.name || 'Unknown'}`,
      author: `\n\nTime : ${time}\n${global?.swm || ''}\n${global?.suorceUrl || ''}`,
    });

  } catch (error) {
    console.error(error);
    throw 'Gagal membuat stiker bratbahlil. Pastikan library canvas sudah terinstal.';
  }
};

handler.help = ["bratbahlil"].map((a) => a + " *[text]*");
handler.tags = ["sticker"];
handler.command = /^bratbahlil$/i;
handler.limit = 20;

module.exports = handler;