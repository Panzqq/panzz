const axios = require("axios");
const fs = require("fs/promises");
const path = require("path");
const { sleep } = require("../lib/utils");
const { tmpFile, safeUnlink } = require("../lib/tmpManager");

const fetchFn =
  globalThis.fetch ||
  ((...args) => import("node-fetch").then(({ default: fetch }) => fetch(...args)));

function generateUUID() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

function cleanText(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .trim();
}

function slugify(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

function cleanFileName(name) {
  return String(name || "scribd-document")
    .replace(/[\\/:*?"<>|]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 100);
}

function fixUrl(url) {
  if (!url) return null;

  url = String(url).trim();

  if (url.startsWith("//")) return "https:" + url;
  if (url.startsWith("/")) return "https://www.scribd.com" + url;
  if (url.startsWith("http")) return url;

  return null;
}

function pick(obj, paths, fallback = null) {
  for (const path of paths) {
    const value = path.split(".").reduce((acc, key) => acc?.[key], obj);
    if (value !== undefined && value !== null && value !== "") return value;
  }

  return fallback;
}

function findDeep(obj, check, maxDepth = 8) {
  const seen = new Set();

  function walk(value, depth) {
    if (!value || depth > maxDepth) return null;

    if (typeof value === "string" || typeof value === "number") {
      return check(value) ? value : null;
    }

    if (typeof value !== "object") return null;
    if (seen.has(value)) return null;

    seen.add(value);

    if (Array.isArray(value)) {
      for (const item of value) {
        const found = walk(item, depth + 1);
        if (found) return found;
      }
    } else {
      for (const key of Object.keys(value)) {
        const val = value[key];

        if (check(val, key)) return val;

        const found = walk(val, depth + 1);
        if (found) return found;
      }
    }

    return null;
  }

  return walk(obj, 0);
}

function getScribdId(doc) {
  let id = pick(doc, [
    "id",
    "document_id",
    "doc_id",
    "document.id",
    "document.document_id",
    "resource_id",
    "content_id"
  ], null);

  if (id) return String(id);

  id = findDeep(doc, (value, key) => {
    if (!key) return false;

    key = String(key).toLowerCase();

    return (
      ["id", "document_id", "doc_id"].includes(key) &&
      /^\d+$/.test(String(value))
    );
  });

  return id ? String(id) : null;
}

function getScribdUrl(doc, title) {
  let directUrl = pick(doc, [
    "url",
    "web_url",
    "read_url",
    "canonical_url",
    "document.url",
    "document.web_url",
    "document.read_url",
    "metadata.url",
    "metadata.web_url"
  ], null);

  directUrl = fixUrl(directUrl);

  if (directUrl) return directUrl;

  directUrl = findDeep(doc, value => {
    if (typeof value !== "string") return false;
    return value.includes("scribd.com/document/") || value.startsWith("/document/");
  });

  directUrl = fixUrl(directUrl);

  if (directUrl) return directUrl;

  const id = getScribdId(doc);

  const slug = cleanText(
    pick(doc, [
      "slug",
      "seo_slug",
      "url_slug",
      "document.slug",
      "document.seo_slug",
      "metadata.slug"
    ], null)
  ) || slugify(title);

  if (id) {
    return `https://www.scribd.com/document/${id}/${slug || "document"}`;
  }

  return "-";
}

function getThumbnail(doc) {
  let thumb = pick(doc, [
    "thumbnail_url",
    "image_url",
    "cover_url",
    "image",
    "document.thumbnail_url",
    "document.image_url",
    "document.cover_url",
    "metadata.thumbnail_url"
  ], null);

  thumb = fixUrl(thumb);

  if (thumb) return thumb;

  thumb = findDeep(doc, value => {
    if (typeof value !== "string") return false;

    return (
      value.includes("scribdassets.com") ||
      value.match(/\.(jpg|jpeg|png|webp)(\?|$)/i)
    );
  });

  return fixUrl(thumb);
}

function parseDoc(doc) {
  const title = cleanText(
    pick(doc, [
      "title",
      "name",
      "document.title",
      "metadata.title"
    ], "Untitled")
  );

  const description = cleanText(
    pick(doc, [
      "description",
      "subtitle",
      "snippet",
      "summary",
      "document.description",
      "metadata.description"
    ], "Tidak ada deskripsi.")
  );

  const author = cleanText(
    pick(doc, [
      "author.name",
      "user.name",
      "uploader.name",
      "owner.name",
      "document.author.name"
    ], "Unknown")
  );

  const pageCount = pick(doc, [
    "page_count",
    "pages",
    "num_pages",
    "document.page_count",
    "metadata.page_count"
  ], "Unknown");

  const reads = pick(doc, [
    "reads",
    "read_count",
    "stats.reads",
    "document.read_count"
  ], "Unknown");

  const id = getScribdId(doc);
  const url = getScribdUrl(doc, title);

  return {
    id,
    title,
    description,
    author,
    url,
    thumbnail: getThumbnail(doc),
    pageCount,
    reads
  };
}

async function getScribd(query) {
  const pageViewId = generateUUID();

  const url = `https://www.scribd.com/search/query?query=${encodeURIComponent(query)}&content_type=documents&page_view_id=${pageViewId}`;

  const response = await axios.get(url, {
    timeout: 30000,
    headers: {
      "X-Requested-With": "XMLHttpRequest",
      "Accept": "application/json",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      "Referer": `https://www.scribd.com/search?query=${encodeURIComponent(query)}`
    }
  });

  const rawDocs = response.data?.results?.documents?.content?.documents || [];

  return rawDocs.slice(0, 10).map(parseDoc);
}

class ScribdDownloader {
  constructor() {
    this.baseHeaders = {
      "User-Agent": "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 Chrome/147.0.7727.137 Mobile Safari/537.36",
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
      "Upgrade-Insecure-Requests": "1"
    };
  }

  #generateSig(pathUrl) {
    let base64Str = Buffer.from(pathUrl).toString("base64");
    let H = Math.floor(Math.random() * base64Str.length);
    let part1 = (H * 666111444 + 0).toString(16);
    let shifted = base64Str.substring(H) + base64Str.substring(0, H);
    let part2 = shifted.split("").reverse().join("");
    let part3 = (H * 666).toString(16);
    let part4 = base64Str
      .split("")
      .filter(() => Math.random() > 0.5)
      .sort(() => Math.random() - 0.5)
      .join("");

    return `${part1}_${part2}_${part3}_${part4}`;
  }

  getSetCookie(headers) {
    if (!headers) return [];

    if (typeof headers.getSetCookie === "function") {
      return headers.getSetCookie();
    }

    if (typeof headers.raw === "function") {
      return headers.raw()["set-cookie"] || [];
    }

    const raw = headers.get?.("set-cookie");
    if (!raw) return [];

    return raw.split(/,(?=\s*[^;,]+=)/g);
  }

  getCookieValue(headers, name) {
    const cookies = this.getSetCookie(headers);

    for (const cookie of cookies) {
      const match = String(cookie).match(new RegExp(`(${name}=[^;]+)`));
      if (match) return match[1];
    }

    return "";
  }

  async getJSON(link) {
    const idMatch =
      String(link).match(/(?:document|doc)\/(\d+)/i) ||
      String(link).match(/^(\d+)$/);

    if (!idMatch) {
      throw new Error("ID dokumen tidak valid atau tidak ditemukan dalam URL.");
    }

    const docId = idMatch[1];
    const pathUrl = `document/${docId}`;
    const sig = this.#generateSig(pathUrl);

    const apiUrl = `https://api.scribd-downloader.co/${pathUrl}?sig=${sig}`;

    const resApi = await fetchFn(apiUrl, {
      headers: {
        ...this.baseHeaders,
        origin: "https://scribd-downloader.co",
        referer: "https://scribd-downloader.co/"
      }
    });

    if (!resApi.ok) {
      throw new Error(`Gagal mengambil data dokumen. HTTP ${resApi.status}`);
    }

    const apiData = await resApi.json();

    if (!apiData.openUrl) {
      throw new Error("Gagal mendapatkan openUrl dari API.");
    }

    return {
      docId,
      title: apiData.title || "Dokumen",
      openUrl: apiData.openUrl,
      raw: apiData
    };
  }

  async getDownload(openUrl) {
    const resInit = await fetchFn(openUrl, {
      headers: this.baseHeaders,
      redirect: "manual"
    });

    let sessionCookie = "";
    let html = "";

    if ([301, 302, 307, 308].includes(resInit.status)) {
      sessionCookie = this.getCookieValue(resInit.headers, "ci_session");

      const location = resInit.headers.get("location");
      if (!location) throw new Error("Redirect URL tidak ditemukan.");

      const redirectUrl = new URL(
        location,
        "https://compress-pdf.vietdreamhouse.com"
      ).href;

      const resRedirect = await fetchFn(redirectUrl, {
        headers: {
          ...this.baseHeaders,
          Cookie: sessionCookie,
          Referer: openUrl
        }
      });

      html = await resRedirect.text();
    } else {
      html = await resInit.text();
      sessionCookie = this.getCookieValue(resInit.headers, "ci_session");
    }

    if (!sessionCookie) {
      throw new Error("Gagal mendapatkan ci_session cookie.");
    }

    const idMatch = html.match(/id:\s*['"]([a-f0-9]+)['"]/i);

    if (!idMatch) {
      throw new Error("Gagal menemukan ID proses di HTML.");
    }

    const processId = idMatch[1];

    let attempt = 1;

    while (true) {
      await sleep(3000);

      const resCheck = await fetchFn(
        "https://compress-pdf.vietdreamhouse.com/check-status",
        {
          method: "POST",
          headers: {
            ...this.baseHeaders,
            Accept: "application/json, text/javascript, */*; q=0.01",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Cookie: sessionCookie,
            "X-Requested-With": "XMLHttpRequest",
            Origin: "https://compress-pdf.vietdreamhouse.com"
          },
          body: `type=compresspdf&id=${processId}`
        }
      );

      const statusJson = await resCheck.json().catch(() => null);

      if (statusJson?.status === true) break;

      attempt++;

      if (attempt > 20) {
        throw new Error("Timeout. Server terlalu lama memproses file.");
      }
    }

    const resFinalPage = await fetchFn("https://compress-pdf.vietdreamhouse.com/", {
      headers: {
        ...this.baseHeaders,
        Cookie: sessionCookie
      }
    });

    const finalHtml = await resFinalPage.text();

    const downloadLinkMatch = finalHtml.match(
      /href=['"]([^'"]*\/download\/[^'"]*)['"]/i
    );

    if (!downloadLinkMatch) {
      throw new Error("Gagal menemukan link download.");
    }

    let actualDownloadUrl = downloadLinkMatch[1];

    if (actualDownloadUrl.startsWith("/")) {
      actualDownloadUrl =
        "https://compress-pdf.vietdreamhouse.com" + actualDownloadUrl;
    }

    const resDownload = await fetchFn(actualDownloadUrl, {
      method: "GET",
      headers: {
        ...this.baseHeaders,
        Cookie: sessionCookie,
        Referer: "https://compress-pdf.vietdreamhouse.com/"
      }
    });

    if (!resDownload.ok) {
      throw new Error(`Gagal mengambil file. HTTP ${resDownload.status}`);
    }

    const arrayBuffer = await resDownload.arrayBuffer();
    return Buffer.from(arrayBuffer);
  }
}

async function scribdDownload(link) {
  const scribd = new ScribdDownloader();

  const info = await scribd.getJSON(link);
  const buffer = await scribd.getDownload(info.openUrl);

  const fileName = `${cleanFileName(info.title)}-${info.docId}.pdf`;
  const filePath = tmpFile({ dir: "downloads/scribd", prefix: `${cleanFileName(info.title)}-${info.docId}`, ext: "pdf" });

  await fs.writeFile(filePath, buffer);

  return {
    status: true,
    title: info.title,
    docId: info.docId,
    fileName,
    file: filePath
  };
}

function isScribdDownloadInput(text) {
  text = String(text || "").trim();

  return (
    /^\d+$/.test(text) ||
    /^https?:\/\/(www\.)?scribd\.com\/(document|doc)\/\d+/i.test(text)
  );
}

async function sendScribdFile(conn, m, link) {
  const result = await scribdDownload(link);

  await conn.sendMessage(
    m.chat,
    {
      document: { url: result.file },
      mimetype: "application/pdf",
      fileName: result.fileName,
      caption: [
        "```",
        "> [+] SCRIBD RESULT",
        "",
        "> [+] Status : Success",
        `> [+] Title  : ${result.title}`,
        `> [+] Doc ID : ${result.docId}`,
        "```"
      ].join("\n")
    },
    { quoted: m }
  );

  await safeUnlink(result.file);
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      [
        "```",
        "> [+] SCRIBD SEARCH & DOWNLOADER",
        "",
        `> [+] Search   : ${usedPrefix + command} mtk`,
        `> [+] Download : ${usedPrefix + command} 33308065`,
        `> [+] Download : ${usedPrefix + command} https://www.scribd.com/document/33308065/L-arc-en-ciel`,
        "```"
      ].join("\n")
    );
  }

  try {
    if (isScribdDownloadInput(text)) {
      await m.reply(global.wait || "> [!] Sedang mengambil dokumen, mohon tunggu...");
      return await sendScribdFile(conn, m, text.trim());
    }

    await m.reply(global.wait || "> [!] Sedang mencari dokumen Scribd...");

    const results = await getScribd(text);

    if (!results.length) {
      return m.reply(`> [-] Data tidak ditemukan untuk: *${text}*`);
    }

    const listText = results.slice(0, 10).map((doc, i) => {
      return `\`${i + 1}. ${doc.title}\`

> [+] Author: ${doc.author}
> [+] Pages: ${doc.pageCount || "Unknown"}
> [+] Reads: ${doc.reads || "Unknown"}
> [+] Desc: ${doc.description}
> [+] Link: ${doc.url || "-"}`;
    }).join("\n\n");

    const caption =
`乂 S C R I B D  S E A R C H

\`Q U E R Y\`
> [+] ${text}

\`R E S U L T\`
${listText}

> Pilih dokumen di list bawah untuk download.
> Source: Scribd`;

    const rows = results.slice(0, 10).map((doc, i) => {
      const downloadTarget = doc.url && doc.url !== "-" ? doc.url : doc.id;

      return {
        header: `Result ${i + 1}`,
        title: doc.title.slice(0, 60),
        description: `Author: ${doc.author} | Pages: ${doc.pageCount || "Unknown"}`,
        id: `${usedPrefix + command} ${downloadTarget}`
      };
    });

    const datas = {
      title: `[ ${global.namebot || "Bot"} - Scribd Result ]`,
      sections: [
        {
          title: "Pilih dokumen untuk download",
          rows
        }
      ]
    };

    const firstThumb = results.find(v => v.thumbnail)?.thumbnail;

    if (typeof conn.sendButtonLoc === "function") {
      return conn.sendButtonLoc(
        m.chat,
        [
          {
            id: "pilih",
            text: "[ Pilih Dokumen ]",
            native: true
          },
          {
            id: `${usedPrefix}menu`,
            text: "[ Menu ]"
          }
        ],
        caption,
        ` [ ${global.namebot || "Bot"} Powered By ${global.nameown || "Owner"} ] `,
        m,
        {
          mentions: [m.sender],
          nativeSelectData: datas,
          thumbUrl: firstThumb || global.thumb || "https://files.catbox.moe/toarxh.jpg",
          name: global.namebot || "Renvy",
          address: "Scribd Search Result"
        }
      );
    }

    return conn.sendMessage(
      m.chat,
      {
        text:
`${caption}

\`C A R A  D O W N L O A D\`
> Ketik:
> ${usedPrefix + command} <link / id>`
      },
      { quoted: m }
    );
  } catch (e) {
    console.error(e);

    return m.reply(
      [
        "```",
        "> [+] SCRIBD RESULT",
        "",
        "> [+] Status : Error",
        `> [+] Message: ${e.message || e}`,
        "```"
      ].join("\n")
    );
  }
};

handler.help = [
  "scribd *<query/link/id>*"
];

handler.tags = ["internet"];

handler.command = /^(scribd)$/i;

module.exports = handler;