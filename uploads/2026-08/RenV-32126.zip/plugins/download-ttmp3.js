const axios = require("axios");
const cheerio = require("cheerio");
const { CookieJar } = require("tough-cookie");

const BASE = "https://musicaldown.com";
const HOME = `${BASE}/id`;

const UA =
  "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";

async function getWrapper() {
  const mod = await import("axios-cookiejar-support");
  return mod.wrapper;
}

async function createClient() {
  const wrapper = await getWrapper();
  const jar = new CookieJar();

  return wrapper(
    axios.create({
      jar,
      withCredentials: true,
      timeout: 60000,
      maxRedirects: 5,
      validateStatus: () => true,
      headers: {
        "user-agent": UA,
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
      },
    })
  );
}

function absoluteUrl(url) {
  if (!url) return null;
  if (url.startsWith("http")) return url;
  return new URL(url, BASE).href;
}

function cleanText(text = "") {
  return String(text || "")
    .replace(/arrow_downward/gi, "")
    .replace(/content_paste/gi, "")
    .replace(/close/gi, "")
    .trim()
    .replace(/\s+/g, " ");
}

function stripDownloadTitle(title = "") {
  return cleanText(title)
    .replace(/\s*\|\s*Download Sekarang!?$/i, "")
    .replace(/\s*\|\s*Download Now!?$/i, "")
    .trim();
}

async function getFormData(client, url) {
  const res = await client.get(HOME, {
    headers: {
      accept:
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
      referer: HOME,
      "cache-control": "max-age=0",
      "sec-ch-ua":
        '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
      "sec-ch-ua-mobile": "?1",
      "sec-ch-ua-platform": '"Android"',
      "sec-fetch-site": "same-origin",
      "sec-fetch-mode": "navigate",
      "sec-fetch-user": "?1",
      "sec-fetch-dest": "document",
      "upgrade-insecure-requests": "1",
    },
  });

  if (res.status !== 200) {
    throw new Error(`Gagal membuka MusicalDown. HTTP ${res.status}`);
  }

  const html = String(res.data || "");
  const $ = cheerio.load(html);

  const form = $("#submit-form").first();
  const action = absoluteUrl(form.attr("action") || "/id/download");
  const urlField = form.find('input[type="text"][name]').first().attr("name");

  if (!urlField) {
    throw new Error("Field URL tidak ditemukan.");
  }

  const body = new URLSearchParams();
  body.set(urlField, url);

  form.find('input[type="hidden"][name]').each((_, el) => {
    const name = $(el).attr("name");
    const value = $(el).attr("value") || "";
    if (name) body.set(name, value);
  });

  return { action, body };
}

function parseTitle(html) {
  const $ = cheerio.load(html);
  const rawTitle = cleanText($("title").first().text());
  return stripDownloadTitle(rawTitle) || "tiktok-audio";
}

function isAudioLink(label = "", event = "", url = "") {
  const source = `${label} ${event} ${url}`;
  return event === "mp3_download_click" || /mp3|audio|sound/i.test(source);
}

function parseAudioResult(html) {
  const $ = cheerio.load(html);
  let audio = null;

  $("a[href]").each((_, el) => {
    if (audio) return;

    const href = $(el).attr("href");
    const label = cleanText($(el).text());
    const event = $(el).attr("data-event") || "";

    if (!href) return;

    const url = absoluteUrl(href);
    if (!url) return;

    if (!url.includes("fastdl.muscdn.app")) return;
    if (!isAudioLink(label, event, url)) return;

    audio = {
      url,
      label: label || "Download MP3",
    };
  });

  return audio;
}

async function musicaldownMp3(tiktokUrl) {
  const client = await createClient();
  const form = await getFormData(client, tiktokUrl);

  const res = await client.post(form.action, form.body.toString(), {
    headers: {
      accept:
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
      "content-type": "application/x-www-form-urlencoded",
      origin: BASE,
      referer: HOME,
      "cache-control": "max-age=0",
      "sec-ch-ua":
        '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
      "sec-ch-ua-mobile": "?1",
      "sec-ch-ua-platform": '"Android"',
      "sec-fetch-site": "same-origin",
      "sec-fetch-mode": "navigate",
      "sec-fetch-user": "?1",
      "sec-fetch-dest": "document",
      "upgrade-insecure-requests": "1",
    },
  });

  const html = String(res.data || "");

  if (html.includes('id="submit-form"') && !html.includes("fastdl.muscdn.app")) {
    return {
      status: false,
      error: "MusicalDown kembali ke halaman awal.",
    };
  }

  const audio = parseAudioResult(html);
  const title = parseTitle(html);

  if (!audio?.url) {
    return {
      status: false,
      error: "Audio MP3 tidak ditemukan.",
    };
  }

  return {
    status: true,
    audio,
    title,
  };
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    if (!text) {
      return m.reply(
        `Contoh:\n${usedPrefix + command} https://vt.tiktok.com/ZSxaLQToh/`
      );
    }

    if (!/tiktok\.com|vt\.tiktok\.com|vm\.tiktok\.com/i.test(text)) {
      return m.reply("Masukkan link TikTok yang valid.");
    }

    const result = await musicaldownMp3(text);

    if (!result.status || !result.audio?.url) {
      return m.reply(`❌ Gagal mengambil audio.\n\nError: ${result.error}`);
    }

    return conn.sendAudioMessage(m.chat, result.audio.url, ftroli, {
      fileName: `${result.title
        .replace(/[\/:*?"<>|]/g, "")
        .slice(0, 50)}.mp3`,
      ptt: true,
    });
  } catch (e) {
    return m.reply(`❌ Error: ${e.message || e}`);
  }
};

handler.help = ["ttmp3 *<link tiktok>*"];
handler.tags = ["download"];
handler.command = /^(ttmp3|tiktokmp3|tikaudio)$/i;

module.exports = handler;