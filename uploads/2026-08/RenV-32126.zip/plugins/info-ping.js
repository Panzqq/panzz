const os = require("os");
const axios = require("axios");
const JimpLib = require("jimp");
const { performance } = require("perf_hooks");
const { sizeFormatter } = require("human-readable");

const Jimp = JimpLib.Jimp || JimpLib;
const MIME_JPEG = JimpLib.MIME_JPEG || "image/jpeg";

let format = sizeFormatter({
  std: "JEDEC",
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
});

async function bufferFromUrl(url) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    headers: {
      "User-Agent": "Mozilla/5.0"
    }
  });

  return Buffer.from(res.data);
}

async function makeJpegThumbnail(url) {
  const buffer = await bufferFromUrl(url);
  const img = await Jimp.read(buffer);

  try {
    img.cover(300, 180);
  } catch {
    img.cover({ w: 300, h: 180 });
  }

  let out;

  for (const q of [60, 45, 30, 20]) {
    if (typeof img.quality === "function") img.quality(q);

    if (typeof img.getBufferAsync === "function") {
      out = await img.getBufferAsync(MIME_JPEG);
    } else {
      out = await img.getBuffer(MIME_JPEG);
    }

    if (out.length <= 60000) break;
  }

  return out;
}

let handler = async (m, { conn }) => {
  const chats = Object.entries(conn.chats || {}).filter(
    ([id, data]) => id && data.isChats
  );

  const groupsIn = chats.filter(([id]) => id.endsWith("@g.us"));
  const used = process.memoryUsage();

  const cpus = os.cpus().map(cpu => {
    cpu.total = Object.values(cpu.times).reduce((a, b) => a + b, 0);
    return cpu;
  });

  const cpu = cpus.reduce(
    (acc, cpu, _, { length }) => {
      acc.total += cpu.total;
      acc.speed += cpu.speed / length;
      for (let type in cpu.times) acc.times[type] += cpu.times[type];
      return acc;
    },
    {
      speed: 0,
      total: 0,
      times: {
        user: 0,
        nice: 0,
        sys: 0,
        idle: 0,
        irq: 0,
      },
    }
  );

  let t1 = performance.now();
  let speed = (performance.now() - t1).toFixed(2);

  let text = `
\`== BOT & SERVER STATUS ==\`

> [+] Ping/Latency      : ${speed} ms
> [+] Total Chats       : ${chats.length}
> [+] Group Chats       : ${groupsIn.length}
> [+] Personal Chats    : ${chats.length - groupsIn.length}

\`--- SERVER INFO ---\`
> [+] Platform          : ${os.platform()}
> [+] Hostname          : ${os.hostname()}
> [+] RAM Usage         : ${format(os.totalmem() - os.freemem())} / ${format(os.totalmem())}
> [+] Free RAM          : ${format(os.freemem())}

\`--- NODEJS MEMORY ---\`
${"```" + Object.keys(used).map(k => `${k.padEnd(12)}: ${format(used[k])}`).join("\n") + "```"}

\`--- CPU INFO (${cpus.length} Core) ---\`
> Total CPU Speed      : ${cpu.speed.toFixed(2)} MHZ
> CPU Model            : ${cpus[0].model.trim()}

${cpus.map((c, i) => `
> Core ${i + 1} - ${c.model.trim()} (${c.speed} MHZ)
${Object.keys(c.times).map(type => `  • ${type.padEnd(5)}: ${(100 * c.times[type] / c.total).toFixed(2)}%`).join("\n")}
`).join("")}
`.trim();

  const thumbUrl =
    global.thumb ||
    global.thumbnail ||
    "https://raw.githubusercontent.com/Panzqq/panzz/main/uploads/2026-03-20/RenV-22542.jpeg";

  let jpegThumbnail = null;

  try {
    jpegThumbnail = await makeJpegThumbnail(thumbUrl);
  } catch (e) {
    console.error("Gagal membuat thumbnail location:", e.message);
  }

  await conn.sendMessage(
    m.chat,
    {
      location: {
        degreesLatitude: 0,
        degreesLongitude: 0,
        name: "Renvy Server Status",
        address: "Bot & Server Information",
        jpegThumbnail
      },
      caption: text,
      footer: global.wm || "Renvy",
      buttons: [
        {
          buttonId: ".menu",
          buttonText: {
            displayText: "Menu"
          },
          type: 1
        },
        {
          buttonId: ".owner",
          buttonText: {
            displayText: "Owner"
          },
          type: 1
        }
      ],
      headerType: 6,
      viewOnce: true
    },
    {
      quoted: m
    }
  );
};

handler.help = ["ping", "speed"];
handler.tags = ["info", "tools"];
handler.command = /^(ping|speed|info)$/i;

module.exports = handler;