let handler = async(m, { conn, text, participants }) => {
  let teks = `*乂 M E S S A G E - F R O M - A D M I N S*\n *${text ? text : 'Nothing'}*\n\n`
		      	for (let mem of participants) {
		            teks += `*[+]* @${mem.id.split('@')[0]}\n`
				}
                teks += `___________________________________________`
                conn.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, )
}
handler.help = ['tagall <pesan>']
handler.tags = ['group']
handler.command = /^(tagall)$/i

handler.group = true
handler.admin = true

module.exports = handler
