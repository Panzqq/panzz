const moment = require('moment-timezone')

let handler = async () => {}

handler.before = async function (m) {
  try {
    if (!m) return true
    if (!m.chat || !m.sender) return true

    const isGroup = m.isGroup || m.chat.endsWith('@g.us')
    if (!isGroup) return true

    if (m.fromMe) return true
    if (m.sender.endsWith('@newsletter')) return true
    if (m.sender.endsWith('@g.us')) return true

    global.db = global.db || {}
    global.db.data = global.db.data || {}
    global.db.data.users = global.db.data.users || {}

    const users = global.db.data.users

    if (!users[m.sender]) users[m.sender] = {}

    const user = users[m.sender]
    const today = moment.tz('Asia/Jakarta').format('YYYY-MM-DD')

    if (user.lastChatDate !== today) {
      user.chatToday = 0
      user.lastChatDate = today
    }

    user.totalChat = Number(user.totalChat || 0) + 1
    user.chatToday = Number(user.chatToday || 0) + 1
    user.lastChat = Date.now()

    return true
  } catch (e) {
    console.error('[chat counter]', e)
    return true
  }
}

handler.help = []
handler.tags = []
handler.command = []

module.exports = handler