const axios = require("axios");
const crypto = require("crypto");
const JimpLib = require("jimp");

const Jimp = JimpLib.Jimp || JimpLib;
const MIME_JPEG = JimpLib.MIME_JPEG || "image/jpeg";

const FALLBACK_THUMB =
  "https://raw.githubusercontent.com/Panzqq/panzz/main/uploads/2026-03-20/RenV-22542.jpeg";

class Parser {
  _getImg(o) {
    return (o?.sources || []).map(s => ({
      url: s.url,
      width: s.width || s.maxWidth || null,
      height: s.height || s.maxHeight || null
    }));
  }

  _getCol(o) {
    return o?.extractedColors?.colorRaw?.hex || o?.extractedColors?.colorDark?.hex || null;
  }

  _getVI(v) {
    return v?.squareCoverImage?.extractedColorSet ? {
      text_color: v.squareCoverImage.extractedColorSet.encoreBaseSetTextColor || null,
      high_contrast: v.squareCoverImage.extractedColorSet.highContrast || null,
      higher_contrast: v.squareCoverImage.extractedColorSet.higherContrast || null,
      min_contrast: v.squareCoverImage.extractedColorSet.minContrast || null
    } : null;
  }

  _getLink(uri) {
    if (!uri) return { id: null, url: null };
    const p = uri.split(":");
    return {
      uri,
      id: p[2] || null,
      url: p[2] ? `https://open.spotify.com/${p[1]}/${p[2]}` : null
    };
  }

  parseSearch(res) {
    if (!res) return null;

    const parse = (arr, mapFn, isTrack = false) => (arr || []).reduce((acc, node) => {
      const d = isTrack ? node.item?.data : node.data;
      if (d) acc.push({ ...mapFn(d), ...(node.matchedFields && { matched_fields: node.matchedFields }) });
      return acc;
    }, []);

    const trackItems = res.tracksV2?.items?.length
      ? res.tracksV2.items
      : res.topResultsV2?.itemsV2?.filter(i => i.item?.__typename === "TrackResponseWrapper");

    return {
      tracks: parse(trackItems, t => ({
        ...this._getLink(t.uri),
        name: t.name || null,
        duration_ms: t.duration?.totalMilliseconds || 0,
        explicit: t.contentRating?.label === "EXPLICIT",
        media_type: t.trackMediaType || null,
        playability: {
          playable: !!t.playability?.playable,
          reason: t.playability?.reason || null
        },
        artists: (t.artists?.items || []).map(a => ({
          ...this._getLink(a.uri),
          uri: a.uri,
          name: a.profile?.name
        })),
        album: {
          ...this._getLink(t.albumOfTrack?.uri),
          name: t.albumOfTrack?.name || null,
          images: this._getImg(t.albumOfTrack?.coverArt),
          color_dark: this._getCol(t.albumOfTrack?.coverArt),
          visual_identity: this._getVI(t.albumOfTrack?.visualIdentity)
        }
      }), true)
    };
  }

  parseTrack(data) {
    const t = data?.track || data;
    if (!t || t.__typename !== "Track") return null;

    const allArtists = [
      ...(t.firstArtist?.items || []),
      ...(t.otherArtists?.items || [])
    ];

    return {
      ...this._getLink(t.uri),
      name: t.name || null,
      duration_ms: t.duration?.totalMilliseconds || 0,
      playcount: parseInt(t.playcount) || 0,
      explicit: t.contentRating?.label === "EXPLICIT",
      track_number: t.trackNumber || null,
      album: {
        ...this._getLink(t.albumOfTrack?.uri),
        name: t.albumOfTrack?.name || null,
        type: t.albumOfTrack?.type || null,
        release_year: t.albumOfTrack?.date?.year || null,
        images: this._getImg(t.albumOfTrack?.coverArt),
        color: this._getCol(t.albumOfTrack?.coverArt),
        visual_identity: this._getVI(t.albumOfTrack?.visualIdentity)
      },
      artists: allArtists.map(node => ({
        ...this._getLink(node.uri),
        name: node.profile?.name || null,
        images: this._getImg(node.visuals?.avatarImage)
      }))
    };
  }
}

class Spotify {
  constructor() {
    this.cfg = {
      secret: "376136387538459893883312310911992847112448894410210511297108",
      version: 61,
      client_version: "1.2.88.61.ge172202b",
      query: {
        search: {
          opt: "searchDesktop",
          sha: "21b3fe49546912ba782db5c47e9ef5a7dbd20329520ba0c7d0fcfadee671d24e"
        },
        track: {
          opt: "getTrack",
          sha: "612585ae06ba435ad26369870deaae23b5c8800a256cd8a57e08eddc25a37294"
        }
      }
    };

    this.is = axios.create({
      headers: {
        referer: "https://open.spotify.com/",
        origin: "https://open.spotify.com",
        "content-type": "application/json",
        accept: "application/json",
        "user-agent": "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.7499.34 Mobile Safari/537.36"
      }
    });

    this.parser = new Parser();
  }

  generateTOTP(tsms) {
    const counter = Math.floor((tsms / 1000) / 30);
    const buffer = Buffer.alloc(8);
    buffer.writeBigInt64BE(BigInt(counter));

    const hmac = crypto
      .createHmac("sha1", Buffer.from(this.cfg.secret, "utf8"))
      .update(buffer);

    const digest = hmac.digest();
    const offset = digest[digest.length - 1] & 0xf;
    const code = (digest.readUInt32BE(offset) & 0x7fffffff) % 1000000;

    return code.toString().padStart(6, "0");
  }

  async getToken() {
    try {
      if (this.is.defaults.headers.authorization) return true;

      const sts = Math.floor(Date.now() / 1000);

      const { data: token } = await this.is.get("https://open.spotify.com/api/token", {
        params: {
          reason: "init",
          productType: "web-player",
          totp: this.generateTOTP(Date.now()),
          totpServer: this.generateTOTP(sts * 1000),
          totpVer: String(this.cfg.version)
        }
      });

      const { data: client } = await this.is.post("https://clienttoken.spotify.com/v1/clienttoken", {
        client_data: {
          client_version: this.cfg.client_version,
          client_id: token.clientId,
          js_sdk_data: {
            device_brand: "unknown",
            device_model: "unknown",
            os: "linux",
            os_version: "24.04",
            device_id: crypto.randomUUID(),
            device_type: "computer"
          }
        }
      });

      Object.assign(this.is.defaults.headers, {
        "accept-language": "en",
        "app-platform": "WebPlayer",
        authorization: `Bearer ${token.accessToken}`,
        "client-token": client.granted_token.token,
        "spotify-app-version": this.cfg.client_version
      });

      return true;
    } catch {
      return false;
    }
  }

  async query(name, vars) {
    if (!(await this.getToken())) throw new Error("Gagal mengambil token Spotify.");

    const sel = this.cfg.query[name];

    const { data: res } = await this.is.post("https://api-partner.spotify.com/pathfinder/v2/query", {
      variables: vars,
      operationName: sel.opt,
      extensions: {
        persistedQuery: {
          version: 1,
          sha256Hash: sel.sha
        }
      }
    });

    return res;
  }

  async search(query) {
    const res = await this.query("search", {
      searchTerm: query,
      offset: 0,
      limit: 10,
      numberOfTopResults: 5,
      includeAudiobooks: true,
      includeArtistHasConcertsField: false,
      includePreReleases: true,
      includeAuthors: false,
      includeEpisodeContentRatingsV2: false
    });

    return this.parser.parseSearch(res.data.searchV2);
  }

  async track(id) {
    const res = await this.query("track", {
      uri: `spotify:track:${id}`
    });

    return this.parser.parseTrack(res.data.trackUnion);
  }
}

const spotify = new Spotify();

function pickImage(images = []) {
  if (!Array.isArray(images) || !images.length) return global.thumb || FALLBACK_THUMB;

  const sorted = images
    .filter(x => x.url)
    .sort((a, b) => (b.width || 0) - (a.width || 0));

  return sorted[0]?.url || global.thumb || FALLBACK_THUMB;
}

function msToTime(ms = 0) {
  ms = Number(ms) || 0;
  const total = Math.floor(ms / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function cut(text = "", max = 60) {
  text = String(text || "");
  return text.length > max ? text.slice(0, max - 3) + "..." : text;
}

function sanitizeFileName(name = "Spotify Audio") {
  return String(name)
    .replace(/[\\/:*?"<>|]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 80) || "Spotify Audio";
}

function parseTrackId(input = "") {
  input = String(input || "").trim();

  if (/spotify:track:/i.test(input)) {
    return input.split(":").pop();
  }

  const match = input.match(/open\.spotify\.com\/track\/([a-zA-Z0-9]+)/i);
  if (match) return match[1];

  return input.replace(/[^a-zA-Z0-9]/g, "");
}

async function bufferFromUrl(url) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 60000,
    headers: {
      "User-Agent": "Mozilla/5.0"
    }
  });

  return Buffer.from(res.data);
}

async function jimpBuffer(img, mime) {
  if (typeof img.getBufferAsync === "function") return img.getBufferAsync(mime);

  return new Promise((resolve, reject) => {
    img.getBuffer(mime, (err, buffer) => {
      if (err) reject(err);
      else resolve(buffer);
    });
  });
}

async function makeJpegThumbnail(url) {
  try {
    const buffer = await bufferFromUrl(url || FALLBACK_THUMB);
    const img = await Jimp.read(buffer);

    try {
      img.cover(300, 180);
    } catch {
      img.cover({ w: 300, h: 180 });
    }

    let out;

    for (const q of [70, 55, 40, 25]) {
      if (typeof img.quality === "function") img.quality(q);
      out = await jimpBuffer(img, MIME_JPEG);
      if (out.length <= 60000) break;
    }

    return out;
  } catch {
    const buffer = await bufferFromUrl(FALLBACK_THUMB);
    const img = await Jimp.read(buffer);

    try {
      img.cover(300, 180);
    } catch {
      img.cover({ w: 300, h: 180 });
    }

    return jimpBuffer(img, MIME_JPEG);
  }
}

async function SpotifyDl(url) {
  try {
    const { data: pp } = await axios.post('https://gamepvz.com/api/download/get-url', {
      url: url
    }, {
      'headers': {
        'content-type': 'application/json',
        'user-agent': 'Mozilla/5.0 (Linux; Android 16; NX729J) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.7499.34 Mobile Safari/537.36',
      }
    })
    return {
      status: true,
      title: pp.title,
      author: pp.authorName,
      cover: pp.coverUrl,
      dl: atob(pp.originalVideoUrl.split('url=')[1])
    }
  } catch(e) {
    return { status: false }
  }
}

async function sendOldButton(conn, m, caption, imageUrl, buttons = []) {
  const thumb = await makeJpegThumbnail(imageUrl || global.thumb || FALLBACK_THUMB);

  return conn.sendMessage(
    m.chat,
    {
      location: {
        degreesLatitude: 0,
        degreesLongitude: 0,
        name: "Spotify Music",
        address: "Renvy Spotify Finder",
        jpegThumbnail: thumb
      },
      caption,
      footer: global.wm || "Renvy",
      buttons: buttons.slice(0, 3),
      headerType: 6,
      viewOnce: true
    },
    { quoted: m }
  );
}

async function sendGalaxyList(conn, m, caption, sections, imageUrl) {
  const listData = {
    title: "Spotify Search Result",
    sections
  };

  const buttons = [
    {
      id: "spotify_galaxy",
      text: "[ ✦ Spotify Music Finder ]",
      native: "galaxy_message"
    },
    {
      id: "spotify_list",
      text: "[ 🎧 ] Pilih Lagu",
      native: true
    },
    {
      id: ".spotify",
      text: "[ 🔎 ] Cari Lagi"
    }
  ];

  if (typeof conn.sendbtnglaxy === "function") {
    try {
      return await conn.sendbtnglaxy(
        m.chat,
        buttons,
        caption,
        "[ Spotify Search • Renvy System ]",
        m.sender,
        m,
        listData,
        imageUrl || global.thumb || FALLBACK_THUMB
      );
    } catch (e) {
      console.error("sendbtnglaxy error:", e.message);
    }
  }

  const thumb = await makeJpegThumbnail(imageUrl || global.thumb || FALLBACK_THUMB);

  return conn.sendMessage(
    m.chat,
    {
      location: {
        degreesLatitude: 0,
        degreesLongitude: 0,
        name: "Spotify Search",
        address: "Pilih lagu lewat tombol list",
        jpegThumbnail: thumb
      },
      caption,
      footer: global.wm || "Renvy",
      buttons: [
        {
          buttonId: "spotify_list",
          buttonText: {
            displayText: "Pilih Lagu"
          },
          type: 4,
          nativeFlowInfo: {
            name: "single_select",
            paramsJson: JSON.stringify(listData)
          }
        },
        {
          buttonId: ".spotify",
          buttonText: {
            displayText: "Cari Lagi"
          },
          type: 1
        }
      ],
      headerType: 6,
      viewOnce: true
    },
    { quoted: m }
  );
}

async function sendSearchResult(conn, m, query, result) {
  const tracks = result?.tracks || [];

  if (!tracks.length) {
    return m.reply(`Lagu dengan kata kunci *${query}* tidak ditemukan.`);
  }

  const rows = tracks.slice(0, 10).map((t, i) => {
    const artists = (t.artists || []).map(a => a.name).filter(Boolean).join(", ") || "-";
    const album = t.album?.name || "-";

    return {
      header: `#${i + 1} • ${msToTime(t.duration_ms)}`,
      title: cut(t.name || "Unknown Title", 45),
      description: cut(`${artists} • ${album}`, 70),
      id: `.spotifyget ${t.id}`
    };
  });

  const top = tracks.slice(0, 5).map((t, i) => {
    const artists = (t.artists || []).map(a => a.name).filter(Boolean).join(", ") || "-";
    return `${i + 1}. *${t.name}*\n   Artist : ${artists}\n   Durasi : ${msToTime(t.duration_ms)}`;
  }).join("\n\n");

  const caption = `
乂 S P O T I F Y  S E A R C H

Query : ${query}
Hasil : ${tracks.length} lagu

${top}

Tekan tombol *Pilih Lagu* untuk membuka detail.
`.trim();

  const image = pickImage(tracks[0]?.album?.images);

  return sendGalaxyList(
    conn,
    m,
    caption,
    [
      {
        title: `🎧 Hasil pencarian: ${query}`,
        rows
      }
    ],
    image
  );
}

async function sendTrackDetail(conn, m, track) {
  const artists = (track.artists || []).map(a => a.name).filter(Boolean).join(", ") || "-";
  const image = pickImage(track.album?.images);

  const caption = `
乂 S P O T I F Y  T R A C K

Title     : ${track.name || "-"}
Artist    : ${artists}
Album     : ${track.album?.name || "-"}
Release   : ${track.album?.release_year || "-"}
Duration  : ${msToTime(track.duration_ms)}
Playcount : ${track.playcount ? track.playcount.toLocaleString("id-ID") : "-"}
Explicit  : ${track.explicit ? "Ya" : "Tidak"}

Link:
${track.url || "-"}
`.trim();

  return sendOldButton(conn, m, caption, image, [
    {
      buttonId: `.spotifydl ${track.url}`,
      buttonText: {
        displayText: "Download Musik"
      },
      type: 1
    },
    {
      buttonId: `.spotify ${track.name || ""}`,
      buttonText: {
        displayText: "Cari Kembali"
      },
      type: 1
    }
  ]);
}

async function sendSpotifyAudio(conn, m, spotifyUrl) {
  await m.reply("⏳ Sedang mengambil audio Spotify...");

  const result = await SpotifyDl(spotifyUrl);

  if (!result.status || !result.dl) {
    throw new Error("Gagal mengambil audio melalui API Downloader baru.");
  }

  const title = sanitizeFileName(result.title || "Spotify Audio");

  return conn.sendAudioMessage(m.chat, result.dl, ftroli, {
    fileName: `${title}.mp3`,
    ptt: true
  });
}

let handler = async (m, { conn, text, command, usedPrefix }) => {
  const prefix = usedPrefix || ".";

  try {
    if (/^spotifyget$/i.test(command)) {
      const id = parseTrackId(text);

      if (!id) {
        return m.reply(`Contoh:\n${prefix}spotifyget <id/url>`);
      }

      await m.reply("⏳ Mengambil detail lagu...");

      const track = await spotify.track(id);

      if (!track) return m.reply("Detail lagu tidak ditemukan.");

      return sendTrackDetail(conn, m, track);
    }

    if (/^spotifydl$/i.test(command)) {
      if (!text) {
        return m.reply(`Contoh:\n${prefix}spotifydl https://open.spotify.com/track/xxxx`);
      }

      if (!/open\.spotify\.com\/track\//i.test(text)) {
        return m.reply("Link Spotify tidak valid. Gunakan link track Spotify.");
      }

      return sendSpotifyAudio(conn, m, text);
    }

    if (!text) {
      return sendOldButton(
        conn,
        m,
        `
乂 S P O T I F Y  F I N D E R

Cari lagu Spotify dengan tampilan button.

Contoh:
${prefix}spotify kicau mania
${prefix}spotify about you
${prefix}spotify hindia secukupnya
`.trim(),
        global.thumb || FALLBACK_THUMB,
        [
          {
            buttonId: `${prefix}spotify kicau mania`,
            buttonText: {
              displayText: "Contoh Search"
            },
            type: 1
          },
          {
            buttonId: ".menu",
            buttonText: {
              displayText: "Menu"
            },
            type: 1
          }
        ]
      );
    }

    await m.reply("⏳ Mencari lagu di Spotify...");

    const result = await spotify.search(text);

    return sendSearchResult(conn, m, text, result);
  } catch (e) {
    console.error(e);

    return m.reply(
      `乂 S P O T I F Y  E R R O R\n\nError: ${e.message || e}`
    );
  }
};

handler.help = ["spotify <query>", "spotifyget <id>", "spotifydl <url>"];
handler.tags = ["download"];
handler.command = /^(spotify|spotifysearch|spotifyget|spotifydl)$/i;
handler.register = true;

module.exports = handler;