const fs = require('fs')
const path = require('path')

const OBF_CONFIG_HOME = path.join(process.cwd(), 'database', '.config')
try {
  fs.mkdirSync(OBF_CONFIG_HOME, { recursive: true })
  process.env.XDG_CONFIG_HOME = process.env.XDG_CONFIG_HOME || OBF_CONFIG_HOME
  process.env.ADBLOCK = process.env.ADBLOCK || '1'
  process.env.DISABLE_OPENCOLLECTIVE = process.env.DISABLE_OPENCOLLECTIVE || '1'
} catch {}

const JavaScriptObfuscator = require('javascript-obfuscator')
const terser = require('terser')
const zlib = require('zlib')

let proto, generateWAMessageFromContent
try {
  const baileys = require('baileys')
  proto = baileys.proto
  generateWAMessageFromContent = baileys.generateWAMessageFromContent
} catch {
  proto = null
  generateWAMessageFromContent = null
}

function cleanName(name = 'renvy') {
  return path
    .basename(String(name))
    .replace(/\.js$/i, '')
    .replace(/[^\w.-]/g, '_')
}

function pickFileName(q) {
  return (
    q?.fileName ||
    q?.msg?.fileName ||
    q?.message?.documentMessage?.fileName ||
    'renvy.js'
  )
}

async function getSourceCode(m, text) {
  const q = m.quoted || null

  if (q) {
    const mime = q.mimetype || q.msg?.mimetype || ''
    const fileName = pickFileName(q)

    if (q.download && (/javascript|text|octet-stream/i.test(mime) || /\.js$/i.test(fileName))) {
      const buffer = await q.download()
      if (buffer && buffer.length) {
        return {
          source: buffer.toString('utf8'),
          fileName
        }
      }
    }

    if (typeof q.text === 'string' && q.text.trim()) {
      return {
        source: q.text,
        fileName: 'renvy-text.js'
      }
    }

    if (q.download) {
      const buffer = await q.download()
      if (buffer && buffer.length) {
        return {
          source: buffer.toString('utf8'),
          fileName
        }
      }
    }
  }

  if (text && text.trim()) {
    return {
      source: text,
      fileName: 'renvy-text.js'
    }
  }

  return {
    source: '',
    fileName: 'renvy.js'
  }
}

async function makeEnc(source) {
  if (!source || typeof source !== 'string') {
    throw new Error('Kode kosong.')
  }

  const minified = await terser.minify(source, {
    compress: {
      passes: 3,
      drop_debugger: true,
      drop_console: false
    },
    mangle: true,
    format: {
      comments: false
    }
  })

  if (minified.error) throw minified.error

  const code = minified.code || source
  const gzip = zlib.gzipSync(Buffer.from(code, 'utf8'))
  const base64 = gzip.toString('base64')

  const loader = `
;(function () {
  const _renvy_core = 'renvy'
  const _renvy_by = 'whatsapp bot by panpan'
  const _renvy_time = Date.now()
  const _renvy_data = '${base64}'
  const _renvy_zlib = require('zlib')
  const _renvy_buffer = Buffer.from(_renvy_data, 'base64')
  const _renvy_code = _renvy_zlib.gunzipSync(_renvy_buffer).toString('utf8')

  function _renvy_guard_1() { return _renvy_core + _renvy_by }
  function _renvy_guard_2() { return _renvy_time + Math.random() }
  function _renvy_guard_3() { return Buffer.from(_renvy_core).toString('hex') }

  const _renvy_fake_1 = _renvy_guard_1()
  const _renvy_fake_2 = _renvy_guard_2()
  const _renvy_fake_3 = _renvy_guard_3()

  if (!_renvy_fake_1 || !_renvy_fake_2 || !_renvy_fake_3) {
    throw new Error('Renvy protection error')
  }

  module._compile(_renvy_code, __filename)
})()
`

  const obfuscated = JavaScriptObfuscator.obfuscate(loader, {
    target: 'node',
    compact: true,

    identifierNamesGenerator: 'hexadecimal',
    identifiersPrefix: '_renvy_',

    renameGlobals: false,

    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.95,

    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.45,

    stringArray: true,
    stringArrayEncoding: ['rc4'],
    stringArrayThreshold: 1,
    rotateStringArray: true,
    shuffleStringArray: true,

    stringArrayWrappersCount: 5,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 5,
    stringArrayWrappersType: 'function',

    splitStrings: true,
    splitStringsChunkLength: 4,

    transformObjectKeys: true,
    unicodeEscapeSequence: true,
    numbersToExpressions: true,
    simplify: true,

    selfDefending: false,
    debugProtection: false,
    disableConsoleOutput: false
  })

  return obfuscated.getObfuscatedCode()
}

async function sendCopyButton(conn, m, code, fileName) {
  if (!proto || !generateWAMessageFromContent) {
    throw new Error('Baileys belum support interactiveMessage / cta_copy.')
  }

  const msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
              text:
                `✅ Encode berhasil\n\n` +
                `📄 File: ${fileName}\n\n` +
                `Klik tombol di bawah untuk copy kode.`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: 'Renvy Encryptor'
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: 'COPY CODE',
                    id: 'copy_renvy_enc',
                    copy_code: code
                  })
                }
              ]
            })
          })
        }
      }
    },
    { quoted: m }
  )

  await conn.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  })
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    const { source, fileName } = await getSourceCode(m, text)

    if (!source) {
      return m.reply(
        `Kirim/reply file .js atau teks kode JS.\n\n` +
        `Contoh:\n` +
        `${usedPrefix + command} console.log("halo")\n\n` +
        `Atau reply file/teks kode dengan:\n` +
        `${usedPrefix + command}`
      )
    }

    if (source.length > 1000 * 1000) {
      return m.reply('Kode terlalu besar. Maksimal sekitar 1MB agar bot tidak berat.')
    }

    await m.reply('⏳ Sedang encode kode...')

    const enc = await makeEnc(source)
    const outputName = cleanName(fileName) + '.enc.js'

    await conn.sendMessage(
      m.chat,
      {
        document: Buffer.from(enc),
        fileName: outputName,
        mimetype: 'application/javascript',
        caption:
          `✅ Berhasil encode JavaScript\n\n` +
          `📄 File: ${outputName}`
      },
      { quoted: m }
    )

    await sendCopyButton(conn, m, enc, outputName)
  } catch (e) {
    m.reply(`❌ Gagal encode:\n${e.message}`)
  }
}

handler.help = handler.command = ['encjs', 'enc', 'encryptjs']
handler.tags = ['tools']
handler.owner = true

module.exports = handler