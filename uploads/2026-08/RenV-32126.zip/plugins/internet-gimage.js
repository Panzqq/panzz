// Kalau pakai Node.js versi lama (di bawah v18), jangan lupa uncomment baris ini:
// const fetch = require('node-fetch')

/**
 * google image search  19 agustus 2026
 * skrep mungkin gk akan hidup selamanya
 * karena perlu kuki NID yang valid
 * kalian bisa generate sendiri kalau semisal kukinya dead ya
 * tapi untuk saat ini mungkin masih bisa digunakan, cb aja
 * btw bs aja valuenya detail isi beberapa info kaya w x h, about url, source url dll
 * tapi aku kasih url image aja biar simple haha
 * 
 * @param {string} query 
 * @returns {string[]} array of string
 * @throws {Error} kalau error :v
 */
const googleImageSearch = async (query) => {
  const queryType = typeof query
  if (queryType !== "string" || !query) throw Error(`param query harus string dan gak boleh kosong. ${queryType} diterima`)

  const url = new URL("https://www.google.com")
  url.pathname = "/search"
  url.search = new URLSearchParams({
    "as_st": "y",
    "as_q": query,
    "as_epq": "",
    "as_eq": "",
    "as_sitesearch": "",
    "imgar": "",
    "cr": "",
    "as_filetype": "",
    "tbs": "",
    "authuser": "0",
    "udm": "2"
  })

  const r = await fetch(url, {
    "headers": {
      "accept-encoding": "gzip, deflate, br, zstd",
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      "cookie": "NID=534=JfgKfpTI0nMmEVTUkt99_nSUrVNVVVQkwkdP2aaBqEoGO2Lwe1Z6D27jcdudKDF54CPrujLl55Ebv5g_-jMyO9LMOo7EMAqZs0bLLkwnpiYfInEzq3cwh3GXisUx7Xhm8_O3HXztAR0P244qoFVZUb-yX04WJgY2JZPCcFbK_plWEhzWL8l-U4khQ1tLXgBaeRnE9_Ii0jjRWEa2Oktv7YzEe98i9YuzBIzRpZdZBMn3Gg",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36"
    },
  });

  const html = await r.text()
  const match = html.match(/var m={(.+?);var a=m/gms)
  if (!match) throw Error("Gagal mengambil data dari Google (mungkin kuki NID dead atau layout berubah)")
  
  const code = match[0]
  const trim = code.substring(0, code.length - 7)
  const res = eval(`${trim}; m`)
  const imageUrls = Object.keys(res)
    .map(k => res[k]?.[3]?.[0])
    .filter(url => url?.startsWith('http'))
  
  return imageUrls
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  // Cegah user ngeblank
  if (!text) return m.reply(`Ketik pencariannya dong!\n\nContoh: *${usedPrefix}${command} isabelle animal crossing cute fanart*`)

  // Kasih indikator loading biar user tau bot lagi kerja
  await m.reply('Tunggu bentar, lagi nyari gambarnya...')

  try {
    const result = await googleImageSearch(text)

    if (!result || result.length === 0) {
      return m.reply('Waduh, gambarnya nggak ketemu. Coba kata kunci lain ya.')
    }

    // Ambil 1 url gambar secara acak dari hasil array biar nggak itu-itu aja yang dikirim
    const randomImage = result[Math.floor(Math.random() * result.length)]

    // Kirim gambar ke chat
    await conn.sendMessage(m.chat, { 
      image: { url: randomImage }, 
      caption: `Hasil pencarian untuk: *${text}*` 
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    m.reply(`Waduh error nih :v\n${e.message}`)
  }
}

handler.help = ['gimage <query>']
handler.command = ['gimage', 'googleimage', 'gambar']
handler.tags = ['internet']

module.exports = handler;