const axios = require('axios')
const fs = require('fs')
const path = require('path')

const RUMAHOTP_API_KEY = 'rk-dev-vUKnO3fxBfNR6flCozkomwKsCv8Jts7n'
const RUMAHOTP_PAYMENT_ID = 'qris'
const RUMAHOTP_POLL_INTERVAL = 8000
const ORDER_EXPIRE_MS = 15 * 60 * 1000 // 15 menit, sesuaikan sama masa aktif QRIS RumahOTP

const BASE_URL = 'https://www.rumahotp.io/api'
const DB_PATH = path.join(process.cwd(), 'database', 'rumahotp-payment.json')

function ensureDB() {
  const dir = path.dirname(DB_PATH)
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({ orders: {} }, null, 2))
  }
}

function loadPayDB() {
  ensureDB()
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'))
  } catch {
    return { orders: {} }
  }
}

function savePayDB(data) {
  ensureDB()
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2))
}

function checkConfig() {
  if (!RUMAHOTP_API_KEY || RUMAHOTP_API_KEY === 'ISI_API_KEY_BARU_KAMU') {
    throw new Error('API Key RumahOTP belum diisi di plugin.')
  }
}

function errorText(data) {
  if (!data) return 'Tidak ada response dari API'
  if (typeof data === 'string') return data
  if (typeof data.message === 'string') return data.message
  if (typeof data.error === 'string') return data.error
  if (data.message && typeof data.message === 'object') return JSON.stringify(data.message, null, 2)
  if (data.error && typeof data.error === 'object') return JSON.stringify(data.error, null, 2)
  return JSON.stringify(data, null, 2)
}

function rupiah(n) {
  return 'Rp' + Number(n || 0).toLocaleString('id-ID')
}

function parseAmount(text) {
  const amount = parseInt(String(text || '').replace(/[^\d]/g, ''), 10)
  if (!amount || amount < 1000) return null
  return amount
}

function now() {
  return new Date().toISOString()
}

function isExpired(order) {
  if (!order?.createdAt) return false
  return Date.now() - new Date(order.createdAt).getTime() > ORDER_EXPIRE_MS
}

function isOwner(sender) {
  const num = String(sender || '').split('@')[0]
  const owners = Array.isArray(global.owner) ? global.owner : []
  return owners.some((o) => String(Array.isArray(o) ? o[0] : o) === num)
}

function getDepositId(data) {
  return (
    data.id ||
    data.deposit_id ||
    data.id_deposit ||
    data.trxid ||
    data.transaction_id ||
    data.reference ||
    ''
  )
}

function getDepositStatus(data, fallback = 'pending') {
  return String(data.status || data.deposit_status || data.state || fallback).toLowerCase()
}

async function rumahotpGet(endpoint, params = {}) {
  checkConfig()

  const res = await axios.get(`${BASE_URL}${endpoint}`, {
    params,
    headers: {
      'x-apikey': RUMAHOTP_API_KEY,
      Accept: 'application/json',
    },
    timeout: 30000,
    validateStatus: () => true,
  })

  console.log('[RumahOTP Response]', res.status, JSON.stringify(res.data, null, 2))

  if (res.status < 200 || res.status >= 300) {
    throw new Error(`RumahOTP Error ${res.status}:\n${errorText(res.data)}`)
  }

  if (!res.data?.success) {
    throw new Error(`RumahOTP Gagal:\n${errorText(res.data)}`)
  }

  return res.data.data
}

async function createDeposit(amount) {
  return rumahotpGet('/v2/deposit/create', {
    amount,
    payment_id: RUMAHOTP_PAYMENT_ID,
  })
}

async function checkDeposit(depositId) {
  return rumahotpGet('/v2/deposit/get_status', {
    deposit_id: depositId,
  })
}

async function getRumahOtpBalance() {
  return rumahotpGet('/v1/user/balance')
}

function getUserSaldo(sender) {
  return Number(global.db?.data?.users?.[sender]?.saldo || 0)
}

function addUserBalance(sender, amount) {
  if (!global.db?.data?.users) return false

  if (!global.db.data.users[sender]) {
    global.db.data.users[sender] = {}
  }

  const user = global.db.data.users[sender]
  user.saldo = Number(user.saldo || 0) + Number(amount || 0)

  return true
}

async function sendPaidNotif(conn, order) {
  if (!conn || !order || order.notified) return

  await conn.sendMessage(order.chat, {
    text:
`✅ *Deposit Berhasil*

Halo @${order.sender.split('@')[0]}, pembayaran kamu sudah terdeteksi.

• ID: ${order.id}
• Nominal Deposit: ${rupiah(order.amount)}
• Total Bayar: ${rupiah(order.total)}
• Status: *SUCCESS*
${order.balanceAdded ? `• Saldo Ditambahkan: ${rupiah(order.amount)}` : ''}
• Saldo Sekarang: ${rupiah(getUserSaldo(order.sender))}

Terima kasih.`,
    mentions: [order.sender],
  })
}

async function updateStatus(conn, depositId) {
  const paydb = loadPayDB()
  const order = paydb.orders[depositId]
  if (!order) return null

  if (order.status === 'pending' && isExpired(order)) {
    order.status = 'expired'
    order.updatedAt = now()
    paydb.orders[depositId] = order
    savePayDB(paydb)
    return order
  }

  const statusData = await checkDeposit(depositId)
  const status = getDepositStatus(statusData, order.status)

  order.rawStatus = statusData
  order.status = status
  order.updatedAt = now()

  if (status === 'success') {
    order.status = 'success'
    order.paidAt = order.paidAt || now()

    if (!order.balanceAdded) {
      order.balanceAdded = addUserBalance(order.sender, order.amount)
    }

    if (!order.notified) {
      await sendPaidNotif(conn, order)
      order.notified = true
    }
  }

  if (status === 'cancel' || status === 'cancelled' || status === 'expired') {
    order.status = status
  }

  paydb.orders[depositId] = order
  savePayDB(paydb)

  return order
}

function startAutoChecker(conn, depositId) {
  global.__rumahotpChecker = global.__rumahotpChecker || {}
  if (global.__rumahotpChecker[depositId]) return

  let count = 0
  const maxCheck = 180

  global.__rumahotpChecker[depositId] = setInterval(async () => {
    count++

    try {
      const order = await updateStatus(conn, depositId)

      if (
        !order ||
        ['success', 'cancel', 'cancelled', 'expired'].includes(order.status) ||
        count >= maxCheck
      ) {
        clearInterval(global.__rumahotpChecker[depositId])
        delete global.__rumahotpChecker[depositId]
      }
    } catch (e) {
      console.error('[RumahOTP Auto Check Error]', e?.message || e)

      if (count >= maxCheck) {
        clearInterval(global.__rumahotpChecker[depositId])
        delete global.__rumahotpChecker[depositId]
      }
    }
  }, RUMAHOTP_POLL_INTERVAL)
}

function resumePendingChecker(conn) {
  const paydb = loadPayDB()
  const orders = Object.values(paydb.orders)

  for (const order of orders) {
    if (order.status === 'pending' && !isExpired(order)) {
      startAutoChecker(conn, order.id)
    }
  }
}

async function sendInvoice(conn, m, order, usedPrefix) {
  const text =
`乂 *D E P O S I T  Q R I S*

• ID: ${order.id}
• Nominal Deposit: ${rupiah(order.amount)}
• Total Bayar: ${rupiah(order.total)}
• Fee: ${rupiah(order.fee)}
• Status: *PENDING*
• Berlaku: ${Math.round(ORDER_EXPIRE_MS / 60000)} menit

Silakan scan QRIS ini.

Bot akan otomatis mendeteksi jika pembayaran berhasil.

Cek manual:
${usedPrefix}paycheck ${order.id}`

  if (order.qr_image) {
    return conn.sendMessage(m.chat, { image: { url: order.qr_image }, caption: text }, { quoted: m })
  }

  if (order.qr_string) {
    return conn.sendMessage(m.chat, { text: `${text}\n\n*QR String:*\n${order.qr_string}` }, { quoted: m })
  }

  return conn.sendMessage(m.chat, { text: `${text}\n\nQRIS tidak ditemukan dari response API.` }, { quoted: m })
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const cmd = String(command || '').toLowerCase()

  try {
    resumePendingChecker(conn)

    // ================= DEPOSIT =================
    if (cmd === 'depo') {
      if (!text) {
        return m.reply(`Contoh:\n${usedPrefix + command} 10000`)
      }

      const amount = parseAmount(text)
      if (!amount) {
        return m.reply(`Nominal tidak valid (min. Rp1.000).\n\nContoh:\n${usedPrefix + command} 10000`)
      }

      await m.reply(global.wait || 'Sedang membuat QRIS deposit...')

      const dep = await createDeposit(amount)
      const depositId = getDepositId(dep)

      if (!depositId) {
        throw new Error(`ID deposit tidak ditemukan dari response API.\n\nResponse:\n${JSON.stringify(dep, null, 2)}`)
      }

      const order = {
        id: depositId,
        sender: m.sender,
        chat: m.chat,
        amount,
        method: dep.method || dep.payment_id || RUMAHOTP_PAYMENT_ID,
        status: getDepositStatus(dep, 'pending'),
        total: dep.total || dep.currency?.total || dep.amount || amount,
        fee: dep.fee || dep.currency?.fee || 0,
        diterima: dep.diterima || dep.currency?.diterima || amount,
        qr_string: dep.qr_string || dep.qrString || '',
        qr_image: dep.qr_image || dep.qrImage || dep.qr_url || dep.qrUrl || '',
        createdAt: now(),
        updatedAt: now(),
        expiredAt: dep.expired_at || dep.expired || null,
        paidAt: null,
        notified: false,
        balanceAdded: false,
        rawCreate: dep,
      }

      const paydb = loadPayDB()
      paydb.orders[order.id] = order
      savePayDB(paydb)

      startAutoChecker(conn, order.id)

      return sendInvoice(conn, m, order, usedPrefix)
    }

    // ================= CEK STATUS DEPOSIT =================
    if (cmd === 'paycheck') {
      const depositId = String(text || '').trim()

      if (!depositId) {
        return m.reply(`Contoh:\n${usedPrefix + command} ID_DEPOSIT`)
      }

      await m.reply(global.wait || 'Sedang mengecek pembayaran...')

      const order = await updateStatus(conn, depositId)
      if (!order) {
        return m.reply('Order tidak ditemukan di database bot.')
      }

      return m.reply(
`乂 *S T A T U S  D E P O S I T*

• ID: ${order.id}
• Nominal Deposit: ${rupiah(order.amount)}
• Total Bayar: ${rupiah(order.total)}
• Status: *${String(order.status).toUpperCase()}*
• Dibayar: ${order.paidAt ? 'Ya' : 'Belum'}
• Saldo Masuk: ${order.balanceAdded ? 'Ya' : 'Belum'}`
      )
    }

    // ================= CEK SALDO USER =================
    if (cmd === 'saldo') {
      const saldo = getUserSaldo(m.sender)
      return conn.sendMessage(m.chat, {
        text:
`💰 *S A L D O  K A M U*

@${m.sender.split('@')[0]}
Saldo: *${rupiah(saldo)}*

Ketik ${usedPrefix}depo <nominal> buat top up.`,
        mentions: [m.sender],
      }, { quoted: m })
    }

    // ================= RIWAYAT DEPOSIT USER =================
    if (cmd === 'riwayat' || cmd === 'mutasi') {
      const paydb = loadPayDB()
      const orders = Object.values(paydb.orders)
        .filter((o) => o.sender === m.sender)
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 10)

      if (!orders.length) {
        return m.reply('Belum ada riwayat deposit.')
      }

      const list = orders
        .map((o, i) => {
          const tgl = new Date(o.createdAt).toLocaleString('id-ID', { dateStyle: 'short', timeStyle: 'short' })
          return `${i + 1}. ${rupiah(o.amount)} — *${o.status.toUpperCase()}* (${tgl})\n   ID: ${o.id}`
        })
        .join('\n\n')

      return m.reply(`乂 *R I W A Y A T  D E P O S I T*\n(10 transaksi terakhir)\n\n${list}`)
    }

    // ================= CEK SALDO AKUN RUMAHOTP (ADMIN) =================
    if (cmd === 'rumahsaldo') {
      if (!isOwner(m.sender)) {
        return m.reply('Fitur ini khusus admin/owner bot.')
      }

      await m.reply(global.wait || 'Sedang mengecek saldo RumahOTP...')

      const data = await getRumahOtpBalance()

      return m.reply(
`乂 *S A L D O  A K U N  R U M A H O T P*

• Saldo: ${data.formated || rupiah(data.balance)}
• Username: ${data.username || '-'}
• Email: ${data.email || '-'}`
      )
    }
  } catch (e) {
    console.error('[RumahOTP Payment Error]', e)

    let msg = e?.message
    if (!msg || msg === '[object Object]') {
      try {
        msg = JSON.stringify(e, null, 2)
      } catch {
        msg = String(e)
      }
    }

    return m.reply(`Terjadi error:\n${msg}`)
  }
}

handler.help = handler.command = ['depo', 'paycheck', 'saldo', 'riwayat', 'mutasi', 'rumahsaldo']
handler.tags = ['payment']

module.exports = handler