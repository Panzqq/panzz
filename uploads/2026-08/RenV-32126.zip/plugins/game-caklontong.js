const { caklontong } = require("@bochilteam/scraper");
let timeout = 120000;

let handler = async (m, { conn, command, usedPrefix }) => {
  conn.caklontongAuto = conn.caklontongAuto ? conn.caklontongAuto : {};
  let id = m.chat;
  if (id in conn.caklontongAuto) {
    conn.reply(
      m.chat,
      "You Already have question to answer !",
      conn.caklontongAuto[id][0],
    );
  }
  let json = await caklontong();
  let caption = `*[ CAK LONTONG ]*
*• Timeout :* 60 seconds
*• Question :* ${json.soal}
*• Clue :* ${json.jawaban.replace(/[AIUEOaiueo]/g, "_")}

reply to this message to answer the question
type *\`nyerah\`* to surender`.trim();

  conn.caklontongAuto[id] = [
    conn.reply(m.chat, caption, m),
    json,
    setTimeout(() => {
      if (conn.caklontongAuto[id])
        conn.sendMessage(
          id,
          {
            text: `Game Over !!
You lose with reason : *[ Timeout ]*

• Answer : *[ ${json.jawaban} ]*`,
          },
          { quoted: m },
        );
      delete conn.caklontongAuto[id];
    }, timeout),
  ];
};

handler.before = async (m, { conn }) => {
  conn.caklontongAuto = conn.caklontongAuto ? conn.caklontongAuto : {};
  let id = m.chat;
  if (!m.text) return;
  if (m.isCommand) return;
  if (!conn.caklontongAuto[id]) return;
  let json = await conn.caklontongAuto[id][1];
  let reward = db.data.users[m.sender];
  if (
    m.text.toLowerCase() === "nyerah" ||
    m.text.toLowerCase() === "surender"
  ) {
    clearTimeout(await conn.caklontongAuto[id][2]);
    conn.sendMessage(
      m.chat,
      {
        text: `Game Over !!
You lose with reason : *[ ${m.text} ]*

• Answer : *[ ${json.jawaban} ]*`,
      },
      { quoted: await conn.caklontongAuto[id][0] },
    );
    delete conn.caklontongAuto[id];
  } else if (m.text.toLowerCase() === json.jawaban.toLowerCase()) {
    reward.money += parseInt(10000);
    reward.limit += 10;
    clearTimeout(await conn.caklontongAuto[id][2]);
    await conn.sendMessage(
      m.chat,
      {
        text: `Congratulations 🎉
you have successfully guessed the answer!

* *Money :* 10.000+
* *Limit :* 10+

Next question...`,
      },
      { quoted: await conn.caklontongAuto[id][0] },
    );
    delete conn.caklontongAuto[id];
    await conn.appendTextMessage(m, ".caklontongauto", m.chatUpdate);
  } else {
    conn.sendMessage(m.chat, {
      react: {
        text: "❌",
        key: m.key,
      },
    });
  }
};

handler.help = ["caklontongauto", "caklontong2"];
handler.tags = ["game"];
handler.command = ["caklontongauto", "caklontong2", "cakauto"];
handler.group = true;

module.exports = handler;
