const fetch = require("node-fetch");
const { writeFileSync } = require("fs");
const path = require('path');
const { tmpFile, safeUnlink } = require('../lib/tmpManager');

let handler = async (m, { text, conn, usedPrefix, command }) => {
  if (!text) throw `Masukkan teks untuk diubah menjadi gambar\n*Contoh:* ${usedPrefix}${command} 1girl, blush, looking to viewer, warm smile`;
  if (!text.includes(',')) throw `Tolong gunakan prompt dengan benar. Gunakan koma *[ , ]* untuk memisahkan argumen.\n*Contoh:* ${usedPrefix}${command} 1girl, blush, looking to viewer, warm smile`;  
  const prompt = text.split(',').join(', ');
  const response = await fetch(`${btch.url}/api/search/stablediffusion?apikey=${btch.key}&text=${prompt}`);
  const buffer = await response.buffer();
  const saveFilename = tmpFile({ dir: 'ai/diffusion', prefix: 'stablediffusion', ext: 'jpg' });
  try {
    writeFileSync(saveFilename, buffer);
    await conn.sendFile(m.chat, saveFilename, null, `*Result For:* _${prompt}_`, m);
  } finally {
    await safeUnlink(saveFilename);
  }
};
handler.command = handler.help = ['diffusion', 'stablediffusion', 'diff'];
handler.tags = ['ai'];
handler.limit = true;
handler.private = false;
handler.group = false;

module.exports = handler;
