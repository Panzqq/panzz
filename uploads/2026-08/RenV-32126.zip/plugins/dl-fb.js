const axios = require('axios');

let handler = async (m, { conn, args, usedPrefix, command, text }) => {
  let input = `[!] *Wrong input*\n\nEx: ${usedPrefix + command} https://www.facebook.com/share/r/1BYyYZ6JKH/`;
  if (!text) return m.reply(input);

  try {
    await conn.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });

    let { data } = await axios.get(global.api + `/api/download/facebook?url=${encodeURIComponent(text)}`);
    
    if (!data.status || !data.data) {
      return m.reply('Waduh error nih bree, tolong report ke owner gw.');
    }

    const result = data.data;
    const caption = `乂 *F A C E B O O K*\n*Url*: ${text}\n*Title*: ${result.title || 'No title'}`;

    await conn.sendMessage(
      m.chat,
      {
        video: { url: result.hd || result.sd },
        caption: caption,
        footer: global.wm,
        buttons: [
          {
            buttonId: ".menu",
            buttonText: { displayText: "🗒️ Back Menu" }
          }
        ],
        viewOnce: true,
        headerType: 6,
        contextInfo: {
          externalAdReply: {
            title: caption,
            body: null,
            thumbnailUrl: global.thumb,
            sourceUrl: global.saluran,
            mediaType: 1,
            mentionedJid: [m.sender],
            renderLargerThumbnail: true,
          },
        },
      },
      { quoted: m }
    );

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (err) {
    console.error(err);
    m.reply('Waduhh, error pas mau ngunduh media bree. Report ke owner dan coba lagi.');
  }
};

handler.help = ["facebook"];
handler.tags = ["download"];
handler.command = /^(facebook|fb|fbdl|facebookdl)$/i;
handler.limit = true;
handler.register = true;

module.exports = handler;