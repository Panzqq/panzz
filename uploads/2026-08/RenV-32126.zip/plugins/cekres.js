const jimp = require("jimp");

let handler = async (m, { conn, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  if (!mime || !/^image\//.test(mime)) throw `• *Example:* .${command} [send/reply media]`;
  let media = await q.download(); 
  let image = await jimp.read(await media); 
  let width = image.getWidth();
  let height = image.getHeight();
  m.reply(`*_RESOLOTION_*
  ${width} x ${height}
  
*> width (Lebar) :* ${width}
*> height (Tinggi) :* ${height}`);
};

handler.help = ['cekresolution *<foto>*', 'cekreso *<foto>*'];
handler.tags = ['tools'];
handler.command = /^(cekreso(lution)?)$/i;

module.exports = handler;