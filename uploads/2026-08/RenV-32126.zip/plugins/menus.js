const fs = require("fs");
const os = require("os");
const Theme = require("../lib/theme");

async function getBuffer(input) {
  try {
    if (!input) return null;
    if (Buffer.isBuffer(input)) return input;

    if (typeof input === "string") {
      if (/^https?:\/\//i.test(input)) {
        const res = await fetch(input, {
          headers: {
            "User-Agent": "Mozilla/5.0"
          }
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return Buffer.from(await res.arrayBuffer());
      }

      if (fs.existsSync(input)) {
        return fs.readFileSync(input);
      }
    }

    return null;
  } catch (e) {
    console.log("Gagal ambil thumbnail:", e.message);
    return null;
  }
}

function isBlockedMenu(text = "") {
  return /(bug|crash|blank|kill|force|attack|virus|ddos|fc|delay)/i.test(String(text));
}

function beautifyTag(tag = "") {
  return String(tag)
    .replace(/[-_]/g, " ")
    .split(" ")
    .filter(Boolean)
    .map(v => v.charAt(0).toUpperCase() + v.slice(1))
    .join(" ");
}

function galaxyButton(text = "Open", id = "galaxy_button") {
  return {
    name: "galaxy_message",
    buttonParamsJson: JSON.stringify({
      mode: "published",
      flow_message_version: "3",
      flow_token: id,
      flow_id: id,
      flow_cta: text,
      flow_action: "navigate",
      flow_action_payload: {
        screen: "RENVY_SCREEN",
        data: {
          id,
          title: text
        }
      }
    })
  };
}

function normalizeListData(listData, buttons = []) {
  const theme = Theme.getTheme();
  const sym = theme.symbols;

  if (listData) {
    return {
      title: listData.title || `${sym.section} Select Access ${sym.sectionClose}`,
      sections: (listData.sections || []).map(section => ({
        title: section.title || `${sym.section} Menu Area ${sym.sectionClose}`,
        highlight_label: section.highlight_label || "",
        rows: (section.rows || [])
          .filter(row => !isBlockedMenu(`${row.header} ${row.title} ${row.description} ${row.id}`))
          .map(row => ({
            header: row.header || "",
            title: row.title || row.text || "Open Menu",
            description: row.description || "",
            id: row.id || ".menu"
          }))
      }))
    };
  }

  return {
    title: `${sym.section} Quick Access ${sym.sectionClose}`,
    sections: [
      {
        title: `${sym.bullet} Shortcut Area`,
        highlight_label: "Fast Access",
        rows: buttons
          .filter(btn => !isBlockedMenu(`${btn.text} ${btn.id}`))
          .map(btn => ({
            title: btn.text || "Open Menu",
            description: "Tekan untuk menjalankan menu ini.",
            id: btn.id || ".menu"
          }))
      }
    ]
  };
}

let handler = async (m, { conn, command, args }) => {
  const perintah = args[0] || (command === "allmenu" ? "all" : "tags");

  const botName = typeof namebot !== "undefined" ? namebot : "Renvy";
  const ownerName = typeof nameown !== "undefined" ? nameown : "PanPan";
  const botVersion = typeof version !== "undefined" ? version : "1.0.0";
  const thumbUrl = global.thumb;
  const theme = Theme.getTheme();
  const sym = theme.symbols;

  const users = global.db?.data?.users || {};
  const chats = conn.chats || {};
  const user = users[m.sender] || {};
  const pluginsList = Object.values(global.plugins || {}).filter(p => p.help && !p.disabled);

  const tagCount = {};
  const tagHelpMapping = {};

  for (const p of pluginsList) {
    const tags = Array.isArray(p.tags) ? p.tags : [];
    const helps = Array.isArray(p.help) ? p.help : [p.help];

    for (const tag of tags) {
      if (isBlockedMenu(tag)) continue;

      const cleanHelps = helps.filter(h => !isBlockedMenu(h));

      tagCount[tag] = (tagCount[tag] || 0) + 1;
      tagHelpMapping[tag] = [...(tagHelpMapping[tag] || []), ...cleanHelps];
    }
  }

  const listTags = Object.keys(tagCount);

  const fitur = pluginsList
    .map(p => p.help)
    .flat(1)
    .filter(h => !isBlockedMenu(h));

  const hasil = fitur.length;

  const totalMemory = os.totalmem();
  const freeMemory = os.freemem();
  const usedMemory = totalMemory - freeMemory;

  let uptime = process.uptime();
  const hari = Math.floor(uptime / 86400);
  uptime %= 86400;
  const jam = Math.floor(uptime / 3600);
  uptime %= 3600;
  const menit = Math.floor(uptime / 60);
  const detik = Math.floor(uptime % 60);
  const runtime = `${hari}D ${jam}H ${menit}M ${detik}S`;

  const ownerNumber = String(typeof nomorown !== "undefined" ? nomorown : "")
    .replace("@s.whatsapp.net", "")
    .replace("@c.us", "")
    .replace(/[^0-9]/g, "");

  const formatSize = n =>
    global.Func?.formatSize ? global.Func.formatSize(n) : `${n} B`;

  const dbSize = fs.existsSync("database/database.sqlite")
    ? formatSize(fs.statSync("database/database.sqlite").size)
    : "0 B";

  const categoryRows = listTags.map(tag => {
    const cap = beautifyTag(tag);

    return {
      header: `${sym.section} ${cap} Area ${sym.sectionClose}`,
      title: `${sym.item} Open ${cap}`,
      description: `Tema ${theme.name} • kumpulan fitur ${cap} siap digunakan.`,
      id: `.menu ${tag}`
    };
  });

  const dashboard = `
\`${sym.section} ${botName.toUpperCase()} ACCESS PANEL ${sym.sectionClose}\`

> ${sym.item} Halo, *${user.name || m.pushName || "User"}*
> ${sym.sub} Sistem *${botName}* sudah aktif dan siap digunakan.
> ${sym.bullet} Pilih kategori menu di bawah untuk mulai menggunakan fitur.

\`${sym.section} USER PROFILE ${sym.sectionClose}\`
> ${sym.item} Name     : ${user.name || m.pushName || "User"}
> ${sym.item} Tag      : @${m.sender.split("@")[0]}
> ${sym.item} Status   : ${user.premium ? "Premium Access" : "Regular Access"}
> ${sym.item} Role     : ${user.role || "User"}
> ${sym.item} Limit    : ${isNaN(user.limit) ? "Unlimited" : user.limit}
> ${sym.item} Level    : ${user.level || 0}
> ${sym.item} Exp      : ${user.exp || 0}
> ${sym.item} Saldo    : ${user.saldo || 0}
> ${sym.item} Bank     : ${user.bank || 0}
> ${sym.item} Cash     : ${user.money || 0}

\`${sym.section} BOT INFORMATION ${sym.sectionClose}\`
> ${sym.sub} Bot Name : ${botName}
> ${sym.sub} Creator  : ${ownerName}
> ${sym.sub} Version  : ${botVersion}
> ${sym.sub} Theme    : ${theme.name}
> ${sym.sub} Module   : CommonJS
> ${sym.sub} Mode     : ${global.opts?.self ? "Self Mode" : "Public Mode"}
> ${sym.sub} Owner    : @${ownerNumber}
> ${sym.sub} Features : ${hasil} Fitur
> ${sym.sub} Users    : ${Object.keys(users).length}
> ${sym.sub} Chats    : ${Object.keys(chats).length}

\`${sym.section} SYSTEM STATUS ${sym.sectionClose}\`
> ${sym.bullet} Runtime  : ${runtime}
> ${sym.bullet} DB Size  : ${dbSize}
> ${sym.bullet} RAM Free : ${formatSize(freeMemory)}
> ${sym.bullet} RAM Used : ${formatSize(usedMemory)}

\`${sym.section} MENU GUIDE ${sym.sectionClose}\`
> ${sym.item} *.menu all* untuk melihat semua fitur.
> ${sym.item} *.menu kategori* untuk membuka menu tertentu.
> ${sym.sub} Gunakan command seperlunya agar bot tetap stabil.
`.trim();

  const datas = {
    title: `[ ${botName} • Access Panel ]`,
    sections: [
      {
        title: `${sym.section} Main Access ${sym.sectionClose}`,
        highlight_label: `By ${ownerName}`,
        rows: [
          {
            header: `[ Global Menu ]`,
            title: `${sym.item} Open All Features`,
            description: `Tampilkan semua fitur aktif di ${botName}.`,
            id: ".menu all"
          }
        ]
      },
      {
        title: `${sym.section} Module Area ${sym.sectionClose}`,
        highlight_label: "Select Category",
        rows: categoryRows
      },
      {
        title: `${sym.section} Creator Area ${sym.sectionClose}`,
        highlight_label: `Owner Access`,
        rows: [
          {
            header: "[ Developer Info ]",
            title: `${sym.item} Creator Profile`,
            description: "Lihat kontak dan informasi pemilik bot.",
            id: ".owner"
          }
        ]
      },
      {
        title: `${sym.section} System Monitor ${sym.sectionClose}`,
        highlight_label: "Bot Status",
        rows: [
          {
            header: "[ Response Check ]",
            title: `${sym.item} Check Bot Speed`,
            description: "Lihat respon dan kondisi bot saat ini.",
            id: ".ping"
          }
        ]
      },
      {
        title: `${sym.section} Premium Area ${sym.sectionClose}`,
        highlight_label: "Special Access",
        rows: [
          {
            header: `[ Rent ${botName} ]`,
            title: `${sym.item} Rental Information`,
            description: "Lihat detail sewa dan akses premium bot.",
            id: ".sewa"
          }
        ]
      }
    ]
  };

  const sendMenuAudio = async () => {
    try {
      const menuAudio = typeof audioz !== "undefined" ? audioz : global.audioz;

      if (menuAudio && typeof conn.sendAudioMessage === "function") {
        await conn.sendAudioMessage(
          m.chat,
          menuAudio,
          typeof ftroli !== "undefined" ? ftroli : m
        );
      }
    } catch (e) {
      console.log("Gagal mengirim audio menu:", e.message);
    }
  };

  const sendSettoButton = async (caption, buttons = [], listData = null) => {
    const fixedListData = normalizeListData(listData, buttons);

    const sent = await conn.sendMessage(
      m.chat,
      {
        interactiveMessage: {
          header: `© ${botName} Access System`,
          title: caption,
          footer: `[ ${botName} • Powered by @${ownerNumber} ]`,

          image: thumbUrl
            ? {
                url: thumbUrl
              }
            : undefined,

          contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [
              `${ownerNumber}@s.whatsapp.net`,
              m.sender
            ],
            forwardedNewsletterMessageInfo: {
              newsletterName: typeof wm2 !== "undefined" ? wm2 : `${botName} Channel`,
              newsletterJid: typeof idsaluran !== "undefined" ? idsaluran : "",
              serverMessageId: null
            }
          },

          nativeFlowMessage: {
            messageParamsJson: JSON.stringify({
              limited_time_offer: {
                text: `${botName} Menu Access`,
                url: `https://wa.me/${ownerNumber}`,
                copy_code: botName,
                expiration_time: Date.now() * 999
              },
              bottom_sheet: {
                in_thread_buttons_limit: 2,
                divider_indices: [1, 2, 3, 4, 5, 999],
                list_title: `[ ${sym.section} ${botName} Access Panel ${sym.sectionClose} ]`,
                button_title: `${sym.bullet}${sym.section} Launch Panel ${sym.sectionClose}`
              },
              tap_target_configuration: {
                title: botName,
                description: `${botName} menu system is ready`,
                canonical_url: `https://wa.me/${ownerNumber}`,
                domain: "renvy.my.id",
                button_index: 0
              }
            }),

            buttons: [
              galaxyButton(`[ ${sym.section} ${botName} Access Panel ${sym.sectionClose} ]`, "access_panel"),

              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  has_multiple_buttons: true
                })
              },

              {
                name: "call_permission_request",
                buttonParamsJson: JSON.stringify({
                  has_multiple_buttons: true
                })
              },

              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  title: `[ ${sym.section} ${botName} Module Area ${sym.sectionClose} ]`,
                  sections: fixedListData.sections,
                  has_multiple_buttons: true
                })
              },

              galaxyButton(`#${botName} System`, "bot_system"),

              galaxyButton("Creator Profile", "creator_profile"),

              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "Chat Creator",
                  url: `https://wa.me/${ownerNumber}`,
                  merchant_url: `https://wa.me/${ownerNumber}`
                })
              }
            ]
          }
        }
      },
      {
        quoted: typeof ftroli !== "undefined" ? ftroli : m
      }
    );

    await sendMenuAudio();

    return sent;
  };

  if (perintah === "tags") {
    return sendSettoButton(
      dashboard,
      [
        {
          id: ".owner",
          text: "👑 Creator"
        },
        {
          id: ".ping",
          text: "⚡ Status"
        },
        {
          id: ".menu all",
          text: "🌐 All Menu"
        },
        {
          id: ".sewa",
          text: "💎 Service"
        }
      ],
      datas
    );
  }

  if (tagHelpMapping[perintah]) {
    const menuName = beautifyTag(perintah);

    const helpItems = tagHelpMapping[perintah]
      .filter(h => !isBlockedMenu(h))
      .map(h => `> ${sym.item} .*${h}*`)
      .join("\n");

    const categoryResponse = `
\`${sym.section} ${menuName.toUpperCase()} MENU ${sym.sectionClose}\`

${helpItems}

\`${sym.section} NAVIGATION ${sym.sectionClose}\`
> ${sym.sub} *.menu* untuk kembali ke menu utama.
> ${sym.sub} *.menu all* untuk melihat semua fitur.
`.trim();

    return sendSettoButton(categoryResponse, [
      {
        id: ".menu",
        text: "🔙 Back"
      },
      {
        id: ".owner",
        text: "👑 Creator"
      },
      {
        id: ".ping",
        text: "⚡ Status"
      }
    ]);
  }

  if (perintah === "all") {
    const allTagsAndHelp = listTags
      .map(tag => {
        const menuName = beautifyTag(tag);

        const list = tagHelpMapping[tag]
          .filter(helpItem => !isBlockedMenu(helpItem))
          .map(helpItem => `> ${sym.item} .*${helpItem}*`)
          .join("\n");

        return `
\`${sym.section} ${menuName.toUpperCase()} MENU ${sym.sectionClose}\`

${list}
${sym.line}
`.trim();
      })
      .join("\n\n");

    return sendSettoButton(
      `${dashboard}

\`${sym.section} ALL FEATURES ${sym.sectionClose}\`

${allTagsAndHelp}`,
      [
        {
          id: ".menu",
          text: "🔙 Back"
        },
        {
          id: ".owner",
          text: "👑 Creator"
        },
        {
          id: ".ping",
          text: "⚡ Status"
        }
      ]
    );
  }

  return conn.reply(
    m.chat,
    `Menu *${perintah.toUpperCase()}* tidak ditemukan.\n\nKetik *.menu* untuk membuka daftar menu yang tersedia.`,
    m
  );
};

handler.help = ["menu", "allmenu"];
handler.tags = ["main"];
handler.command = ["menu", "allmenu"];
handler.register = true;

module.exports = handler;