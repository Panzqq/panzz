const axios = require('axios');

let handler = async (m, { conn }) => {
  try {
    const res = await axios.get('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json');
    const data = res.data.Infogempa.gempa;

    const hasil = `> [+] INFO GEMPA TERKINI (BMKG)\n> \n> [+] Tanggal   : ${data.Tanggal}\n> [+] Jam       : ${data.Jam}\n> [+] Koordinat : ${data.Coordinates}\n> [+] Magnitude : ${data.Magnitude} SR\n> [+] Kedalaman : ${data.Kedalaman}\n> [+] Wilayah   : ${data.Wilayah}\n> [+] Potensi   : ${data.Potensi}\n> \n> [+] Dirasakan : ${data.Dirasakan}\n> \n> [+] Status: Success`;

    const imageMap = `https://data.bmkg.go.id/DataMKG/TEWS/${data.Shakemap}`;

    await conn.sendMessage(m.chat, { 
        image: { url: imageMap }, 
        caption: hasil 
    }, { quoted: m });

  } catch (err) {
    m.reply(`> [-] Gagal mengambil data gempa dari server BMKG.\n> [+] Status: Error`);
  }
};

handler.help = ['gempa'];
handler.tags = ['info'];
handler.command = /^(gempa|infogempa)$/i;

module.exports = handler;