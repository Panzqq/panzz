const axios = require('axios')
const FormData = require('form-data')

async function removeBg(buffer) {
    const apiKey = global.keyremovebg || process.env.REMOVE_BG_API_KEY

    if (!apiKey) {
        throw new Error('global.keyremovebg belum diisi')
    }

    const form = new FormData()
    form.append('image_file', buffer, {
        filename: 'image.jpg',
        contentType: 'image/jpeg'
    })
    form.append('size', 'auto')

    const res = await axios.post(
        'https://api.remove.bg/v1.0/removebg',
        form,
        {
            headers: {
                ...form.getHeaders(),
                'X-Api-Key': apiKey
            },
            responseType: 'arraybuffer',
            timeout: 120000,
            validateStatus: () => true
        }
    )

    const result = Buffer.from(res.data)
    const text = result.toString('utf8')

    if (res.status !== 200) {
        try {
            const json = JSON.parse(text)
            const msg =
                json?.errors?.[0]?.title ||
                json?.errors?.[0]?.detail ||
                json?.message ||
                'Gagal menghapus background'
            throw new Error(msg)
        } catch (e) {
            if (e.message !== 'Unexpected token') throw e
            throw new Error(`Gagal removebg. Status: ${res.status}`)
        }
    }

    return result
}

let handler = async (m, { conn, usedPrefix, command }) => {
    try {
        let q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || q.mimetype || ''

        if (!/image\/(jpe?g|png|webp)/i.test(mime)) {
            return m.reply(
                `Kirim atau reply gambar dengan command:\n\n` +
                `*${usedPrefix + command}*`
            )
        }

        await m.reply('⏳ Sedang menghapus background...')

        let img = await q.download()
        if (!img) throw new Error('Gagal download gambar')

        let result = await removeBg(img)

        await conn.sendMessage(
            m.chat,
            {
                image: result,
                mimetype: 'image/png',
                caption: '✅ Background berhasil dihapus.'
            },
            { quoted: m }
        )
    } catch (e) {
        console.error(e)
        m.reply(`Terjadi error:\n${e.message}`)
    }
}

handler.help = handler.command = ['removebg', 'rmbg', 'nobg']
handler.tags = ['tools']

module.exports = handler