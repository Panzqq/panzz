const { Canvas, loadImage, FontLibrary } = require("skia-canvas")
const fs = require("fs")
const path = require("path")

const DEBUG = false

const HEADER = {
  text: "Ditzzx",
  x: 543,
  y: 200,
  fontSize: 130,
  color: "#E8F0F0",
  fakeBoldOffset: 4,
  letterSpacing: "0px",
  debug: { x: 40, y: 130, w: 1006, h: 140 }
}

const PESAN = {
  text: "",
  x: 30,
  y: 300,
  fontSize: 63,
  lineHeight: 110,
  color: "#000000",
  strokeWidth: 0,
  scaleY: 1.3,
  letterSpacing: "5px",
  padding: { top: 20, bottom: 20, left: 30, right: 30 },
  debug: { x: 0, y: 280, w: 1086, h: 700 }
}

const INFO = {
  sender: "Ditzzx",
  date: "02/05/2026",
  time: "11:28",
  x: 30,
  y: 980,
  useAutoY: false,
  gap: 120,
  fontSize: 48,
  lineHeight: 80,
  color: "#000000",
  strokeWidth: 0,
  scaleY: 1.3,
  letterSpacing: "5px",
  debug: { x: 0, y: 980, w: 1086, h: 320 }
}

const WIDTH = 1086
const HEIGHT = 1448

const BG_URL = "https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Image/file_00000000a9f47208a295c9c984f92b7a.jpeg"
const FONT_URL = "https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Font/nokia-6000-series-medium.ttf"

const ASSET_DIR = path.join(process.cwd(), "database", "assets", "nokiaquote")
const BG_PATH = path.join(ASSET_DIR, "bg.jpg")
const FONT_PATH = path.join(ASSET_DIR, "nokia.ttf")

async function download(url, dest) {
  if (fs.existsSync(dest)) return

  const res = await fetch(url)
  if (!res.ok) throw new Error(`Gagal download asset: ${res.status}`)

  const buf = Buffer.from(await res.arrayBuffer())
  fs.writeFileSync(dest, buf)
}

let assetsReady = false

async function prepareAssets() {
  if (assetsReady) return

  fs.mkdirSync(ASSET_DIR, { recursive: true })

  await download(BG_URL, BG_PATH)
  await download(FONT_URL, FONT_PATH)

  FontLibrary.use("FontHeader", FONT_PATH)
  FontLibrary.use("FontPesan", FONT_PATH)
  FontLibrary.use("FontInfo", FONT_PATH)

  assetsReady = true
}

function drawDebugBox(ctx, x, y, w, h, label, color) {
  ctx.save()
  ctx.strokeStyle = color
  ctx.lineWidth = 3
  ctx.setLineDash([8, 4])
  ctx.strokeRect(x, y, w, h)
  ctx.fillStyle = color
  ctx.font = "24px sans-serif"
  ctx.textAlign = "left"
  ctx.textBaseline = "top"
  ctx.fillText(label, x + 4, y + 4)
  ctx.restore()
}

function drawHeaderText(ctx, cfg) {
  ctx.fillStyle = cfg.color
  ctx.font = `${cfg.fontSize}px FontHeader`
  ctx.letterSpacing = cfg.letterSpacing || "0px"
  ctx.textAlign = "center"
  ctx.textBaseline = "middle"

  for (let i = 0; i <= cfg.fakeBoldOffset; i++) {
    ctx.fillText(cfg.text, cfg.x + i, cfg.y)
  }
}

function drawBodyText(ctx, text, x, y, fontName, fontSize, color, strokeWidth, scaleY, letterSpacing) {
  ctx.save()

  if (scaleY !== 1.0) {
    ctx.translate(x, y)
    ctx.scale(1, scaleY)
    ctx.translate(-x, -y)
  }

  ctx.font = `${fontSize}px ${fontName}`
  ctx.letterSpacing = letterSpacing
  ctx.textAlign = "left"
  ctx.textBaseline = "top"

  if (strokeWidth > 0) {
    ctx.strokeStyle = color
    ctx.lineWidth = strokeWidth
    ctx.lineJoin = "round"
    ctx.strokeText(text, x, y)
  }

  ctx.fillStyle = color
  ctx.fillText(text, x, y)

  ctx.restore()
}

function wrapLine(ctx, text, maxW, fontSize, fontName, letterSpacing) {
  ctx.font = `${fontSize}px ${fontName}`
  ctx.letterSpacing = letterSpacing

  const words = text.split(" ")
  const wrapped = []
  let current = ""

  for (const word of words) {
    const test = current ? current + " " + word : word

    if (ctx.measureText(test).width > maxW && current) {
      wrapped.push(current)
      current = word
    } else {
      current = test
    }
  }

  if (current) wrapped.push(current)

  return wrapped
}

function getFitFontSize(ctx, lines, cfg, maxH) {
  const pad = cfg.padding
  const maxW = cfg.debug.w - pad.left - pad.right

  let fontSize = cfg.fontSize

  while (fontSize > 10) {
    const lineH = fontSize * (cfg.lineHeight / cfg.fontSize)

    const allWrapped = lines.flatMap(line =>
      wrapLine(ctx, line, maxW, fontSize, "FontPesan", cfg.letterSpacing)
    )

    const totalH = allWrapped.length * lineH

    if (totalH <= maxH) break

    fontSize -= 1
  }

  return fontSize
}

function getDateNow() {
  const date = new Date()

  const tanggal = date.toLocaleDateString("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric"
  })

  const jam = date.toLocaleTimeString("id-ID", {
    timeZone: "Asia/Jakarta",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  })

  return { tanggal, jam }
}

async function generateNokiaQuote(text, senderName = "User") {
  await prepareAssets()

  const { tanggal, jam } = getDateNow()

  const header = {
    ...HEADER,
    text: senderName
  }

  const pesan = {
    ...PESAN,
    text
  }

  const info = {
    ...INFO,
    sender: senderName,
    date: tanggal,
    time: jam
  }

  const canvas = new Canvas(WIDTH, HEIGHT)
  const ctx = canvas.getContext("2d")

  const bg = await loadImage(BG_PATH)
  ctx.drawImage(bg, 0, 0, WIDTH, HEIGHT)

  drawHeaderText(ctx, header)

  if (DEBUG) {
    drawDebugBox(ctx, header.debug.x, header.debug.y, header.debug.w, header.debug.h, "HEADER", "rgba(0,150,255,0.8)")
  }

  const rawLines = pesan.text.split("\n")
  const maxW = pesan.debug.w - pesan.padding.left - pesan.padding.right
  const textX = pesan.debug.x + pesan.padding.left
  const textY = pesan.debug.y + pesan.padding.top
  const maxH = info.y - textY - pesan.padding.bottom

  const fitFontSize = getFitFontSize(ctx, rawLines, pesan, maxH)
  const fitLineHeight = fitFontSize * (pesan.lineHeight / pesan.fontSize)

  const wrappedLines = rawLines.flatMap(line =>
    wrapLine(ctx, line, maxW, fitFontSize, "FontPesan", pesan.letterSpacing)
  )

  wrappedLines.forEach((line, i) => {
    drawBodyText(
      ctx,
      line,
      textX,
      textY + i * fitLineHeight,
      "FontPesan",
      fitFontSize,
      pesan.color,
      pesan.strokeWidth,
      pesan.scaleY,
      pesan.letterSpacing
    )
  })

  if (DEBUG) {
    drawDebugBox(ctx, pesan.debug.x, pesan.debug.y, pesan.debug.w, pesan.debug.h, "PESAN", "rgba(255,0,0,0.8)")
  }

  const infoY = info.useAutoY
    ? pesan.y + wrappedLines.length * fitLineHeight + info.gap
    : info.y

  const infoLines = ["Dari:", info.sender, info.date, info.time]

  infoLines.forEach((line, i) => {
    drawBodyText(
      ctx,
      line,
      info.x,
      infoY + i * info.lineHeight,
      "FontInfo",
      info.fontSize,
      info.color,
      info.strokeWidth,
      info.scaleY,
      info.letterSpacing
    )
  })

  return await canvas.toBuffer("png")
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`Masukkan teksnya.\n\nContoh:\n${usedPrefix + command} halo teman teman`)
  }

  try {
    await m.reply("⏳ Sedang membuat nokia quote...")

    const senderName =
      m.pushName ||
      m.name ||
      "User"

    const buffer = await generateNokiaQuote(text, senderName)

    await conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: "✅ Nokia quote berhasil dibuat"
      },
      { quoted: m }
    )
  } catch (e) {
    console.error(e)
    m.reply(`Gagal membuat nokia quote.\n\nError: ${e.message}`)
  }
}

handler.help = ["nokiaquote <teks>"]
handler.tags = ["maker"]
handler.command = /^(nokiaquote|nq)$/i

module.exports = handler