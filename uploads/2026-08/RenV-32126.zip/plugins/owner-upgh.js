const fs = require("fs");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const axios = require("axios");
const { execFile } = require("child_process");

const GITHUB_TOKEN = "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";
const GITHUB_OWNER = "Panzqq";
const DEFAULT_BRANCH = "main";
const MAX_FILE_SIZE = 95 * 1024 * 1024;
const USER_AGENT =
  "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function safeName(input) {
  return String(input || "")
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
    .replace(/\s+/g, "_")
    .replace(/\.+$/, "")
    .slice(0, 180) || "file";
}

function safeRepoName(input) {
  return String(input || "")
    .trim()
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "-")
    .replace(/\s+/g, "-")
    .replace(/[^a-zA-Z0-9._-]/g, "-")
    .replace(/-+/g, "-")
    .replace(/^[-.]+|[-.]+$/g, "")
    .slice(0, 90) || "project";
}

function randomSuffix(len = 6) {
  return crypto.randomBytes(Math.ceil(len / 2)).toString("hex").slice(0, len);
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function isHttpUrl(u) {
  try {
    const x = new URL(u);
    return x.protocol === "http:" || x.protocol === "https:";
  } catch {
    return false;
  }
}

function getExtFromContentType(contentType) {
  const type = String(contentType || "").split(";")[0].trim().toLowerCase();
  const map = {
    "text/html": ".html",
    "text/plain": ".txt",
    "text/css": ".css",
    "text/javascript": ".js",
    "application/javascript": ".js",
    "application/x-javascript": ".js",
    "application/json": ".json",
    "application/xml": ".xml",
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "image/svg+xml": ".svg",
    "image/x-icon": ".ico",
    "font/woff": ".woff",
    "font/woff2": ".woff2",
    "font/ttf": ".ttf",
    "font/otf": ".otf",
    "video/mp4": ".mp4",
    "video/webm": ".webm",
    "audio/mpeg": ".mp3",
    "audio/mp4": ".m4a",
    "audio/wav": ".wav",
    "application/pdf": ".pdf",
    "application/zip": ".zip",
    "application/x-zip-compressed": ".zip",
  };
  return map[type] || "";
}

function getFileNameFromUrlOrHeaders(url, headers = {}, fallbackType = "") {
  const disp = headers["content-disposition"] || headers["Content-Disposition"] || "";
  const match = /filename\*=UTF-8''([^;]+)|filename="?([^"]+)"?/i.exec(disp);
  let filename = match ? decodeURIComponent(match[1] || match[2] || "") : "";

  if (!filename) {
    try {
      const u = new URL(url);
      filename = path.basename(u.pathname || "");
    } catch {
      filename = "";
    }
  }

  if (!filename || filename === "/" || filename === "." || filename === "..") {
    filename = "download";
  }

  if (!path.extname(filename)) {
    filename += getExtFromContentType(headers["content-type"] || fallbackType) || "";
  }

  return safeName(filename);
}

function isZipName(name, mime) {
  const n = String(name || "").toLowerCase();
  const m = String(mime || "").toLowerCase();
  return n.endsWith(".zip") || m.includes("zip") || m.includes("x-zip");
}

function pathToPosix(p) {
  return String(p).split(path.sep).join("/");
}

function shouldIgnorePath(relPath) {
  const base = path.basename(relPath);
  const lower = String(base || "").toLowerCase();
  const parts = String(relPath || "").split(path.sep).map((x) => x.toLowerCase());
  const ignored = new Set([".ds_store", "thumbs.db", "desktop.ini", ".git", "node_modules", "__macosx"]);
  if (ignored.has(lower)) return true;
  if (base.startsWith("._")) return true;
  if (parts.includes(".git") || parts.includes("node_modules") || parts.includes("__macosx")) return true;
  return false;
}

function rootCandidatesFromDir(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true })
    .filter((ent) => ![".DS_Store", "Thumbs.db", "desktop.ini"].includes(ent.name))
    .filter((ent) => !ent.name.startsWith("._"))
    .filter((ent) => ent.name !== ".git" && ent.name !== "node_modules" && ent.name !== "__MACOSX");

  const dirs = entries.filter((e) => e.isDirectory());
  const files = entries.filter((e) => e.isFile());

  if (dirs.length === 1 && files.length === 0) return path.join(dir, dirs[0].name);
  return dir;
}

function walkFiles(root) {
  const files = [];
  const emptyDirs = [];

  function recur(current) {
    const entries = fs.readdirSync(current, { withFileTypes: true })
      .filter((ent) => ![".DS_Store", "Thumbs.db", "desktop.ini"].includes(ent.name))
      .filter((ent) => !ent.name.startsWith("._"))
      .filter((ent) => ent.name !== ".git" && ent.name !== "node_modules" && ent.name !== "__MACOSX");

    if (entries.length === 0) {
      if (current !== root) emptyDirs.push(current);
      return;
    }

    for (const ent of entries) {
      const full = path.join(current, ent.name);
      if (ent.isDirectory()) recur(full);
      else if (ent.isFile()) files.push(full);
    }
  }

  recur(root);
  return { files, emptyDirs };
}

function detectArchiveKind(name, mime) {
  const n = String(name || "").toLowerCase();
  const m = String(mime || "").toLowerCase();

  if (n.endsWith(".tar.gz") || n.endsWith(".tgz") || m.includes("gzip")) return "targz";
  if (n.endsWith(".tar.bz2") || n.endsWith(".tbz2") || m.includes("bzip")) return "tarbz2";
  if (n.endsWith(".tar.xz") || n.endsWith(".txz") || m.includes("xz")) return "tarxz";
  if (n.endsWith(".tar")) return "tar";
  if (n.endsWith(".zip") || m.includes("zip")) return "zip";
  if (n.endsWith(".rar") || m.includes("rar")) return "rar";
  if (n.endsWith(".7z") || m.includes("7z")) return "7z";
  if (n.endsWith(".gz") || m.includes("gzip")) return "gz";
  return "none";
}

function which(cmd) {
  return new Promise((resolve) => {
    execFile("sh", ["-lc", `command -v ${cmd} >/dev/null 2>&1 && echo yes || echo no`], (err, stdout) => {
      resolve(String(stdout || "").trim() === "yes");
    });
  });
}

async function extractArchive(archivePath, outDir, archiveKind) {
  ensureDir(outDir);

  const has7z = await which("7z");
  const hasUnzip = await which("unzip");
  const hasTar = await which("tar");
  const hasGunzip = await which("gunzip");

  const run = (cmd, args) =>
    new Promise((resolve, reject) => {
      execFile(cmd, args, (err, stdout, stderr) => {
        if (err) reject(new Error(String(stderr || stdout || err.message || err)));
        else resolve();
      });
    });

  if (has7z && ["zip", "rar", "7z", "tar", "targz", "tarbz2", "tarxz", "gz"].includes(archiveKind)) {
    try {
      await run("7z", ["x", "-y", `-o${outDir}`, archivePath]);
      return;
    } catch {
      // fallback below
    }
  }

  if (archiveKind === "zip") {
    if (hasUnzip) return run("unzip", ["-o", archivePath, "-d", outDir]);
    throw new Error('Untuk ekstrak ZIP, server butuh "7z" atau "unzip".');
  }

  if (archiveKind === "rar" || archiveKind === "7z") {
    if (!has7z) throw new Error('Untuk ekstrak RAR/7Z, server butuh "7z".');
    return run("7z", ["x", "-y", `-o${outDir}`, archivePath]);
  }

  if (archiveKind === "tar") {
    if (!hasTar) throw new Error('Untuk ekstrak TAR, server butuh "tar".');
    return run("tar", ["-xf", archivePath, "-C", outDir]);
  }

  if (archiveKind === "targz") {
    if (!hasTar) throw new Error('Untuk ekstrak TAR.GZ, server butuh "tar".');
    return run("tar", ["-xzf", archivePath, "-C", outDir]);
  }

  if (archiveKind === "tarbz2") {
    if (!hasTar) throw new Error('Untuk ekstrak TAR.BZ2, server butuh "tar".');
    return run("tar", ["-xjf", archivePath, "-C", outDir]);
  }

  if (archiveKind === "tarxz") {
    if (!hasTar) throw new Error('Untuk ekstrak TAR.XZ, server butuh "tar".');
    return run("tar", ["-xJf", archivePath, "-C", outDir]);
  }

  if (archiveKind === "gz") {
    if (!hasGunzip) throw new Error('Untuk ekstrak GZ, server butuh "gunzip".');
    return new Promise((resolve, reject) => {
      execFile("gunzip", ["-c", archivePath], { maxBuffer: 1024 * 1024 * 50 }, (err, stdout, stderr) => {
        if (err) return reject(new Error(String(stderr || stdout || err.message || err)));
        const outFile = path.join(outDir, path.basename(archivePath).replace(/\.gz$/i, "") || "output");
        fs.writeFileSync(outFile, stdout);
        resolve();
      });
    });
  }

  throw new Error(`Format arsip tidak dikenali: ${archiveKind}`);
}

async function downloadBuffer(url) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 60000,
    maxRedirects: 5,
    validateStatus: () => true,
    headers: {
      "user-agent": USER_AGENT,
      accept: "*/*",
    },
  });

  if (res.status < 200 || res.status >= 300) {
    throw new Error(`Gagal download URL: HTTP ${res.status}`);
  }

  return {
    buffer: Buffer.from(res.data),
    name: getFileNameFromUrlOrHeaders(url, res.headers),
    mime: res.headers["content-type"] || "",
  };
}

async function downloadFromQuotedOrCurrent(conn, m) {
  const target = m.quoted || m;

  if (typeof target.download === "function") {
    const buf = await target.download();
    if (buf) {
      return {
        buffer: Buffer.from(buf),
        name: target.fileName || target.filename || "file",
        mime: target.mimetype || target.mime || "",
      };
    }
  }

  if (conn && typeof conn.downloadMediaMessage === "function") {
    const msg = target.msg || target;
    const buf = await conn.downloadMediaMessage(msg);
    if (buf) {
      return {
        buffer: Buffer.from(buf),
        name: target.fileName || target.filename || "file",
        mime: target.mimetype || target.mime || "",
      };
    }
  }

  return null;
}

function parseUpghArgs(text) {
  const raw = String(text || "").trim();
  const tokens = raw ? raw.split(/\s+/).filter(Boolean) : [];

  let sourceUrl = null;
  let visibility = null;
  const nameParts = [];

  for (const token of tokens) {
    const low = token.toLowerCase();
    if (low === "private" || low === "public") {
      visibility = low;
      continue;
    }
    if (!sourceUrl && isHttpUrl(token)) {
      sourceUrl = token;
      continue;
    }
    nameParts.push(token);
  }

  return {
    repoPrefix: safeRepoName(nameParts.join(" ")),
    visibility,
    sourceUrl,
  };
}

async function githubRequest(method, url, data, retries = 3) {
  let lastErr = null;

  for (let i = 0; i <= retries; i++) {
    try {
      const res = await axios.request({
        method,
        url,
        data,
        timeout: 60000,
        validateStatus: () => true,
        headers: {
          Authorization: `Bearer ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github+json",
          "X-GitHub-Api-Version": "2022-11-28",
          "User-Agent": "wa-bot-upgh",
        },
      });

      if (res.status >= 500 || res.status === 429) {
        lastErr = new Error(`HTTP ${res.status}`);
        await sleep(700 * (i + 1));
        continue;
      }

      return res;
    } catch (e) {
      lastErr = e;
      await sleep(700 * (i + 1));
    }
  }

  throw lastErr || new Error("GitHub request gagal");
}

async function createRepoUnique(baseName, isPrivate) {
  const cleanBase = safeRepoName(baseName);

  for (let attempt = 0; attempt < 12; attempt++) {
    const repoName = `${cleanBase}-${randomSuffix(6)}`;
    const res = await githubRequest("POST", "https://api.github.com/user/repos", {
      name: repoName,
      private: Boolean(isPrivate),
      auto_init: true,
      description: "Uploaded from WhatsApp bot",
    });

    if (res.status === 201) return res.data;

    const message = String(res.data?.message || "");
    const errs = Array.isArray(res.data?.errors) ? res.data.errors : [];
    const exists =
      res.status === 422 &&
      (
        message.toLowerCase().includes("already exists") ||
        errs.some((e) => String(e.message || e.code || "").toLowerCase().includes("already exists"))
      );

    if (!exists) {
      throw new Error(`Gagal membuat repo: ${message || JSON.stringify(res.data || {})}`);
    }
  }

  throw new Error("Gagal membuat repository unik setelah beberapa percobaan.");
}

async function getBranchHead(owner, repo, branch) {
  const res = await githubRequest(
    "GET",
    `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/ref/heads/${encodeURIComponent(branch)}`
  );

  if (res.status === 200 && res.data?.object?.sha) {
    return res.data.object.sha;
  }

  return null;
}

async function createBlob(owner, repo, fileBuffer) {
  const res = await githubRequest(
    "POST",
    `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/blobs`,
    {
      content: fileBuffer.toString("base64"),
      encoding: "base64",
    }
  );

  if (res.status !== 201) {
    throw new Error(`Gagal membuat blob: ${String(res.data?.message || JSON.stringify(res.data || {}))}`);
  }

  return res.data.sha;
}

async function createTree(owner, repo, treeEntries) {
  const res = await githubRequest(
    "POST",
    `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/trees`,
    {
      tree: treeEntries,
    }
  );

  if (res.status !== 201) {
    throw new Error(`Gagal membuat tree: ${String(res.data?.message || JSON.stringify(res.data || {}))}`);
  }

  return res.data.sha;
}

async function createCommit(owner, repo, message, treeSha, parentSha = null) {
  const payload = {
    message,
    tree: treeSha,
  };
  if (parentSha) payload.parents = [parentSha];

  const res = await githubRequest(
    "POST",
    `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/commits`,
    payload
  );

  if (res.status !== 201) {
    throw new Error(`Gagal membuat commit: ${String(res.data?.message || JSON.stringify(res.data || {}))}`);
  }

  return res.data.sha;
}

async function createOrUpdateRef(owner, repo, branch, commitSha) {
  const refName = `refs/heads/${branch}`;
  const createRes = await githubRequest(
    "POST",
    `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/refs`,
    {
      ref: refName,
      sha: commitSha,
    }
  );

  if (createRes.status === 201) return true;

  const msg = String(createRes.data?.message || "");
  if (createRes.status === 422 && msg.toLowerCase().includes("already exists")) {
    const upd = await githubRequest(
      "PATCH",
      `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/git/refs/heads/${encodeURIComponent(branch)}`,
      {
        sha: commitSha,
        force: true,
      }
    );

    if (upd.status === 200) return true;
    throw new Error(`Gagal update ref: ${String(upd.data?.message || JSON.stringify(upd.data || {}))}`);
  }

  throw new Error(`Gagal create ref: ${msg || JSON.stringify(createRes.data || {})}`);
}

async function setRepoDescription(owner, repo, description) {
  const res = await githubRequest(
    "PATCH",
    `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`,
    { description }
  );
  return res.status === 200;
}

async function setRepoTopics(owner, repo, topics) {
  if (!topics || !topics.length) return false;
  const res = await githubRequest(
    "PUT",
    `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/topics`,
    { names: topics }
  );
  return res.status === 200;
}

function buildReadme(repoName, visibility, totalFiles, sourceLabel) {
  return `# ${repoName}\n\n` +
    `Uploaded from WhatsApp bot.\n\n` +
    `## Info\n\n` +
    `- Visibility: ${visibility}\n` +
    `- Total files: ${totalFiles}\n` +
    `- Source: ${sourceLabel || "single file / archive"}\n`;
}

function buildGitignore() {
  return `node_modules/\n.env\n.env.*\n*.log\n.DS_Store\nThumbs.db\ndesktop.ini\n`;
}

function buildMitLicense(owner) {
  const year = new Date().getFullYear();
  return `MIT License

Copyright (c) ${year} ${owner}

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
`;
}

function inferTopicsFromFiles(allFiles, repoName) {
  const topics = new Set();
  const names = allFiles.map((f) => path.basename(f).toLowerCase());
  const joined = names.join(" ");

  if (names.includes("package.json")) topics.add("javascript");
  if (names.includes("tsconfig.json")) topics.add("typescript");
  if (names.includes("vite.config.js") || names.includes("vite.config.ts")) topics.add("vite");
  if (names.includes("next.config.js") || names.includes("next.config.mjs") || joined.includes("next")) topics.add("nextjs");
  if (joined.includes("react")) topics.add("react");
  if (joined.includes("vue")) topics.add("vue");
  if (joined.includes("nuxt")) topics.add("nuxt");
  if (joined.includes("astro")) topics.add("astro");
  if (joined.includes("angular")) topics.add("angular");
  if (names.includes("index.html")) topics.add("html");
  if (joined.includes(".css")) topics.add("css");
  if (joined.includes(".js")) topics.add("javascript");

  if (topics.size === 0) {
    topics.add("repository");
    topics.add("upload");
  }

  topics.add(safeRepoName(repoName || "project").toLowerCase());
  return Array.from(topics).slice(0, 20);
}

async function sendText(conn, m, text) {
  if (conn && typeof conn.sendMessage === "function") {
    try {
      await conn.sendMessage(m.chat, { text }, { quoted: m });
      return;
    } catch {}
  }
  await m.reply(text);
}

async function uploadFilesAsGitRepo({
  owner,
  repoName,
  branch,
  visibility,
  sourceLabel,
  files,
  emptyDirs,
  parentSha
}) {
  const treeEntries = [];

  for (const file of files) {
    const rel = file.rel;
    if (!rel || shouldIgnorePath(rel)) continue;

    const stat = fs.statSync(file.abs);
    if (!stat.isFile()) continue;
    if (stat.size > MAX_FILE_SIZE) {
      throw new Error(`File terlalu besar: ${rel}`);
    }

    const buf = fs.readFileSync(file.abs);
    const sha = await createBlob(owner, repoName, buf);

    treeEntries.push({
      path: pathToPosix(rel),
      mode: (stat.mode & 0o111) ? "100755" : "100644",
      type: "blob",
      sha,
    });
  }

  for (const dir of emptyDirs) {
    const rel = dir.rel;
    if (!rel || shouldIgnorePath(rel)) continue;
    const sha = await createBlob(owner, repoName, Buffer.from("", "utf8"));
    treeEntries.push({
      path: pathToPosix(path.join(rel, ".gitkeep")),
      mode: "100644",
      type: "blob",
      sha,
    });
  }

  const lowerPaths = new Set(treeEntries.map((e) => String(e.path).toLowerCase()));

  if (!lowerPaths.has("readme.md")) {
    const sha = await createBlob(owner, repoName, Buffer.from(buildReadme(repoName, visibility, files.length, sourceLabel), "utf8"));
    treeEntries.push({
      path: "README.md",
      mode: "100644",
      type: "blob",
      sha,
    });
  }

  if (!lowerPaths.has("license") && !lowerPaths.has("license.md") && !lowerPaths.has("license.txt")) {
    const sha = await createBlob(owner, repoName, Buffer.from(buildMitLicense(owner), "utf8"));
    treeEntries.push({
      path: "LICENSE",
      mode: "100644",
      type: "blob",
      sha,
    });
  }

  if (!lowerPaths.has(".gitignore")) {
    const sha = await createBlob(owner, repoName, Buffer.from(buildGitignore(), "utf8"));
    treeEntries.push({
      path: ".gitignore",
      mode: "100644",
      type: "blob",
      sha,
    });
  }

  const treeSha = await createTree(owner, repoName, treeEntries);
  const commitSha = await createCommit(
    owner,
    repoName,
    `Initial upload from WhatsApp bot: ${repoName}`,
    treeSha,
    parentSha || null
  );
  await createOrUpdateRef(owner, repoName, branch, commitSha);

  const topics = inferTopicsFromFiles(files.map((x) => x.abs), repoName);
  try { await setRepoTopics(owner, repoName, topics); } catch {}
  try { await setRepoDescription(owner, repoName, `Uploaded from WhatsApp bot (${visibility})`); } catch {}

  return { treeEntries, commitSha, topics };
}

let handler = async (m, { conn, text }) => {
  if (!GITHUB_TOKEN || GITHUB_TOKEN.includes("PASTE_YOUR_TEST_TOKEN_HERE")) {
    throw "Token GitHub belum diisi.";
  }
  if (!GITHUB_OWNER || GITHUB_OWNER.includes("USERNAME_GITHUB")) {
    throw "Owner GitHub belum diisi.";
  }

  const { repoPrefix, visibility, sourceUrl } = parseUpghArgs(text);
  if (!visibility) {
    throw "Visibility wajib dipilih: private atau public.\nContoh:\n.upgh private\n.upgh NamaRepo public\n.upgh https://contoh.com/file.zip private";
  }

  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), "upgh-"));
  ensureDir(tempRoot);

  try {
    let source = await downloadFromQuotedOrCurrent(conn, m);
    if (!source && sourceUrl) source = await downloadBuffer(sourceUrl);
    if (!source) {
      throw "Kirim file ZIP/arsip/file biasa lalu reply command ini, atau pakai URL file langsung.";
    }

    const inputPath = path.join(tempRoot, "input");
    fs.writeFileSync(inputPath, source.buffer);

    const archiveKind = detectArchiveKind(source.name, source.mime);
    const repoBase = repoPrefix || safeRepoName(path.parse(source.name || "project").name || "project");
    const repoSeed = `${repoBase}-${randomSuffix(4)}`;
    const visibilityLabel = visibility === "private" ? "Private" : "Public";
    const sourceLabel = safeName(source.name || "file");

    await sendText(conn, m, [
      "Mulai proses upgh...",
      `• Source: ${sourceLabel}`,
      `• Type: ${archiveKind === "none" ? "file biasa" : `arsip (${archiveKind})`}`,
      `• Visibility: ${visibilityLabel}`,
      `• Repo prefix: ${repoBase}`
    ].join("\n"));

    let rootDir = inputPath;

    if (archiveKind !== "none") {
      const extractDir = path.join(tempRoot, "extract");
      ensureDir(extractDir);
      await sendText(conn, m, "Mengekstrak arsip...");
      await extractArchive(inputPath, extractDir, archiveKind);
      rootDir = rootCandidatesFromDir(extractDir);
    }

    let files = [];
    let emptyDirs = [];

    if (fs.statSync(rootDir).isFile()) {
      files = [{ abs: rootDir, rel: path.basename(rootDir) }];
    } else {
      const walked = walkFiles(rootDir);
      files = walked.files.map((abs) => ({
        abs,
        rel: path.relative(rootDir, abs),
      }));
      emptyDirs = walked.emptyDirs.map((abs) => ({
        abs,
        rel: path.relative(rootDir, abs),
      }));
    }

    const repo = await createRepoUnique(repoSeed, visibility === "private");
    const repoName = repo.name;
    const repoUrl = repo.html_url || `https://github.com/${GITHUB_OWNER}/${repoName}`;
    const branch = repo.default_branch || DEFAULT_BRANCH;

    const parentSha = await getBranchHead(GITHUB_OWNER, repoName, branch);

    await sendText(conn, m, `Repository baru dibuat: ${repoName}\nSedang upload ${files.length + emptyDirs.length} item ke GitHub...`);

    const result = await uploadFilesAsGitRepo({
      owner: GITHUB_OWNER,
      repoName,
      branch,
      visibility: visibilityLabel,
      sourceLabel,
      files,
      emptyDirs,
      parentSha
    });

    await sendText(conn, m, [
      "✅ Upload berhasil",
      `• Repository: ${repoName}`,
      `• Visibility: ${visibilityLabel}`,
      `• Branch: ${branch}`,
      `• Source: ${sourceLabel}`,
      `• Files uploaded: ${files.length}`,
      `• Empty dirs: ${emptyDirs.length}`,
      `• Commit: ${result.commitSha}`,
      `• Link: ${repoUrl}`,
      `• MIT License: added`,
      `• README.md: added`,
      `• .gitignore: added`,
      `• Topics: ${result.topics.join(", ")}`
    ].join("\n"));
  } catch (e) {
    await sendText(conn, m, `Gagal:\n${String(e && e.message ? e.message : e)}`);
  } finally {
    try {
      if (fs.existsSync(tempRoot)) fs.rmSync(tempRoot, { recursive: true, force: true });
    } catch {}
  }
};

handler.help = ["upgh [repoName] private|public"];
handler.tags = ["owner"];
handler.command = ["upgh"];
handler.owner = true
module.exports = handler;