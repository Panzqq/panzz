const axios = require("axios")
const crypto = require("crypto")

const BASE = "https://www.perplexity.ai"

const header_dasar = {
  "User-Agent":
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
  Accept: "text/event-stream",
  "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
  "Content-Type": "application/json",
  Origin: BASE,
  Referer: BASE + "/"
}

function buat_cookie() {
  const cookies = {
    "pplx.visitor-id": crypto.randomUUID(),
    "pplx.session-id": crypto.randomUUID(),
    "pplx.edge-vid": crypto.randomUUID(),
    "pplx.edge-sid": crypto.randomUUID()
  }

  return Object.entries(cookies)
    .map(([k, v]) => `${k}=${v}`)
    .join("; ")
}

function buat_payload(query) {
  return {
    params: {
      last_backend_uuid: crypto.randomUUID(),
      read_write_token: crypto.randomUUID(),
      attachments: [],
      language: "id-ID",
      timezone: "Asia/Jakarta",
      search_focus: "internet",
      sources: ["web"],
      frontend_uuid: crypto.randomUUID(),
      mode: "copilot",
      model_preference: "turbo",
      query_source: "followup",
      version: "2.18"
    },
    query_str: query
  }
}

function parse_sse(raw) {
  if (!raw) return null

  const lines = raw.split("\n")

  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim()
    if (!line.startsWith("data: ")) continue

    try {
      const d = JSON.parse(line.slice(6))

      if (d.text && d.final) {
        const parsed = JSON.parse(d.text)

        for (const item of parsed) {
          if (item.step_type === "FINAL" && item.content?.answer) {
            const answerJson = JSON.parse(item.content.answer)

            return String(answerJson.answer || "")
              .replace(/\[\d+\]/g, "")
              .trim()
          }
        }
      }
    } catch {}
  }

  return null
}

async function perplexity(query) {
  const { data } = await axios.post(
    `${BASE}/rest/sse/perplexity_ask`,
    JSON.stringify(buat_payload(query)),
    {
      headers: {
        ...header_dasar,
        Cookie: buat_cookie(),
        "x-request-id": crypto.randomUUID()
      },
      timeout: 30000,
      responseType: "text",
      validateStatus: () => true
    }
  )

  if (typeof data !== "string") {
    throw new Error("Respon bukan text")
  }

  const hasil = parse_sse(data)

  if (!hasil) {
    throw new Error("Gagal mendapatkan jawaban dari Perplexity")
  }

  return hasil
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const query = text || m.quoted?.text || ""

  if (!query) {
    return m.reply(
      `Masukkan pertanyaan.\n\nContoh:\n${usedPrefix + command} siapa presiden indonesia sekarang?`
    )
  }

  if (query.length > 4000) {
    return m.reply("Pertanyaan terlalu panjang, maksimal 4000 karakter.")
  }

  try {
    await conn.sendPresenceUpdate?.("composing", m.chat)

    const result = await perplexity(query)

    let teks = `乂 P E R P L E X I T Y\n\n`
    teks += `• Pertanyaan:\n${query}\n\n`
    teks += `• Jawaban:\n${result}`

    await m.reply(teks)
  } catch (e) {
    console.error(e)

    m.reply(
      `Gagal mengambil jawaban.\n\nError: ${e.message || e}`
    )
  }
}

handler.help = handler.command = ["pplx", "perplexity", "aiweb"]
handler.tags = ["ai"]

module.exports = handler