const axios = require("axios");
const fs = require("node:fs");
const path = require("node:path");
const { tmpFile, safeUnlinkSync } = require("../lib/tmpManager");

let handler = async (m, { conn, usedPrefix, command }) => {
  let tempPath = "";

  try {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || "";

    if (!/image/.test(mime)) {
      return m.reply(`Reply atau kirim gambar dengan caption *${usedPrefix + command}* untuk menghapus watermarknya.`);
    }

    m.reply("⏳ Sedang memproses gambar, mohon tunggu sebentar...");

    let media = await q.download();
    tempPath = tmpFile({ dir: "ai/remwm", prefix: "input", ext: "jpg" });
    fs.writeFileSync(tempPath, media);

    const resultUrl = await removeWatermark(tempPath);

    await conn.sendMessage(m.chat, {
      image: { url: resultUrl },
      caption: "✅ Watermark berhasil dihapus!"
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    m.reply("❌ Gagal memproses gambar. Mungkin watermarknya terlalu rumit atau server sedang sibuk.");
  } finally {
    safeUnlinkSync(tempPath);
  }
};

handler.help = handler.command = ["nowm", "removewm", "hapuswm"];
handler.tags = ["tools"];
module.exports = handler;

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function getMime(file) {
  const ext = path.extname(file).toLowerCase();
  if (ext === ".png") return "image/png";
  if (ext === ".webp") return "image/webp";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  return "application/octet-stream";
}

async function removeWatermark(filePath) {
  const filename = path.basename(filePath);
  const buffer = fs.readFileSync(filePath);
  const mime = getMime(filePath);
  const boundary = `----FormBoundary${Math.random().toString(36).slice(2)}`;

  const body = Buffer.concat([
    Buffer.from(`--\( {boundary}\r\nContent-Disposition: form-data; name="image_file"; filename=" \){filename}"\r\nContent-Type: ${mime}\r\n\r\n`),
    buffer,
    Buffer.from(`\r\n--${boundary}--\r\n`)
  ]);

  const create = await axios.post(
    "https://api.ezremove.ai/api/ez-remove/watermark-remove/create-job",
    body,
    {
      headers: {
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Origin": "https://ezremove.ai",
        "Referer": "https://ezremove.ai/",
        "product-serial": `sr-${Date.now()}`,
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
        "Content-Length": body.length
      },
      timeout: 30000,
      validateStatus: () => true,
      maxBodyLength: Infinity,
      maxContentLength: Infinity
    }
  );

  if (create.status < 200 || create.status >= 300) throw new Error("Gagal membuat job");

  const jobId = create.data?.result?.job_id;
  if (!jobId) throw new Error("Job ID tidak ditemukan");

  for (let i = 0; i < 30; i++) {
    await sleep(2000);

    const check = await axios.get(
      `https://api.ezremove.ai/api/ez-remove/watermark-remove/get-job/${jobId}`,
      {
        headers: {
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36",
          "Accept": "application/json, text/plain, */*",
          "Origin": "https://ezremove.ai",
          "Referer": "https://ezremove.ai/",
          "product-serial": `sr-${Date.now()}`
        },
        timeout: 15000,
        validateStatus: () => true
      }
    );

    if (check.status < 200 || check.status >= 300) throw new Error("Gagal cek status job");

    const resultUrl = check.data?.result?.output?.[0];

    if (check.data?.code === 100000 && resultUrl) {
      return resultUrl;
    }

    if (check.data?.code !== 300001) {
      throw new Error("Job gagal diproses");
    }
  }

  throw new Error("Timeout: Proses terlalu lama");
}