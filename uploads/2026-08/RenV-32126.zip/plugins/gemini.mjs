#!/usr/bin/env node
/**
 * Gemini CLI — JS port (Node 18+ native fetch, no headless)
 * Pure HTTP, mirror python gemini_cli.py logic
 * Endpoint: POST https://gemini.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate?bl=&f.sid=&hl=&_reqid=&rt=c
 * inner 81-slot, streaming length-prefixed, guest 200 ok
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import process from 'process';
import https from 'https';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const COOKIES_FILE = path.join(__dirname, 'cookies.json');

const CREATOR = "Lann";

function _compact(o){ const c={creator:CREATOR, status:o.status, prompt:o.prompt}; const ans=o.extracted_text||o.answer|| (o.result&&o.result.text)||""; if(ans) c.answer= ans.length>500? ans.slice(0,500)+"...":ans; if(o.mode) c.mode=o.mode; if(o.status_code!=null) c.status_code=o.status_code; if(o.is_error && o.error_details) c.error=String(o.error_details).slice(0,250); if(o.thoughts) c.reasoning=o.thoughts.slice(0,400); if(o.generated_images) c.images=o.generated_images.length; if(o.web_images) c.web_images=o.web_images.length; if(o.videos) c.videos=o.videos.length; if(o.result && o.result.text && !c.answer) c.answer=o.result.text.slice(0,500); return c; }
function _injectCreator(o){ if(o && typeof o==="object"){ o.creator=CREATOR; } return o; }


const ENDPOINT_INIT = 'https://gemini.google.com/app';
const ENDPOINT_GENERATE = 'https://gemini.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate';

const RE_SNLM0E = /"SNlM0e"\s*:\s*"(.*?)"/;
const RE_CFB2H  = /"cfb2h"\s*:\s*"(.*?)"/;
const RE_FDRFJE = /"FdrFJe"\s*:\s*"(.*?)"/;
const RE_TUX5CC = /"TuX5cc"\s*:\s*"(.*?)"/;
const RE_PUSHID = /"qKIAYe"\s*:\s*"(.*?)"/;

const DEFAULT_LANGUAGE = 'id';
const DEFAULT_METADATA = ["", "", "", null, null, null, null, null, null, ""];

const STREAMING_FLAG_INDEX = 7, GEM_FLAG_INDEX = 19, TEMPORARY_FLAG_INDEX = 45;
const MODEL_HEADER_KEY = "x-goog-ext-525001261-jspb";
const MODEL_MAP_PURE = {
  "gemini-pro": ["9d8ca3786ebdfbea",3],
  "gemini-flash": ["fbb127bbb056c959",1],
  "gemini-flash-lite": ["cf41b0e0dd7d53e5",6],
  "pro": ["9d8ca3786ebdfbea",3],
  "flash": ["fbb127bbb056c959",1],
  "lite": ["cf41b0e0dd7d53e5",6],
};
const SESSIONS_FILE = path.join(__dirname, "sessions.json");
const FALLBACK_MODELS = [
  {model_name:"gemini-pro",display_name:"Gemini Pro",model_id:"9d8ca3786ebdfbea",available:true,aliases:["pro"]},
  {model_name:"gemini-flash",display_name:"Gemini Flash",model_id:"fbb127bbb056c959",available:true,aliases:["flash"]},
  {model_name:"gemini-flash-lite",display_name:"Gemini Flash-Lite",model_id:"cf41b0e0dd7d53e5",available:true,aliases:["lite"]},
];

let _reqid = Math.floor(Math.random()*900000)+100000;

function buildPureModelHeader(modelName){
  const k=(modelName||'').toLowerCase().trim();
  if(MODEL_MAP_PURE[k]){
    const [mid,num]=MODEL_MAP_PURE[k];
    const header=`[1,null,null,null,"${mid}",null,null,0,[4,5,6,8],null,null,1,null,null,${num}]`;
    return [{[MODEL_HEADER_KEY]:header,"x-goog-ext-73010989-jspb":"[0]","x-goog-ext-73010990-jspb":"[0,0,0]"}, num];
  }
  return [{}, null];
}

async function interactiveModelSelect() {
  if (!process.stdin.isTTY) {
    console.log(JSON.stringify(_injectCreator({status:"success", models:FALLBACK_MODELS, source:"fallback static"}),null,2));
    return null;
  }
  return new Promise(async (resolve) => {
    let selected = 0;
    const models = FALLBACK_MODELS;
    const { stdin, stdout } = process;
    const C = { reset: "\x1b[0m", cyan: "\x1b[36m", green: "\x1b[32m", gray: "\x1b[90m" };
    
    const readline = await import('readline');
    readline.emitKeypressEvents(stdin);

    const render = () => {
      stdout.write('\x1b[?25l'); // hide cursor
      stdout.write(`\r\x1b[K${C.cyan}Gunakan Panah Atas/Bawah untuk memilih, lalu tekan Enter:${C.reset}\n`);
      models.forEach((m, i) => {
        if (i === selected) {
          stdout.write(`  ${C.green}❯ ${m.display_name} (${m.model_name})${C.reset}\x1b[K\n`);
        } else {
          stdout.write(`    ${m.display_name} (${m.model_name})\x1b[K\n`);
        }
      });
      stdout.write(`\x1b[${models.length + 1}A`); // move cursor back up
    };

    const cleanup = () => {
      stdout.write(`\x1b[${models.length + 1}B`); // move cursor below the list
      stdout.write('\x1b[?25h'); // show cursor
      stdin.setRawMode(false);
      stdin.removeListener('keypress', onKeypress);
    };

    const onKeypress = (str, key) => {
      if (key && key.ctrl && key.name === 'c') {
        cleanup();
        process.exit();
      }
      if (key && key.name === 'up') {
        selected = (selected - 1 + models.length) % models.length;
        render();
      } else if (key && key.name === 'down') {
        selected = (selected + 1) % models.length;
        render();
      } else if (key && (key.name === 'return' || key.name === 'enter')) {
        cleanup();
        resolve(models[selected].model_name);
      }
    };

    stdin.setRawMode(true);
    stdin.resume();
    stdin.on('keypress', onKeypress);
    render();
  });
}

function getNestedValue(data, path, defVal=null){
  let cur=data;
  for(const key of path){
    if(Array.isArray(cur) && typeof key==='number'){
      if(key>=0 && key<cur.length) cur=cur[key]; else return defVal;
    } else if(cur && typeof cur==='object' && typeof key==='string'){
      if(key in cur) cur=cur[key]; else return defVal;
    } else return defVal;
    if(cur==null) return defVal;
  }
  return cur==null?defVal:cur;
}
function getField(container,index,defVal=null){
  if(!Array.isArray(container)||!container.length) return defVal;
  let val = index>=0 && index<container.length ? container[index] : null;
  if(val==null || (Array.isArray(val)&&!val.length) || (typeof val==='object'&&!Array.isArray(val)&&!Object.keys(val).length)){
    const bundle = Array.isArray(container[container.length-1])?null:container[container.length-1];
    if(bundle && typeof bundle==='object' && !Array.isArray(bundle)) val=bundle[String(index+1)];
    else val=defVal;
  }
  if(val==null || (Array.isArray(val)&&!val.length)) return defVal;
  return val;
}
function extractJsonFromResponse(text){
  if(typeof text!=='string') return [];
  let content=text.trimStart();
  if(content.startsWith(")]}'")) content=content.slice(5).trimStart();
  const pattern=/^\s*(\d+)\s*\n/gm;
  let pos=0, parsed=[];
  try{
    let m;
    // simple scanner
    const regex=/^\s*(\d+)\s*\n/gm;
    let idx=0;
    let out=[];
    let p=0;
    while(true){
      regex.lastIndex=p;
      const mm=regex.exec(content);
      if(!mm) break;
      const len=parseInt(mm[1],10);
      const start=mm.index+mm[0].length;
      const chunk=content.slice(start,start+len);
      if(chunk.length<len) break;
      const s=chunk.trim();
      if(s){
        try{
          const v=JSON.parse(s);
          if(Array.isArray(v)) out.push(...v); else out.push(v);
        }catch{}
      }
      p=start+len;
      if(p>=content.length) break;
    }
    if(out.length) return out;
  }catch{}
  try{
    const v=JSON.parse(content.trim());
    return Array.isArray(v)?v:[v];
  }catch{}
  const collected=[];
  for(const line of content.trim().split('\n')){
    const s=line.trim(); if(!s) continue;
    try{
      const v=JSON.parse(s);
      if(Array.isArray(v)) collected.push(...v); else collected.push(v);
    }catch{}
  }
  if(collected.length) return collected;
  throw new Error("Could not parse response JSON");
}
function cleanText(s){
  if(!s) return "";
  s=s.replace(/\n```$/,'');
  s=s.replace(/\\+[`*_~].*$/,'');
  s=s.replace(/https?:\/\/googleusercontent\.com\/(?:\w+\/)+\d+\n*/g,'');
  return s;
}
function extractTextFromGenerateResponse(responseText){
  let frames;
  try{ frames=extractJsonFromResponse(responseText);}catch(e){ return ["",[],e.message];}
  let allText=""; let candidates=[];
  for(const part of frames){
    let innerStr=null;
    if(Array.isArray(part) && part.length>2 && typeof part[2]==='string' && part[2].trim().startsWith('[')) innerStr=part[2];
    else if(Array.isArray(part) && part.length && Array.isArray(part[0])){
      for(const sub of part) if(Array.isArray(sub)&&sub.length>2&&typeof sub[2]==='string'){ innerStr=sub[2]; break; }
    }
    if(innerStr==null){
      const cand=getNestedValue(part,[4],null);
      if(Array.isArray(cand)&&cand.length){
        const part_json=part;
        const candidatesList=getNestedValue(part_json,[4],[]);
        for(const candData of candidatesList){
          let txt=getNestedValue(candData,[1,0],"");
          if(txt){
            if(/^https?:\/\/googleusercontent\.com\/card_content/.test(txt)){
              const alt=getNestedValue(candData,[22,0],""); if(alt) txt=alt;
            }
            txt=cleanText(txt);
            candidates.push({rcid:getNestedValue(candData,[0],""), text:txt});
            if(txt.length>allText.length) allText=txt;
          }
        }
        continue;
      }
      continue;
    }
    if(!innerStr) continue;
    let part_json;
    try{ part_json=JSON.parse(innerStr);}catch{continue;}
    const list=getNestedValue(part_json,[4],[]);
    if(!Array.isArray(list)) continue;
    for(const candData of list){
      let txt=getNestedValue(candData,[1,0],"");
      if(txt){
        if(/^https?:\/\/googleusercontent\.com\/card_content/.test(txt)){
          const alt=getNestedValue(candData,[22,0],""); if(alt) txt=alt;
        }
        txt=cleanText(txt);
        candidates.push({rcid:getNestedValue(candData,[0],""), text:txt});
        if(txt.length>allText.length) allText=txt;
      }
    }
  }
  if(!allText){
    const tmp=[];
    function collect(obj){
      if(typeof obj==='string' && obj.trim().length>30 && obj.includes(' ') && !obj.toLowerCase().includes('http') && !obj.startsWith(")]}'")) tmp.push(obj.trim());
      else if(Array.isArray(obj)) obj.forEach(collect);
      else if(obj&&typeof obj==='object') Object.values(obj).forEach(collect);
    }
    frames.forEach(collect);
    if(tmp.length){ allText=tmp.reduce((a,b)=> b.length>a.length?b:a, ""); candidates.push({rcid:"fallback", text:allText});}
  }
  return [allText,candidates,null];
}
function extractRichContent(responseText){
  let frames;
  try{ frames=extractJsonFromResponse(responseText);}catch(e){ return {text:"",thoughts:"",web_images:[],generated_images:[],videos:[],citations:[],error:String(e)};}
  let textAll="", thoughts=""; let web_images=[], gen_images=[], videos=[], citations=[];
  for(const part of frames){
    let innerStr=null;
    if(Array.isArray(part)&&part.length>2&&typeof part[2]==='string') innerStr=part[2];
    let part_json=null;
    if(innerStr){
      try{ part_json=JSON.parse(innerStr);}catch{}
    } else if(Array.isArray(getNestedValue(part,[4],null))){
      part_json=part;
    }
    if(!part_json) continue;
    const cands=getNestedValue(part_json,[4],[]);
    for(const cand of cands){
      const txt=getNestedValue(cand,[1,0],"")||"";
      const th=getNestedValue(cand,[37,0,0],"")||"";
      if(txt && txt.length>textAll.length) textAll=cleanText(txt);
      if(th && th.length>thoughts.length) thoughts=th;
      const wiField = (()=>{ const rc=getNestedValue(cand,[12],null); return rc? getField(rc,1,[]):[];})();
      for(const wi of wiField||[]){
        const url=getNestedValue(wi,[0,0,0],""); if(url) web_images.push({url, alt:getNestedValue(wi,[0,4],"")});
      }
      const giField = (()=>{ const rc=getNestedValue(cand,[12],null); const v=rc? getField(rc,7,null):null; return v? getNestedValue(v,[0],[]):[];})();
      for(const gi of giField||[]){
        const url=getNestedValue(gi,[0,3,3],""); if(url) gen_images.push({url, alt:getNestedValue(gi,[0,3,2],""), id:getNestedValue(gi,[1,0],"")});
      }
      const vInfo = (()=>{ const rc=getNestedValue(cand,[12],null); return rc? getField(rc,59,null):null;})();
      if(vInfo){
        const vi=getNestedValue(vInfo,[0,0,0],[]);
        if(vi){ const urls=getNestedValue(vi,[0,7],[]); if(urls.length>=2) videos.push({url:urls[1], thumb:urls[0]}); }
      }
    }
  }
  const dedup=(arr)=>{ const seen=new Set(),out=[]; for(const x of arr){ const u=x.url; if(u&&!seen.has(u)){seen.add(u); out.push(x);} } return out; };
  return {text:textAll, thoughts, web_images:dedup(web_images), generated_images:dedup(gen_images), videos:dedup(videos), citations};
}
function loadLocalSessions(){
  try{ if(fs.existsSync(SESSIONS_FILE)) return JSON.parse(fs.readFileSync(SESSIONS_FILE,'utf-8')); }catch{}
  return [];
}
function splitArgsRespectQuotes(str){
  const out=[]; let cur=""; let inQ=false; let qChar="";
  for(let i=0;i<str.length;i++){
    const c=str[i];
    if(inQ){
      if(c===qChar){ inQ=false; out.push(cur); cur=""; }
      else cur+=c;
    } else {
      if(c==='"' || c==="'"){ inQ=true; qChar=c; if(cur) { out.push(cur); cur=""; } }
      else if(/\s/.test(c)){ if(cur){ out.push(cur); cur=""; } }
      else cur+=c;
    }
  }
  if(cur) out.push(cur);
  return out;
}
function extractFileAndPrompt(remaining){
  remaining=remaining.trim();
  if(!remaining) return [null,""];
  // quoted
  if(remaining[0]==='"' || remaining[0]==="'"){
    const q=remaining[0];
    const end=remaining.indexOf(q,1);
    if(end!==-1){
      const file=remaining.slice(1,end);
      const prompt=remaining.slice(end+1).trim();
      return [file, prompt];
    }
  }
  // try longest prefix that is existing file
  const parts=remaining.split(/\s+/);
  // Try combining from longest to shortest
  for(let i=parts.length;i>=1;i--){
    const cand=parts.slice(0,i).join(" ");
    // clean quotes
    const clean=cand.replace(/^"|"$/g,'').replace(/^'|'$/g,'');
    try{ if(fs.existsSync(clean) || fs.existsSync(cand)) return [clean, parts.slice(i).join(" ")]; }catch{}
    try{ if(fs.existsSync(path.resolve(clean))) return [path.resolve(clean), parts.slice(i).join(" ")]; }catch{}
  }
  // fallback: first token as file
  const first=parts[0].replace(/^"|"$/g,'');
  return [first, parts.slice(1).join(" ")];
}
function saveLocalSession(prompt, answer, mode="guest", model=null){
  try{
    const arr=loadLocalSessions();
    arr.push({time:new Date().toISOString(), prompt, answer: String(answer).slice(0,800), mode, model});
    const keep=arr.slice(-50);
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(keep,null,2), 'utf-8');
  }catch{}
}


function loadCookies(){
  if(!fs.existsSync(COOKIES_FILE)) return {};
  try{
    const raw=fs.readFileSync(COOKIES_FILE,'utf-8').trim();
    if(!raw) return {};
    const data=JSON.parse(raw);
    if(Array.isArray(data)){
      const out={}; for(const it of data){ const n=it.name||it.Name||it.key; const v=it.value||it.Value; if(n&&v) out[n]=String(v); } return out;
    } else if(data && typeof data==='object'){
      const out={}; for(const [k,v] of Object.entries(data)) if(v) out[k]=String(v); return out;
    }
  }catch{}
  return {};
}
function validateCookies(cookies){
  const required=["__Secure-1PSID","__Secure-1PSIDTS"];
  const missing=required.filter(k=>!cookies[k]);
  const present=Object.keys(cookies);
  const advice = missing.length ? `Cookie kritis hilang: ${missing.join(", ")}. Export ulang dari Chrome DevTools > Application > Cookies > https://gemini.google.com` : null;
  return {total:Object.keys(cookies).length, present_keys:present, missing_required:missing, is_guest_like: missing.length===2, advice, has_required: missing.length===0};
}
function cookiesToHeader(cookies){
  return Object.entries(cookies).map(([k,v])=>`${k}=${v}`).join('; ');
}

async function rotateCookiesViaGoogle(cookies){
  const cookieHeader = cookiesToHeader(cookies);
  return new Promise((resolve)=>{
    const postData = '[000,"-0000000000000000000"]';
    const opts = {
      hostname: "accounts.google.com",
      path: "/RotateCookies",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Origin": "https://accounts.google.com",
        "Cookie": cookieHeader,
        "Content-Length": Buffer.byteLength(postData)
      },
      maxHeaderSize: 1024*1024*2
    };
    const req = https.request(opts, res => {
      let d = ""; res.on("data", c => d += c);
      res.on("end", () => {
        if (res.statusCode === 200) {
          const setCookies = res.headers["set-cookie"] || [];
          const newCookies = {...cookies};
          for (const sc of setCookies) {
            const m = sc.match(/^([^=]+)=([^;]+)/);
            if (m && (m[1]==="__Secure-1PSIDTS" || m[1]==="__Secure-1PSIDCC")) {
              newCookies[m[1]] = m[2];
            }
          }
          resolve({ok: true, cookies: newCookies, newSidts: newCookies["__Secure-1PSIDTS"] !== cookies["__Secure-1PSIDTS"]});
        } else if (res.statusCode === 401) {
          resolve({ok: false, reason: "401 session expired"});
        } else {
          resolve({ok: false, reason: `status ${res.statusCode}`});
        }
      });
    });
    req.on("error", e => resolve({ok: false, reason: e.message}));
    req.write(postData);
    req.end();
  });
}

async function tryAutoRefreshCookies(){
  const cookies = loadCookies();
  const sid = cookies["__Secure-1PSID"];
  if (!sid) return {refreshed: false, reason: "no __Secure-1PSID"};
  const sidts = cookies["__Secure-1PSIDTS"];
  console.log("\x1b[90m⟳ Cookie expired, mencoba auto-refresh...\x1b[0m");
  const rot = await rotateCookiesViaGoogle(cookies);
  if (rot.ok && rot.newSidts) {
    fs.writeFileSync(COOKIES_FILE, JSON.stringify(rot.cookies, null, 2), "utf-8");
    console.log("\x1b[32m✔ Cookie refreshed via RotateCookies\x1b[0m");
    return {refreshed: true, cookies: rot.cookies};
  }
  if (rot.ok && !rot.newSidts) {
    console.log("\x1b[90m  RotateCookies OK tapi 1PSIDTS sama (mungkin masih fresh)\x1b[0m");
  } else {
    console.log(`\x1b[90m  RotateCookies gagal: ${rot.reason}\x1b[0m`);
  }
  if (process.platform === "win32") {
    try {
      const pyScript = path.join(__dirname, "refresh_cookies.py");
      if (fs.existsSync(pyScript)) {
        console.log("\x1b[90m  Mencoba extract dari Chrome DB...\x1b[0m");
        const {execSync} = await import("child_process");
        const out = execSync(`python "${pyScript}"`, {timeout: 15000, encoding: "utf-8"});
        if (out.includes("OK")) {
          const fresh = loadCookies();
          if (fresh["__Secure-1PSID"]) {
            console.log("\x1b[32m✔ Cookie extracted dari Chrome\x1b[0m");
            return {refreshed: true, cookies: fresh};
          }
        }
      }
    } catch(e) {
      console.log(`\x1b[90m  Chrome extract gagal: ${e.message}\x1b[0m`);
    }
  }
  return {refreshed: false, reason: "all methods failed"};
}
function extractInitData(html){
  const sn=(html.match(RE_SNLM0E)||[])[1]||null;
  const bl=(html.match(RE_CFB2H)||[])[1]||null;
  const sid=(html.match(RE_FDRFJE)||[])[1]||null;
  const lang=(html.match(RE_TUX5CC)||[])[1]||null;
  const push=(html.match(RE_PUSHID)||[])[1]||null;
  return {snlm0e:sn, bl, sid, lang, push_id:push};
}
function isLoggedIn(html, init, finalUrl){
  if(finalUrl.includes('accounts.google.com')) return false;
  if(init.snlm0e) return true;
  const low=html.toLowerCase();
  if(low.includes('viewer-signed-out')||low.includes('signed-out')) return false;
  return false;
}
function buildInner(prompt, language, fileData=null, gemId=null, temporary=false, thinking=false){
  const msg=[prompt,0,null,fileData,null,null,0];
  const inner=new Array(81).fill(null);
  // thinking RE field 37, inner[80]=2 on

  inner[0]=msg; inner[1]=[language]; inner[2]=DEFAULT_METADATA;
  inner[6]=[1]; inner[7]=1; inner[10]=1; inner[11]=0; inner[17]=[[0]]; inner[18]=0;
  if(gemId) inner[GEM_FLAG_INDEX]=gemId;
  inner[27]=1; inner[30]=[4]; inner[41]=[1];
  if(temporary) inner[TEMPORARY_FLAG_INDEX]=1;
  inner[53]=0; inner[61]=[]; inner[68]=1; inner[79]=1; inner[80]= thinking ? 2 : 1;
  const uuidVal = crypto.randomUUID().toUpperCase();
  inner[59]=uuidVal;
  return [inner, uuidVal];
}
async function syncUploadFilePure(filePath, pushId, cookies){
  const p=path.resolve(filePath);
  if(!fs.existsSync(p)) throw new Error(`File tidak ditemukan: ${p}`);
  const buf=fs.readFileSync(p);
  const filename=path.basename(p);
  // use https with large header to avoid overflow
  const https = await import('https');
  const boundary = "----FormBoundary" + Math.random().toString(36).slice(2);
  const header = `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: application/octet-stream\r\n\r\n`;
  const footer = `\r\n--${boundary}--\r\n`;
  const body = Buffer.concat([Buffer.from(header), buf, Buffer.from(footer)]);
  const cookieHeader = cookiesToHeader(cookies);
  return await new Promise((resolve, reject)=>{
    const opts = {
      hostname: "content-push.googleapis.com",
      path: "/upload",
      method: "POST",
      headers: {
        "Push-ID": pushId,
        "X-Tenant-Id": "bard-storage",
        "Origin": "https://gemini.google.com",
        "Referer": "https://gemini.google.com/",
        "Cookie": cookieHeader,
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
        "Content-Length": body.length
      },
      maxHeaderSize: 1024*1024*2
    };
    const req = https.request(opts, res=>{
      let d=""; res.on("data",c=>d+=c); res.on("end",()=> {
        if(res.statusCode>=200 && res.statusCode<300) resolve(d.trim());
        else reject(new Error(`Upload failed ${res.statusCode} ${d}`));
      });
    });
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

async function sendGeminiPrompt(prompt, opts={}){ const thinking=!!opts.thinking;
  const cookies=opts.cookies || loadCookies();
  const targetUrl=opts.targetUrl||ENDPOINT_INIT;
  const timeout=opts.timeout||30000;
  const files=opts.files||null;
  const gemId=opts.gemId||null;
  const temporary=!!opts.temporary;
  const model=opts.model||null;

  const cookieDiag=validateCookies(cookies);
  const cookieHeader=cookiesToHeader(cookies);

  // 1. GET INIT (https dengan maxHeaderSize 1M biar tidak overflow)
  let init={snlm0e:null,bl:null,sid:null,lang:null,push_id:null};
  let finalUrl=targetUrl, getStatus=null, isLogged=false, html="";
  try{
    const httpsGet = (url, headers) => new Promise((resolve, reject)=>{
      const u=new URL(url);
      const opts={hostname: u.hostname, path: u.pathname+u.search, method:"GET", headers, maxHeaderSize: 1024*1024*2};
      const req=https.request(opts, res=>{
        let d=""; res.on("data",c=>d+=c); res.on("end",()=> resolve({status:res.statusCode, url: url, text:()=>d, headers:res.headers, textSync:d}));
      });
      req.on("error", reject); req.end();
    });
    // wrap to mimic fetch
    const rWrap = await new Promise((resolve,reject)=>{
      const u=new URL(targetUrl);
      const opts={hostname:u.hostname, path:u.pathname+u.search, method:"GET", headers:{
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
        "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language":"id-ID,id;q=0.9,en-US;q=0.8",
        "Cookie":cookieHeader,
        "Sec-Fetch-Dest":"document","Sec-Fetch-Mode":"navigate","Sec-Fetch-Site":"same-origin"
      }, maxHeaderSize: 1024*1024*2};
      const req=https.request(opts, res=>{
        let d=""; res.on("data",c=>d+=c); res.on("end",()=> resolve({status:res.statusCode, url: targetUrl, text:()=>d, headers:res.headers, _text:d}));
      });
      req.on("error", reject); req.end();
    });
    getStatus=rWrap.status; finalUrl=rWrap.url; html=rWrap._text;
    init=extractInitData(html); isLogged=isLoggedIn(html,init,finalUrl);
  }catch(e){
    // continue
  }
  const snlm0e=init.snlm0e, bl=init.bl, sid=init.sid, lang=init.lang||DEFAULT_LANGUAGE;

  // 1.5 files
  let fileData=null;
  if(files && files.length){
    const pushId=init.push_id||"feeds/mcudyrk2a4khkz";
    const uploaded=[];
    for(const fp of files){
      try{
        const fid=await syncUploadFilePure(fp, pushId, cookies);
        uploaded.push([[fid], path.basename(fp)]);
      }catch(e){
        return _injectCreator({creator:CREATOR,  status:"error", status_code:null, prompt, cookies_loaded:Object.keys(cookies).length, cookie_validation:cookieDiag, snlm0e_token:snlm0e, build_label:bl, session_id:sid, language:lang, final_url:finalUrl, is_logged_in:isLogged, is_error:true, error_details:`Upload gagal ${fp}: ${e.message}. Butuh login untuk vision.`, extracted_text:"", mode:isLogged?"authenticated":"guest"});
      }
    }
    if(uploaded.length) fileData=uploaded;
  }

  // 2. BUILD
  _reqid+=100000;
  const params=new URLSearchParams({hl:lang,_reqid:String(_reqid),rt:"c"});
  if(bl) params.set("bl",bl);
  if(sid) params.set("f.sid",sid);
  let [inner, uuidVal]=buildInner(prompt, lang, fileData, gemId, temporary, thinking);
  let modelHeaders={};
  if(model){
    const [mh,mnum]=buildPureModelHeader(model);
    if(Object.keys(mh).length){
      modelHeaders=mh;
      if(mnum!=null) inner[79]=mnum;
      try{
        const hdr=JSON.parse(mh[MODEL_HEADER_KEY]);
        if(Array.isArray(hdr)){ hdr.push(1); hdr.push(crypto.randomUUID().toUpperCase()); modelHeaders[MODEL_HEADER_KEY]=JSON.stringify(hdr); }
      }catch{}
    }
  }
  const fReq=JSON.stringify([null, JSON.stringify(inner)]);
  const body=new URLSearchParams({at: snlm0e||"", "f.req": fReq});
  const headers={
    "Content-Type":"application/x-www-form-urlencoded;charset=UTF-8",
    "Origin":"https://gemini.google.com",
    "Referer":targetUrl,
    "X-Same-Domain":"1",
    "x-goog-ext-525005358-jspb":`["${uuidVal}",1]`,
    "Cookie":cookieHeader,
    ...modelHeaders
  };
  let raw="", postStatus=null, postError=null;
  try{
    const postData = body.toString();
    const rWrap2 = await new Promise((resolve,reject)=>{
      const u=new URL(`${ENDPOINT_GENERATE}?${params.toString()}`);
      const opts={hostname:u.hostname, path:u.pathname+u.search, method:"POST", headers:{...headers, "Content-Length": Buffer.byteLength(postData), "Cookie": cookieHeader}, maxHeaderSize: 1024*1024*2};
      const req=https.request(opts, res=>{
        let d=""; res.on("data",c=>d+=c); res.on("end",()=> resolve({status:res.statusCode, text:()=>d, _text:d, headers:res.headers}));
      });
      req.on("error", reject); req.write(postData); req.end();
    });
    postStatus=rWrap2.status; raw=rWrap2._text;
    if(rWrap2.status===429) postError="Rate limited 429";
    else if(rWrap2.status===401) postError="Unauthorized 401";
    else if(rWrap2.status===403) postError="Forbidden 403";
  }catch(e){ postError=String(e); }

  let extracted="", candidates=[], rich={web_images:[],generated_images:[],videos:[],thoughts:""};
  let parseError=null;
  if(raw){
    if(raw.trim().startsWith("<!doctype")||raw.toLowerCase().slice(0,500).includes("<html")){
      parseError="Response HTML — sesi invalid";
    } else {
      try{
        const [txt,cands]=extractTextFromGenerateResponse(raw);
        extracted=txt; candidates=cands;
        try{
          const r2=extractRichContent(raw);
          rich=r2;
          if(!extracted && r2.text) extracted=r2.text;
        }catch{}
      }catch(e){ parseError=String(e); }
    }
  }
  let isSuccess = postStatus===200 && !!(extracted||candidates.length);
  if(candidates.length){
    const best={};
    for(const c of candidates){
      const k=c.rcid||"unknown";
      if(!best[k]||c.text.length>best[k].text.length) best[k]=c;
    }
    candidates=Object.values(best);
  }
  let parsedPreview=null;
  try{
    const v=extractJsonFromResponse(raw);
    parsedPreview=v.length>3? v.slice(0,2):v;
  }catch{ parsedPreview=raw.slice(0,3000); }
  const isGuest=!snlm0e||!isLogged;
  let error_details=null;
  if(!isSuccess){
    const parts=[];
    if(!snlm0e) parts.push(`Token SNlM0e KOSONG — guest. GET ${getStatus} ${finalUrl}. ${cookieDiag.advice||""}`);
    if(postError) parts.push(postError);
    if(parseError) parts.push(parseError);
    if(postStatus && postStatus!==200) parts.push(`Status ${postStatus}`);
    error_details=parts.join(" ")||`Status ${postStatus}`;
  }

  // AUTO-REFRESH: kalau guest dan ada 1PSID, coba rotate/extract
  if (isGuest && cookies["__Secure-1PSID"] && !opts._retried) {
    const refresh = await tryAutoRefreshCookies();
    if (refresh.refreshed) {
      return sendGeminiPrompt(prompt, {...opts, cookies: refresh.cookies, _retried: true});
    }
  }

  const advice = !isSuccess ? cookieDiag.advice : (isGuest ? "Mode GUEST — tanpa personalisasi. Lengkapi __Secure-1PSID & __Secure-1PSIDTS untuk full." : null);
  try{ saveLocalSession(prompt, extracted, isGuest?"guest":"authenticated", model); }catch{}
  return _injectCreator({
    creator: CREATOR,
    status: isSuccess?"success":"error",
    status_code: postStatus ?? getStatus,
    prompt,
    cookies_loaded:Object.keys(cookies).length,
    cookie_validation:cookieDiag,
    snlm0e_token:snlm0e,
    build_label:bl,
    session_id:sid,
    language:lang,
    final_url:finalUrl,
    is_logged_in:isLogged,
    is_error:!isSuccess,
    error_details,
    extracted_text:extracted,
    thoughts:rich.thoughts||"",
    candidates,
    web_images:rich.web_images||[],
    generated_images:rich.generated_images||[],
    videos:rich.videos||[],
    response: parsedPreview,
    raw_response_preview: raw.slice(0,3000),
    used_endpoint:ENDPOINT_GENERATE,
    used_params:Object.fromEntries(params),
    advice,
    mode: isGuest?"guest":"authenticated"
  });
}

function printHelp(){
  const C = { reset: "\x1b[0m", bold: "\x1b[1m", cyan: "\x1b[36m", gray: "\x1b[90m", green: "\x1b[32m", yellow: "\x1b[33m" };
  console.log(`
${C.bold}${C.cyan}✦ GEMINI CLI v2.1${C.reset} ${C.gray}— by Lann${C.reset}

${C.bold}PENGGUNAAN:${C.reset}
  node gemini_cli.js ${C.green}"tanya sesuatu"${C.reset}    ${C.gray}# Mode CLI (Langsung)${C.reset}
  node gemini_cli.js                     ${C.gray}# Mode REPL (Interaktif)${C.reset}

${C.bold}PERINTAH (CLI & REPL):${C.reset} ${C.gray}Gunakan awalan "/" di REPL (contoh: /vision img.jpg)${C.reset}
  ${C.cyan}ask "prompt"${C.reset}      Tanya dengan opsi (hanya CLI)
  ${C.cyan}vision <file>${C.reset}     Analisis gambar (+ prompt)
  ${C.cyan}gen-image/video${C.reset}   Generate media dari prompt
  ${C.cyan}models${C.reset}            Pilih model interaktif
  ${C.cyan}reasoning on/off${C.reset}  Toggle pemikiran (hanya REPL)
  ${C.cyan}history / chats${C.reset}   Riwayat lokal (list | read <cid>)
  ${C.cyan}files upload${C.reset}      Upload file
  ${C.cyan}inspect${C.reset}           Cek status & kuota

${C.bold}OPSI CLI:${C.reset} ${C.gray}(Bisa digabung dengan perintah di atas)${C.reset}
  ${C.cyan}--model <nama>  --reasoning  --files <f1 f2>  --save <dir>${C.reset}
`);
}

async function main(){
  const args=process.argv.slice(2);
  if(args.length > 0 && args[0].startsWith("/")) {
    args[0] = args[0].substring(1);
  }
  const C = { reset: "\x1b[0m", bold: "\x1b[1m", dim: "\x1b[2m", cyan: "\x1b[36m", green: "\x1b[32m", gray: "\x1b[90m" };

  const printAnswer = (r) => {
    console.log(JSON.stringify(r.prompt ? _compact(r) : r, null, 2));
    if(r.thoughts) {
      console.log(`\n${C.dim}${C.gray}💭 Reasoning:\n${r.thoughts}${C.reset}`);
    }
    if(r.extracted_text) {
      console.log(`\n${C.bold}${C.cyan}✦ Gemini${C.reset}\n\n${r.extracted_text}\n`);
    }
  };

  if(!args.length){
    const cookies=loadCookies();
    const diag=validateCookies(cookies);
    if(diag.missing_required.length) {
      console.log(`${C.gray}Cookies missing: ${diag.missing_required.join(",")}${C.reset}`);
    }
    let currentModel = null;
    let reasoningEnabled = false;
    const readline = await import('readline');
    
    const runRepl = async () => {
      while(true) {
        const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
        const p = await new Promise(resolve => rl.question(`${C.cyan}❯${C.reset} `, resolve));
        rl.close();
        
        const line = p.trim();
        if(!line) continue;
        if(["exit","q","quit"].includes(line.toLowerCase())) break;
        
        const cmdArgs = splitArgsRespectQuotes(line);
        const cmd = (cmdArgs[0]||"").toLowerCase();
        
        if(cmd === "/help" || cmd === "help") {
          printHelp();
          continue;
        }
        if(cmd === "/models") {
          const selected = await interactiveModelSelect();
          if (selected) {
            currentModel = selected;
            console.log(`\n${C.green}✔ Model aktif sekarang: ${currentModel}${C.reset}`);
          }
          continue;
        }
        if(cmd === "/model") {
          if(cmdArgs[1]) {
            currentModel = cmdArgs[1];
            console.log(`${C.green}✔ Model set to: ${currentModel}${C.reset}`);
          } else {
            console.log(`${C.cyan}Current model:${C.reset} ${currentModel || "default"}`);
            console.log(`${C.gray}Usage: /model <model_name>${C.reset}`);
          }
          continue;
        }
        if(cmd === "/reasoning") {
          const v = (cmdArgs[1] || "").toLowerCase();
          if (v === "on" || v === "true" || v === "1") reasoningEnabled = true;
          else if (v === "off" || v === "false" || v === "0") reasoningEnabled = false;
          else reasoningEnabled = !reasoningEnabled;
          console.log(`${C.green}✔ Reasoning (pemikiran) saat ini: ${reasoningEnabled ? "ON" : "OFF"}${C.reset}`);
          continue;
        }
        if(cmd === "/history" || cmd === "/sessions") {
          const local = loadLocalSessions();
          console.log(JSON.stringify(_injectCreator({status:"success", history: local.slice(-20), source:"local sessions.json"}),null,2));
          if(cookies["__Secure-1PSID"]){
             console.log(`\n${C.gray}Tip: python gemini_cli.py history untuk history server (advanced)${C.reset}`);
          }
          continue;
        }
        if(cmd === "/chats") {
          if (cmdArgs[1] === "list") {
            console.log(JSON.stringify(_injectCreator({status:"success", chats: loadLocalSessions().slice(-20), source:"local"}),null,2));
            console.log(`\n${C.gray}Untuk server history: python gemini_cli.py chats list (butuh login)${C.reset}`);
          } else if (cmdArgs[1] === "read") {
            const cid = cmdArgs[2];
            if(!cid) { console.log(`${C.gray}Usage: /chats read <cid>${C.reset}`); continue; }
            const local = loadLocalSessions().filter(s => (s.prompt && s.prompt.includes(cid)) || s.cid === cid);
            console.log(JSON.stringify(_injectCreator({status:"success", chat: local}),null,2));
          } else {
            console.log(`${C.gray}Usage: /chats list | /chats read <cid>${C.reset}`);
          }
          continue;
        }
        if(cmd === "/inspect") {
          process.stdout.write(`${C.gray}Thinking...${C.reset}\r`);
          const r = await sendGeminiPrompt("inspect", {model: currentModel, thinking: reasoningEnabled});
          process.stdout.write('\x1b[2K\r');
          console.log(JSON.stringify(_injectCreator({status:r.status, inspect_pure:r}),null,2));
          continue;
        }
        if(cmd === "/gen-image") {
          const prompt = cmdArgs.slice(1).join(" ");
          if(!prompt) {
             console.log(`${C.gray}Usage: /gen-image <prompt>${C.reset}`);
             continue;
          }
          process.stdout.write(`${C.gray}Generating image...${C.reset}\r`);
          const r = await sendGeminiPrompt(prompt, {model: currentModel, thinking: reasoningEnabled});
          process.stdout.write('\x1b[2K\r');
          console.log(JSON.stringify(r,null,2));
          if(r.generated_images?.length) console.log(`\n${C.green}✔ Generated ${r.generated_images.length} images${C.reset}`);
          if(r.web_images?.length) console.log(`${C.gray}Web images: ${r.web_images.length}${C.reset}`);
          continue;
        }
        if(cmd === "/gen-video") {
          const prompt = cmdArgs.slice(1).join(" ");
          if(!prompt) {
             console.log(`${C.gray}Usage: /gen-video <prompt>${C.reset}`);
             continue;
          }
          process.stdout.write(`${C.gray}Generating video...${C.reset}\r`);
          const r = await sendGeminiPrompt(prompt, {model: currentModel, thinking: reasoningEnabled});
          process.stdout.write('\x1b[2K\r');
          console.log(JSON.stringify(r,null,2));
          if(r.videos?.length) console.log(`\n${C.green}✔ Generated ${r.videos.length} videos${C.reset}`);
          continue;
        }
        if(cmd === "/vision") {
          const rest = line.slice(cmd.length).trim();
          let [img, prompt] = extractFileAndPrompt(rest);
          prompt = prompt || "describe this image";
          if(!img) {
            console.log(`${C.gray}Usage: /vision <image_path> [prompt]${C.reset}`);
            console.log(`${C.gray}Contoh: /vision "C:\\Users\\MUHAMMAD LANDO\\OneDrive\\Gambar\\Screenshots\\Cuplikan layar 2026-08-09 130242.png" deskripsikan${C.reset}`);
            continue;
          }
          // handle if img still has quotes
          img = img.replace(/^"|"$/g,'').replace(/^'|'$/g,'');
          if(!fs.existsSync(img)){
            console.log(`${C.gray}File tidak ditemukan: ${img}${C.reset}`);
            console.log(`${C.gray}Tip: pakai quotes untuk path dengan spasi, contoh: /vision "C:\\path dengan spasi\\file.png" prompt${C.reset}`);
            continue;
          }
          process.stdout.write(`${C.gray}Thinking...${C.reset}\r`);
          const r = await sendGeminiPrompt(prompt, {files: [img], model: currentModel, thinking: reasoningEnabled});
          process.stdout.write('\x1b[2K\r');
          printAnswer(r);
          continue;
        }

        process.stdout.write(`${C.gray}Thinking...${C.reset}\r`);
        const r=await sendGeminiPrompt(line, {model: currentModel, thinking: reasoningEnabled});
        process.stdout.write('\x1b[2K\r'); // clear the "Thinking..." line
        printAnswer(r);
      }
    };
    
    await runRepl();
    return;
  }
  if(args[0]==="--help"||args[0]==="-h"||args[0]==="help"){
    printHelp(); return;
  }
  if(args[0]==="models"){
    const selected = await interactiveModelSelect();
    if (selected) {
      console.log(`\n\x1b[32m✔ Model dipilih: ${selected}\x1b[0m`);
    }
    return;
  }
  if(args[0]==="inspect"){
    const r=await sendGeminiPrompt("inspect");
    console.log(JSON.stringify(_injectCreator({status:r.status, inspect_pure:r}),null,2));
    return;
  }
  if(args[0]==="vision"){
    const img=args[1]; const prompt=args.slice(2).join(" ")||"describe this image";
    if(!img){ console.log(`${C.cyan}Usage:${C.reset} vision <image> "prompt"`); return; }
    const r=await sendGeminiPrompt(prompt,{files:[img]});
    printAnswer(r);
    return;
  }
  if(args[0]==="gen-image"){
    let prompt=args.slice(1).join(" ")||"a cute cat";
    let save=null;
    const idx=args.indexOf("--save");
    if(idx!==-1){ save=args[idx+1]; prompt=args.slice(1,idx).join(" "); }
    const r=await sendGeminiPrompt(prompt);
    console.log(JSON.stringify(r,null,2));
    if(r.generated_images?.length) console.log(`\n${C.green}✔ Generated ${r.generated_images.length} images${C.reset}`);
    if(r.web_images?.length) console.log(`${C.gray}Web images: ${r.web_images.length}${C.reset}`);
    if(save && r.generated_images?.length){
      const fs2=await import('fs');
      fs2.mkdirSync(save,{recursive:true});
      for(const gi of r.generated_images){
        try{
          const resp=await fetch(gi.url);
          const buf=Buffer.from(await resp.arrayBuffer());
          const fp=path.join(save, `gen_${Date.now()}.png`);
          fs.writeFileSync(fp, buf);
          console.log(`${C.gray}Saved: ${fp}${C.reset}`);
        }catch(e){ console.log(`${C.gray}Download failed: ${e.message}${C.reset}`); }
      }
    }
    return;
  }
  if(args[0]==="ask"){
    let promptParts=[], files=[], model=null, thinking=false;
    for(let i=1;i<args.length;i++){
      const a=args[i];
      if(a==="--files"){ i++; while(i<args.length && !args[i].startsWith("--")){ if(fs.existsSync(args[i])) files.push(args[i]); else break; i++; } continue; }
      if(a==="--model"){ model=args[i+1]; i+=2; continue; }
      if(a==="--reasoning"){ thinking=true; continue; }
      if(a.startsWith("--")){i++; continue;}
      promptParts.push(a);
    }
    const prompt=promptParts.join(" ")||"Halo";
    const r=await sendGeminiPrompt(prompt,{files: files.length?files:null, model, thinking});
    printAnswer(r);
    return;
  }
  if(args[0]==="history"||args[0]==="sessions"){
    const local=loadLocalSessions();
    console.log(JSON.stringify(_injectCreator({status:"success", history: local.slice(-20), source:"local sessions.json"}),null,2));
    // coba advanced jika ada 1PSID
    const cookies=loadCookies();
    if(cookies["__Secure-1PSID"]){
      console.log("\nTip: python gemini_cli.py history untuk history server (advanced)");
    }
    return;
  }
  if(args[0]==="chats" && args[1]==="list"){
    console.log(JSON.stringify(_injectCreator({status:"success", chats: loadLocalSessions().slice(-20), source:"local"}),null,2));
    console.log("\nUntuk server history: python gemini_cli.py chats list (butuh login)");
    return;
  }
  if(args[0]==="chats" && args[1]==="read"){
    const cid=args[2];
    if(!cid){ console.log("Usage: chats read <cid>"); return; }
    const local=loadLocalSessions().filter(s=> s.prompt && s.prompt.includes(cid) || s.cid===cid);
    console.log(JSON.stringify(_injectCreator({status:"success", chat: local}),null,2));
    return;
  }
  if(args[0]==="files" && args[1]==="upload"){
    const fp=args[2];
    if(!fp){ console.log(`${C.cyan}Usage:${C.reset} files upload <file>`); return; }
    const cookies=loadCookies();
    const r1 = await new Promise((resolve,reject)=>{
      const u=new URL(ENDPOINT_INIT);
      const opts={hostname:u.hostname, path:u.pathname+u.search, method:"GET", headers:{Cookie:cookiesToHeader(cookies), "User-Agent":"Mozilla/5.0"}, maxHeaderSize: 1024*1024*2};
      const req=https.request(opts, res=>{let d=""; res.on("data",c=>d+=c); res.on("end",()=>resolve({status:res.statusCode, text:()=>d, _text:d}));});
      req.on("error",reject); req.end();
    });;
    const html=await r1.text();
    const init=extractInitData(html);
    const push=init.push_id||"feeds/mcudyrk2a4khkz";
    try{
      const fid=await syncUploadFilePure(fp,push,cookies);
      console.log(JSON.stringify(_injectCreator({status:"success", file:fp, file_id:fid}),null,2));
    }catch(e){ console.log(JSON.stringify(_injectCreator({status:"error", error:String(e)}),null,2)); }
    return;
  }
  if(args.some(a=>a.startsWith("--"))){
    let files=[], promptParts=[], model=null, thinking=false;
    for(let i=0;i<args.length;i++){
      const a=args[i];
      if(a==="--files"){ i++; while(i<args.length && !args[i].startsWith("--") && fs.existsSync(args[i])){ files.push(args[i]); i++; } i--; }
      else if(a==="--model"){ model=args[i+1]; i++; }
      else if(a==="--reasoning"){ thinking=true; }
      else if(a.startsWith("--")){}
      else promptParts.push(a);
    }
    const prompt=promptParts.join(" ")||"Halo";
    const r=await sendGeminiPrompt(prompt,{files:files.length?files:null, model, thinking});
    printAnswer(r);
    return;
  }
  const prompt=args.join(" ");
  const r=await sendGeminiPrompt(prompt, {thinking: false});
  printAnswer(r);
}

export { sendGeminiPrompt };
