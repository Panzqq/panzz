const https = require('https');
const http = require('http');
const crypto = require('crypto');

const MODELS = ['flux', 'turbo', 'sd3', 'dalle3', 'sdxl'];

function randomSeed() {
  return crypto.randomInt(100000, 9999999);
}

function isValidSize(width, height) {
  return (
    Number.isInteger(width) &&
    Number.isInteger(height) &&
    width >= 256 &&
    height >= 256 &&
    width <= 2048 &&
    height <= 2048
  );
}

function parseInput(text = '') {
  let input = String(text || '').trim();

  let model = 'flux';
  let width = 1024;
  let height = 1024;

  const sizeMatch = input.match(/--size[=\s]+(\d{3,4})x(\d{3,4})/i);
  if (sizeMatch) {
    width = parseInt(sizeMatch[1]);
    height = parseInt(sizeMatch[2]);
    input = input.replace(sizeMatch[0], '').trim();
  }

  const modelMatch = input.match(/--model[=\s]+([a-z0-9]+)/i);
  if (modelMatch) {
    model = modelMatch[1].toLowerCase();
    input = input.replace(modelMatch[0], '').trim();
  }

  if (input.includes('|')) {
    const parts = input.split('|').map(v => v.trim()).filter(Boolean);
    input = parts[0] || '';
    if (parts[1]) model = parts[1].toLowerCase();
  }

  return {
    prompt: input,
    model,
    width,
    height
  };
}

function buildImageUrl(prompt, options = {}) {
  const {
    model = 'flux',
    width = 1024,
    height = 1024,
    seed = randomSeed(),
    nologo = true
  } = options;

  const encodedPrompt = encodeURIComponent(prompt);

  const query = new URLSearchParams({
    width: String(width),
    height: String(height),
    model,
    seed: String(seed),
    nologo: String(nologo)
  });

  return {
    url: `https://image.pollinations.ai/prompt/${encodedPrompt}?${query.toString()}`,
    seed
  };
}

function getBuffer(url, redirect = 0) {
  return new Promise((resolve, reject) => {
    if (redirect > 5) return reject(new Error('Terlalu banyak redirect.'));

    const lib = url.startsWith('https') ? https : http;

    const req = lib.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/137 Mobile Safari/537.36',
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8'
      }
    }, res => {
      const status = res.statusCode || 0;

      if (status >= 300 && status < 400 && res.headers.location) {
        const nextUrl = new URL(res.headers.location, url).href;
        res.resume();
        return resolve(getBuffer(nextUrl, redirect + 1));
      }

      if (status !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${status}`));
      }

      const chunks = [];

      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => {
        const buffer = Buffer.concat(chunks);

        if (!buffer.length) {
          return reject(new Error('Gambar kosong.'));
        }

        resolve(buffer);
      });
    });

    req.setTimeout(60000, () => {
      req.destroy(new Error('Request timeout.'));
    });

    req.on('error', reject);
  });
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const inputText = text || (m.quoted && m.quoted.text) || '';

  if (!inputText) {
    return m.reply(
      `Masukkan prompt gambar.\n\n` +
      `Contoh:\n` +
      `${usedPrefix + command} kucing lucu pakai hoodie\n\n` +
      `Pakai model:\n` +
      `${usedPrefix + command} robot cyberpunk | flux\n\n` +
      `Pakai size:\n` +
      `${usedPrefix + command} anime girl cinematic --size 1024x1024\n\n` +
      `Pakai model + size:\n` +
      `${usedPrefix + command} naga api cinematic --model flux --size 1024x1024`
    );
  }

  const { prompt, model, width, height } = parseInput(inputText);

  if (!prompt) {
    return m.reply('Prompt gambarnya tidak boleh kosong.');
  }

  if (!MODELS.includes(model)) {
    return m.reply(
      `Model tidak tersedia.\n\n` +
      `Model yang bisa dipakai:\n${MODELS.map(v => `- ${v}`).join('\n')}`
    );
  }

  if (!isValidSize(width, height)) {
    return m.reply('Ukuran tidak valid. Gunakan ukuran 256x256 sampai 2048x2048.\nContoh: --size 1024x1024');
  }

  try {
    await m.reply('Sedang membuat gambar...');

    const { url, seed } = buildImageUrl(prompt, {
      model,
      width,
      height
    });

    const buffer = await getBuffer(url);

    await conn.sendMessage(m.chat, {
      image: buffer,
      caption:
        `*AI Image Generator*\n\n` +
        `*Prompt:* ${prompt}\n` +
        `*Model:* ${model}\n` +
        `*Size:* ${width}x${height}\n` +
        `*Seed:* ${seed}`
    }, { quoted: m });

  } catch (e) {
    m.reply(`Gagal membuat gambar.\n\nError: ${e.message}`);
  }
};

handler.help = handler.command = ['txt2img', 'text2img'];
handler.tags = ['ai'];

module.exports = handler;