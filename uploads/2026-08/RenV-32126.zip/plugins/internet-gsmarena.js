/**
 *   GSMARENA SCRAPER
 *
 *   [•] AUTHOR      :: DEFAN
 *   [•] WEB         :: soonex.biz.id
 *   [•] DESCRIPTION :: Search HP + ambil detail spesifikasi dari GSMArena
 *   [•] BASE        :: https://www.gsmarena.com
 *   [•] CHANNEL     :: https://whatsapp.com/channel/0029Vb89qIx1XquQoXgzdd2m
 *
 *   [!] ATTENTION:
 *   Modification without permission is prohibited.
 *   RESPECT THE AUTHOR, DO NOT REMOVE THIS WATERMARK!
 */

const axios = require('axios');
const cheerio = require('cheerio');

const BASE = 'https://www.gsmarena.com';

const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
  'Connection': 'keep-alive',
  'Referer': 'https://www.gsmarena.com/'
};

function fixUrl(url) {
  if (!url) return null;
  if (url.startsWith('//')) return 'https:' + url;
  if (url.startsWith('http')) return url;
  return BASE + '/' + url.replace(/^\//, '');
}

async function get(url) {
  const res = await axios.get(url, {
    headers: HEADERS,
    timeout: 20000
  });
  return res.data;
}

async function searchGsmarena(query) {
  const url = `${BASE}/results.php3?sQuickSearch=${encodeURIComponent(query)}`;
  const html = await get(url);
  const $ = cheerio.load(html);

  const results = [];
  const words = query.toLowerCase().split(/\s+/).filter(v => v.length > 1);

  $('.makers li').each((_, el) => {
    const a = $(el).find('a').first();
    const href = a.attr('href') || '';

    if (!href || !href.endsWith('.php')) return;

    const name = a.find('span').text().trim() || a.text().trim().replace(/\s+/g, ' ');
    if (!name) return;

    const nameLower = name.toLowerCase();
    const match = words.length ? words.some(w => nameLower.includes(w)) : true;
    if (!match) return;

    const img = fixUrl(a.find('img').attr('src'));
    const desc = a.find('img').attr('title') || name;

    results.push({
      name,
      desc,
      img,
      url: fixUrl(href),
      slug: href.replace(/\.php.*/, '')
    });
  });

  return results;
}

async function detailGsmarena(url) {
  url = fixUrl(url);

  const html = await get(url);
  const $ = cheerio.load(html);

  const name = $('h1.specs-phone-name-title').text().trim()
    || $('h1').first().text().trim()
    || 'Unknown';

  const img = fixUrl(
    $('div.specs-photo-main img').attr('src')
    || $('.specs-photo-main img').attr('src')
  );

  const rating = $('span[itemprop="ratingValue"]').text().trim() || null;
  const votes = $('span[itemprop="ratingCount"]').text().trim() || null;

  const specs = {};
  let currentSection = 'General';

  $('#specs-list table, div.specs-list table, table.specs-list').each((_, table) => {
    $(table).find('tr').each((_, row) => {
      const th = $(row).find('th');

      if (th.length) {
        currentSection = th.text().trim();
        if (!specs[currentSection]) specs[currentSection] = {};
        return;
      }

      const label = $(row).find('td.ttl').text().trim();
      const value = $(row).find('td.nfo').text().trim().replace(/\s+/g, ' ');

      if (label && value) {
        if (!specs[currentSection]) specs[currentSection] = {};
        specs[currentSection][label] = value;
      }
    });
  });

  return {
    name,
    url,
    img,
    rating: rating ? { score: rating, votes } : null,
    specs
  };
}

function pickSpec(specs, section, key) {
  return specs?.[section]?.[key] || null;
}

function formatMainSpecs(data) {
  const s = data.specs || {};
  const lines = [];

  const released = pickSpec(s, 'Launch', 'Status');
  const dimensions = pickSpec(s, 'Body', 'Dimensions');
  const weight = pickSpec(s, 'Body', 'Weight');
  const displayType = pickSpec(s, 'Display', 'Type');
  const displaySize = pickSpec(s, 'Display', 'Size');
  const resolution = pickSpec(s, 'Display', 'Resolution');
  const os = pickSpec(s, 'Platform', 'OS');
  const chipset = pickSpec(s, 'Platform', 'Chipset');
  const cpu = pickSpec(s, 'Platform', 'CPU');
  const gpu = pickSpec(s, 'Platform', 'GPU');
  const memory = pickSpec(s, 'Memory', 'Internal');

  const mainCam =
    pickSpec(s, 'Main Camera', 'Single') ||
    pickSpec(s, 'Main Camera', 'Dual') ||
    pickSpec(s, 'Main Camera', 'Triple') ||
    pickSpec(s, 'Main Camera', 'Quad');

  const selfie =
    pickSpec(s, 'Selfie camera', 'Single') ||
    pickSpec(s, 'Selfie Camera', 'Single');

  const battery = pickSpec(s, 'Battery', 'Type');
  const charging = pickSpec(s, 'Battery', 'Charging');
  const colors = pickSpec(s, 'Misc', 'Colors');
  const price = pickSpec(s, 'Misc', 'Price');

  if (released) lines.push(`> [+] Rilis: ${released}`);
  if (dimensions) lines.push(`> [+] Dimensi: ${dimensions}`);
  if (weight) lines.push(`> [+] Berat: ${weight}`);
  if (displayType) lines.push(`> [+] Layar: ${displayType}`);
  if (displaySize) lines.push(`> [+] Ukuran Layar: ${displaySize}`);
  if (resolution) lines.push(`> [+] Resolusi: ${resolution}`);
  if (os) lines.push(`> [+] OS: ${os}`);
  if (chipset) lines.push(`> [+] Chipset: ${chipset}`);
  if (cpu) lines.push(`> [+] CPU: ${cpu}`);
  if (gpu) lines.push(`> [+] GPU: ${gpu}`);
  if (memory) lines.push(`> [+] Memori: ${memory}`);
  if (mainCam) lines.push(`> [+] Kamera Utama: ${mainCam}`);
  if (selfie) lines.push(`> [+] Kamera Depan: ${selfie}`);
  if (battery) lines.push(`> [+] Baterai: ${battery}`);
  if (charging) lines.push(`> [+] Charging: ${charging}`);
  if (colors) lines.push(`> [+] Warna: ${colors}`);
  if (price) lines.push(`> [+] Harga: ${price}`);

  return lines.join('\n') || '> [-] Spesifikasi utama tidak ditemukan.';
}

async function sendDetail(conn, m, data) {
  let caption =
`乂 G S M A R E N A

\`I N F O\`
> [+] Nama: ${data.name}
> [+] Rating: ${data.rating ? `${data.rating.score}/5 (${data.rating.votes || 0} votes)` : 'Tidak tersedia'}
> [+] Link: ${data.url}

\`S P E S I F I K A S I\`
${formatMainSpecs(data)}

> Source: GSMArena`;

  if (caption.length > 3500) {
    caption = caption.slice(0, 3500) + '\n\n> [!] Teks dipotong karena terlalu panjang.';
  }

  if (data.img) {
    return conn.sendMessage(
      m.chat,
      {
        image: { url: data.img },
        caption
      },
      { quoted: m }
    );
  }

  return conn.sendMessage(
    m.chat,
    {
      text: caption
    },
    { quoted: m }
  );
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
`乂 G S M A R E N A

\`C A R A  P A K A I\`
> [+] ${usedPrefix + command} samsung s24
> [+] ${usedPrefix + command} iphone 15
> [+] ${usedPrefix}gsm-detail https://www.gsmarena.com/apple_iphone_15-12559.php`
    );
  }

  try {
    if (command === 'gsm-detail') {
      await m.reply(global.wait || '> [!] Sedang mengambil detail HP...');
      const data = await detailGsmarena(text.trim());
      return sendDetail(conn, m, data);
    }

    if (/^https?:\/\/(www\.)?gsmarena\.com\/.+\.php/i.test(text.trim())) {
      await m.reply(global.wait || '> [!] Sedang mengambil detail HP...');
      const data = await detailGsmarena(text.trim());
      return sendDetail(conn, m, data);
    }

    await m.reply(global.wait || '> [!] Sedang mencari HP di GSMArena...');

    const results = await searchGsmarena(text);

    if (!results.length) {
      return m.reply(`> [-] Tidak ditemukan hasil untuk: *${text}*`);
    }

    const listText = results.slice(0, 10).map((v, i) => {
      return `> [${i + 1}] *${v.name}*\n> [+] ${v.desc || 'No description'}\n> [+] ${v.url}`;
    }).join('\n\n');

    const caption =
`乂 G S M A R E N A

\`S E A R C H  R E S U L T\`
> [+] Query: ${text}
> [+] Result: ${results.length}

${listText}

> Pilih list di bawah untuk melihat detail spesifikasi.`;

    const datas = {
      title: `[ ${global.namebot || 'Bot'} - GSMArena Result ]`,
      sections: [
        {
          title: 'Phone Result',
          rows: results.slice(0, 10).map((v, i) => ({
            header: `Result ${i + 1}`,
            title: v.name,
            description: v.desc || 'Lihat spesifikasi detail',
            id: `${usedPrefix}gsm-detail ${v.url}`
          }))
        }
      ]
    };

    if (typeof conn.sendButtonLoc === 'function') {
      return conn.sendButtonLoc(
        m.chat,
        [
          {
            id: 'pilih',
            text: '[ Pilih HP ]',
            native: true
          },
          {
            id: `${usedPrefix}menu`,
            text: '[ Menu ]'
          }
        ],
        caption,
        ` [ ${global.namebot || 'Bot'} Powered By ${global.nameown || 'Owner'} ] `,
        m,
        {
          mentions: [m.sender],
          nativeSelectData: datas,
          thumbUrl: results[0]?.img || global.thumb || 'https://files.catbox.moe/toarxh.jpg',
          name: global.namebot || 'Renvy',
          address: 'GSMArena Search Result'
        }
      );
    }

    return conn.sendMessage(
      m.chat,
      {
        text:
`${caption}

\`C A R A  A M B I L  D E T A I L\`
> Ketik:
> ${usedPrefix}gsm-detail <link gsmarena>`
      },
      { quoted: m }
    );
  } catch (e) {
    console.error(e);
    return m.reply(`> [!] Error: ${e.message || e}`);
  }
};

handler.help = [
  'gsmarena *<nama hp>*',
  'gsm *<nama hp>*',
  'gsm-detail *<url>*'
];

handler.tags = ['internet'];

handler.command = /^(gsmarena|gsm|specshp|hpdetail|gsm-detail)$/i;

module.exports = handler;