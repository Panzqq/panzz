const axios = require('axios');
const FormData = require('form-data');

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    let q = m.quoted || m;
    let mime = (q.msg || q).mimetype || '';
    if (!/audio/.test(mime)) return m.reply(`📢 *Reply audio-nya!*\n\nContoh: ${usedPrefix + command} (sambil reply audio)`);

    let audio = await q.download();
    if (!audio) throw 'Gagal mendownload audio!';

    let { instrumental_path, vocal_path } = await vocalRemover(audio);

    await conn.sendFile(m.chat, instrumental_path, null, null, instrumen);
    await conn.sendFile(m.chat, vocal_path, null, null, vocal);

  } catch (e) {
    console.error(e);
    m.reply(e.message || 'Terjadi kesalahan saat memproses audio.');
  }
};
handler.tags = ["tools", "ai"];
handler.command = /^vocalremover$/i;
module.exports = handler;

async function vocalRemover(audioBuffer) {
  const api = axios.create({ baseURL: 'https://aivocalremover.com' });

  const getKey = async () => {
    const res = await api.get('/');
    return res.data.match(/key:"(\w+)/)[1];
  };

  const form = new FormData();
  form.append('fileName', audioBuffer, Math.random().toString(36).slice(2) + '.mpeg');

  const [key, uploadRes] = await Promise.all([
    getKey(),
    api.post('/api/v2/FileUpload', form, { headers: form.getHeaders() }).catch(e => e.response)
  ]);

  if (uploadRes.status !== 200) throw uploadRes.data || uploadRes.statusText;

  const processRes = await api.post('/api/v2/ProcessFile', new URLSearchParams({
    file_name: uploadRes.data.file_name,
    action: 'watermark_video',
    key,
    web: 'web'
  })).catch(e => e.response);

  return processRes.data;
}

const instrumen = {
  key: { remoteJid: "0@s.whatsapp.net", participant: "0@s.whatsapp.net", id: "" },
  message: { conversation: "*🎵 Audio Instrumen*" },
};

const vocal = {
  key: { remoteJid: "0@s.whatsapp.net", participant: "0@s.whatsapp.net", id: "" },
  message: { conversation: "*🎤 Audio Vokal*" },
};

global.instrumen = instrumen;
global.vocal = vocal;