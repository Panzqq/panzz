const axios = require('axios')

let handler = async (m, { text }) => {
  if (!text) return m.reply('Masukin URL nya.')

  try {
    let data = await getPastebin(text)
    return m.reply(data)
  } catch (e) {
    console.error(e)
    return m.reply('Error.')
  }
}

handler.help = ['pastebin <url>']
handler.tags = ['tools']
handler.command = ['pastebin', 'getpaste']
module.exports = handler

async function getPastebin(url) {
  let match = url.match(/pastebin\.com\/(?:raw\/)?([a-zA-Z0-9]+)/)
  if (!match) throw 'URL tidak valid'
  let rawUrl = `https://pastebin.com/raw/${match[1]}`
  let res = await axios.get(rawUrl)
  return res.data
}