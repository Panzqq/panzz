function extractVideoId(input) {
  if (!input) return null;

  const text = String(input).trim();

  if (/^[a-zA-Z0-9_-]{11}$/.test(text)) return text;

  try {
    const url = new URL(text);

    if (url.hostname.includes("youtu.be")) {
      const id = url.pathname.split("/").filter(Boolean)[0];
      return /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
    }

    if (url.hostname.includes("youtube.com")) {
      const v = url.searchParams.get("v");
      if (/^[a-zA-Z0-9_-]{11}$/.test(v)) return v;

      const parts = url.pathname.split("/").filter(Boolean);
      const index = parts.findIndex(v =>
        ["shorts", "embed", "v", "live"].includes(v)
      );

      if (index !== -1 && parts[index + 1]) {
        const id = parts[index + 1];
        return /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
      }
    }
  } catch {}

  const match = text.match(
    /(?:v=|\/shorts\/|youtu\.be\/|embed\/|\/v\/|\/live\/)([a-zA-Z0-9_-]{11})/
  );

  return match ? match[1] : null;
}

function formatDuration(seconds) {
  if (!seconds) return "Unknown";

  seconds = Number(seconds);
  if (isNaN(seconds)) return "Unknown";

  const m = Math.floor(seconds / 60);
  const s = seconds % 60;

  return `${m}:${String(s).padStart(2, "0")}`;
}

function cleanFileName(name = "video") {
  return String(name)
    .replace(/[\\/:*?"<>|]/g, "")
    .replace(/\s+/g, "_")
    .slice(0, 80);
}

function parseQuality(q) {
  if (!q) return "720p";
  const num = q.toString().replace(/[^0-9]/g, "");
  return num ? `${num}p` : "720p";
}

const downloadYtMp4 = async (url, quality = "720p") => {
  const targetQuality = parseQuality(quality);

  const res = await fetch("https://ytapi.jaky.dev/api/v1/mp4", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      url,
      quality: targetQuality
    })
  });

  if (!res.ok) {
    throw new Error(`HTTP Error: ${res.status} ${res.statusText}`);
  }

  const result = await res.json();

  if (!result.success || !result.data?.downloadUrl) {
    throw new Error(result.message || "Gagal mengonversi video MP4");
  }

  return result.data;
};

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `> *YOUTUBE VIDEO DOWNLOADER*\n\nFormat:\n${usedPrefix + command} <URL YouTube> [quality]\n\nContoh:\n${usedPrefix + command} https://youtu.be/jNQXAC9IVRw 720p`
    );
  }

  const args = text.trim().split(/\s+/);
  const url = args[0];
  const reqQuality = args[1] || "720p";

  if (!extractVideoId(url)) {
    return m.reply("> [!] URL YouTube tidak valid.");
  }

  try {
    await m.reply("> Sedang memproses video, mohon tunggu...");

    const data = await downloadYtMp4(url, reqQuality);

    const caption = `
乂 *Y O U T U B E  V I D E O*

> *Judul*     : ${data.title || "-"}
> *Channel*   : ${data.author || "-"}
> *Kualitas*  : ${data.quality || reqQuality}
> *Durasi*    : ${formatDuration(data.duration)}
> *Link*      : ${url}
`.trim();

    await conn.sendMessage(
      m.chat,
      {
        video: { url: data.downloadUrl },
        mimetype: "video/mp4",
        fileName: `${cleanFileName(data.title || "video")}.mp4`,
        caption
      },
      { quoted: m }
    );
  } catch (err) {
    console.error(err);
    return m.reply(`> [!] Gagal mengambil video.\n> *Pesan:* ${err.message || err}`);
  }
};

handler.help = ["ytv *<url> [quality]*", "ytmp4 *<url> [quality]*"];
handler.command = ["ytv", "ytmp4"];
handler.tags = ["download"];
handler.limit = true;

module.exports = handler;