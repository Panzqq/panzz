const axios = require('axios');
const fs = require('fs');
const moment = require("moment-timezone");
const { tmpFile, safeUnlinkSync } = require("../lib/tmpManager");

const handler = async (m, { conn, text, usedPrefix }) => {
    if (!text) {
        throw `🚫 *Format Salah!*\nGunakan: ${usedPrefix}brat <teks>`;
    }

    await conn.sendMessage(m.chat, {
        react: {
            text: '🎨',
            key: m.key
        }
    });

    const sources = [
        `https://aqul-brat.hf.space/api/brat?text=${encodeURIComponent(text)}`
    ];

    let success = false;

    for (let i = 0; i < sources.length; i++) {
        try {
            const response = await axios.get(sources[i], { responseType: 'arraybuffer' });
            const tempFilePath = tmpFile({ dir: "sticker/brat", prefix: "brat", ext: "jpg" });

            try {
                fs.writeFileSync(tempFilePath, response.data);

                await conn.sendImageAsSticker(m.chat, tempFilePath, m, {
                    packname: wm,
                    author: nameown
                });
            } finally {
                safeUnlinkSync(tempFilePath);
            }
            success = true;
            break;
        } catch (e) {
            console.error(`❌ Error akses ${sources[i]}:`, e.message);
            if (i === sources.length - 1) {
                throw `❌ Gagal menghasilkan stiker dari teks. Coba lagi nanti.`;
            }
        }
    }

    if (!success) {
        throw `❌ Semua server gagal diakses. Silakan coba lagi.`;
    }
};

handler.help = ['brat *[text]*'];
handler.tags = ['sticker'];
handler.command = /^brat$/i;
handler.limit = true;

module.exports = handler;