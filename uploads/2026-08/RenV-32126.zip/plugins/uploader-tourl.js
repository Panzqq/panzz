const { generateWAMessageFromContent } = global.bail;
const axios = require('axios');

const GITHUB_TOKEN = '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';
const GITHUB_USER = 'Panzqq';
const GITHUB_REPO = 'panzz';
const GITHUB_BRANCH = 'main';

function detectFileType(mime) {
  if (/image/.test(mime)) return 'Image';
  if (/video/.test(mime)) return 'Video';
  if (/audio/.test(mime)) return 'Audio';
  if (/pdf|word|excel|presentation|officedocument|text/.test(mime)) return 'Document';
  if (/zip|rar|7z|tar/.test(mime)) return 'Archive';
  if (/x-sh|x-executable|msdownload|x-msdownload/.test(mime)) return 'Executable';
  return 'Other';
}

function generateRenVFilename(ext = 'bin') {
  const code = Math.floor(10000 + Math.random() * 90000);
  return `RenV-${code}.${ext}`;
}

function getDateFolder() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

async function uploadToGitHub(buffer, filename) {
  const folder = getDateFolder();
  const path = `uploads/${folder}/${filename}`;
  const content = buffer.toString('base64');

  const res = await axios.put(`https://api.github.com/repos/${GITHUB_USER}/${GITHUB_REPO}/contents/${path}`, {
    message: `Upload ${filename}`,
    branch: GITHUB_BRANCH,
    content
  }, {
    headers: {
      Authorization: `token ${GITHUB_TOKEN}`,
      'User-Agent': 'UploaderBot/1.0'
    }
  });

  if (!res.data || !res.data.content || !res.data.content.download_url) {
    throw new Error('Gagal upload ke GitHub.');
  }

  return res.data.content.download_url;
}

let handler = async (m, { conn }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  if (!mime) throw '[×] Tidak ditemukan media untuk diupload.';

  let media = await q.download();
  let fileSizeMB = (media.length / (1024 * 1024)).toFixed(2);
  if (fileSizeMB > 20) throw '[×] Ukuran file maksimal 20 MB.';

  const ext = mime.split('/')[1] || 'bin';
  const filename = generateRenVFilename(ext);
  const filetype = detectFileType(mime);

  let downloadLink;
  try {
    downloadLink = await uploadToGitHub(media, filename);
  } catch (e) {
    throw `[×] Gagal upload ke GitHub.\n${e.message}`;
  }

  let teks = [
    `[+] GITHUB UPLOADER`,
    `[ FILE ] ${filename}`,
    `[ SIZE ] ${fileSizeMB} MB`,
    `[ TYPE ] ${filetype}`,
    `[ LINK ]`,
    `${downloadLink}`
  ].join('\n');

  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: {
          body: { text: teks },
          footer: { text: wm3 },
          nativeFlowMessage: {
            buttons: [
              { name: 'cta_copy', buttonParamsJson: `{"display_text": "Salin Link","copy_code": "${downloadLink}"}` }
            ]
          }
        }
      }
    }
  }, { quoted: m });

  await conn.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
};

handler.help = ['tourl'];
handler.tags = ['uploader'];
handler.command = /^tourl$/i;
handler.limit = true;

module.exports = handler;