const fs = require('fs');
const Runtime = require('../lib/runtime');

function formatMs(ms = 0) {
  ms = Number(ms || 0);
  if (ms < 1000) return `${ms}ms`;
  const sec = Math.floor(ms / 1000);
  const min = Math.floor(sec / 60);
  const hour = Math.floor(min / 60);
  if (hour) return `${hour}h ${min % 60}m`;
  if (min) return `${min}m ${sec % 60}s`;
  return `${sec}s`;
}

function formatBytes(bytes = 0) {
  bytes = Number(bytes || 0);
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  return `${(mb / 1024).toFixed(1)} GB`;
}

function formatTime(ts = 0) {
  if (!ts) return '-';
  try {
    return new Date(ts).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
  } catch {
    return String(ts);
  }
}

function cut(text = '', len = 130) {
  text = String(text || '').replace(/\s+/g, ' ').trim();
  return text.length > len ? text.slice(0, len - 3) + '...' : text;
}

async function sendRichOrText(conn, m, payload, fallbackText) {
  if (typeof conn.sendAIRich === 'function') {
    try {
      return await conn.sendAIRich(m.chat, payload, m);
    } catch {}
  }
  return m.reply(fallbackText);
}

let handler = async (m, { conn, args, command }) => {
  const cmd = String(command || '').toLowerCase();
  const status = Runtime.getStatus();

  if (cmd === 'guard') {
    const sub = String(args[0] || 'status').toLowerCase();
    global.renvyGuard = global.renvyGuard || {};

    if (sub === 'on') {
      global.renvyGuard.enabled = true;
      return m.reply('Renvy Guard aktif. Cooldown tetap nonaktif.');
    }

    if (sub === 'off') {
      global.renvyGuard.enabled = false;
      return m.reply('Renvy Guard dimatikan sementara.');
    }

    if (sub === 'queueon' || sub === 'queueoff') {
      return m.reply('Sistem antrian command berat sudah dihapus permanen dari bot ini — semua command sekarang selalu langsung dieksekusi.');
    }

    if (sub === 'clearcache') {
      Runtime.groupCache.clear();
      return m.reply('Group metadata cache dibersihkan.');
    }
  }



  if (cmd === 'icache' || cmd === 'intcache') {
    const sub = String(args[0] || 'status').toLowerCase();
    global.renvyGuard = global.renvyGuard || {};
    global.renvyGuard.intelligenceCache = global.renvyGuard.intelligenceCache || {};

    if (sub === 'on') {
      global.renvyGuard.intelligenceCache.enabled = true;
      return m.reply('Renvy Intelligence Cache aktif.');
    }

    if (sub === 'off') {
      global.renvyGuard.intelligenceCache.enabled = false;
      return m.reply('Renvy Intelligence Cache dimatikan sementara.');
    }

    if (sub === 'clear' || sub === 'purge') {
      await Runtime.intelligenceCache.clear();
      return m.reply('Renvy Intelligence Cache dibersihkan.');
    }

    if (sub === 'prune') {
      Runtime.intelligenceCache.prune(true);
      return m.reply('Cache expired dan cache berlebih sudah dipangkas.');
    }

    const cache = Runtime.intelligenceCache.getStatus();
    const topRows = cache.top.map((x, i) => [
      String(i + 1),
      x.command,
      String(x.hits),
      formatBytes(x.sizeBytes),
      cut(x.textPreview, 35)
    ]);

    const text = [
      '*Renvy Intelligence Cache*',
      '',
      `Status: ${cache.enabled ? 'ON' : 'OFF'}`,
      `Entries: ${cache.entries}`,
      `Size: ${formatBytes(cache.bytes)}`,
      `Hit: ${cache.hit}`,
      `Miss: ${cache.miss}`,
      `Saved: ${cache.saved}`,
      `Skipped: ${cache.skipped}`,
      `Replayed: ${cache.replayed}`,
      `Error: ${cache.error}`,
      `Last Hit: ${formatTime(cache.lastHitAt)}`,
      `Last Save: ${formatTime(cache.lastSaveAt)}`,
      '',
      cache.top.length ? '*Top Cache:*' : '*Top Cache:* -',
      ...cache.top.map((x, i) => `${i + 1}. ${x.command} | hit ${x.hits} | ${formatBytes(x.sizeBytes)} | ${cut(x.textPreview, 80)}`),
      '',
      'Subcommand:',
      '.icache on / off / clear / prune'
    ].join('\n');

    return sendRichOrText(conn, m, {
      title: 'Renvy Intelligence Cache',
      subtitle: cache.enabled ? 'Active' : 'Disabled',
      text,
      table: [
        ['Metric', 'Value'],
        ['Status', cache.enabled ? 'ON' : 'OFF'],
        ['Entries', String(cache.entries)],
        ['Size', formatBytes(cache.bytes)],
        ['Hit/Miss', `${cache.hit}/${cache.miss}`],
        ['Saved', String(cache.saved)],
        ['Skipped', String(cache.skipped)]
      ],
      suggest: ['guard', 'queue', 'icache clear']
    }, text);
  }


  if (cmd === 'backupstatus') {
    const backup = Runtime.smartBackup.getStatus();
    const latestRows = backup.latest.map((x, i) => [
      String(i + 1),
      x.mode,
      formatBytes(x.bytes),
      x.trigger || '-',
      formatTime(x.createdAt)
    ]);

    const text = [
      '*Renvy Smart Backup*',
      '',
      `Status: ${backup.enabled ? 'ON' : 'OFF'}`,
      `Auto: ${backup.auto ? 'ON' : 'OFF'}`,
      `Running: ${backup.running ? 'YES' : 'NO'}`,
      `Folder Manual: ${backup.directory}`,
      `Auto Delivery: ${backup.delivery?.whatsapp ? 'WhatsApp owner' : 'OFF'}`,
      `Auto Local File: ${backup.delivery?.deleteLocalAutoAfterSend ? 'hapus setelah terkirim' : 'simpan di panel'}`,
      `Hari ini: ${backup.todayImportant}/${backup.minImportantPerDay} backup penting`,
      `Total: ${backup.total}`,
      `Total Size: ${formatBytes(backup.bytes)}`,
      `Idle: ${backup.idle.ok ? 'YES' : 'NO'}${backup.idle.reason ? ` (${backup.idle.reason})` : ''}`,
      `Next Slot: ${backup.nextSlot ? `${backup.nextSlot.mode} @ ${backup.nextSlot.hour}:00` : '-'}`,
      `Last Skip: ${backup.lastSkip ? `${backup.lastSkip.reason} - ${formatTime(backup.lastSkip.at)}` : '-'}`,
      '',
      backup.latest.length ? '*Backup Terakhir:*' : '*Backup Terakhir:* -',
      ...backup.latest.map((x, i) => `${i + 1}. ${x.fileName}\n   Mode: ${x.mode} | ${formatBytes(x.bytes)} | ${x.trigger || '-'}\n   WA: ${x.delivery?.whatsapp?.sent ? 'sent' : x.delivery?.whatsapp?.error ? 'failed' : '-'} | Local: ${x.localDeleted ? 'deleted' : 'saved'}\n   Waktu: ${formatTime(x.createdAt)}`),
      '',
      'Command:',
      '.backupnow light',
      '.backupnow data',
      '.backupnow full'
    ].join('\n');

    return sendRichOrText(conn, m, {
      title: 'Renvy Smart Backup',
      subtitle: `${backup.todayImportant}/${backup.minImportantPerDay} important backups today`,
      text,
      table: [
        ['Metric', 'Value'],
        ['Status', backup.enabled ? 'ON' : 'OFF'],
        ['Auto', backup.auto ? 'ON' : 'OFF'],
        ['Today Important', `${backup.todayImportant}/${backup.minImportantPerDay}`],
        ['Total', String(backup.total)],
        ['Size', formatBytes(backup.bytes)],
        ['Idle', backup.idle.ok ? 'YES' : 'NO']
      ],
      suggest: ['backupnow light', 'backupnow data', 'guard']
    }, text);
  }

  if (cmd === 'backupnow') {
    const mode = ['light', 'data', 'full'].includes(String(args[0] || '').toLowerCase())
      ? String(args[0]).toLowerCase()
      : 'light';

    await m.reply(`⏳ Membuat Smart Backup mode ${mode}...`);

    const result = await Runtime.smartBackup.createBackup(mode, {
      force: true,
      forceManual: true,
      trigger: 'manual',
      reason: `owner-command-${mode}`
    });

    if (!result.ok) {
      return m.reply(`❌ Backup gagal/skip: ${result.reason || 'unknown'}`);
    }

    const caption = [
      '✅ Renvy Smart Backup selesai.',
      '',
      `Mode: ${result.mode}`,
      `File: ${result.fileName}`,
      `Ukuran: ${formatBytes(result.bytes)}`,
      `Source Files: ${result.sourceFiles}`,
      `Waktu: ${formatTime(result.createdAt)}`,
      '',
      'Backup ini sudah disimpan di folder backups/smart dan dikirim ke chat ini.',
      'Cache besar, session, node_modules, tmp, dan backup lama tidak ikut dimasukkan.'
    ].join('\n');

    return conn.sendMessage(m.chat, {
      document: fs.readFileSync(result.path),
      mimetype: 'application/zip',
      fileName: result.fileName,
      caption
    }, { quoted: m });
  }

  if (cmd === 'unquarantine') {
    const plugin = args.join(' ').trim();
    if (!plugin) return m.reply('Masukkan nama plugin. Contoh: .unquarantine download-play.js');
    const ok = Runtime.quarantine.clear(plugin);
    return m.reply(ok ? `Plugin ${plugin} sudah dikeluarkan dari quarantine.` : `Plugin ${plugin} tidak sedang dikarantina.`);
  }

  if (cmd === 'quarantine') {
    const list = Runtime.quarantine.list();
    if (!list.length) return m.reply('Tidak ada plugin yang sedang dikarantina.');

    const rows = list.map((x, i) => [
      String(i + 1),
      x.plugin,
      formatMs(x.remainingMs),
      cut(x.reason, 60)
    ]);

    const text = [
      '*Renvy Guard - Quarantine*',
      '',
      ...list.map((x, i) => `${i + 1}. ${x.plugin}\n   Sisa: ${formatMs(x.remainingMs)}\n   Reason: ${cut(x.reason, 100)}`)
    ].join('\n');

    return sendRichOrText(conn, m, {
      title: 'Renvy Guard',
      text: 'Plugin yang sedang dikarantina karena error berulang.',
      table: [['#', 'Plugin', 'Sisa', 'Reason'], ...rows],
      suggest: ['guard', 'errcmd', 'slowcmd']
    }, text);
  }

  if (cmd === 'queue') {
    const q = Runtime.queue.getStatus();
    const text = [
      '*Renvy Guard - Queue*',
      '',
      `Running: ${q.running}`,
      `Pending: ${q.pending}`,
      `Completed: ${q.completed}`,
      `Rejected: ${q.rejected}`,
      `Duplicate Keys: ${q.activeDuplicateKeys}`,
      `Last Run: ${formatTime(q.lastRunAt)}`,
      '',
      q.next.length ? '*Next Jobs:*' : '*Next Jobs:* -',
      ...q.next.map((x, i) => `${i + 1}. ${x.command} (${x.plugin})`)
    ].join('\n');

    return sendRichOrText(conn, m, {
      title: 'Renvy Guard Queue',
      text,
      table: [
        ['Metric', 'Value'],
        ['Running', String(q.running)],
        ['Pending', String(q.pending)],
        ['Completed', String(q.completed)],
        ['Rejected', String(q.rejected)]
      ],
      suggest: ['guard', 'slowcmd', 'errcmd']
    }, text);
  }

  if (cmd === 'slowcmd') {
    const rows = Runtime.profiler.listSlow(10);
    if (!rows.length) return m.reply('Belum ada data slow command. Pakai bot beberapa saat dulu.');

    const text = [
      '*Renvy Guard - Slow Commands*',
      '',
      ...rows.map((x, i) => `${i + 1}. ${x.plugin}\n   Avg: ${formatMs(x.avgMs)} | Max: ${formatMs(x.maxMs)} | Total: ${x.total}`)
    ].join('\n');

    return sendRichOrText(conn, m, {
      title: 'Renvy Guard Slow Commands',
      text: 'Plugin/command dengan rata-rata eksekusi paling lambat.',
      table: [['#', 'Plugin', 'Avg', 'Max', 'Total'], ...rows.map((x, i) => [String(i + 1), x.plugin, formatMs(x.avgMs), formatMs(x.maxMs), String(x.total)])],
      suggest: ['guard', 'errcmd', 'queue']
    }, text);
  }

  if (cmd === 'errcmd') {
    const rows = Runtime.profiler.listErrors(10);
    if (!rows.length) return m.reply('Belum ada command error yang tercatat.');

    const text = [
      '*Renvy Guard - Error Commands*',
      '',
      ...rows.map((x, i) => `${i + 1}. ${x.plugin}\n   Error: ${x.error} | Total: ${x.total}\n   Last: ${cut(x.lastError, 100)}`)
    ].join('\n');

    return sendRichOrText(conn, m, {
      title: 'Renvy Guard Error Commands',
      text: 'Plugin/command dengan error terbanyak.',
      table: [['#', 'Plugin', 'Error', 'Total', 'Last Error'], ...rows.map((x, i) => [String(i + 1), x.plugin, String(x.error), String(x.total), cut(x.lastError, 50)])],
      suggest: ['guard', 'slowcmd', 'quarantine']
    }, text);
  }

  const monitor = status.monitor;
  const profiler = status.profiler;
  const q = status.queue;
  const quarantine = status.quarantine;
  const groupCache = status.groupCache;
  const cache = status.intelligenceCache;
  const backup = status.smartBackup;

  const text = [
    '*Renvy Runtime Guardian*',
    '',
    `Status: ${monitor.status}`,
    `Uptime: ${formatMs(monitor.uptimeMs)}`,
    `Event Loop Lag: ${monitor.lagMs}ms`,
    `Avg Lag: ${monitor.avgLagMs}ms`,
    `Max Lag: ${monitor.maxLagMs}ms`,
    `Heap Used: ${monitor.memory.heapUsedMb} MB`,
    `RSS: ${monitor.memory.rssMb} MB`,
    '',
    '*Queue*',
    `Running: ${q.running}`,
    `Pending: ${q.pending}`,
    `Completed: ${q.completed}`,
    '',
    '*Profiler*',
    `Today Total: ${profiler.today.total}`,
    `Today Success: ${profiler.today.success}`,
    `Today Error: ${profiler.today.error}`,
    `Total Tracked: ${profiler.total}`,
    '',
    '*Protection*',
    `Quarantine: ${quarantine.length}`,
    `Group Cache: ${groupCache.size}`,
    `Intelligence Cache: ${cache.entries} entries / ${formatBytes(cache.bytes)}`,
    `Cache Hit/Miss: ${cache.hit}/${cache.miss}`,
    `Smart Backup: ${backup.todayImportant}/${backup.minImportantPerDay} today | ${backup.total} files`,
    `Cooldown: OFF`
  ].join('\n');

  return sendRichOrText(conn, m, {
    title: 'Renvy Runtime Guardian',
    subtitle: 'No cooldown mode',
    text,
    table: [
      ['Metric', 'Value'],
      ['Status', monitor.status],
      ['Uptime', formatMs(monitor.uptimeMs)],
      ['Lag', `${monitor.lagMs}ms`],
      ['Heap', `${monitor.memory.heapUsedMb} MB`],
      ['Queue', `${q.running} running / ${q.pending} pending`],
      ['Today', `${profiler.today.total} cmd / ${profiler.today.error} err`],
      ['Quarantine', String(quarantine.length)],
      ['I-Cache', `${cache.entries} entries / ${formatBytes(cache.bytes)}`],
      ['Cache Hit/Miss', `${cache.hit}/${cache.miss}`],
      ['Smart Backup', `${backup.todayImportant}/${backup.minImportantPerDay} today`],
      ['Cooldown', 'OFF']
    ],
    suggest: ['slowcmd', 'errcmd', 'queue', 'icache', 'backupstatus']
  }, text);
};

handler.help = handler.command = ['guard', 'slowcmd', 'errcmd', 'queue', 'quarantine', 'unquarantine', 'icache', 'intcache', 'backupstatus', 'backupnow'];
handler.tags = ['owner'];
handler.owner = true;

module.exports = handler;
