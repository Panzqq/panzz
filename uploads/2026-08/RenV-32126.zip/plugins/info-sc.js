let handler = async (m, { conn, args, usedPrefix, command }) => {
  let plugins = Object.values(global.plugins).filter(v => v.help && !v.disabled);

  let categorizedHelp = plugins.reduce((acc, plugin) => {
    if (plugin.tags && Array.isArray(plugin.tags)) {
      plugin.tags.forEach(tag => {
        if (!acc[tag]) acc[tag] = { commands: [], count: 0 };
        if (Array.isArray(plugin.help)) {
          acc[tag].commands.push(...plugin.help);
          acc[tag].count += plugin.help.length;
        }
      });
    }
    return acc;
  }, {});

  let totalCommands = Object.values(categorizedHelp).reduce((sum, { count }) => sum + count, 0);

  let featureList = Object.keys(categorizedHelp).map(tag => {
    let count = categorizedHelp[tag].count;
    return `> [+] \`${tag.toUpperCase()}\`: ${count} command${count > 1 ? 's' : ''}`;
  }).join('\n');

  let infoText = `
\`=== ${namebot} v${version} ===\`
> Type          : Plugin < CJS >
> Total Features: ${totalCommands}
> Price         : Rp 40,000

\`--- BENEFITS ---\`
> [+] Lightweight (~5MB)
> [+] Scraping Features (80%)
> [+] Payment Gateway Support (Saweria)
> [+] Lifetime Free Updates
> [+] Button Support (List, Image, Video, Doc)

\`--- FEATURE CATEGORIES ---\`
${featureList}

\`--- NOTE ---\`
> This script is not for resale or distribution.
  `.trim();

  let menu = [{
    rows: [
      { title: "Bot Menu", body: "Browse available commands", command: ".menu" },
      { title: "Contact Owner", body: "Chat with the bot owner directly", command: ".owner" },
      { title: "Server Status", body: "Check the bot server status", command: ".ping" }
    ]
  }];

  let footer = `
\`───────────────\`
Script by Repan
Do not sell or share this script!
\`───────────────\`
`.trim();

  conn.sendList(m.chat, "🚀 Tap Below to Explore 🚀", menu, fdoc, {
    body: infoText,
    footer: footer,
    url: thumb
  });
};

handler.help = ['sc'];
handler.tags = ['main'];
handler.command = /^(sc|script)$/i;
handler.limit = true;

module.exports = handler;