const https = require('https');
const { URL } = require('url');
const crypto = require('crypto');

// ========================================
// ALIGHT MOTION PREMIUM GENERATOR V3.0
// Monitor inbox mode - User login manual
// ========================================

class AlightMotionMonitor {
  constructor(config = {}) {
    this.userAgent = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36';
    this.debug = config.debug !== false;
    this.pollInterval = config.pollInterval || 5000; // 5 seconds
  }

  _log(...args) {
    if (this.debug) console.log(`[AM-MON ${new Date().toISOString().slice(11, 19)}]`, ...args);
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async _httpsRequest(url, options = {}) {
    return new Promise((resolve, reject) => {
      const urlObj = new URL(url);
      const reqOptions = {
        hostname: urlObj.hostname,
        port: urlObj.port || 443,
        path: urlObj.pathname + urlObj.search,
        method: options.method || 'GET',
        headers: options.headers || {},
        timeout: options.timeout || 30000
      };

      const req = https.request(reqOptions, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            body: data
          });
        });
      });

      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy();
        reject(new Error('Request timeout'));
      });

      if (options.body) {
        req.write(options.body);
      }
      req.end();
    });
  }

  // ========================================
  // TEMP MAIL: tempmail.lol implementation
  // ========================================
  async _createTempMailLol() {
    this._log('📧 Creating temp email via tempmail.lol...');
    
    const res = await this._httpsRequest('https://api.tempmail.lol/generate', {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });
    
    if (res.statusCode !== 200) {
      throw new Error(`Failed to create tempmail.lol account: ${res.statusCode}`);
    }

    const data = JSON.parse(res.body);
    this._log(`✓ Email created: ${data.address}`);
    
    return {
      email: data.address,
      token: data.token
    };
  }

  async _getTempMailLolMessages(token) {
    const res = await this._httpsRequest(`https://api.tempmail.lol/auth/${token}`, {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });

    if (res.statusCode === 200) {
      const data = JSON.parse(res.body);
      return data.email || [];
    }
    return [];
  }

  _extractMagicLink(text) {
    if (!text) return null;
    
    // Extract full magic link URL
    const patterns = [
      /https:\/\/alight-creative\.firebaseapp\.com\/__\/auth\/links\?[^"'\s<>]+/i,
      /https:\/\/alightcreative\.com\/auth_action\/\?[^"'\s<>]+/i,
      /https:\/\/[^"'\s<>]+oobCode=[^"'\s<>]+/i
    ];

    for (const pattern of patterns) {
      const match = pattern.exec(text);
      if (match) {
        // Clean up HTML entities
        return match[0].replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#x3D;/g, '=');
      }
    }

    return null;
  }

  async monitorInbox(mailAccount, onLinkReceived, timeoutMs = 300000) {
    this._log('📬 Monitoring inbox for verification link...');
    this._log(`⏱️ Checking every ${this.pollInterval / 1000} seconds...`);
    
    const start = Date.now();
    let checkCount = 0;
    let lastMessageCount = 0;

    while (Date.now() - start < timeoutMs) {
      checkCount++;
      
      try {
        const messages = await this._getTempMailLolMessages(mailAccount.token);
        
        if (messages.length > lastMessageCount) {
          this._log(`📨 New message detected! (${messages.length} total)`);
          lastMessageCount = messages.length;
        }
        
        for (const msg of messages) {
          if (msg.from && (msg.from.includes('noreply') || msg.from.includes('firebase') || msg.from.includes('alight'))) {
            const fullText = (msg.html || '') + (msg.body || '');
            const magicLink = this._extractMagicLink(fullText);
            
            if (magicLink) {
              this._log(`✓ Verification link found!`);
              await onLinkReceived(magicLink);
              return { success: true, link: magicLink, checksPerformed: checkCount };
            }
          }
        }
        
        // Show progress
        if (checkCount % 6 === 0) {
          const elapsed = Math.floor((Date.now() - start) / 1000);
          this._log(`⏳ Still monitoring... (${elapsed}s elapsed, ${checkCount} checks)`);
        }
        
      } catch (error) {
        this._log(`⚠️ Check failed: ${error.message}`);
      }
      
      await this._sleep(this.pollInterval);
    }

    this._log('⏰ Monitoring timeout reached');
    return { success: false, checksPerformed: checkCount };
  }

  // ========================================
  // MAIN WORKFLOW
  // ========================================
  async generateAndMonitor(sendToUser = null) {
    console.log('==================================================');
    console.log('🚀 Alight Motion Premium Generator V3.0');
    console.log('   Monitor Mode - Manual Login');
    console.log('==================================================\n');

    try {
      // Step 1: Create temp email
      const mailAccount = await this._createTempMailLol();
      
      if (sendToUser) {
        await sendToUser(
          `📧 *EMAIL PREMIUM BERHASIL DIBUAT!*\n\n` +
          `Email: \`${mailAccount.email}\`\n\n` +
          `━━━━━━━━━━━━━━━━━━━\n` +
          `📱 *LANGKAH SELANJUTNYA:*\n` +
          `━━━━━━━━━━━━━━━━━━━\n\n` +
          `1. Buka aplikasi *Alight Motion*\n` +
          `2. Tap *Sign In* → *Continue with Email*\n` +
          `3. Masukkan email di atas\n` +
          `4. Tap *Send Sign-In Link*\n\n` +
          `⏳ _Bot sedang memantau inbox..._\n` +
          `_Link verifikasi akan dikirim otomatis begitu masuk!_`
        );
      }

      // Step 2: Monitor inbox and send link when received
      const result = await this.monitorInbox(
        mailAccount,
        async (link) => {
          if (sendToUser) {
            await sendToUser(
              `✅ *LINK VERIFIKASI DITERIMA!*\n\n` +
              `🔗 *Klik link ini untuk aktivasi:*\n` +
              `${link}\n\n` +
              `━━━━━━━━━━━━━━━━━━━\n` +
              `📲 *CARA PAKAI:*\n` +
              `━━━━━━━━━━━━━━━━━━━\n\n` +
              `*PENTING:* Jangan paste ke browser!\n\n` +
              `✅ *Metode 1 (Recommended):*\n` +
              `1. Copy link di atas\n` +
              `2. Kirim ke chat WA sendiri\n` +
              `3. Klik dari dalam WA\n` +
              `4. Pilih "Buka di Alight Motion"\n` +
              `5. Premium aktif! ✨\n\n` +
              `✅ *Metode 2 (Alternatif):*\n` +
              `1. Copy link di atas\n` +
              `2. Paste ke browser HP\n` +
              `3. Akan redirect ke AM app\n` +
              `4. Premium aktif! ✨\n\n` +
              `⏰ _Link valid 10 menit dari sekarang_`
            );
          }
        }
      );

      return {
        success: result.success,
        email: mailAccount.email,
        checksPerformed: result.checksPerformed,
        timestamp: new Date().toISOString()
      };

    } catch (error) {
      this._log(`❌ Error: ${error.message}`);
      throw error;
    }
  }
}

// ========================================
// WHATSAPP BOT HANDLER
// ========================================
let handler = async (m, { conn }) => {
  await m.reply('🚀 *Membuat Email Premium...*\n\n⏳ _Mohon tunggu sebentar..._');

  try {
    const monitor = new AlightMotionMonitor({ debug: true, pollInterval: 5000 });
    
    const sendToUser = async (text) => {
      await m.reply(text);
    };

    const result = await monitor.generateAndMonitor(sendToUser);
    
    if (!result.success) {
      await m.reply(
        `⏰ *Monitoring Timeout*\n\n` +
        `Email: \`${result.email}\`\n\n` +
        `Bot sudah menunggu 5 menit tapi belum ada link masuk.\n\n` +
        `*Kemungkinan:*\n` +
        `• Anda belum input email di Alight Motion\n` +
        `• Email belum di-send dari AM\n` +
        `• Ada delay dari Firebase\n\n` +
        `*Solusi:*\n` +
        `1. Cek inbox manual di: https://tempmail.lol\n` +
        `2. Login dengan email: \`${result.email}\`\n` +
        `3. Klik link verifikasi yang ada\n\n` +
        `Atau coba generate email baru dengan ketik \`.amprem\` lagi.`
      );
    }

  } catch (error) {
    console.error('Error:', error);
    await m.reply(`❌ *Terjadi Kesalahan:*\n${error.message}\n\n_Silakan coba lagi._`);
  }
};

handler.help = handler.command = ['amprem', 'ampremnew'];
handler.tags = ['premium'];

module.exports = handler;

// Export class untuk testing
if (typeof module !== 'undefined' && module.exports) {
  module.exports.AlightMotionMonitor = AlightMotionMonitor;
}