const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');
const { writeFile, mkdir } = require('node:fs/promises');
const { existsSync } = require('node:fs');
const { join } = require('node:path');

let handler = async (m, { conn, text, command }) => {
    let chatText = text || (m.quoted ? m.quoted.text : null);

    if (!chatText) {
        return conn.sendMessage(m.chat, {
            text: `⚡ *TikTok Chat Maker*\n\n` +
                  `Cara pakai:\n` +
                  `${command} <pesan>\n\n` +
                  `Contoh:\n` +
                  `${command} Just friend kok cemburu 😂\n\n` +
                  `Nama otomatis diambil dari nama WhatsApp kamu.`
        }, { quoted: m });
    }

    let username = m.pushName || m.sender.split('@')[0];
    const avatarUrl = `https://i.pravatar.cc/300?u=${encodeURIComponent(username)}`;

    try {
        const outputPath = join(__dirname, `ttchat-${Date.now()}.png`);
        const resultPath = await renderTikTokChat(username, chatText.trim(), avatarUrl, outputPath);

        await conn.sendMessage(m.chat, {
            image: { url: resultPath },
            caption: `✅ *TikTok Chat Screenshot*\n\n👤 Nama: ${username}\n💬 Pesan: ${chatText}`
        }, { quoted: m });

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, { text: `❌ Gagal membuat gambar.\n${e.message}` }, { quoted: m });
    }
};

async function renderTikTokChat(username, chatText, avatarSrc, outputPath) {
    const ASSETS_DIR = join(__dirname, 'assets');
    const FONTS_DIR = join(ASSETS_DIR, 'fonts');
    const TEMPLATE_PATH = join(ASSETS_DIR, 'template.png');
    const TEMPLATE_URL = 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/qyzwa.png';

    const FONT_ASSETS = [
        { name: 'PlusJakartaSans-Regular', file: 'PlusJakartaSans-Regular.ttf', url: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/PlusJakartaSans-Regular.ttf', family: 'Plus Jakarta Sans' },
        { name: 'PlusJakartaSans-Medium', file: 'PlusJakartaSans-Medium.ttf', url: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/PlusJakartaSans-Medium.ttf', family: 'Plus Jakarta Sans' },
        { name: 'PlusJakartaSans-Bold', file: 'PlusJakartaSans-Bold.ttf', url: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/PlusJakartaSans-Bold.ttf', family: 'Plus Jakarta Sans' },
        { name: 'FontAwesome-Solid', file: 'fa-solid-900.ttf', url: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/ttqc/fa-solid-900.ttf', family: 'Font Awesome 6 Free' },
        { name: 'NotoColorEmoji', file: 'NotoColorEmoji.ttf', url: 'https://github.com/googlefonts/noto-emoji/raw/main/fonts/NotoColorEmoji.ttf', family: 'Noto Color Emoji' },
    ];

    const MENU_ICONS = [
        { unicode: '\uf3e5', text: 'Balas', color: '#000000' },
        { unicode: '\uf064', text: 'Teruskan', color: '#000000' },
        { unicode: '\uf0c5', text: 'Salin', color: '#000000' },
        { unicode: '\uf1ab', text: 'Terjemahkan', color: '#000000' },
        { unicode: '\uf2ed', text: 'Hapus untuk saya', color: '#000000' },
        { unicode: '\uf024', text: 'Laporkan', color: '#ea4335' },
    ];

    const config = {
        topPPX: 183, topPPY: 83, topPPRadius: 42,
        topNameX: 250, topNameY: 82, topNameSize: 34,
        chatPPX: 75, chatPPRadius: 38,
        textX: 175, textY: 962,
        bubbleWidth: 520, textSize: 30,
        bubbleBgColor: '#ffffff', textColor: '#161823',
    };

    if (!existsSync(ASSETS_DIR)) await mkdir(ASSETS_DIR, { recursive: true });
    if (!existsSync(FONTS_DIR)) await mkdir(FONTS_DIR, { recursive: true });

    if (!existsSync(TEMPLATE_PATH)) {
        const https = require('https');
        const buffer = await new Promise((res, rej) => https.get(TEMPLATE_URL, r => {
            const chunks = []; r.on('data', c => chunks.push(c)); r.on('end', () => res(Buffer.concat(chunks)));
        }).on('error', rej));
        await writeFile(TEMPLATE_PATH, buffer);
    }

    for (const font of FONT_ASSETS) {
        const dest = join(FONTS_DIR, font.file);
        if (!existsSync(dest)) {
            const https = require('https');
            const buffer = await new Promise((res, rej) => https.get(font.url, r => {
                const chunks = []; r.on('data', c => chunks.push(c)); r.on('end', () => res(Buffer.concat(chunks)));
            }).on('error', rej));
            await writeFile(dest, buffer);
            GlobalFonts.registerFromPath(dest, font.family);
        }
    }

    const templateImage = await loadImage(TEMPLATE_PATH);
    const avatarImage = await loadImage(avatarSrc);

    const canvas = createCanvas(1080 * 2, 2280 * 2);
    const ctx = canvas.getContext('2d');

    ctx.scale(2, 2);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    ctx.drawImage(templateImage, 0, 0, 1080, 2280);

    ctx.save();
    ctx.beginPath();
    ctx.arc(config.topPPX, config.topPPY, config.topPPRadius, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(avatarImage, config.topPPX - config.topPPRadius, config.topPPY - config.topPPRadius, config.topPPRadius*2, config.topPPRadius*2);
    ctx.restore();

    ctx.font = `bold ${config.topNameSize}px 'Plus Jakarta Sans'`;
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(username, config.topNameX, config.topNameY);

    ctx.font = `500 ${config.textSize}px 'Plus Jakarta Sans'`;
    const lines = wrapText(ctx, chatText, config.bubbleWidth - 52);
    const lineH = config.textSize * 1.45;

    let maxW = 0;
    for (const l of lines) if (ctx.measureText(l).width > maxW) maxW = ctx.measureText(l).width;

    const padX = 30, padY = 24;
    const bubbleW = Math.max(maxW + padX * 2, 180);
    const bubbleH = lines.length * lineH + padY * 2;
    const bubbleX = config.textX - padX;
    const bubbleY = config.textY - padY;

    ctx.save();
    ctx.beginPath();
    ctx.arc(config.chatPPX, bubbleY + bubbleH / 2, config.chatPPRadius, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(avatarImage, config.chatPPX - config.chatPPRadius, bubbleY + bubbleH/2 - config.chatPPRadius, config.chatPPRadius*2, config.chatPPRadius*2);
    ctx.restore();

    ctx.fillStyle = config.bubbleBgColor;
    ctx.beginPath();
    ctx.roundRect(bubbleX, bubbleY, bubbleW, bubbleH, 35);
    ctx.fill();

    ctx.fillStyle = config.textColor;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    lines.forEach((line, i) => {
        ctx.fillText(line, config.textX, config.textY + i * lineH + config.textSize / 2);
    });

    const menuX = 90, menuY = bubbleY + bubbleH + 28;
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.roundRect(menuX, menuY, 565, 580, 40);
    ctx.fill();

    const itemH = 90, iconX = menuX + 60, labelX = menuX + 130;
    MENU_ICONS.forEach((item, i) => {
        const cy = menuY + 25 + i * itemH + itemH / 2;
        ctx.fillStyle = item.color;
        ctx.font = `900 34px 'Font Awesome 6 Free'`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(item.unicode, iconX, cy);

        ctx.fillStyle = '#000000';
        ctx.font = `500 34px 'Plus Jakarta Sans'`;
        ctx.textAlign = 'left';
        ctx.fillText(item.text, labelX, cy);
    });

    const pngData = await canvas.encode('png');
    await writeFile(outputPath, pngData);
    return outputPath;
}

function wrapText(ctx, text, maxWidth) {
    const words = text.split(/(\s+)/);
    const lines = [];
    let currentLine = '';
    for (const word of words) {
        if (!word) continue;
        const testLine = currentLine + word;
        if (ctx.measureText(testLine).width > maxWidth) {
            if (currentLine) lines.push(currentLine.trimEnd());
            currentLine = word.trimStart();
        } else {
            currentLine = testLine;
        }
    }
    if (currentLine.trim()) lines.push(currentLine.trimEnd());
    return lines;
}

handler.help = ['ttchat'];
handler.command = ['ttchat', 'tiktokchat', 'chattt'];
handler.tags = ['maker'];

module.exports = handler;