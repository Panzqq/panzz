const cp = require("child_process");
const { promisify } = require("util");
const exec = promisify(cp.exec).bind(cp);

let handler = async (m) => {
  const currentPath = process.cwd(); 
  let o;
  try {
    o = await exec(`
      cd "${currentPath}" &&
      find . -type f | wc -l &&
      du -h --max-depth=1 &&
      du -sh
    `);
  } catch (e) {
    o = e;
  } finally {
    let { stdout, stderr } = o;
    if (stdout?.trim()) {
      const output = stdout.trim().split("\n");
      const totalFiles = output.shift();
      const totalSize = output.pop();
      const lines = output.map(line => `> [+] ${line}`).join("\n");

      const response = `
\`=== DISK USAGE REPORT ===\`
> [+] Path            : ${currentPath}
> [+] Total Files     : ${totalFiles} file
> [+] Total Size      : ${totalSize}

\`--- Folder Breakdown ---\`
${lines}

\`--- End of Report ---\`
      `.trim();

      m.reply(response); // Backtick tunggal
    }
    if (stderr?.trim()) m.reply("`ERROR:\n" + stderr + "`");
  }
};

handler.help = ["disk"].map(a => a + " *[cek penggunaan disk di direktori bot]*");
handler.tags = ["info"];
handler.command = ["disk"];

module.exports = handler;