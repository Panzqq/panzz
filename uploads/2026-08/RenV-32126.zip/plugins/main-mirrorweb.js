const fs = require("fs");
const fsp = fs.promises;
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const { execFile } = require("child_process");
const axios = require("axios");
const cheerio = require("cheerio");

const TIMEOUT = 60000;
const DEFAULT_DEPTH = 2;
const MAX_PAGES = 500;
const MAX_FILE_BYTES = 40 * 1024 * 1024; // 40 MB per file
const USER_AGENT =
  "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";

function safeName(input) {
  return String(input || "")
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "_")
    .replace(/\s+/g, "_")
    .replace(/\.+$/, "")
    .slice(0, 180) || "output";
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function md5(text) {
  return crypto.createHash("md5").update(String(text)).digest("hex").slice(0, 10);
}

function getSiteName(hostname) {
  const clean = String(hostname || "")
    .replace(/^www\./, "")
    .replace(/:\d+$/, "");

  const parts = clean.split(".").filter(Boolean);

  if (parts.length >= 3 && parts.at(-2) === "my" && parts.at(-1) === "id") {
    return parts.at(-3);
  }

  if (parts.length >= 2) return parts.at(-2);
  return parts[0] || "output";
}

function getExtFromContentType(contentType) {
  const type = String(contentType || "").split(";")[0].trim().toLowerCase();

  const map = {
    "text/html": ".html",
    "text/plain": ".txt",
    "text/css": ".css",
    "text/javascript": ".js",
    "application/javascript": ".js",
    "application/x-javascript": ".js",
    "application/json": ".json",
    "application/xml": ".xml",
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "image/svg+xml": ".svg",
    "image/x-icon": ".ico",
    "font/woff": ".woff",
    "font/woff2": ".woff2",
    "font/ttf": ".ttf",
    "font/otf": ".otf",
    "video/mp4": ".mp4",
    "video/webm": ".webm",
    "audio/mpeg": ".mp3",
    "audio/mp4": ".m4a",
    "audio/wav": ".wav",
    "application/pdf": ".pdf",
    "application/zip": ".zip"
  };

  return map[type] || "";
}

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function isHttpUrl(u) {
  try {
    const x = new URL(u);
    return x.protocol === "http:" || x.protocol === "https:";
  } catch {
    return false;
  }
}

function normalizeUrl(raw, baseUrl) {
  if (!raw) return null;
  const str = String(raw).trim();

  if (
    !str ||
    str.startsWith("data:") ||
    str.startsWith("mailto:") ||
    str.startsWith("tel:") ||
    str.startsWith("javascript:") ||
    str.startsWith("#")
  ) {
    return null;
  }

  try {
    if (str.startsWith("//")) {
      const base = new URL(baseUrl);
      return `${base.protocol}${str}`;
    }
    return new URL(str, baseUrl).href;
  } catch {
    return null;
  }
}

function sameOrigin(a, b) {
  try {
    const ua = new URL(a);
    const ub = new URL(b);
    return ua.origin === ub.origin;
  } catch {
    return false;
  }
}

function splitPathnameForPage(urlObj) {
  let pathname = decodeURIComponent(urlObj.pathname || "/");
  if (!pathname || pathname === "/") pathname = "/index.html";
  else if (pathname.endsWith("/")) pathname += "index.html";
  else if (!path.extname(pathname)) pathname += "/index.html";

  return pathname;
}

function splitPathnameForAsset(urlObj, contentType) {
  let pathname = decodeURIComponent(urlObj.pathname || "/");
  const hasExt = !!path.extname(pathname);

  if (!pathname || pathname === "/") {
    pathname = "/index";
  }

  if (!hasExt) {
    const ext = getExtFromContentType(contentType) || ".bin";
    pathname += ext;
  }

  return pathname;
}

function urlToLocalPath(url, siteRoot, contentType, isPage = false) {
  const u = new URL(url);
  const pathname = isPage
    ? splitPathnameForPage(u)
    : splitPathnameForAsset(u, contentType);

  const safeParts = pathname
    .split("/")
    .filter(Boolean)
    .map((seg) => safeName(seg));

  const queryHash = u.search ? `__q_${md5(u.search)}` : "";
  const last = safeParts.pop() || "index.html";

  let finalLast = last;
  if (queryHash) {
    const ext = path.extname(last);
    const base = ext ? path.basename(last, ext) : last;
    finalLast = `${base}${queryHash}${ext}`;
  }

  const localPath = path.join(siteRoot, ...safeParts, finalLast);
  return localPath;
}

function toPosixRelative(fromFile, toFile) {
  let rel = path.relative(path.dirname(fromFile), toFile);
  if (!rel) rel = ".";
  return rel.split(path.sep).join("/");
}

function rewriteSrcset(value, baseUrl, resolveLocal) {
  return String(value || "")
    .split(",")
    .map((item) => {
      const trimmed = item.trim();
      if (!trimmed) return trimmed;

      const parts = trimmed.split(/\s+/);
      const rawUrl = parts.shift();
      const abs = normalizeUrl(rawUrl, baseUrl);
      if (!abs) return trimmed;

      const local = resolveLocal(abs);
      if (!local) return trimmed;

      parts.unshift(local);
      return parts.join(" ");
    })
    .join(", ");
}

function isLikelyHtmlContent(contentType, url) {
  const type = String(contentType || "").split(";")[0].trim().toLowerCase();
  if (type.includes("text/html")) return true;
  if (type.includes("application/xhtml+xml")) return true;

  const ext = path.extname(new URL(url).pathname || "").toLowerCase();
  if (!ext || ext === ".html" || ext === ".htm" || ext === ".php" || ext === ".asp" || ext === ".aspx") {
    return true;
  }

  return false;
}

async function fetchBuffer(url, referer) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: TIMEOUT,
    maxRedirects: 5,
    validateStatus: () => true,
    headers: {
      "user-agent": USER_AGENT,
      accept: "*/*",
      referer: referer || new URL(url).origin + "/"
    }
  });

  return res;
}

function saveFile(filePath, buffer) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, buffer);
}

function zipFolder(zipPath, folderToZip) {
  return new Promise((resolve, reject) => {
    execFile(
      "zip",
      ["-r", "-q", zipPath, path.basename(folderToZip)],
      { cwd: path.dirname(folderToZip) },
      (err) => {
        if (err) return reject(err);
        resolve();
      }
    );
  });
}

let handler = async (m, { text, conn }) => {
  if (!text) throw "Masukkan URL.\nContoh:\n.mirrorweb https://ditzzx.my.id 2";

  const args = text.trim().split(/\s+/);
  const TARGET_URL = args[0];
  const DEPTH = Math.max(0, Math.min(Number(args[1] || DEFAULT_DEPTH) || DEFAULT_DEPTH, 6));

  if (!isHttpUrl(TARGET_URL)) throw "URL tidak valid. Gunakan http:// atau https://";

  const parsed = new URL(TARGET_URL);
  const siteName = safeName(getSiteName(parsed.hostname));
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), "mirror-"));
  const siteRoot = path.join(tempRoot, siteName);
  const zipPath = path.join(tempRoot, `${siteName}-mirror.zip`);

  ensureDir(siteRoot);

  const visited = new Set();
  const queue = [{ url: TARGET_URL, depth: 0 }];
  const discoveredPages = new Set();
  const failures = [];

  let sentZip = false;

  const resolveLocalForRef = (resourceUrl, contentType, isPage) => {
    const localPath = urlToLocalPath(resourceUrl, siteRoot, contentType, isPage);
    return toPosixRelative(currentLocalFile, localPath);
  };

  async function ensureDownloaded(resourceUrl, parentUrl, depth, forcePage = false) {
    if (!resourceUrl) return null;
    if (!sameOrigin(resourceUrl, TARGET_URL)) return null;

    const key = resourceUrl;
    if (visited.has(key)) {
      const known = visitedMap.get(key);
      return known || null;
    }

    if (visited.size >= MAX_PAGES) {
      failures.push({ url: resourceUrl, error: "Batas halaman tercapai" });
      return null;
    }

    visited.add(key);

    let res;
    try {
      res = await fetchBuffer(resourceUrl, parentUrl);
    } catch (e) {
      failures.push({ url: resourceUrl, error: String(e.message || e) });
      return null;
    }

    if (res.status < 200 || res.status >= 400) {
      failures.push({ url: resourceUrl, error: `HTTP ${res.status}` });
      return null;
    }

    const contentType = String(res.headers["content-type"] || "").split(";")[0].trim().toLowerCase();
    const buffer = Buffer.from(res.data);

    if (buffer.length > MAX_FILE_BYTES) {
      failures.push({ url: resourceUrl, error: "File terlalu besar" });
      return null;
    }

    const isPage = forcePage || isLikelyHtmlContent(contentType, resourceUrl);
    const localPath = urlToLocalPath(resourceUrl, siteRoot, contentType, isPage);
    visitedMap.set(resourceUrl, localPath);

    if (isPage) {
      const html = buffer.toString("utf8");
      const rewritten = await rewriteHtml(resourceUrl, html, localPath, depth);
      saveFile(localPath, Buffer.from(rewritten, "utf8"));
      return localPath;
    }

    if (contentType.includes("text/css") || path.extname(new URL(resourceUrl).pathname || "").toLowerCase() === ".css") {
      const css = buffer.toString("utf8");
      const rewrittenCss = await rewriteCss(resourceUrl, css, localPath, depth);
      saveFile(localPath, Buffer.from(rewrittenCss, "utf8"));
      return localPath;
    }

    saveFile(localPath, buffer);
    return localPath;
  }

  async function rewriteCss(cssUrl, cssText, currentLocalCss, depth) {
    const cssBase = cssUrl;
    let out = String(cssText || "");

    const urlRegex = /url\(\s*(['"]?)(.*?)\1\s*\)/gi;
    const importRegex = /@import\s+(?:url\()?['"]?(.*?)['"]?\)?\s*;/gi;

    const refs = new Set();

    out = out.replace(urlRegex, (full, quote, raw) => {
      const abs = normalizeUrl(raw, cssBase);
      if (!abs || !sameOrigin(abs, TARGET_URL)) return full;

      refs.add(abs);
      const local = urlToLocalPath(abs, siteRoot, "", false);
      const rel = toPosixRelative(currentLocalCss, local);
      return `url("${rel}")`;
    });

    out = out.replace(importRegex, (full, raw) => {
      const abs = normalizeUrl(raw, cssBase);
      if (!abs || !sameOrigin(abs, TARGET_URL)) return full;

      refs.add(abs);
      const local = urlToLocalPath(abs, siteRoot, "", false);
      const rel = toPosixRelative(currentLocalCss, local);
      return `@import url("${rel}");`;
    });

    for (const ref of refs) {
      await ensureDownloaded(ref, cssBase, depth, false);
    }

    return out;
  }

  async function rewriteHtml(pageUrl, htmlText, currentLocalHtml, depth) {
    const $ = cheerio.load(String(htmlText || ""), { decodeEntities: false });

    const linkSelectors = [
      ["a[href]", "href", true],
      ["area[href]", "href", true],
      ["link[href]", "href", false],
      ["script[src]", "src", false],
      ["img[src]", "src", false],
      ["source[src]", "src", false],
      ["video[src]", "src", false],
      ["audio[src]", "src", false],
      ["iframe[src]", "src", true],
      ["embed[src]", "src", false],
      ["object[data]", "data", false],
      ["form[action]", "action", true]
    ];

    const refs = new Set();

    const resolveLocal = (absUrl, forcePage = false) => {
      const local = urlToLocalPath(absUrl, siteRoot, "", forcePage);
      return toPosixRelative(currentLocalHtml, local);
    };

    for (const [selector, attr, maybePage] of linkSelectors) {
      $(selector).each((_, el) => {
        const raw = $(el).attr(attr);
        const abs = normalizeUrl(raw, pageUrl);
        if (!abs || !sameOrigin(abs, TARGET_URL)) return;

        refs.add(abs);

        const isPage = maybePage;
        const local = resolveLocal(abs, isPage);
        $(el).attr(attr, local);
      });
    }

    $("img[srcset], source[srcset]").each((_, el) => {
      const raw = $(el).attr("srcset");
      if (!raw) return;

      const rewritten = String(raw)
        .split(",")
        .map((item) => {
          const trimmed = item.trim();
          if (!trimmed) return trimmed;

          const parts = trimmed.split(/\s+/);
          const imgUrl = parts.shift();
          const abs = normalizeUrl(imgUrl, pageUrl);
          if (!abs || !sameOrigin(abs, TARGET_URL)) return trimmed;

          refs.add(abs);
          const local = resolveLocal(abs, false);
          parts.unshift(local);
          return parts.join(" ");
        })
        .join(", ");

      $(el).attr("srcset", rewritten);
    });

    $("meta[content]").each((_, el) => {
      const name = String($(el).attr("name") || $(el).attr("property") || "").toLowerCase();
      const content = $(el).attr("content");
      if (!content) return;

      if (
        name.includes("image") ||
        name.includes("twitter:image") ||
        name.includes("og:image") ||
        name.includes("twitter:card")
      ) {
        const abs = normalizeUrl(content, pageUrl);
        if (!abs || !sameOrigin(abs, TARGET_URL)) return;

        refs.add(abs);
        const local = resolveLocal(abs, false);
        $(el).attr("content", local);
      }
    });

    $("style").each((_, el) => {
      const css = $(el).html();
      if (!css) return;

      const rewritten = css.replace(/url\(\s*(['"]?)(.*?)\1\s*\)/gi, (full, quote, raw) => {
        const abs = normalizeUrl(raw, pageUrl);
        if (!abs || !sameOrigin(abs, TARGET_URL)) return full;

        refs.add(abs);
        const local = resolveLocal(abs, false);
        return `url("${local}")`;
      });

      $(el).html(rewritten);
    });

    $("[style]").each((_, el) => {
      const style = $(el).attr("style");
      if (!style) return;

      const rewritten = style.replace(/url\(\s*(['"]?)(.*?)\1\s*\)/gi, (full, quote, raw) => {
        const abs = normalizeUrl(raw, pageUrl);
        if (!abs || !sameOrigin(abs, TARGET_URL)) return full;

        refs.add(abs);
        const local = resolveLocal(abs, false);
        return `url("${local}")`;
      });

      $(el).attr("style", rewritten);
    });

    for (const ref of refs) {
      const local = await ensureDownloaded(ref, pageUrl, depth + 1, false);
      if (local && depth < DEPTH) {
        const isHtml = local.endsWith(".html") || local.endsWith(".htm");
        if (isHtml) discoveredPages.add(ref);
      }
    }

    return $.html();
  }

  const visitedMap = new Map();
  let currentLocalFile = "";

  await m.reply(`Mulai mirror...\n• URL: ${TARGET_URL}\n• Depth: ${DEPTH}`);

  try {
    while (queue.length) {
      const item = queue.shift();
      if (!item || !item.url) continue;

      const url = item.url;
      const depth = item.depth || 0;

      if (visited.has(url) && visitedMap.has(url)) continue;
      if (visited.size >= MAX_PAGES) break;

      let res;
      try {
        res = await fetchBuffer(url, TARGET_URL);
      } catch (e) {
        failures.push({ url, error: String(e.message || e) });
        continue;
      }

      if (res.status < 200 || res.status >= 400) {
        failures.push({ url, error: `HTTP ${res.status}` });
        continue;
      }

      const contentType = String(res.headers["content-type"] || "").split(";")[0].trim().toLowerCase();
      const buffer = Buffer.from(res.data);

      if (buffer.length > MAX_FILE_BYTES) {
        failures.push({ url, error: "File terlalu besar" });
        continue;
      }

      const isPage = isLikelyHtmlContent(contentType, url);
      const localPath = urlToLocalPath(url, siteRoot, contentType, isPage);
      visitedMap.set(url, localPath);
      visited.add(url);
      currentLocalFile = localPath;

      if (isPage) {
        const html = buffer.toString("utf8");
        const rewritten = await rewriteHtml(url, html, localPath, depth);
        saveFile(localPath, Buffer.from(rewritten, "utf8"));

        if (depth < DEPTH) {
          const $ = cheerio.load(html, { decodeEntities: false });

          const nextUrls = new Set();
          $("a[href], area[href], iframe[src], form[action]").each((_, el) => {
            const attr = $(el).attr("href") || $(el).attr("src") || $(el).attr("action");
            const abs = normalizeUrl(attr, url);
            if (!abs || !sameOrigin(abs, TARGET_URL)) return;
            nextUrls.add(abs);
          });

          for (const next of nextUrls) {
            if (!visited.has(next)) queue.push({ url: next, depth: depth + 1 });
          }
        }
      } else if (contentType.includes("text/css") || path.extname(new URL(url).pathname || "").toLowerCase() === ".css") {
        const css = buffer.toString("utf8");
        const rewrittenCss = await rewriteCss(url, css, localPath, depth);
        saveFile(localPath, Buffer.from(rewrittenCss, "utf8"));
      } else {
        saveFile(localPath, buffer);
      }

      await sleep(20);
    }

    await m.reply("Mirror selesai. Sedang membuat ZIP...");

    await zipFolder(zipPath, siteRoot);

    if (!fs.existsSync(zipPath)) {
      throw new Error("ZIP gagal dibuat");
    }

    const zipBuffer = fs.readFileSync(zipPath);

    await conn.sendMessage(m.chat, {
      document: zipBuffer,
      mimetype: "application/zip",
      fileName: `${siteName}-mirror.zip`
    }, { quoted: m });

    sentZip = true;

    const summary = [
      `✅ Selesai`,
      `• URL: ${TARGET_URL}`,
      `• Depth: ${DEPTH}`,
      `• Halaman/file: ${visitedMap.size}`,
      `• Gagal: ${failures.length}`
    ].join("\n");

    await m.reply(summary);
  } catch (e) {
    await m.reply(`Gagal mirror:\n${String(e.message || e)}`);
    throw e;
  } finally {
    try {
      if (fs.existsSync(tempRoot)) {
        fs.rmSync(tempRoot, { recursive: true, force: true });
      }
    } catch {}
  }
};

handler.help = ["mirrorweb <url> [depth]"];
handler.tags = ["main"];
handler.command = ["mirrorweb", "getweb"];

module.exports = handler;