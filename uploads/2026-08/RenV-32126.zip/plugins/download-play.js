const yts = require("yt-search");
const crypto = require("crypto");
const axios = require("axios");

class SaveTubeDownloader {
  constructor() {
    this.ky = "C5D58EF67A7584E4A29F6C35BBC4EB12";
    this.formats = ["144", "240", "360", "480", "720", "1080", "mp3"];

    this.client = axios.create({
      timeout: 30000,
      headers: {
        accept: "application/json, text/plain, */*",
        "content-type": "application/json",
        origin: "https://yt.savetube.me",
        referer: "https://yt.savetube.me/",
        "user-agent":
          "Mozilla/5.0 (Linux; Android 15; Mobile) AppleWebKit/537.36 Chrome/130.0.0.0 Mobile Safari/537.36"
      }
    });
  }

  extractVideoId(input) {
    if (!input) return null;

    const text = String(input).trim();

    if (/^[a-zA-Z0-9_-]{11}$/.test(text)) return text;

    try {
      const url = new URL(text);

      if (url.hostname.includes("youtu.be")) {
        const id = url.pathname.split("/").filter(Boolean)[0];
        return /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
      }

      if (url.hostname.includes("youtube.com")) {
        const v = url.searchParams.get("v");
        if (/^[a-zA-Z0-9_-]{11}$/.test(v)) return v;

        const parts = url.pathname.split("/").filter(Boolean);
        const index = parts.findIndex(v =>
          ["shorts", "embed", "v", "live"].includes(v)
        );

        if (index !== -1 && parts[index + 1]) {
          const id = parts[index + 1];
          return /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
        }
      }
    } catch {}

    const match = text.match(
      /(?:v=|\/shorts\/|youtu\.be\/|embed\/|\/v\/|\/live\/)([a-zA-Z0-9_-]{11})/
    );

    return match ? match[1] : null;
  }

  async decrypt(enc) {
    try {
      if (!enc) throw new Error("Encrypted data kosong");

      const encrypted = Buffer.from(enc, "base64");
      const key = Buffer.from(this.ky, "hex");

      const iv = encrypted.slice(0, 16);
      const data = encrypted.slice(16);

      const decipher = crypto.createDecipheriv("aes-128-cbc", key, iv);

      const decrypted = Buffer.concat([
        decipher.update(data),
        decipher.final()
      ]).toString();

      return JSON.parse(decrypted);
    } catch (e) {
      throw new Error(`Gagal decrypt data: ${e.message}`);
    }
  }

  async getCdn() {
    try {
      const res = await this.client.get(
        "https://media.savetube.vip/api/random-cdn"
      );

      const cdn = res.data?.cdn;

      if (!cdn) {
        return {
          status: false,
          msg: "CDN tidak ditemukan",
          raw: res.data
        };
      }

      return {
        status: true,
        cdn
      };
    } catch (e) {
      return {
        status: false,
        msg: "Gagal mengambil CDN",
        error: e.message
      };
    }
  }

  cleanFileName(name = "download") {
    return String(name)
      .replace(/[\\/:*?"<>|]/g, "")
      .replace(/\s+/g, "_")
      .slice(0, 80);
  }

  async download(url, format = "mp3") {
    const id = this.extractVideoId(url);

    if (!id) {
      return {
        status: false,
        msg: "ID YouTube tidak valid"
      };
    }

    if (!this.formats.includes(format)) {
      return {
        status: false,
        msg: "Format tidak didukung",
        supported_formats: this.formats
      };
    }

    try {
      const cdnData = await this.getCdn();
      if (!cdnData.status) return cdnData;

      const cdn = cdnData.cdn;

      const infoRes = await this.client.post(`https://${cdn}/v2/info`, {
        url: `https://www.youtube.com/watch?v=${id}`
      });

      const encryptedData = infoRes.data?.data;
      const info = await this.decrypt(encryptedData);

      if (!info?.key) {
        return {
          status: false,
          msg: "Key download tidak ditemukan",
          raw: info
        };
      }

      const type = format === "mp3" ? "audio" : "video";
      const quality = format === "mp3" ? "128" : format;

      const downRes = await this.client.post(`https://${cdn}/download`, {
        id,
        downloadType: type,
        quality,
        key: info.key
      });

      const downloadUrl =
        downRes.data?.data?.downloadUrl ||
        downRes.data?.downloadUrl ||
        downRes.data?.data?.url;

      if (!downloadUrl) {
        return {
          status: false,
          msg: "URL download tidak ditemukan",
          raw: downRes.data
        };
      }

      const ext = format === "mp3" ? "mp3" : "mp4";
      const title = info.title || "YouTube Download";

      return {
        status: true,
        title,
        videoId: id,
        type,
        quality,
        format,
        thumbnail:
          info.thumbnail || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
        duration: info.duration || null,
        cached: info.fromCache || false,
        downloadUrl,
        filename: `${this.cleanFileName(title)}.${ext}`
      };
    } catch (e) {
      return {
        status: false,
        msg: "Gagal download media",
        error: e.response?.data || e.message
      };
    }
  }
}

const downloader = new SaveTubeDownloader();

const formatDuration = seconds => {
  seconds = Number(seconds);

  if (!seconds || isNaN(seconds)) return "-";

  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);

  if (h > 0) {
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }

  return `${m}:${String(s).padStart(2, "0")}`;
};

const errorText = e => {
  if (!e) return "Unknown error";
  if (typeof e === "string") return e;
  if (typeof e === "object") return JSON.stringify(e, null, 2);
  return String(e);
};

const download = async url => {
  const result = await downloader.download(url, "mp3");

  if (!result.status) {
    throw result.error || result.msg || "Gagal mengambil audio";
  }

  return {
    title: result.title,
    link: result.downloadUrl,
    thumbnail: result.thumbnail,
    duration: result.duration,
    filename: result.filename
  };
};

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply("[ Masukkan judul lagu YouTube ]");
  }

  try {
    const search = await yts(text);
    const vid = search.videos?.[0] || search.all?.find(v => v.type === "video");

    if (!vid) {
      return m.reply("[ Lagu tidak ditemukan ]");
    }

    const result = await download(vid.url);
    const durasi = formatDuration(result.duration || vid.seconds);

    const caption = `
> [+] *PLAY YOUTUBE*

> [ JUDUL   ] ${result.title}
> [ DURASI  ] ${durasi}
> [ VIEWERS ] ${vid.views?.toLocaleString() || "-"}
> [ UPLOAD  ] ${vid.ago || "-"}
> [ LINK    ] ${vid.url}

> [+] Mengirim audio...
`.trim();

    await conn.sendButtonLoc(
      m.chat,
      [{ id: `.ytmp4 ${vid.url}`, text: "[ Video ]" }],
      caption,
      `[ ${typeof namebot !== 'undefined' ? namebot : "Bot"} :: ${typeof nameown !== 'undefined' ? nameown : "Owner"} ]`,
      m,
      {
        mentions: [m.sender],
        thumbUrl: result.thumbnail || (typeof global.thumb !== 'undefined' ? global.thumb : ""),
        name: typeof namebot !== 'undefined' ? namebot : "Renvy",
        address: "YouTube Audio"
      }
    );

    // MENGIRIM SEBAGAI AUDIO MP3 (Bisa diputar langsung)
    await conn.sendMessage(m.chat, {
      audio: { url: result.link },
      mimetype: 'audio/mpeg',
      fileName: result.filename
    }, { quoted: typeof ftroli !== 'undefined' ? ftroli : m });

    /* 
    OPSIONAL: 
    Jika kamu ingin file dikirim sebagai "Dokumen" agar user bisa melihat 
    file name (.mp3) dan menyimpannya di file manager, gunakan kode di bawah ini 
    (hapus kode conn.sendMessage audio di atas, lalu hilangkan tanda /* pada kode di bawah):
    
    await conn.sendMessage(m.chat, {
      document: { url: result.link },
      mimetype: 'audio/mpeg',
      fileName: result.filename
    }, { quoted: typeof ftroli !== 'undefined' ? ftroli : m });
    */

  } catch (e) {
    console.error(e);

    m.reply(`
> [!] Gagal memproses permintaan.
> ${errorText(e)}
`.trim());
  }
};

handler.help = ["play"];
handler.tags = ["download"];
handler.command = ["play"];
handler.limit = true;

module.exports = handler;