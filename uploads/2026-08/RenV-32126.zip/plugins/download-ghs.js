const fetch = require('node-fetch');

let handler = async (m, { text }) => {
    if (!text) return conn.reply(m.chat, `🚩 Masukkan query untuk dicari`, m);

    let res = await fetch(`https://api.github.com/search/repositories?q=${encodeURIComponent(text)}`);
    if (!res.ok) throw await res.text();

    let json = await res.json();
    if (!json.items || !json.items.length) return conn.reply(m.chat, '🚩 Tidak ada hasil ditemukan.', m);

    let categoryRows = json.items.map(repo => ({
        header: `[ ${repo.name} ]`,
        title: `📦 ${repo.owner.login}`,
        description: repo.description || 'Tidak ada deskripsi',
        id: `.github ${repo.clone_url}`
    }));

    const datas = {
        title: `[ ${namebot} - GitHub Search Results ]`,
        sections: [
            {
                title: "📁 Hasil Pencarian Repositori",
                highlight_label: "✨ Pilih untuk clone",
                rows: categoryRows,
            },
        ],
    };

    await conn.sendButtonMessage(
        m.chat,
        [
            { id: 'gada', text: '🔍 Menu Lengkap', native: true },
            { id: '.owner', text: '[ Owner ]' }
        ],
        `🔍 Ditemukan *${json.items.length}* repositori untuk: *${text}*`,
        `[ ${namebot} Powered By @${nomorown.split("@")[0]} ]`,
        m.sender,
        fdoc,
        datas, 
    );
};

handler.help = ["ghs"];
handler.tags = ["download"];
handler.limit = true;
handler.command = /^(githubsearch|ghs)$/i;

module.exports = handler;