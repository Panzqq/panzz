const axios = require('axios');
const cheerio = require('cheerio');

let handler = async (m, { text, conn, usedPrefix, command }) => {
  if (!text) throw `> [-] Masukkan parameter judul anime.\n> [+] Contoh: ${usedPrefix + command} naruto`;

  try {
    const query = text.trim().replace(/ /g, '+');
    const url = `https://otakudesu.cloud/?s=${query}&post_type=anime`;

    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    const firstResult = $('.chivsrc li').first();
    
    if (!firstResult.length) throw new Error('Not found');

    const title = firstResult.find('h2 a').text().trim();
    const link = firstResult.find('h2 a').attr('href');
    const genres = firstResult.find('.set').first().text().replace('Genres : ', '').trim();
    const status = firstResult.find('.set').eq(1).text().replace('Status : ', '').trim();
    const rating = firstResult.find('.set').eq(2).text().replace('Rating : ', '').trim();

    const replyText = `> [+] PENCARIAN ANIME\n> \n> [+] Judul  : ${title}\n> [+] Genre  : ${genres}\n> [+] Status : ${status}\n> [+] Rating : ${rating}\n> \n> [+] Tautan : ${link}\n> \n> [+] Status: Success`;

    await m.reply(replyText);

  } catch (err) {
    m.reply(`> [-] Anime dengan judul "${text}" tidak ditemukan.\n> [+] Status: Error`);
  }
};

handler.help = ['anime'];
handler.tags = ['search'];
handler.command = /^(anime|otakudesu)$/i;

module.exports = handler;