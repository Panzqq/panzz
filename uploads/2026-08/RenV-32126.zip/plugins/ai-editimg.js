const fs = require('fs');
const axios = require('axios');
const FormData = require('form-data');
const { tmpFile, safeUnlink } = require('../lib/tmpManager');

const API_URL = 'https://gpt2images.vercel.app/api/generate';

function getExtFromMime(mime = '') {
  if (mime.includes('png')) return 'png';
  if (mime.includes('webp')) return 'webp';
  if (mime.includes('jpeg') || mime.includes('jpg')) return 'jpg';
  return 'jpg';
}

async function downloadMedia(conn, q) {
  if (q && typeof q.download === 'function') {
    return await q.download();
  }

  if (conn && typeof conn.downloadMediaMessage === 'function') {
    return await conn.downloadMediaMessage(q);
  }

  throw new Error('Gagal download media. Fungsi download tidak tersedia.');
}

async function generateImage(imageBuffer, fileName, mime, prompt) {
  const formData = new FormData();

  formData.append('image', imageBuffer, {
    filename: fileName,
    contentType: mime || 'image/jpeg'
  });

  formData.append('prompt', prompt);

  const res = await axios.post(API_URL, formData, {
    headers: { ...formData.getHeaders() },
    responseType: 'arraybuffer',
    timeout: 120000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    validateStatus: () => true
  });

  if (res.status < 200 || res.status >= 300) {
    const text = Buffer.from(res.data || '').toString('utf8');
    throw new Error(`HTTP ${res.status}: ${text || 'Gagal memproses gambar'}`);
  }

  return Buffer.from(res.data);
}

async function uploadWithUploader(buffer) {
  const uploader = global.Uploader || (typeof Uploader !== 'undefined' ? Uploader : null);

  if (!uploader || typeof uploader.github !== 'function') {
    throw new Error('Uploader.github tidak tersedia.');
  }

  return await uploader.github(buffer);
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted || m;
  const mime = (q.msg || q).mimetype || q.mimetype || '';
  const wm = global.namebot || 'Bot';

  if (!text) {
    return m.reply(
      `Masukkan prompt edit gambar.\n\nContoh:\n${usedPrefix + command} ubah background menjadi langit malam berbintang`
    );
  }

  if (!/image\/(jpe?g|png|webp)/i.test(mime)) {
    return m.reply(
      `Reply gambar dengan command ini.\n\nContoh:\n${usedPrefix + command} ubah background menjadi langit malam berbintang`
    );
  }

  let inputPath;
  let outputPath;

  try {
    await m.reply('⏳ Sedang mengedit gambar, mohon tunggu...');

    const imageBuffer = await downloadMedia(conn, q);
    if (!imageBuffer || !Buffer.isBuffer(imageBuffer)) {
      throw new Error('Gambar tidak berhasil diunduh.');
    }

    const ext = getExtFromMime(mime);
    const fileName = `input_${Date.now()}.${ext}`;

    inputPath = tmpFile({ dir: 'ai/edit-image', prefix: 'input', ext });
    outputPath = tmpFile({ dir: 'ai/edit-image', prefix: 'edited', ext: 'png' });

    fs.writeFileSync(inputPath, imageBuffer);

    const resultBuffer = await generateImage(imageBuffer, fileName, mime, text);
    fs.writeFileSync(outputPath, resultBuffer);

    const imageUrl = await uploadWithUploader(resultBuffer);

    await conn.sendMessage(m.chat, {
      image: { url: imageUrl },
      caption: `# AI Edit Image\n\n> Gambar berhasil diedit.\n\n[+] Prompt\n${text}\n\n[+] Bot: ${wm}`
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    await m.reply(`❌ Gagal mengedit gambar.\n\nError: ${e.message}`);
  } finally {
    try {
      await safeUnlink(inputPath);
      await safeUnlink(outputPath);
    } catch {}
  }
};

handler.help = handler.command = ['aiedit', 'editimg', 'imgedit'];
handler.tags = ['ai'];

module.exports = handler;