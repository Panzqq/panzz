'use strict';

/**
 * plugins/cuaca.js
 * ─────────────────────────────────────────────────────────────────
 * Cuaca real-time + prakiraan 4 hari pake Open-Meteo.
 * 100% gratis, no API key, no billing.
 *
 * Reuse titik acuan yang sama kayak maps.js (data/last-location.json)
 * biar tinggal .cuaca abis share-location, gak perlu input kota manual.
 * Bisa juga override manual: .cuaca <nama kota>
 *
 * CATATAN: semua error di-handle langsung lewat m.reply, gak ada
 * throw sama sekali - konsisten sama maps.js.
 *
 * PERINTAH:
 *   .cuaca            — cuaca di titik acuan terakhir (dari share-location)
 *   .cuaca <kota>      — cuaca di kota tertentu (geocode via Nominatim)
 */

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '../data');
const LAST_LOCATION_FILE = path.join(DATA_DIR, 'last-location.json');

const NOMINATIM_SEARCH = 'https://nominatim.openstreetmap.org/search';
const OPEN_METEO_API = 'https://api.open-meteo.com/v1/forecast';

const USER_AGENT = process.env.NOMINATIM_USER_AGENT || 'RenvyBail-WhatsAppBot/1.0 (personal use, non-commercial)';

// WMO weather interpretation codes -> deskripsi Indonesia
const WEATHER_CODES = {
  0: 'Cerah',
  1: 'Cerah berawan sebagian',
  2: 'Berawan sebagian',
  3: 'Berawan tebal / mendung',
  45: 'Berkabut',
  48: 'Kabut es',
  51: 'Gerimis ringan',
  53: 'Gerimis sedang',
  55: 'Gerimis lebat',
  56: 'Gerimis beku ringan',
  57: 'Gerimis beku lebat',
  61: 'Hujan ringan',
  63: 'Hujan sedang',
  65: 'Hujan lebat',
  66: 'Hujan beku ringan',
  67: 'Hujan beku lebat',
  71: 'Salju ringan',
  73: 'Salju sedang',
  75: 'Salju lebat',
  77: 'Butiran salju',
  80: 'Hujan sebentar ringan',
  81: 'Hujan sebentar sedang',
  82: 'Hujan sebentar lebat',
  85: 'Salju sebentar ringan',
  86: 'Salju sebentar lebat',
  95: 'Badai petir',
  96: 'Badai petir + hujan es ringan',
  99: 'Badai petir + hujan es lebat'
};

function describeWeather(code) {
  return WEATHER_CODES[code] || `Kode cuaca tidak dikenal (${code})`;
}

function _loadLastLocations() {
  try { return JSON.parse(fs.readFileSync(LAST_LOCATION_FILE, 'utf-8')); }
  catch { return {}; }
}

function getLastLocation(jid) {
  return _loadLastLocations()[jid] || null;
}

// Return { ok, lat, lng, address, error } - gak throw.
async function geocodeCity(name) {
  try {
    const url = `${NOMINATIM_SEARCH}?format=jsonv2&q=${encodeURIComponent(name)}&limit=1&accept-language=id`;
    const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT } });
    const data = await res.json();

    if (!res.ok || !data.length) {
      return { ok: false, error: `Kota/tempat \`${name}\` gak ketemu.` };
    }

    return {
      ok: true,
      lat: Number(data[0].lat),
      lng: Number(data[0].lon),
      address: data[0].display_name
    };
  } catch (e) {
    return { ok: false, error: `Gagal geocode kota: ${e.message}` };
  }
}

// Return { ok, data, error } - gak throw.
async function getWeather(lat, lng) {
  try {
    const params = new URLSearchParams({
      latitude: lat,
      longitude: lng,
      current: 'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m',
      daily: 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max',
      timezone: 'auto',
      forecast_days: '4'
    });

    const res = await fetch(`${OPEN_METEO_API}?${params.toString()}`);
    const data = await res.json();

    if (!res.ok) {
      return { ok: false, error: `Gagal ambil data cuaca: ${data.reason || res.status}` };
    }

    return { ok: true, data };
  } catch (e) {
    return { ok: false, error: `Weather API error: ${e.message}` };
  }
}

function fmtHari(isoDate, i) {
  if (i === 0) return 'Hari ini';
  if (i === 1) return 'Besok';
  const d = new Date(isoDate);
  return d.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'short' });
}

// ───────────────────────── Handler ─────────────────────────

let handler = async (m, { conn, args }) => {
  const cityQuery = args.join(' ').trim();

  let lat, lng, address;

  if (cityQuery) {
    await m.reply('`Mencari lokasi...`');
    const geo = await geocodeCity(cityQuery);
    if (!geo.ok) {
      return m.reply(geo.error);
    }
    lat = geo.lat;
    lng = geo.lng;
    address = geo.address;
  } else {
    const ref = getLastLocation(m.sender);
    if (!ref) {
      return m.reply('Belum ada titik acuan. Share location dulu, atau pakai: `.cuaca <nama kota>`');
    }
    lat = ref.lat;
    lng = ref.lng;
    address = ref.address;
  }

  await m.reply('`Mengambil data cuaca...`');

  const weather = await getWeather(lat, lng);
  if (!weather.ok) {
    return m.reply(weather.error);
  }

  const cur = weather.data.current;
  const daily = weather.data.daily;

  const lines = [];
  lines.push('`CUACA - REAL TIME`');
  lines.push('');
  lines.push(`[+] Lokasi     > ${address}`);
  lines.push(`[+] Kondisi    > ${describeWeather(cur.weather_code)}`);
  lines.push(`[+] Suhu       > ${cur.temperature_2m}°C (terasa ${cur.apparent_temperature}°C)`);
  lines.push(`[+] Kelembapan > ${cur.relative_humidity_2m}%`);
  lines.push(`[+] Presipitasi> ${cur.precipitation} mm`);
  lines.push(`[+] Angin      > ${cur.wind_speed_10m} km/j`);
  lines.push('');
  lines.push('`PRAKIRAAN 4 HARI`');
  lines.push('');

  daily.time.forEach((date, i) => {
    lines.push(`[+] ${fmtHari(date, i)}`);
    lines.push(`    > Kondisi : ${describeWeather(daily.weather_code[i])}`);
    lines.push(`    > Suhu    : ${daily.temperature_2m_min[i]}°C - ${daily.temperature_2m_max[i]}°C`);
    lines.push(`    > Hujan   : ${daily.precipitation_probability_max[i]}% kemungkinan`);
    lines.push('');
  });

  lines.push('`Sumber data: Open-Meteo`');

  await conn.sendMessage(m.chat, { text: lines.join('\n').trim() }, { quoted: m });
};

handler.help = ['cuaca', 'cuaca <kota>'];
handler.tags = ['tools'];
handler.command = /^cuaca$/i;
handler.limit = true;

module.exports = handler;