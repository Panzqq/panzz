const util = require("util");
const { exec } = require("child_process");

function isBotOwnMessage(m, conn) {
  const botJid = conn?.decodeJid
    ? conn.decodeJid(conn.user?.id || conn.user?.jid || "")
    : (conn?.user?.id || conn?.user?.jid || "");

  const sender = conn?.decodeJid ? conn.decodeJid(m.sender || "") : (m.sender || "");
  const id = m.id || m.key?.id || "";

  return (
    m.fromMe === true ||
    m.key?.fromMe === true ||
    m.isBaileys === true ||
    (botJid && sender === botJid) ||
    id.startsWith("BAE5") ||
    id.startsWith("3EB0")
  );
}

module.exports = {
  owner: true,
  tags: ["owner"],
  before: async (m, { conn, isOwner }) => {
    if (!m?.text) return false;

    // Jangan proses pesan yang dikirim oleh bot sendiri.
    // Ini mencegah caption/reply bot yang diawali ">" terbaca sebagai eval.
    if (isBotOwnMessage(m, conn)) return false;

    const text = String(m.text || "").trimStart();

    if (text.startsWith("=>")) {
      if (!isOwner) return false;

      const code = text.slice(2).trim();
      if (!code) return false;

      await m.reply(global.wait || "wait...");
      try {
        const result = await eval(`(async () => { return ${code} })()`);
        await m.reply(util.format(result));
      } catch (e) {
        await m.reply(util.format(e));
      }

      return true;
    }

    if (text.startsWith(">")) {
      if (!isOwner) return false;

      const code = text.slice(1).trim();
      if (!code) return false;

      await m.reply(global.wait || "wait...");
      try {
        const result = await eval(`(async () => {\n${code}\n})()`);
        await m.reply(util.format(result));
      } catch (e) {
        await m.reply(util.format(e));
      }

      return true;
    }

    if (text.startsWith("$")) {
      if (!isOwner) return false;

      const command = text.slice(1).trim();
      if (!command) return false;

      const { key } = await conn.sendMessage(
        m.chat,
        { text: "executed..." },
        { quoted: m }
      );

      exec(command, async (err, stdout, stderr) => {
        const output = err ? util.format(err) : (stdout || stderr || "Done.");
        await conn.sendMessage(m.chat, {
          text: output,
          edit: key,
        });
      });

      return true;
    }

    return false;
  },
};