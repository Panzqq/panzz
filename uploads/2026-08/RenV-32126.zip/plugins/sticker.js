const fs = require("fs");

let handler = async (m, { usedPrefix, command, conn }) => {
  let q = m.quoted || m;
  let mime = (q.msg || q).mimetype || "";

  if (!/image|video/.test(mime)) {
    return m.reply(`*• Example :* ${usedPrefix + command} *[reply/send media]*`);
  }

  if (/video/.test(mime) && q.seconds > 11) {
    return m.reply("*[ ! ] Max 10 Second*");
  }

  let media;
  try {
    media = await conn.downloadAndSaveMediaMessage(q, new Date() * 1);

    const exif = {
      packname: global.packname || global.namebot || "RenvyBot",
      author: global.author || global.swm || "Renvy",
    };

    if (/image/.test(mime)) {
      await conn.sendImageAsSticker(m.chat, media, m, exif);
    } else {
      await conn.sendVideoAsSticker(m.chat, media, m, exif);
    }
  } finally {
    if (media && fs.existsSync(media)) fs.unlinkSync(media);
  }
};

handler.help = ["sticker", "s"].map((a) => a + " *[reply/send media]*");
handler.tags = ["sticker"];
handler.command = ["s", "sticker"];

module.exports = handler;
