const WebSocket = require("ws");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");
const { tmpFile, safeUnlinkSync } = require("../lib/tmpManager");

const HF_BASE = "https://yanzbotz-waifu-yanzbotz.hf.space";
const WSS_URL = "wss://yanzbotz-waifu-yanzbotz.hf.space/queue/join";

const MAX_AUDIO_SIZE = 50 * 1024 * 1024; // 50MB
const MAX_DURATION = 300; // 5 menit
const PROCESS_TIMEOUT = 900000; // 15 menit
const RETRY_COUNT = 2;

const characters = {
  kobo: 2,
  zeta: 0,
  gura: 20,
  kaela: 4,
  pekora: 6,
  miko: 8,
  subaru: 10,
  korone: 12,
  luna: 14,
  anya: 16,
  reine: 18,
  calli: 22,
  kroni: 24
};

function randomString(length = 12) {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";

  for (let i = 0; i < length; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }

  return result;
}

function getExtFromMime(mime = "") {
  mime = String(mime).toLowerCase();

  if (mime.includes("ogg")) return "ogg";
  if (mime.includes("opus")) return "ogg";
  if (mime.includes("wav")) return "wav";
  if (mime.includes("mp4")) return "mp4";
  if (mime.includes("mpeg")) return "mp3";
  if (mime.includes("mp3")) return "mp3";
  if (mime.includes("webm")) return "webm";

  return "mp3";
}

function formatDuration(seconds) {
  seconds = Math.floor(seconds || 0);

  const m = Math.floor(seconds / 60);
  const s = seconds % 60;

  return `${m}:${String(s).padStart(2, "0")}`;
}

function shortText(text, max = 700) {
  text = String(text || "");
  if (text.length <= max) return text;
  return text.slice(0, max) + "...";
}

function runCmd(cmd, args) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, (err, stdout, stderr) => {
      if (err) {
        const clean = String(stderr || err.message)
          .split("\n")
          .filter(Boolean)
          .slice(-6)
          .join("\n");

        return reject(new Error(shortText(clean || err.message)));
      }

      resolve(stdout);
    });
  });
}

async function getAudioDuration(buffer, ext = "mp3") {
  const id = `${Date.now()}-${Math.floor(Math.random() * 9999)}`;
  const input = tmpFile({ dir: "audio/wvoice", prefix: `${id}-duration`, ext });

  try {
    fs.writeFileSync(input, buffer);

    const stdout = await runCmd("ffprobe", [
      "-v", "error",
      "-show_entries", "format=duration",
      "-of", "default=noprint_wrappers=1:nokey=1",
      input
    ]);

    const duration = Number(String(stdout).trim());

    if (isNaN(duration)) {
      throw new Error("Gagal membaca durasi audio.");
    }

    return duration;
  } finally {
    safeUnlinkSync(input);
  }
}

async function convertInputToMp3(buffer, ext = "mp3") {
  const id = `${Date.now()}-${Math.floor(Math.random() * 9999)}`;

  const input = tmpFile({ dir: "audio/wvoice", prefix: `${id}-input`, ext });
  const output = tmpFile({ dir: "audio/wvoice", prefix: `${id}-output`, ext: "mp3" });

  try {
    fs.writeFileSync(input, buffer);

    await runCmd("ffmpeg", [
      "-y",
      "-i", input,
      "-vn",
      "-ac", "1",
      "-ar", "22050",
      "-b:a", "64k",
      output
    ]);

    return fs.readFileSync(output);
  } finally {
    safeUnlinkSync(input);
    safeUnlinkSync(output);
  }
}

async function mp4UrlToAudio(url, ptt = true) {
  const id = `${Date.now()}-${Math.floor(Math.random() * 9999)}`;
  const input = tmpFile({ dir: "audio/wvoice", prefix: `${id}-input`, ext: "mp4" });
  const output = tmpFile({ dir: "audio/wvoice", prefix: `${id}-output`, ext: ptt ? "ogg" : "mp3" });

  try {
    const res = await axios.get(url, {
      responseType: "arraybuffer",
      timeout: 180000,
      headers: {
        "user-agent": "Mozilla/5.0"
      }
    });

    fs.writeFileSync(input, Buffer.from(res.data));

    if (ptt) {
      await runCmd("ffmpeg", [
        "-y",
        "-i", input,
        "-vn",
        "-ac", "1",
        "-ar", "48000",
        "-c:a", "libopus",
        "-b:a", "64k",
        "-f", "ogg",
        output
      ]);

      return {
        buffer: fs.readFileSync(output),
        mimetype: "audio/ogg; codecs=opus",
        ptt: true
      };
    }

    await runCmd("ffmpeg", [
      "-y",
      "-i", input,
      "-vn",
      "-acodec", "libmp3lame",
      "-b:a", "128k",
      output
    ]);

    return {
      buffer: fs.readFileSync(output),
      mimetype: "audio/mpeg",
      ptt: true
    };
  } finally {
    safeUnlinkSync(input);
    safeUnlinkSync(output);
  }
}

function buildFileUrl(name) {
  if (!name) return null;

  name = String(name);

  if (/^https?:\/\//i.test(name)) return name;
  if (name.startsWith("/file=")) return encodeURI(HF_BASE + name);

  return encodeURI(`${HF_BASE}/file=${name}`);
}

function findOutputFile(obj) {
  if (!obj) return null;

  if (typeof obj === "string") {
    if (
      obj.includes("/file=") ||
      obj.includes("/tmp/") ||
      obj.endsWith(".mp4") ||
      obj.endsWith(".wav") ||
      obj.endsWith(".mp3") ||
      obj.endsWith(".ogg")
    ) {
      return obj;
    }

    return null;
  }

  if (Array.isArray(obj)) {
    for (const item of obj) {
      const found = findOutputFile(item);
      if (found) return found;
    }

    return null;
  }

  if (typeof obj === "object") {
    if (obj.url) return obj.url;
    if (obj.name) return obj.name;
    if (obj.path) return obj.path;

    for (const key of Object.keys(obj)) {
      const found = findOutputFile(obj[key]);
      if (found) return found;
    }
  }

  return null;
}

function createWsError(reason, lastMsg, closeCode, closeReason) {
  let msg = reason || "WebSocket tertutup sebelum proses selesai.";

  if (closeCode) msg += `\nCode: ${closeCode}`;
  if (closeReason) msg += `\nReason: ${closeReason}`;
  if (lastMsg) msg += `\nLast Msg: ${lastMsg}`;

  return new Error(shortText(msg));
}

function waifuVoiceScrapeOnce(character, audioBuffer) {
  return new Promise((resolve, reject) => {
    character = String(character || "").toLowerCase();

    const fnIndex = characters[character];

    if (fnIndex === undefined) {
      return reject(
        new Error(
          "Character tidak tersedia. Pilih: " + Object.keys(characters).join(", ")
        )
      );
    }

    if (!Buffer.isBuffer(audioBuffer)) {
      return reject(new Error("Audio harus berupa buffer."));
    }

    const fileName = `${Date.now()}-${randomString(8)}.mp3`;
    const sessionHash = randomString(12);

    let finished = false;
    let lastMsg = "-";

    const ws = new WebSocket(WSS_URL, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        Origin: HF_BASE
      },
      handshakeTimeout: 60000
    });

    const timeout = setTimeout(() => {
      if (!finished) {
        finished = true;

        try {
          ws.terminate();
        } catch {}

        reject(
          createWsError(
            "Server timeout / terlalu lama merespons.",
            lastMsg
          )
        );
      }
    }, PROCESS_TIMEOUT);

    const pingInterval = setInterval(() => {
      try {
        if (ws.readyState === WebSocket.OPEN) {
          ws.ping();
        }
      } catch {}
    }, 20000);

    function cleanup() {
      clearTimeout(timeout);
      clearInterval(pingInterval);
    }

    const sendHashPayload = {
      fn_index: fnIndex,
      session_hash: sessionHash
    };

    const sendDataPayload = {
      fn_index: fnIndex,
      data: [
        {
          data: `data:audio/mpeg;base64,${audioBuffer.toString("base64")}`,
          name: fileName
        },
        0,
        "pm",
        0.6,
        false,
        "",
        "en-US-AnaNeural-Female"
      ],
      event_data: null,
      session_hash: sessionHash
    };

    ws.on("open", () => {
      console.log("[WAIFUVOICE] WebSocket connected");
    });

    ws.on("message", (raw) => {
      try {
        const message = JSON.parse(raw.toString());
        lastMsg = message.msg || "-";

        if (message.msg === "send_hash") {
          ws.send(JSON.stringify(sendHashPayload));
          return;
        }

        if (message.msg === "estimation") {
          console.log("[WAIFUVOICE] Queue:", message.rank ?? "-");
          return;
        }

        if (message.msg === "send_data") {
          ws.send(JSON.stringify(sendDataPayload));
          return;
        }

        if (message.msg === "process_starts") {
          console.log("[WAIFUVOICE] Process starts");
          return;
        }

        if (message.msg === "process_generating") {
          console.log("[WAIFUVOICE] Process generating");
          return;
        }

        if (message.msg === "queue_full") {
          if (!finished) {
            finished = true;
            cleanup();

            try {
              ws.close();
            } catch {}

            return reject(new Error("Queue server penuh."));
          }
        }

        if (message.msg === "process_completed") {
          if (message.success === false) {
            const errMsg =
              message?.output?.error ||
              message?.output?.message ||
              "Server gagal memproses audio.";

            if (!finished) {
              finished = true;
              cleanup();

              try {
                ws.close();
              } catch {}

              return reject(new Error(shortText(errMsg)));
            }
          }

          const outputName = findOutputFile(message?.output?.data);
          const url = buildFileUrl(outputName);

          if (!url) {
            if (!finished) {
              finished = true;
              cleanup();

              try {
                ws.close();
              } catch {}

              return reject(
                createWsError(
                  "Output tidak ditemukan dari server.",
                  lastMsg
                )
              );
            }
          }

          if (!finished) {
            finished = true;
            cleanup();

            try {
              ws.close();
            } catch {}

            return resolve({
              status: true,
              character,
              url
            });
          }
        }
      } catch (e) {
        if (!finished) {
          finished = true;
          cleanup();

          try {
            ws.terminate();
          } catch {}

          reject(e);
        }
      }
    });

    ws.on("error", (err) => {
      if (!finished) {
        finished = true;
        cleanup();
        reject(new Error(shortText(err.message || err)));
      }
    });

    ws.on("close", (code, reasonBuffer) => {
      cleanup();

      if (!finished) {
        finished = true;

        const reason = reasonBuffer ? reasonBuffer.toString() : "";

        reject(
          createWsError(
            "WebSocket tertutup sebelum proses selesai.",
            lastMsg,
            code,
            reason
          )
        );
      }
    });
  });
}

async function waifuVoiceScrape(character, audioBuffer) {
  let lastError;

  for (let i = 0; i <= RETRY_COUNT; i++) {
    try {
      if (i > 0) {
        console.log(`[WAIFUVOICE] Retry ${i}/${RETRY_COUNT}`);
        await new Promise((resolve) => setTimeout(resolve, 3000));
      }

      return await waifuVoiceScrapeOnce(character, audioBuffer);
    } catch (e) {
      lastError = e;
      console.log("[WAIFUVOICE] Error:", e.message);
    }
  }

  throw lastError;
}

function getMime(q) {
  return (
    q.mimetype ||
    q.mediaType ||
    q.msg?.mimetype ||
    q.message?.audioMessage?.mimetype ||
    q.message?.videoMessage?.mimetype ||
    ""
  );
}

async function downloadMedia(q, conn) {
  if (typeof q.download === "function") {
    return await q.download();
  }

  if (typeof conn.downloadMediaMessage === "function") {
    return await conn.downloadMediaMessage(q);
  }

  throw new Error("Fungsi download media tidak ditemukan di base bot.");
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
  const normalAudio = args.includes("--audio");

  const character = String(
    args.find((v) => !String(v).startsWith("--")) || ""
  ).toLowerCase();

  if (!character || character === "list") {
    return m.reply(
      "乂 W A I F U  V O I C E\n\n" +
        "> Reply voice note / audio lalu ketik:\n" +
        `> ${usedPrefix + command} kobo\n\n` +
        "> Untuk kirim audio biasa:\n" +
        `> ${usedPrefix + command} kobo --audio\n\n` +
        "> Maksimal durasi: 5 menit\n" +
        "> Maksimal size: 50MB\n\n" +
        "> Character tersedia:\n" +
        Object.keys(characters)
          .map((v) => `> [+] ${v}`)
          .join("\n")
    );
  }

  if (!characters.hasOwnProperty(character)) {
    return m.reply(
      "乂 W A I F U  V O I C E\n\n" +
        "> [!] Character tidak tersedia.\n\n" +
        "> Character tersedia:\n" +
        Object.keys(characters)
          .map((v) => `> [+] ${v}`)
          .join("\n")
    );
  }

  const q = m.quoted ? m.quoted : m;
  const mime = getMime(q);

  if (!/audio|video/i.test(mime)) {
    return m.reply(
      "乂 W A I F U  V O I C E\n\n" +
        "> [!] Reply audio / voice note.\n\n" +
        "> Contoh:\n" +
        `> ${usedPrefix + command} kobo`
    );
  }

  try {
    await m.reply(
      "乂 W A I F U  V O I C E\n\n" +
        `> [+] Character: ${character}\n` +
        "> [+] Sedang mengambil media..."
    );

    let media = await downloadMedia(q, conn);

    if (!media) {
      return m.reply("> [!] Gagal mengambil audio.");
    }

    if (!Buffer.isBuffer(media)) {
      media = Buffer.from(media);
    }

    if (media.length > MAX_AUDIO_SIZE) {
      return m.reply(
        "乂 W A I F U  V O I C E\n\n" +
          "> [!] Audio terlalu besar.\n" +
          "> Maksimal size: 50MB."
      );
    }

    const ext = getExtFromMime(mime);
    const duration = await getAudioDuration(media, ext);

    if (duration > MAX_DURATION) {
      return m.reply(
        "乂 W A I F U  V O I C E\n\n" +
          "> [!] Audio terlalu panjang.\n" +
          "> Maksimal durasi: 5 menit."
      );
    }

    await m.reply(
      "乂 W A I F U  V O I C E\n\n" +
        `> [+] Durasi: ${formatDuration(duration)}\n` +
        "> [+] Sedang compress audio agar lebih ringan..."
    );

    const mp3Input = await convertInputToMp3(media, ext);

    await m.reply(
      "乂 W A I F U  V O I C E\n\n" +
        "> [+] Sedang memproses voice AI...\n" +
        "> [+] Untuk audio panjang, proses bisa beberapa menit.\n" +
        "> [+] Jika WebSocket putus, bot akan retry otomatis."
    );

    const result = await waifuVoiceScrape(character, mp3Input);

    if (!result.status || !result.url) {
      return m.reply("> [!] Gagal membuat waifu voice.");
    }

    await m.reply(
      "乂 W A I F U  V O I C E\n\n" +
        "> [+] Voice selesai dibuat.\n" +
        "> [+] Sedang convert hasil ke audio..."
    );

    const audio = await mp4UrlToAudio(result.url, !normalAudio);

    await conn.sendAudioMessage(m.chat, audio.buffer, ftroli, {
      mimetype: audio.mimetype,
      ptt: true
    });
  } catch (e) {
    return m.reply(
      "乂 W A I F U  V O I C E\n\n" +
        "> [!] Terjadi error.\n" +
        `> ${shortText(e.message || e, 1000)}`
    );
  }
};

handler.help = handler.command = ["waifuvoice", "wvoice", "waifuvoiceai"];
handler.tags = ["ai"];

module.exports = handler;