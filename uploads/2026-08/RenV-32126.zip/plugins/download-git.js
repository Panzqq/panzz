const axios = require('axios');

const regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i;

let handler = async (m, { args }) => {
    if (!args[0]) return conn.reply(m.chat, '🚩 Input your GitHub link', m);
    if (!regex.test(args[0])) return conn.reply(m.chat, '🚩 Link tidak valid!', m);

    try {
        let [, user, repo] = args[0].match(regex) || [];
        repo = repo.replace(/.git$/, '');

        const url = `https://api.github.com/repos/${user}/${repo}`;

        const { data } = await axios.get(url, {
            headers: { 'User-Agent': 'BotWa' }
        });

        const sizeMB = (data.size / 1024).toFixed(2);
        const license = data.license?.name || 'No license';
        const updatedAt = new Date(data.updated_at).toLocaleString();
        const createdAt = new Date(data.created_at).toLocaleString();

        const info = `
[+] Name: ${data.full_name}
[+] Description: ${data.description || 'No description'}
[+] Language: ${data.language || 'Unknown'}
[+] Stars: ${data.stargazers_count}
[+] Forks: ${data.forks_count}
[+] Watchers: ${data.watchers_count}
[+] Open Issues: ${data.open_issues_count}
[+] License: ${license}
[+] Default Branch: ${data.default_branch}
[+] Created At: ${createdAt}
[+] Updated At: ${updatedAt}
[+] Size: ${sizeMB} MB
[+] Owner: ${data.owner.login}
[+] Owner Link: ${data.owner.html_url}
`;

        await conn.reply(m.chat, info, m);

        const zipUrl = `https://api.github.com/repos/${user}/${repo}/zipball`;
        const filename = `${data.name}.zip`;

        await conn.sendMessage(m.chat, {
            document: { url: zipUrl },
            mimetype: 'application/zip',
            fileName: filename
        }, { quoted: m });

    } catch (err) {
        console.log(err);
        conn.reply(m.chat, '🚩 Maaf, repository tidak dapat ditemukan atau error terjadi.', m);
    }
};

handler.help = ['gitclone <url>'];
handler.tags = ["download"];
handler.command = ['gitclone', 'github', 'git'];
handler.limit = true;

module.exports = handler;