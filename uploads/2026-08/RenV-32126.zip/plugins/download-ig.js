const axios = require("axios");
const qs = require("qs");

const version = Buffer.from([107, 122]).toString("base64").slice(0, 3);

function isInstagramUrl(url = "") {
  return /^https?:\/\/(www\.)?instagram\.com\/(p|reel|tv|stories)\/[^\s]+/i.test(url);
}

function cleanUrl(url = "") {
  return String(url || "")
    .trim()
    .replace(/\?.*$/, "");
}

function decodeHtml(str = "") {
  return String(str)
    .replace(/&amp;/g, "&")
    .replace(/&#038;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'");
}

async function getContentType(url) {
  try {
    const res = await axios.head(url, {
      timeout: 15000,
      headers: {
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K)"
      }
    });

    return String(res.headers["content-type"] || "").toLowerCase();
  } catch {
    return "";
  }
}

async function igDownload(url) {
  try {
    const { data: res } = await axios.post(
      "https://savereels.io/api/ajaxSearch",
      qs.stringify({
        q: url,
        v: "v2"
      }),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          "X-Requested-With": "XMLHttpRequest",
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K)",
          "Accept": "*/*",
          "Origin": "https://savereels.io",
          "Referer": "https://savereels.io/"
        },
        timeout: 30000
      }
    );

    if (!res || res.status !== "ok" || !res.data) {
      return {
        wm: version,
        error: "Gagal mengambil data dari server."
      };
    }

    const html = decodeHtml(res.data);

    const links = [
      ...html.matchAll(/href=["'](https:\/\/dl\.snapcdn\.app\/get\?token=[^"']+)["']/g)
    ].map(v => v[1]);

    const results = [...new Set(links)].filter(Boolean);

    if (!results.length) {
      return {
        wm: version,
        error: "Media tidak ditemukan."
      };
    }

    return {
      wm: version,
      results
    };
  } catch (e) {
    return {
      wm: version,
      error: e.message || String(e)
    };
  }
}

let handler = async (m, { conn, text, command, usedPrefix }) => {
  if (!text) {
    return m.reply(
      `> [!] Contoh:\n> ${usedPrefix || "."}${command} https://www.instagram.com/p/DYWVVCDAAuQ/`
    );
  }

  const url = cleanUrl(text);

  if (!isInstagramUrl(url)) {
    return m.reply("> [!] Masukkan link Instagram yang valid.");
  }

  await m.reply("> [+] Mengambil media Instagram...");

  try {
    const data = await igDownload(url);

    if (data.error) {
      return m.reply(`> [!] ${data.error}`);
    }

    const results = data.results || [];

    await m.reply(`> [+] Ditemukan ${results.length} media.`);

    for (let i = 0; i < results.length; i++) {
      const mediaUrl = results[i];
      const type = await getContentType(mediaUrl);

      const caption = `Instagram Downloader\n\nMedia: ${i + 1}/${results.length}`;

      try {
        if (type.includes("image")) {
          await conn.sendMessage(
            m.chat,
            {
              image: { url: mediaUrl },
              caption
            },
            { quoted: m }
          );
        } else if (type.includes("video") || type.includes("octet-stream") || !type) {
          await conn.sendMessage(
            m.chat,
            {
              video: { url: mediaUrl },
              caption
            },
            { quoted: m }
          );
        } else {
          await conn.sendMessage(
            m.chat,
            {
              document: { url: mediaUrl },
              fileName: `instagram-${i + 1}.mp4`,
              mimetype: "video/mp4",
              caption
            },
            { quoted: m }
          );
        }
      } catch {
        await conn.sendMessage(
          m.chat,
          {
            document: { url: mediaUrl },
            fileName: `instagram-${i + 1}.mp4`,
            mimetype: "video/mp4",
            caption
          },
          { quoted: m }
        );
      }
    }
  } catch (e) {
    return m.reply(`> [!] Gagal download Instagram.\n> ${e.message || e}`);
  }
};

handler.help = handler.command = ["ig", "igdl", "instagram"];
handler.tags = ["downloader"];

module.exports = handler;