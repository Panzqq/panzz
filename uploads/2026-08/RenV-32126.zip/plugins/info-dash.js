const { createCanvas, loadImage } = require('canvas')
const fs = require('fs')
const { execFileSync } = require('child_process')
const ffmpeg = require('ffmpeg-static')
const { tmpFolder, tmpFile, safeRmSync, safeUnlinkSync } = require('../lib/tmpManager')

let handler = async (m, { conn }) => {

  if (!db.data.usage) db.data.usage = { total: 0, success: 0, error: 0, today: {}, hourly: Array(24).fill(0), group: 0, private: 0, speed: [] }

  let usage = db.data.usage
  let todayKey = new Date().toISOString().slice(0,10)

  let today = usage.today[todayKey] || { total: 0, success: 0, error: 0 }

  let stats = Object.entries(db.data.stats || {}).map(([key, val]) => {
    let name = Array.isArray(global.plugins[key]?.help) ? global.plugins[key]?.help.join(', ') : global.plugins[key]?.help || key
    return { name, key, ...val }
  })

  let sorted = stats.sort((a,b)=>b.total-a.total)

  let topCmd = sorted.slice(0,3).map((v,i)=>`${i+1}. ${v.name.split(',')[0]}`).join('\n')

  let users = Object.entries(db.data.users || {}).map(([id, u]) => ({
    id,
    total: u.total || 0,
    last: u.last || 0
  }))

  let topUsers = users.sort((a,b)=>b.total-a.total).slice(0,3)
    .map((u,i)=>`${i+1}. @${u.id.split('@')[0]} (${u.total}x)`).join('\n')

  let totalUser = users.length
  let activeUser = users.filter(u => Date.now() - (u.last||0) < 7*86400000).length
  let inactiveUser = totalUser - activeUser

  let peakHour = usage.hourly.indexOf(Math.max(...usage.hourly))
  let lowHour = usage.hourly.indexOf(Math.min(...usage.hourly))

  function hourRange(h){
    let next = (h+2)%24
    return `${String(h).padStart(2,'0')}:00 - ${String(next).padStart(2,'0')}:00`
  }

  let peak = `
> [+] Peak Time
> ${hourRange(peakHour)} (Ramai)
> ${hourRange(lowHour)} (Sepi)
`.trim()

  let todayStat = `
> [+] Aktivitas Hari Ini
> Command : ${today.total}x
> Success : ${today.success}x
> Error   : ${today.error}x
`.trim()

  let errorRate = today.total ? Math.round((today.error / today.total)*100) : 0

  let errorText = `
> [+] Error Rate
> ${errorRate}% gagal
`.trim()

  let pluginUse = {}

  sorted.forEach(s=>{
    let tags = global.plugins[s.key]?.tags || []
    tags.forEach(t=>{
      if(!pluginUse[t]) pluginUse[t]=0
      pluginUse[t]+=s.total||0
    })
  })

  let mostPlugin = Object.keys(pluginUse).sort((a,b)=>pluginUse[b]-pluginUse[a])[0] || '-'
  let mostVal = pluginUse[mostPlugin] || 0

  let pluginText = `
> [+] Most Used Plugin
> ${mostPlugin} (${mostVal}x)
`.trim()

  let group = usage.group || 0
  let priv = usage.private || 0
  let totalSrc = group + priv || 1

  let srcText = `
> [+] Usage Source
> Group   : ${Math.round(group/totalSrc*100)}%
> Private : ${Math.round(priv/totalSrc*100)}%
`.trim()

  let avgSpeed = usage.speed.length ? Math.round(usage.speed.reduce((a,b)=>a+b,0)/usage.speed.length) : 0

  let perf = `
> [+] Performance
> Avg Response: ${avgSpeed}ms
`.trim()

  let history = usage.hourly.slice(-5)
  let spark = history.map(v => '▁▂▃▄▅▆▇'[Math.min(6, Math.floor(v/5))] || '▁').join('')

  let insightArr = []

  if (peakHour >= 18) insightArr.push('Bot aktif tinggi di malam hari')
  if (mostPlugin) insightArr.push(`Kategori ${mostPlugin} mendominasi`)
  if (errorRate > 10) insightArr.push('Error cukup tinggi, perlu perbaikan')

  let insight = `
> [+] Insight
> ${insightArr.join('\n> ')}
`.trim()

  const data = {
    case: today.total,
    plugin: totalUser,
    total: today.total + totalUser
  }

  const totalFrames = 20
  const holdFrames = 20
  const tempDir = tmpFolder({ dir: 'frames/dashboard', prefix: 'dash' })
  const output = tmpFile({ dir: 'frames/dashboard', prefix: 'output', ext: 'mp4' })

  try {
    for (let i = 0; i <= totalFrames; i++) {
      let img = await createFrame(i, totalFrames, data)
      fs.writeFileSync(`${tempDir}/frame_${i}.png`, img)
    }

    for (let i = totalFrames + 1; i <= totalFrames + holdFrames; i++) {
      fs.copyFileSync(`${tempDir}/frame_${totalFrames}.png`, `${tempDir}/frame_${i}.png`)
    }

    execFileSync(ffmpeg, [
      '-y',
      '-framerate', '20',
      '-i', `${tempDir}/frame_%d.png`,
      '-vf', 'scale=900:500,format=yuv420p',
      output
    ])

    let video = fs.readFileSync(output)

    await conn.sendMessage(m.chat, {
      video,
    gifPlayback: true,
    caption: `
> [+] *ULTRA ANALYTICS DASHBOARD*

> [+] Top Users
${topUsers}

${peak}

${todayStat}

${errorText}

${pluginText}

> [+] User Stats
> Total User : ${totalUser}
> Active     : ${activeUser}
> Inactive   : ${inactiveUser}

${srcText}

${perf}

> [+] Top Command
${topCmd}

> [+] Usage Trend
> ${spark}

${insight}
    `.trim()
    }, { quoted: m })
  } finally {
    safeRmSync(tempDir)
    safeUnlinkSync(output)
  }
}

handler.command = handler.help = ['dashboard','dash']
handler.tags = ['info']
module.exports = handler


async function createFrame(frame, maxFrame, data) {
  const width = 900
  const height = 500
  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext('2d')

  const avatar = await loadImage('https://raw.githubusercontent.com/Panzqq/panzz/main/uploads/2026-03-20/RenV-22542.jpeg')

  const items = [
    { label: 'Today Cmd', value: data.case, color: ['#22d3ee','#3b82f6'], delay: 0 },
    { label: 'Users', value: data.plugin, color: ['#facc15','#f97316'], delay: 0.15 },
    { label: 'Total', value: data.total, color: ['#4ade80','#22c55e'], delay: 0.3 }
  ]

  let t = frame / maxFrame

  ctx.fillStyle = '#020617'
  ctx.fillRect(0,0,width,height)

  ctx.save()
  ctx.beginPath()
  ctx.arc(100,100,40,0,Math.PI*2)
  ctx.clip()
  ctx.drawImage(avatar,60,60,80,80)
  ctx.restore()

  ctx.fillStyle='#fff'
  ctx.font='bold 30px Sans'
  ctx.fillText('Analytics Today',160,100)

  let y=180
  let max=Math.max(data.total,100)

  for(let item of items){
    let val=Math.floor(item.value*(1-Math.pow(1-t,3)))

    ctx.fillStyle='#fff'
    ctx.fillText(item.label,80,y)

    ctx.fillText(val.toString(),750,y)

    ctx.fillStyle='#1f2937'
    ctx.fillRect(80,y+10,700,15)

    let w=700*(val/max)
    let g=ctx.createLinearGradient(80,0,80+w,0)
    g.addColorStop(0,item.color[0])
    g.addColorStop(1,item.color[1])

    ctx.fillStyle=g
    ctx.fillRect(80,y+10,w,15)

    y+=80
  }

  return canvas.toBuffer()
}