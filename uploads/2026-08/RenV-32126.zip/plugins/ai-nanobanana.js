const https = require('https');
const fs = require('fs');
const path = require('path');
const { tmpFile, safeUnlink } = require('../lib/tmpManager');

function req(options, body = null) {
  return new Promise((resolve, reject) => {
    const r = https.request(options, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({
        status: res.statusCode,
        headers: res.headers,
        body: Buffer.concat(chunks).toString(),
      }));
    });
    r.on('error', reject);
    if (body) r.write(body);
    r.end();
  });
}

function reqBuf(options, body = null) {
  return new Promise((resolve, reject) => {
    const r = https.request(options, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({
        status: res.statusCode,
        headers: res.headers,
        body: Buffer.concat(chunks).toString(),
      }));
    });
    r.on('error', reject);
    if (body) r.write(body);
    r.end();
  });
}


function getExtFromMime(mime = '') {
  if (mime.includes('png')) return 'png';
  if (mime.includes('webp')) return 'webp';
  if (mime.includes('jpeg') || mime.includes('jpg')) return 'jpg';
  return 'jpg';
}

function getBuffer(url) {
  return new Promise((resolve, reject) => {
    https.get(url, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    }).on('error', reject);
  });
}

async function nanobana(imagePath, prompt) {
  const TM = {
    'Content-Type': 'application/json',
    'Application-Name': 'web',
    'Application-Version': '4.0.0',
    'X-CORS-Header': 'iaWg3pchvFx48fY',
  };

  const tmNew = await req({
    hostname: 'api.internal.temp-mail.io',
    path: '/api/v3/email/new',
    method: 'POST',
    headers: TM
  }, JSON.stringify({ min_name_length: 10, max_name_length: 10 }));

  const { email, token } = JSON.parse(tmNew.body);

  await req({
    hostname: 'www.nanobana.net',
    path: '/api/auth/email/send',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  }, JSON.stringify({ email }));

  let code = null;
  for (let i = 0; i < 15; i++) {
    await new Promise(r => setTimeout(r, 3000));
    const inbox = await req({
      hostname: 'api.internal.temp-mail.io',
      path: `/api/v3/email/${email}/messages`,
      method: 'GET',
      headers: { ...TM, 'X-Mail-Token': token }
    });

    const msgs = JSON.parse(inbox.body);
    if (msgs.length > 0) {
      const m = msgs[0].subject.match(/\d{6}/);
      if (m) { code = m[0]; break; }
    }
  }

  if (!code) throw 'Kode tidak masuk';

  const csrfRes = await req({
    hostname: 'www.nanobana.net',
    path: '/api/auth/csrf',
    method: 'GET',
    headers: { 'Content-Type': 'application/json' }
  });

  const { csrfToken } = JSON.parse(csrfRes.body);
  const csrfCookies = (csrfRes.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ');

  const payload = new URLSearchParams({
    email, code,
    redirect: 'false',
    csrfToken,
    callbackUrl: 'https://www.nanobana.net/'
  }).toString();

  const loginRes = await req({
    hostname: 'www.nanobana.net',
    path: '/api/auth/callback/email-code?',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(payload),
      'Cookie': csrfCookies,
      'Origin': 'https://www.nanobana.net',
      'Referer': 'https://www.nanobana.net/',
      'X-Auth-Return-Redirect': '1',
    },
  }, payload);

  const sessionCookies = (loginRes.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ');

  const fileBuffer = fs.readFileSync(imagePath);
  const filename = path.basename(imagePath);
  const boundary = '----WebKitFormBoundary' + Math.random().toString(36).slice(2);

  const pre = Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: image/jpeg\r\n\r\n`);
  const post = Buffer.from(`\r\n--${boundary}--\r\n`);
  const multipart = Buffer.concat([pre, fileBuffer, post]);

  const uploadRes = await reqBuf({
    hostname: 'www.nanobana.net',
    path: '/api/upload/image',
    method: 'POST',
    headers: {
      'Content-Type': `multipart/form-data; boundary=${boundary}`,
      'Content-Length': multipart.length,
      'Cookie': sessionCookies,
      'Origin': 'https://www.nanobana.net',
      'Referer': 'https://www.nanobana.net',
    },
  }, multipart);

  const { url: imageUrl } = JSON.parse(uploadRes.body);

  const genBody = JSON.stringify({
    prompt,
    aspect_ratio: '1:1',
    image_input: [imageUrl],
    output_format: 'png',
    resolution: '1K',
  });

  const genRes = await req({
    hostname: 'www.nanobana.net',
    path: '/api/nano-banana-pro/generate',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(genBody),
      'Cookie': sessionCookies,
    },
  }, genBody);

  const { data: { taskId } } = JSON.parse(genRes.body);

  let result = null;
  for (let i = 0; i < 30; i++) {
    await new Promise(r => setTimeout(r, 3000));

    const taskRes = await req({
      hostname: 'www.nanobana.net',
      path: `/api/nano-banana-pro/task/${taskId}`,
      method: 'GET',
      headers: { 'Cookie': sessionCookies },
    });

    const taskData = JSON.parse(taskRes.body);
    if (taskData.data?.status === 'completed') {
      result = taskData;
      break;
    }
  }

  if (!result) throw 'Gagal generate';

  const images = result.data?.result?.images || [];
  return images.map(v => v.url || v);
}

/* ================= HANDLER ================= */

let handler = async (m, { conn, text }) => {
  if (!m.quoted) throw 'Reply gambar + prompt';

  const q = m.quoted;
  const mime = (q.msg || q).mimetype || '';
  if (!mime.startsWith('image/')) throw 'Harus gambar';

  if (!text) throw 'Masukkan prompt';

  await conn.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });

  const media = await q.download();
  const filePath = tmpFile({ dir: 'ai/nanobanana', prefix: 'input', ext: getExtFromMime(mime) });
  fs.writeFileSync(filePath, media);

  try {
    const urls = await nanobana(filePath, text);
    const buffer = await getBuffer(urls[0]);

    await conn.sendMessage(m.chat, {
      image: buffer,
      caption: `> [+] Prompt: ${text}`
    }, { quoted: m });

  } catch (e) {
    throw String(e);
  } finally {
    await safeUnlink(filePath);
  }
};

handler.help = ['nanobanana'];
handler.command = ['nanobanana'];
handler.tags = ['ai'];

module.exports = handler;