const axios = require("axios");
const cheerio = require("cheerio");

const BASE_URL = "https://pinedrama.com";
const TIMEOUT = 30000;
const MAX_SEARCH_RESULT = 10;
const MAX_EPISODE_LIST = 60;

const UA =
  "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";

function clean(text) {
  return String(text || "")
    .replace(/\s+/g, " ")
    .replace(/\u00a0/g, " ")
    .trim();
}

function absUrl(url) {
  if (!url) return null;

  try {
    return new URL(url, BASE_URL).href;
  } catch {
    return url;
  }
}

function slugFromUrl(url) {
  if (!url) return null;

  const cleanUrl = url
    .split("?")[0]
    .replace(/\/$/, "")
    .replace(/\/ep\d+$/i, "");

  return cleanUrl.split("/").pop() || null;
}

function dramaUrlFromSlug(slug) {
  return `${BASE_URL}/dramas/${slug}`;
}

function episodeUrlFromSlug(slug, episode) {
  return `${BASE_URL}/dramas/${slug}/ep${episode}`;
}

function uniqueBy(items, key) {
  const seen = new Set();
  const result = [];

  for (const item of items) {
    const value = item[key];
    if (!value || seen.has(value)) continue;

    seen.add(value);
    result.push(item);
  }

  return result;
}

function decodeNextText(html) {
  return String(html || "")
    .replace(/\\u0026/g, "&")
    .replace(/\\u003c/g, "<")
    .replace(/\\u003e/g, ">")
    .replace(/\\u002f/g, "/")
    .replace(/\\"/g, '"')
    .replace(/\\\\/g, "\\");
}

async function fetchHtml(url, referer = BASE_URL + "/") {
  const res = await axios.get(url, {
    timeout: TIMEOUT,
    validateStatus: () => true,
    headers: {
      accept:
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
      "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
      referer,
      "user-agent": UA
    }
  });

  if (res.status !== 200) {
    throw new Error(`Gagal membuka halaman: HTTP ${res.status}`);
  }

  return res.data;
}

function parseJsonLd($) {
  const items = [];

  $('script[type="application/ld+json"]').each((_, el) => {
    const raw = $(el).text();

    try {
      items.push(JSON.parse(raw));
    } catch {}
  });

  return items;
}

function parseDramaCard($, el) {
  const card = $(el);
  const link = card.find('a[href*="/dramas/"]').first();
  const genreLink = card.find('a[href*="/genres/"]').first();
  const img = card.find("img").first();

  let url = absUrl(link.attr("href"));
  if (!url) return null;

  url = url.replace(/\/ep\d+$/i, "");

  const slug = slugFromUrl(url);
  if (!slug) return null;

  const title =
    clean(link.text()) ||
    clean(img.attr("alt")) ||
    slug.replace(/-/g, " ");

  const image = absUrl(img.attr("src") || img.attr("data-src"));
  const genre = clean(genreLink.text()) || null;
  const text = clean(card.text());
  const ratingMatch = text.match(/\b\d(?:\.\d)?\b/);

  return {
    title,
    slug,
    url: dramaUrlFromSlug(slug),
    image,
    genre,
    rating: ratingMatch ? ratingMatch[0] : null
  };
}

async function searchDrama(query) {
  const q = String(query || "").trim();
  const url = q
    ? `${BASE_URL}/search?q=${encodeURIComponent(q)}`
    : `${BASE_URL}/search`;

  const html = await fetchHtml(url, `${BASE_URL}/search`);
  const $ = cheerio.load(html);

  const items = [];

  $('a[href*="/dramas/"]').each((_, a) => {
    const card = $(a).closest("div");
    const item = parseDramaCard($, card);

    if (item) items.push(item);
  });

  return {
    query: q,
    url,
    total: uniqueBy(items, "slug").length,
    items: uniqueBy(items, "slug").slice(0, MAX_SEARCH_RESULT)
  };
}

function parseEpisodeNumbers($, html, slug) {
  const episodes = new Set();
  const decoded = decodeNextText(html);

  $(`a[href*="/dramas/${slug}/ep"]`).each((_, el) => {
    const href = $(el).attr("href") || "";
    const match = href.match(/\/ep(\d+)/i);

    if (match) episodes.add(Number(match[1]));
  });

  const regexUrl = new RegExp(`/dramas/${slug}/ep(\\d+)`, "gi");
  let matchUrl;

  while ((matchUrl = regexUrl.exec(decoded)) !== null) {
    episodes.add(Number(matchUrl[1]));
  }

  const regexId = /"episode_id"\s*:\s*(\d+)/g;
  let matchId;

  while ((matchId = regexId.exec(decoded)) !== null) {
    episodes.add(Number(matchId[1]));
  }

  return [...episodes]
    .filter(n => Number.isInteger(n) && n > 0)
    .sort((a, b) => a - b);
}

function parseStreamUrls(html) {
  const decoded = decodeNextText(html);
  const items = [];
  const regex = /"episode_id"\s*:\s*(\d+)\s*,\s*"url"\s*:\s*"([^"]+)"/g;

  let match;
  while ((match = regex.exec(decoded)) !== null) {
    items.push({
      episode: Number(match[1]),
      url: match[2].replace(/\\u0026/g, "&")
    });
  }

  return items;
}

function parseDramaDetail(html, slug) {
  const $ = cheerio.load(html);
  const jsonLd = parseJsonLd($);

  const schema =
    jsonLd.find(x => x["@type"] === "TVSeries") ||
    jsonLd.find(x => x["@type"] === "Movie") ||
    jsonLd.find(x => x["@type"] === "CreativeWork") ||
    {};

  const title =
    clean(schema.name) ||
    clean($("h1").first().text()) ||
    slug.replace(/-/g, " ");

  const image = absUrl(
    schema.image ||
      $('meta[property="og:image"]').attr("content") ||
      $("img").first().attr("src")
  );

  const description =
    clean($('meta[name="description"]').attr("content")) ||
    clean(schema.description) ||
    "-";

  const genres = [];

  $('a[href*="/genres/"]').each((_, el) => {
    const a = $(el);
    const name = clean(a.text());
    const url = absUrl(a.attr("href"));

    if (!name || !url) return;
    if (genres.some(x => x.url === url)) return;

    genres.push({
      name,
      url
    });
  });

  const episodes = parseEpisodeNumbers($, html, slug);

  return {
    title,
    slug,
    url: dramaUrlFromSlug(slug),
    image,
    description,
    genres,
    episodes
  };
}

async function getDramaDetail(slug) {
  const url = dramaUrlFromSlug(slug);
  const html = await fetchHtml(url, BASE_URL + "/");
  return parseDramaDetail(html, slug);
}

function parseEpisodeDetail(html, slug, episode) {
  const $ = cheerio.load(html);
  const jsonLd = parseJsonLd($);

  const schema =
    jsonLd.find(x => x["@type"] === "TVEpisode") ||
    jsonLd.find(x => x["@type"] === "Episode") ||
    {};

  const title =
    clean(schema.partOfSeries?.name) ||
    clean($("h1").first().text()) ||
    slug.replace(/-/g, " ");

  const episodeTitle =
    clean(schema.name) ||
    `Episode ${episode}`;

  const image = absUrl(
    schema.image ||
      $('meta[property="og:image"]').attr("content") ||
      $("img").first().attr("src")
  );

  const description =
    clean($('meta[name="description"]').attr("content")) ||
    clean(schema.description) ||
    "-";

  const genres = [];

  $('a[href*="/genres/"]').each((_, el) => {
    const a = $(el);
    const name = clean(a.text());
    const url = absUrl(a.attr("href"));

    if (!name || !url) return;
    if (genres.some(x => x.url === url)) return;

    genres.push({
      name,
      url
    });
  });

  return {
    title,
    episodeTitle,
    slug,
    episode,
    url: episodeUrlFromSlug(slug, episode),
    image,
    description,
    genres
  };
}

async function getEpisodeDetail(slug, episode) {
  const url = episodeUrlFromSlug(slug, episode);
  const html = await fetchHtml(url, dramaUrlFromSlug(slug));
  const detail = parseEpisodeDetail(html, slug, episode);
  
  const streams = parseStreamUrls(html);
  const streamUrl = streams.find(item => item.episode === Number(episode))?.url || null;

  const $ = cheerio.load(html);
  const episodes = parseEpisodeNumbers($, html, slug);

  return {
    ...detail,
    streamUrl,
    episodes
  };
}

function footer() {
  return `[ ${global.namebot || "Renvy"} :: ${global.nameown || "Owner"} ]`;
}

function pickThumb(url) {
  return url || global.thumb || null;
}

async function sendSearchResult(m, conn, data) {
  if (!data.items.length) {
    return m.reply(`[ Drama tidak ditemukan untuk: ${data.query} ]`);
  }

  const rows = data.items.map((item, index) => ({
    header: `[ ${index + 1}. ${item.title} ]`,
    title: item.genre ? `Genre: ${item.genre}` : "Lihat detail drama",
    description: item.rating ? `Rating: ${item.rating}` : item.url,
    id: `.pinedrama detail ${item.slug}`
  }));

  const text = `
> [+] *PINEDRAMA SEARCH*

> [ QUERY ] ${data.query || "-"}
> [ TOTAL ] ${data.total}
> [ HASIL ] ${data.items.length}

> Pilih drama dari list di bawah.
`.trim();

  return conn.sendButtonLoc(
    m.chat,
    [{ id: ".pinedrama", text: "[ Pilih Drama ]", native: true }],
    text,
    footer(),
    m,
    {
      mentions: [m.sender],
      thumbUrl: pickThumb(data.items[0]?.image),
      name: global.namebot || "Renvy",
      address: "PineDrama Search",
      nativeSelectData: {
        title: "Pilih Drama",
        sections: [
          {
            title: "Search Results",
            rows
          }
        ]
      }
    }
  );
}

async function sendDramaDetail(m, conn, detail) {
  const episodes = detail.episodes || [];
  const showEpisodes = episodes.slice(0, MAX_EPISODE_LIST);

  const genreText = detail.genres.length
    ? detail.genres.map(x => x.name).join(", ")
    : "-";

  const episodeText = episodes.length
    ? `${episodes.length} episode`
    : "Belum terdeteksi";

  const rows = showEpisodes.length
    ? showEpisodes.map(ep => ({
        header: `[ Episode ${ep} ]`,
        title: "Lihat detail episode",
        description: episodeUrlFromSlug(detail.slug, ep),
        id: `.pinedrama ep ${detail.slug} ${ep}`
      }))
    : [
        {
          header: "[ Episode 1 ]",
          title: "Lihat detail episode",
          description: episodeUrlFromSlug(detail.slug, 1),
          id: `.pinedrama ep ${detail.slug} 1`
        }
      ];

  const moreText =
    episodes.length > MAX_EPISODE_LIST
      ? `\n> [ NOTE ] Ditampilkan ${MAX_EPISODE_LIST} episode pertama.`
      : "";

  const text = `
> [+] *PINEDRAMA DETAIL*

> [ JUDUL   ] ${detail.title}
> [ GENRE   ] ${genreText}
> [ EPISODE ] ${episodeText}
> [ LINK    ] ${detail.url}

> [ SINOPSIS ]
${detail.description}
${moreText}

> Pilih episode dari list di bawah.
`.trim();

  return conn.sendButtonLoc(
    m.chat,
    [{ id: `.pinedrama ${detail.title}`, text: "[ Pilih Episode ]", native: true }],
    text,
    footer(),
    m,
    {
      mentions: [m.sender],
      thumbUrl: pickThumb(detail.image),
      name: global.namebot || "Renvy",
      address: "PineDrama Detail",
      nativeSelectData: {
        title: "Pilih Episode",
        sections: [
          {
            title: "Episode List",
            rows
          }
        ]
      }
    }
  );
}

async function sendEpisodeDetail(m, conn, data) {
  const genreText = data.genres.length
    ? data.genres.map(x => x.name).join(", ")
    : "-";

  const text = `
> [+] *PINEDRAMA EPISODE*

> [ JUDUL   ] ${data.title}
> [ EPISODE ] ${data.episode}
> [ NAMA EP ] ${data.episodeTitle}
> [ GENRE   ] ${genreText}
> [ LINK    ] ${data.url}

> [ SINOPSIS ]
${data.description}

> Gunakan link di atas untuk menonton dari halaman resminya.
`.trim();

  const episodes = data.episodes || [];
  const showEpisodes = episodes.slice(0, MAX_EPISODE_LIST);

  const rows = showEpisodes.length
    ? showEpisodes.map(ep => ({
        header: `[ Episode ${ep} ]`,
        title: "Lihat detail episode",
        description: episodeUrlFromSlug(data.slug, ep),
        id: `.pinedrama ep ${data.slug} ${ep}`
      }))
    : [
        {
          header: "[ Episode 1 ]",
          title: "Lihat detail episode",
          description: episodeUrlFromSlug(data.slug, 1),
          id: `.pinedrama ep ${data.slug} 1`
        }
      ];

  // Mengubah struktur tombol agar menggunakan list selector langsung pada [ Episode Lain ]
  await conn.sendButtonLoc(
    m.chat,
    [
      { id: `.pinedrama detail ${data.slug}`, text: "[ Episode Lain ]", native: true },
      { id: `.pinedrama ${data.title}`, text: "[ Search ]" }
    ],
    text,
    footer(),
    m,
    {
      mentions: [m.sender],
      thumbUrl: pickThumb(data.image),
      name: global.namebot || "Renvy",
      address: `Episode ${data.episode}`,
      nativeSelectData: {
        title: "Episode Lain",
        sections: [
          {
            title: "Episode List",
            rows
          }
        ]
      }
    }
  );

  if (data.streamUrl) {
    try {
      let currentStreamUrl = data.streamUrl;
      let success = false;
      let bufferData = null;

      // Mekanisme perulangan tak terbatas (looping) sampai download berhasil jika terkena 403 / error sesi expired
      while (!success) {
        try {
          if (!currentStreamUrl) {
            const fresh = await getEpisodeDetail(data.slug, data.episode);
            currentStreamUrl = fresh.streamUrl;
            if (!currentStreamUrl) {
              await new Promise(resolve => setTimeout(resolve, 2000));
              continue;
            }
          }

          const response = await axios.get(currentStreamUrl, {
            responseType: "arraybuffer",
            timeout: 60000,
            headers: {
              accept: "*/*",
              "accept-encoding": "identity;q=1, *;q=0",
              range: "bytes=0-",
              referer: BASE_URL + "/",
              "user-agent": UA
            }
          });

          if ([200, 206].includes(response.status)) {
            bufferData = response.data;
            success = true;
          } else {
            // Jika error status bukan 200/206 (seperti 403), ambil stream url baru lalu coba lagi
            const fresh = await getEpisodeDetail(data.slug, data.episode);
            currentStreamUrl = fresh.streamUrl;
            await new Promise(resolve => setTimeout(resolve, 1500));
          }
        } catch (err) {
          // Otomatis re-scrape halaman web jika request stream terputus / forbidden
          const fresh = await getEpisodeDetail(data.slug, data.episode);
          currentStreamUrl = fresh.streamUrl;
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      }

      if (bufferData) {
        await conn.sendMessage(m.chat, {
          video: Buffer.from(bufferData),
          mimetype: "video/mp4",
          fileName: `${data.slug}-ep${data.episode}.mp4`,
          caption: `*${data.title}* - Episode ${data.episode}`
        }, { quoted: m });
      }
    } catch (err) {
      console.error(err);
    }
  } else {
    await m.reply("> [!] Video tidak ditemukan atau episode terkunci (Premium).");
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const input = String(text || "").trim();

  if (!input) {
    return m.reply(
      `Masukkan judul drama.\n\n` +
        `Contoh:\n` +
        `${usedPrefix + command} romance\n\n` +
        `Detail manual:\n` +
        `${usedPrefix + command} detail cooking-my-way-back-to-love\n\n` +
        `Episode manual:\n` +
        `${usedPrefix + command} ep cooking-my-way-back-to-love 2`
    );
  }

  try {
    const args = input.split(/\s+/);
    const action = args[0].toLowerCase();

    if (action === "detail") {
      const slug = args[1];

      if (!slug) {
        return m.reply(
          `Masukkan slug drama.\n\nContoh:\n${usedPrefix + command} detail cooking-my-way-back-to-love`
        );
      }

      await m.reply("> Sedang mengambil detail drama...");
      const detail = await getDramaDetail(slug);
      return sendDramaDetail(m, conn, detail);
    }

    if (action === "ep" || action === "episode") {
      const slug = args[1];
      const episode = Number(args[2] || 1);

      if (!slug || !Number.isInteger(episode) || episode < 1) {
        return m.reply(
          `Format salah.\n\nContoh:\n${usedPrefix + command} ep cooking-my-way-back-to-love 2`
        );
      }

      await m.reply("> Sedang mengambil detail episode...");
      const data = await getEpisodeDetail(slug, episode);
      return sendEpisodeDetail(m, conn, data);
    }

    await m.reply("> Sedang mencari drama...");
    const result = await searchDrama(input);
    return sendSearchResult(m, conn, result);
  } catch (e) {
    console.error(e);

    return m.reply(
      `
> [!] Gagal memproses PineDrama.
> ${e.message || e}
`.trim()
    );
  }
};

handler.help = ["pinedrama"];
handler.tags = ["internet"];
handler.command = ["pinedrama", "pdrama"];
handler.limit = true;

module.exports = handler;