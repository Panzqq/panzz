const axios = require('axios');

let handler = async (m, { text, conn, usedPrefix, command }) => {
  if (!text) throw `> [-] Masukkan kata kunci.\n> [+] Contoh: ${usedPrefix + command} indonesia`;

  try {
    const query = encodeURIComponent(text.trim());
    const url = `https://id.wikipedia.org/api/rest_v1/page/summary/${query}`;

    const { data } = await axios.get(url, {
      headers: { 
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' 
      }
    });

    if (!data.extract) throw new Error('No content');

    const replyText = `> [+] WIKIPEDIA\n> \n> [+] Kata Kunci: ${data.title}\n> [+] Penjelasan:\n> ${data.extract}\n> \n> [+] Sumber: ${data.content_urls.desktop.page}\n> \n> [+] Status: Success`;

    await m.reply(replyText);

  } catch (err) {
    m.reply(`> [-] Artikel tentang "${text}" tidak ditemukan.\n> [+] Status: Error`);
  }
};

handler.help = ['wiki'];
handler.tags = ['search'];
handler.command = /^(wiki|wikipedia)$/i;

module.exports = handler;