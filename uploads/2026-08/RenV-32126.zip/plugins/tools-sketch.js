const path = require('path')

const BASE = 'https://artyde.com'
const PAGE = `${BASE}/photo_to_sketch`
const UPLOAD_URL = `${BASE}/upload_photoToSketch_website`

const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36'

const MIME = {
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.bmp': 'image/bmp'
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
const isUrl = v => /^https?:\/\//i.test(String(v || ''))

function getHeaders(extra = {}) {
  return {
    'user-agent': UA,
    'accept': '*/*',
    'origin': BASE,
    'referer': PAGE,
    ...extra
  }
}

function getMime(ext = '') {
  return MIME[String(ext).toLowerCase()] || 'image/jpeg'
}

function mimeToExt(mime = '') {
  mime = String(mime).toLowerCase()

  if (mime.includes('png')) return '.png'
  if (mime.includes('webp')) return '.webp'
  if (mime.includes('gif')) return '.gif'
  if (mime.includes('bmp')) return '.bmp'
  return '.jpg'
}

function buildOutputName(fileId = '') {
  return String(fileId).replace(/\.[^.]+$/, '.png')
}

function buildOutputUrl(fileId = '') {
  return `${BASE}/output/${buildOutputName(fileId)}`
}

async function loadImage(input) {
  if (Buffer.isBuffer(input?.buffer)) {
    const filename = input.filename || `image${mimeToExt(input.contentType)}`
    const ext = path.extname(filename) || mimeToExt(input.contentType)

    return {
      buffer: input.buffer,
      filename,
      ext,
      contentType: input.contentType || getMime(ext)
    }
  }

  if (isUrl(input)) {
    const res = await fetch(input, {
      headers: {
        'user-agent': UA,
        'accept': '*/*'
      }
    })

    if (!res.ok) {
      throw new Error(`Gagal ambil image URL: ${res.status} ${res.statusText}`)
    }

    const buffer = Buffer.from(await res.arrayBuffer())
    const url = new URL(input)
    const rawName = path.basename(url.pathname) || 'image.jpg'
    const filename = decodeURIComponent(rawName)
    const ext = path.extname(filename) || '.jpg'
    const contentType = (res.headers.get('content-type') || getMime(ext)).split(';')[0]

    return {
      buffer,
      filename,
      ext,
      contentType
    }
  }

  throw new Error('Input gambar tidak valid.')
}

async function uploadPhoto(image, options = {}) {
  if (typeof FormData === 'undefined' || typeof Blob === 'undefined') {
    throw new Error('Node.js kamu belum support FormData/Blob. Gunakan Node.js 18 ke atas.')
  }

  const uploadFields = options.uploadField
    ? [options.uploadField]
    : ['file', 'image', 'img', 'photo', 'source_image', 'upload']

  let lastError = null

  for (const field of uploadFields) {
    try {
      const form = new FormData()
      const blob = new Blob([image.buffer], { type: image.contentType })

      form.append(field, blob, image.filename)

      const res = await fetch(UPLOAD_URL, {
        method: 'POST',
        headers: getHeaders(),
        body: form
      })

      const json = await res.json().catch(() => ({}))

      if (res.ok && json?.status === 'success' && json?.file_id) {
        return {
          upload_field: field,
          file_id: json.file_id,
          filename: json.filename,
          token: json.token || null,
          queue: json.queue ?? null,
          raw: json
        }
      }

      lastError = new Error(`Upload gagal field=${field}: ${JSON.stringify(json)}`)
    } catch (err) {
      lastError = err
    }
  }

  throw lastError || new Error('Upload gagal.')
}

async function checkOutput(outputUrl) {
  const res = await fetch(outputUrl, {
    method: 'GET',
    headers: {
      'user-agent': UA,
      'accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
      'referer': BASE + '/'
    }
  })

  if (res.ok) {
    return {
      ok: true,
      status: res.status,
      content_type: res.headers.get('content-type') || null,
      content_length: res.headers.get('content-length') || null
    }
  }

  return {
    ok: false,
    status: res.status
  }
}

async function waitForResult(fileId, options = {}) {
  const interval = Number(options.interval || 2500)
  const maxAttempts = Number(options.maxAttempts || 20)
  const outputUrl = buildOutputUrl(fileId)

  let last = null

  for (let i = 1; i <= maxAttempts; i++) {
    const result = await checkOutput(outputUrl)
    last = result

    if (result.ok) {
      return {
        done: true,
        attempts: i,
        output_name: buildOutputName(fileId),
        output_url: outputUrl,
        ...result
      }
    }

    await sleep(interval)
  }

  return {
    done: false,
    output_name: buildOutputName(fileId),
    output_url: outputUrl,
    last
  }
}

async function artydePhotoToSketch(input, options = {}) {
  const image = await loadImage(input)
  const uploaded = await uploadPhoto(image, options)
  const result = await waitForResult(uploaded.file_id, options)

  return {
    status: true,
    base: BASE,
    input: {
      filename: image.filename,
      content_type: image.contentType
    },
    upload: {
      upload_field: uploaded.upload_field,
      file_id: uploaded.file_id,
      filename: uploaded.filename,
      token: uploaded.token,
      queue: uploaded.queue
    },
    result
  }
}

async function getImageInput(m, text) {
  const q = m.quoted || m
  const mime = (q.msg || q).mimetype || q.mimetype || ''

  if (/image/i.test(mime)) {
    const buffer = await q.download?.()

    if (!buffer) {
      throw new Error('Gagal download gambar dari pesan.')
    }

    return {
      buffer,
      filename: `photo${mimeToExt(mime)}`,
      contentType: mime.split(';')[0] || 'image/jpeg'
    }
  }

  if (text && isUrl(text)) {
    return text.trim()
  }

  throw new Error(
    `Kirim/reply gambar dengan caption *.sketch*\n\nAtau pakai URL:\n*.sketch https://example.com/image.jpg*`
  )
}

let handler = async (m, { conn, text }) => {
  try {
    const input = await getImageInput(m, text)

    await m.reply('⏳ Sedang mengubah foto menjadi sketch...')

    const res = await artydePhotoToSketch(input, {
      interval: 2500,
      maxAttempts: 20
    })

    if (!res.result?.done) {
      return m.reply(
        `⚠️ Sketch belum selesai diproses.\n\n` +
        `Coba buka manual:\n${res.result?.output_url || '-'}`
      )
    }

    const caption =
      `✅ *Photo To Sketch Berhasil*\n\n` +
      `📁 File: ${res.input.filename}\n` +
      `🖼️ Type: ${res.input.content_type}\n` +
      `🔁 Percobaan: ${res.result.attempts}\n` +
      `🔗 URL: ${res.result.output_url}`

    await conn.sendMessage(
      m.chat,
      {
        image: { url: res.result.output_url },
        caption
      },
      { quoted: m }
    )
  } catch (err) {
    m.reply(`❌ Gagal membuat sketch.\n\n${err.message}`)
  }
}

handler.help = handler.command = ['sketch', 'photosketch', 'tosketch']
handler.tags = ['tools']

module.exports = handler