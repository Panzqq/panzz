let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    let intro = `╭【 ♡・ welcome 】 ・・

・┈ ✦﹕ nama :
・┈ ✦﹕ umur :
・┈ ✦﹕ gender :
・┈ ✦﹕ askot :

╰╮ ✦﹕ semoga betah :
⎯⎯⎯⎯ ・ ✧・ ⎯⎯⎯⎯`;
        conn.sendCopy(m.chat, [
            ["copy link !", intro]
        ], fakestatus("Your Intro Card"), {
            body: intro
        });
};
handler.help = ["intro"].map((a) => a + " *[introduction ys]*");
handler.tags = ["group"];
handler.command = ["intro"];

module.exports = handler;