const axios = require('axios');
const cheerio = require('cheerio');

let handler = async (m, { conn }) => {
  try {
    const url = 'https://news.detik.com/indeks';
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    let resultText = `> [+] BERITA TERKINI (DETIK NEWS)\n> \n`;

    $('.list-content__item').slice(0, 5).each((i, el) => {
      const title = $(el).find('.media__title a').text().trim();
      const link = $(el).find('.media__title a').attr('href');
      const time = $(el).find('.media__date').text().replace('detikNews', '').trim();

      if (title && link) {
        resultText += `> [${i + 1}] ${title}\n> Waktu: ${time}\n> Link: ${link}\n> \n`;
      }
    });

    resultText += `> [+] Status: Success`;
    await m.reply(resultText);

  } catch (err) {
    m.reply(`> [-] Gagal mengambil data berita terbaru dari server.\n> [+] Status: Error`);
  }
};

handler.help = ['berita', 'news'];
handler.tags = ['info'];
handler.command = /^(berita|news)$/i;

module.exports = handler;