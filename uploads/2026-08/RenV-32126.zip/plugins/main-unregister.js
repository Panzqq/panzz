let handler = async (m, { conn, text, usedPrefix, command }) => {
  const users = global.db?.data?.users || (global.db.data.users = {});
  const user = users[m.sender] || (users[m.sender] = {});
  const input = String(text || '').trim();

  const sendText = async (teks, key = null) => {
    try {
      if (key) {
        return await conn.sendMessage(m.chat, { text: teks, edit: key }, { quoted: m });
      }
      return await conn.sendMessage(m.chat, { text: teks }, { quoted: m });
    } catch (e) {
      return await conn.sendMessage(m.chat, { text: teks }, { quoted: m });
    }
  };

  if (!input) {
    return sendText(
      `乂 U N R E G I S T E R\n\n` +
      `> [!] Masukkan ID/SN register kamu.\n` +
      `> [+] Example: ${usedPrefix + command} RenV-xxxxxxxx\n\n` +
      `> Untuk melihat SN, cek pesan saat kamu daftar / verify.`
    );
  }

  let key = null;
  try {
    const sent = await conn.sendMessage(
      m.chat,
      { text: global.wait || '[ SYSTEM ] → Please wait...' },
      { quoted: m }
    );
    key = sent?.key || null;
  } catch (e) {}

  try {
    if (!user.registered) {
      return sendText(
        `乂 U N R E G I S T E R\n\n` +
        `> [!] Kamu belum terdaftar.\n` +
        `> [+] Silakan daftar dulu dengan .register`,
        key
      );
    }

    const sn = String(user.sn || '').trim();

    if (!sn || sn === 'Unreg') {
      return sendText(
        `乂 U N R E G I S T E R\n\n` +
        `> [!] ID/SN register kamu tidak ditemukan di database.\n` +
        `> [+] Silakan hubungi owner atau daftar ulang.`,
        key
      );
    }

    if (input !== sn) {
      return sendText(
        `乂 U N R E G I S T E R\n\n` +
        `> [!] ID/SN salah.\n` +
        `> [+] Pastikan ID yang kamu masukkan sama persis.`,
        key
      );
    }

    user.sn = '';
    user.registered = false;
    user.regTime = -1;
    user.age = -1;

    return sendText(
      `乂 U N R E G I S T E R\n\n` +
      `> [+] Status: Success\n` +
      `> [+] Result: Berhasil unregister.`,
      key
    );
  } catch (e) {
    console.error('Error plugin unreg:', e);
    return sendText(
      `乂 U N R E G I S T E R\n\n` +
      `> [!] Terjadi error saat unregister.\n` +
      `> [+] Error: ${e?.message || e}`,
      key
    );
  }
};

handler.help = ['unreg', 'unregister'].map(a => a + ' *[Your ID]*');
handler.tags = ['main'];
handler.command = ['unreg', 'unregister'];

module.exports = handler;