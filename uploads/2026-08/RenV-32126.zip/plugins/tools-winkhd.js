const axios = require("axios");
const FormData = require("form-data");
const crypto = require("node:crypto");
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const path = require("node:path");
const { pipeline } = require("node:stream/promises");
const { tmpDirAsync, tmpFileAsync, safeUnlink: tmpSafeUnlink } = require("../lib/tmpManager");
const { CookieJar } = require("tough-cookie");
const { sleep } = require("../lib/utils");

const BASE_URL = "https://wink.ai";
const STRATEGY_URL = "https://strategy.app.meitudata.com";

const CLIENT_ID = "1189857605";
const VERSION = "5.1.2";
const COUNTRY_CODE = "ID";
const CLIENT_LANGUAGE = "en_US";
const CLIENT_TIMEZONE = "Asia/Jakarta";

const TASK_TYPE = "11";
const CONTENT_TYPE = "2";

const UA =
  "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36";

async function loadWrapper() {
  try {
    return require("axios-cookiejar-support").wrapper;
  } catch {
    const mod = await import("axios-cookiejar-support");
    return mod.wrapper;
  }
}

function isHttpUrl(input) {
  return /^https?:\/\//i.test(String(input || ""));
}

function extToMime(file) {
  const ext = path.extname(file).toLowerCase();

  if (ext === ".mp4") return "video/mp4";
  if (ext === ".mov") return "video/quicktime";
  if (ext === ".webm") return "video/webm";
  if (ext === ".mkv") return "video/x-matroska";
  if (ext === ".avi") return "video/x-msvideo";
  if (ext === ".m4v") return "video/x-m4v";

  return "application/octet-stream";
}

function contentTypeToExt(type) {
  const clean = String(type || "").split(";")[0].trim().toLowerCase();

  if (clean === "video/mp4") return ".mp4";
  if (clean === "video/quicktime") return ".mov";
  if (clean === "video/webm") return ".webm";
  if (clean === "video/x-matroska") return ".mkv";
  if (clean === "video/x-msvideo") return ".avi";
  if (clean === "video/x-m4v") return ".m4v";

  return "";
}

function getExtFromUrl(url) {
  try {
    const pathname = new URL(url).pathname;
    const ext = path.extname(pathname).toLowerCase();

    if ([".mp4", ".mov", ".webm", ".mkv", ".avi", ".m4v"].includes(ext)) {
      return ext;
    }
  } catch {}

  return "";
}

function makeTrace() {
  return `${crypto.randomBytes(16).toString("hex")}-${crypto.randomBytes(8).toString("hex")}-1`;
}

function traceHeaders() {
  const trace = makeTrace();

  return {
    "sentry-trace": trace,
    baggage: [
      "sentry-environment=release",
      "sentry-release=5.1.2%20(b60d25c477f43c6dfac4107810f26d442320f4f1)",
      "sentry-public_key=e1bf914f3448d9bc8a10c7e499d17d54",
      `sentry-trace_id=${trace.split("-")[0]}`,
      "sentry-sampled=true",
      "sentry-sample_rate=0.75"
    ].join(",")
  };
}

class WinkEnhancer {
  constructor() {
    this.gnum = crypto.randomUUID();
    this.api = null;
  }

  baseParams(extra = {}) {
    return new URLSearchParams({
      client_id: CLIENT_ID,
      version: VERSION,
      country_code: COUNTRY_CODE,
      gnum: this.gnum,
      client_language: CLIENT_LANGUAGE,
      client_channel_id: "",
      client_timezone: CLIENT_TIMEZONE,
      ...extra
    });
  }

  async init() {
    const wrapper = await loadWrapper();
    const jar = new CookieJar();

    await jar.setCookie(`_sm=${this.gnum}; Path=/; Domain=wink.ai`, BASE_URL);
    await jar.setCookie(
      `meitustat=${encodeURIComponent(JSON.stringify({ wgid: this.gnum }))}; Path=/; Domain=wink.ai`,
      BASE_URL
    );

    this.api = wrapper(
      axios.create({
        baseURL: BASE_URL,
        jar,
        withCredentials: true,
        validateStatus: () => true,
        headers: {
          accept: "*/*",
          origin: BASE_URL,
          referer: `${BASE_URL}/video-enhancer/upload`,
          "user-agent": UA,
          "sec-ch-ua": "\"Google Chrome\";v=\"147\", \"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"147\"",
          "sec-ch-ua-mobile": "?1",
          "sec-ch-ua-platform": "\"Android\"",
          ab_info: JSON.stringify({
            ab_codes: [],
            version: "1.4.4"
          })
        }
      })
    );
  }

  async getMaatSign() {
    const params = this.baseParams({
      suffix: ".mp4",
      type: "temp",
      count: "1"
    });

    const res = await this.api.get(`/api/file/get_maat_sign.json?${params.toString()}`, {
      headers: traceHeaders()
    });

    if (res.status >= 400 || res.data?.code !== 0) {
      throw new Error(`get_maat_sign gagal: ${JSON.stringify(res.data)}`);
    }

    return res.data.data;
  }

  async getUploadPolicy(sign) {
    const params = new URLSearchParams({
      app: sign.app,
      count: String(sign.count),
      sig: sign.sig,
      sigTime: sign.sig_time,
      sigVersion: sign.sig_version,
      suffix: sign.suffix,
      type: sign.type
    });

    const res = await axios.get(`${STRATEGY_URL}/upload/policy?${params.toString()}`, {
      headers: {
        accept: "*/*",
        origin: BASE_URL,
        referer: `${BASE_URL}/`,
        "user-agent": UA,
        "sec-ch-ua": "\"Google Chrome\";v=\"147\", \"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"147\"",
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": "\"Android\""
      },
      validateStatus: () => true
    });

    if (res.status >= 400 || !Array.isArray(res.data) || !res.data[0]?.qiniu) {
      throw new Error(`upload policy gagal: ${JSON.stringify(res.data)}`);
    }

    return res.data[0].qiniu;
  }

  async uploadToQiniu(policy, filePath) {
    const form = new FormData();

    form.append("file", fs.createReadStream(filePath), {
      filename: path.basename(filePath),
      contentType: extToMime(filePath)
    });

    form.append("token", policy.token);
    form.append("key", policy.key);
    form.append("fname", path.basename(filePath));

    const res = await axios.post(policy.url, form, {
      headers: form.getHeaders({
        origin: BASE_URL,
        referer: `${BASE_URL}/`,
        "user-agent": UA,
        accept: "*/*"
      }),
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
      validateStatus: () => true
    });

    if (res.status >= 400) {
      throw new Error(
        `upload qiniu gagal HTTP ${res.status}: ${
          typeof res.data === "string" ? res.data : JSON.stringify(res.data)
        }`
      );
    }

    if (!res.data?.url && !res.data?.data && !policy.data) {
      throw new Error(`upload qiniu response tidak valid: ${JSON.stringify(res.data)}`);
    }

    return {
      file_key: policy.key,
      source_url: res.data.url || res.data.data || policy.data,
      raw_url: res.data.data || policy.data,
      raw: res.data
    };
  }

  async getVideoInfo(fileKey) {
    const body = this.baseParams({
      file_key: fileKey
    });

    const res = await this.api.post(
      "/api/file/video_cover_and_display_info_ext.json",
      body.toString(),
      {
        headers: {
          ...traceHeaders(),
          "content-type": "application/x-www-form-urlencoded;charset=UTF-8"
        }
      }
    );

    if (res.status >= 400 || res.data?.code !== 0) {
      throw new Error(`video info gagal: ${JSON.stringify(res.data)}`);
    }

    return res.data.data;
  }

  async startTranscode(fileKey) {
    const body = this.baseParams({
      file_key: fileKey
    });

    const res = await this.api.post("/api/file/video_trans_start.json", body.toString(), {
      headers: {
        ...traceHeaders(),
        "content-type": "application/x-www-form-urlencoded;charset=UTF-8"
      }
    });

    if (res.status >= 400 || res.data?.code !== 0 || !res.data?.data?.id) {
      throw new Error(`transcode start gagal: ${JSON.stringify(res.data)}`);
    }

    return res.data.data.id;
  }

  async queryTranscode(id) {
    const params = this.baseParams({
      id
    });

    const res = await this.api.get(`/api/file/video_trans_query.json?${params.toString()}`, {
      headers: traceHeaders()
    });

    if (res.status >= 400 || res.data?.code !== 0) {
      throw new Error(`transcode query gagal: ${JSON.stringify(res.data)}`);
    }

    return res.data.data;
  }

  async waitTranscode(id, fallbackSourceUrl, maxTry = 80, delayMs = 3000) {
    let last = null;

    for (let i = 1; i <= maxTry; i++) {
      const data = await this.queryTranscode(id);
      last = data;

      const video = data?.video || data?.url || data?.source_url || "";
      const videoTranscoded =
        data?.video_transcoded ||
        data?.transcoded_video ||
        data?.transcoded_url ||
        data?.video_url ||
        "";

      if (videoTranscoded) {
        return {
          source_url: video || fallbackSourceUrl,
          video_transcoded: videoTranscoded,
          raw: data
        };
      }

      await sleep(delayMs);
    }

    return {
      source_url: fallbackSourceUrl,
      video_transcoded: fallbackSourceUrl,
      raw: last
    };
  }

  async delivery(sourceUrl, videoTranscoded, taskName) {
    const body = this.baseParams({
      type: TASK_TYPE,
      content_type: CONTENT_TYPE,
      source_url: sourceUrl,
      type_params: JSON.stringify({
        is_mirror: 0,
        orientation_tag: 1,
        j_420_trans: "1",
        return_ext: "2"
      }),
      right_detail: JSON.stringify({
        source: "1",
        touch_type: "4",
        function_id: "630",
        material_id: "63011",
        url: "https://wink.ai/video-enhancer/upload"
      }),
      ext_params: JSON.stringify({
        task_name: taskName,
        records: TASK_TYPE,
        video_transcoded: videoTranscoded
      }),
      with_prepare: "1"
    });

    const res = await this.api.post("/api/meitu_ai/delivery.json", body.toString(), {
      headers: {
        ...traceHeaders(),
        "content-type": "application/x-www-form-urlencoded;charset=UTF-8"
      }
    });

    if (res.status >= 400 || res.data?.code !== 0) {
      throw new Error(`delivery gagal: ${JSON.stringify(res.data)}`);
    }

    const data = res.data.data || {};

    return {
      msg_id: data.msg_id || "",
      prepare_msg_id: data.prepare_msg_id || "",
      raw: data
    };
  }

  async queryBatch(msgId) {
    const params = this.baseParams({
      msg_ids: msgId
    });

    const res = await this.api.get(`/api/meitu_ai/query_batch.json?${params.toString()}`, {
      headers: {
        ...traceHeaders(),
        referer: `${BASE_URL}/video-enhancer/upload`
      }
    });

    if (res.status >= 400 || res.data?.code !== 0) {
      throw new Error(`query batch gagal: ${JSON.stringify(res.data)}`);
    }

    return res.data.data;
  }

  extractResultUrl(data) {
    const item = data?.item_list?.[0];
    const media = item?.result?.media_info_list?.[0];

    return (
      media?.media_data ||
      item?.result?.result_url ||
      item?.result?.url ||
      item?.client_ext_params?.video_transcoded ||
      ""
    );
  }

  extractNextMsgId(data, currentMsgId) {
    const item = data?.item_list?.[0];
    const resultValue = item?.result?.result || "";
    const realMsgId = item?.result?.msg_id || item?.msg_id || "";

    if (
      resultValue &&
      resultValue !== currentMsgId &&
      !resultValue.startsWith("http") &&
      !resultValue.startsWith("https")
    ) {
      return resultValue;
    }

    if (
      realMsgId &&
      realMsgId !== currentMsgId &&
      !realMsgId.startsWith("wpr_")
    ) {
      return realMsgId;
    }

    return "";
  }

  async waitResult(firstMsgId, maxTry = 120, delayMs = 5000) {
    let msgId = firstMsgId;
    let last = null;

    for (let i = 1; i <= maxTry; i++) {
      const data = await this.queryBatch(msgId);
      last = data;

      const nextMsgId = this.extractNextMsgId(data, msgId);

      if (nextMsgId) {
        msgId = nextMsgId;
        await sleep(1000);
        continue;
      }

      const url = this.extractResultUrl(data);
      const errorCode = data?.item_list?.[0]?.result?.error_code;
      const errorMsg = data?.item_list?.[0]?.result?.error_msg;

      if (url && url.startsWith("http") && errorCode === 0) {
        return url;
      }

      if (errorCode && errorCode !== 29901 && errorCode !== 0) {
        throw new Error(`task gagal: ${errorCode} ${errorMsg || ""}`);
      }

      await sleep(delayMs);
    }

    throw new Error(`result belum selesai: ${JSON.stringify(last)}`);
  }

  async enhance(filePath) {
    await this.init();

    const taskName = `Enhancer-Ultra HD-${path.parse(filePath).name}`;

    const sign = await this.getMaatSign();
    const policy = await this.getUploadPolicy(sign);
    const uploaded = await this.uploadToQiniu(policy, filePath);

    await this.getVideoInfo(uploaded.file_key);

    const transcodeId = await this.startTranscode(uploaded.file_key);
    const transcode = await this.waitTranscode(transcodeId, uploaded.source_url);

    const task = await this.delivery(
      transcode.source_url,
      transcode.video_transcoded,
      taskName
    );

    const firstMsgId = task.msg_id || task.prepare_msg_id;

    if (!firstMsgId) {
      throw new Error(`delivery tidak mengembalikan msg_id: ${JSON.stringify(task.raw)}`);
    }

    return await this.waitResult(firstMsgId);
  }
}

async function downloadVideoUrl(url) {
  const tmpDir = await tmpDirAsync("video/wink-hd");

  const res = await axios.get(url, {
    responseType: "stream",
    timeout: 120000,
    maxRedirects: 5,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    validateStatus: () => true,
    headers: {
      accept: "video/*,*/*",
      "user-agent": UA,
      referer: url
    }
  });

  if (res.status >= 400) {
    throw new Error(`Gagal download URL HTTP ${res.status}`);
  }

  const contentType = String(res.headers["content-type"] || "").toLowerCase();

  const ext =
    contentTypeToExt(contentType) ||
    getExtFromUrl(url) ||
    ".mp4";

  const allowed =
    contentType.startsWith("video/") ||
    contentType.includes("application/octet-stream") ||
    contentType.includes("binary/octet-stream") ||
    getExtFromUrl(url);

  if (!allowed) {
    throw new Error(`URL bukan direct video. Content-Type: ${contentType || "-"}`);
  }

  const filePath = await tmpFileAsync({
    dir: "video/wink-hd",
    prefix: `input-${crypto.randomBytes(4).toString("hex")}`,
    ext
  });

  await pipeline(res.data, fs.createWriteStream(filePath));

  const stat = await fsp.stat(filePath);
  if (!stat.size) throw new Error("File hasil download kosong");

  return filePath;
}

async function downloadQuotedVideo(conn, m, q) {
  const tmpDir = await tmpDirAsync("video/wink-hd");

  let buffer;

  if (typeof q.download === "function") {
    buffer = await q.download();
  }

  if (!buffer && conn.downloadMediaMessage) {
    buffer = await conn.downloadMediaMessage(q);
  }

  if (!buffer) {
    throw new Error("Gagal download video dari pesan yang direply");
  }

  const mimetype = q.mimetype || q.msg?.mimetype || "";
  const ext = contentTypeToExt(mimetype) || ".mp4";

  const filePath = await tmpFileAsync({
    dir: "video/wink-hd",
    prefix: `quoted-${crypto.randomBytes(4).toString("hex")}`,
    ext
  });

  await fsp.writeFile(filePath, buffer);

  const stat = await fsp.stat(filePath);
  if (!stat.size) throw new Error("File video kosong");

  return filePath;
}

async function safeUnlink(filePath) {
  if (!filePath) return;

  try {
    await tmpSafeUnlink(filePath);
  } catch {}
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let filePath = "";
  let resultUrl = "";

  try {
    const q = m.quoted || m;
    const mime = q.mimetype || q.msg?.mimetype || "";

    if (!text && !/video|octet-stream/i.test(mime)) {
      return m.reply(
        `乂 W I N K  H D\n\n` +
          `Kirim/reply video atau masukkan URL video.\n\n` +
          `Contoh:\n` +
          `${usedPrefix + command} https://example.com/video.mp4\n\n` +
          `Atau reply video dengan command:\n` +
          `${usedPrefix + command}`
      );
    }

    await conn.sendMessage(m.chat, {
      react: {
        text: "⏳",
        key: m.key
      }
    });

    await m.reply(
      `乂 W I N K  H D\n\n` +
        `> [+] Status: Memproses video\n` +
        `> [+] Note: Proses bisa agak lama, tunggu sampai selesai.`
    );

    if (text && isHttpUrl(text.trim())) {
      filePath = await downloadVideoUrl(text.trim());
    } else if (/video|octet-stream/i.test(mime)) {
      filePath = await downloadQuotedVideo(conn, m, q);
    } else {
      return m.reply(
        `乂 W I N K  H D\n\n` +
          `> [!] Input tidak valid.\n` +
          `> Reply video atau masukkan direct URL video.`
      );
    }

    const wink = new WinkEnhancer();
    resultUrl = await wink.enhance(filePath);

    if (!resultUrl) {
      throw new Error("Result URL kosong");
    }

    await conn.sendMessage(
      m.chat,
      {
        video: {
          url: resultUrl
        },
        mimetype: "video/mp4",
        caption:
          `乂 W I N K  H D\n\n` +
          `> [+] Status: Berhasil\n` +
          `> [+] Result: Video berhasil di-enhance.`
      },
      {
        quoted: m
      }
    );

    await conn.sendMessage(m.chat, {
      react: {
        text: "✅",
        key: m.key
      }
    });
  } catch (e) {
    await conn.sendMessage(m.chat, {
      react: {
        text: "❌",
        key: m.key
      }
    });

    await m.reply(
      `乂 W I N K  H D\n\n` +
        `> [!] Terjadi error.\n` +
        `> ${e.message || e}`
    );
  } finally {
    await tmpSafeUnlink(filePath);
  }
};

handler.help = handler.command = ["winkhd", "hdvideo", "enhancevideo"];
handler.tags = ["tools"];
handler.limit = true;

module.exports = handler;