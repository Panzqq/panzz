
let handler = async (m, { conn }) => {
  let uptime = process.uptime();
  let hari = Math.floor(uptime / 86400);
  uptime %= 86400;
  let jam = Math.floor(uptime / 3600);
  uptime %= 3600;
  let menit = Math.floor(uptime / 60);
  let detik = Math.floor(uptime % 60);

  let caption = `
> \`[ ${namebot} STATUS ]\`

> [+] Hari   : \`${hari}\`
> [+] Jam    : \`${jam}\`
> [+] Menit  : \`${menit}\`
> [+] Detik  : \`${detik}\`
`;

  await conn.sendButtonLoc(
    m.chat,
    [
      { id: ".menu", text: " [ Menu ]" },
      { id: ".ping", text: " [ Ping ]" }
    ],
    caption,
    global.wm || wm3,
    fdoc,
    {
      name: `${namebot} | Advanced AI Bot`,
      address: `Experience futuristic automation with ${namebot}.`,
      thumbUrl: thumb,
      mentions: [m.sender, nomorown + '@s.whatsapp.net']
    }
  );
};

handler.help = ['runtime'];
handler.tags = ['info'];
handler.command = /^runtime$/i;
handler.limit = false;
handler.group = false;

module.exports = handler;