const fetch = global.fetch || ((...args) =>
  import("node-fetch").then(({ default: fetch }) => fetch(...args))
);

class ChatMusicAPI {
  constructor() {
    this.baseUrl = "https://api.chatmusicpro.com";
    this.identityId = this.generateUUID();
    this.token = null;

    this.headers = {
      "User-Agent": "android",
      "Accept-Encoding": "gzip",
      "Content-Type": "application/x-www-form-urlencoded",
      "region-code": "ID",
      "user-type": "android",
      "version": "1.0.3",
      "app-type": "1",
      "language": "EN",
      "identity-id": this.identityId,
      "app-market": "google_play"
    };
  }

  generateUUID() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = Math.random() * 16 | 0;
      const v = c === "x" ? r : (r & 0x3 | 0x8);
      return v.toString(16).toUpperCase();
    });
  }

  async request(endpoint, data = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const body = new URLSearchParams(data).toString();
    const headers = { ...this.headers };

    if (this.token) headers.token = this.token;

    const res = await fetch(url, {
      method: "POST",
      headers,
      body
    });

    if (!res.ok) {
      throw new Error(`HTTP Error ${res.status}`);
    }

    return await res.json();
  }

  async login() {
    const result = await this.request("/v1/user/device_login", {
      source_site: "google_play",
      identity_id: this.identityId
    });

    if (result.code === 200 && result.data?.token) {
      this.token = result.data.token;
      return result.data;
    }

    throw new Error(result.message || "Login gagal");
  }

  getModelList() {
    return [
      { id: 6, version: "v5.0" },
      { id: 5, version: "v4.5-plus" },
      { id: 4, version: "v4.5" },
      { id: 3, version: "v4.0" },
      { id: 1, version: "v3.5" }
    ];
  }

  async generateMusic(params = {}) {
    const payload = {
      music_model_id: params.modelId || 6,
      title: params.title || "Renvy Music",
      prompt: params.prompt || "",
      lyrics: params.lyrics || "",
      is_instrumental: params.isInstrumental || 0,
      music_style: params.musicStyle || "",
      music_style_code: params.musicStyleCode || "",
      gender_type: params.genderType || 0
    };

    const result = await this.request("/music/create-music", payload);

    if (result.code === 200 && result.data?.create_id) {
      return result.data.create_id;
    }

    throw new Error(result.message || "Gagal membuat musik");
  }

  async getProgress(id) {
    const result = await this.request("/music/get-music-progress", { id });

    if (result.code === 200) {
      return result.data;
    }

    throw new Error(result.message || `Gagal cek progress ${id}`);
  }

  async waitTasks(ids) {
    ids = Array.isArray(ids) ? ids : [ids];

    const completed = new Set();
    const results = [];

    let attempt = 0;
    const maxAttempt = 60;

    while (completed.size < ids.length && attempt < maxAttempt) {
      attempt++;

      for (const id of ids) {
        if (completed.has(id)) continue;

        try {
          const status = await this.getProgress(id);

          if (status?.music_file) {
            completed.add(id);
            results.push(status);
          }
        } catch (e) {
          // Abaikan sementara, nanti dicoba lagi
        }
      }

      if (completed.size < ids.length) {
        await new Promise(resolve => setTimeout(resolve, 3000));
      }
    }

    if (!results.length) {
      throw new Error("Musik belum selesai dibuat atau API terlalu lama merespon");
    }

    return results;
  }

  async generate(payload) {
    await this.login();

    const taskIds = await this.generateMusic(payload);
    return await this.waitTasks(taskIds);
  }
}

function cleanFilename(name = "music") {
  return String(name)
    .replace(/[\\/:*?"<>|]/g, "")
    .slice(0, 50) || "music";
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
`乂 C H A T  M U S I C

Cara pakai:
${usedPrefix + command} judul | style | prompt | lyrics

Contoh:
${usedPrefix + command} Renvy Night | pop edm | lagu semangat malam hari | Aku berjalan di bawah cahaya bulan

Instrumental:
${usedPrefix + command} --instrumental Night Drive | phonk cinematic | beat malam yang keren`
    );
  }

  try {
    await m.reply("⏳ Sedang membuat musik AI, mohon tunggu...");

    const isInstrumental = /--instrumental|-i/i.test(text) ? 1 : 0;
    const cleanText = text.replace(/--instrumental|-i/gi, "").trim();

    const parts = cleanText.split("|").map(v => v.trim());

    const title = parts[0] || "Renvy Music";
    const musicStyle = parts[1] || "";
    const prompt = parts[2] || cleanText;
    const lyrics = parts.slice(3).join("\n").trim();

    const api = new ChatMusicAPI();

    const results = await api.generate({
      modelId: 6,
      title,
      prompt,
      lyrics,
      musicStyle,
      isInstrumental,
      genderType: 0
    });

    for (const music of results) {
      const audioUrl =
        music.music_file ||
        music.audio_url ||
        music.file_url ||
        music.url;

      if (!audioUrl) continue;

      const caption =
`乂 A I  M U S I C

• Title: ${music.title || title}
• Style: ${musicStyle || "-"}
• Instrumental: ${isInstrumental ? "Ya" : "Tidak"}

${audioUrl}`;

      await conn.sendAudioMessage(m.chat, audioUrl, ftroli, {
        fileName: `${cleanFilename(music.title || title)}.mp3`,
        ptt: true
      });

      await conn.sendMessage(
        m.chat,
        {
          text: caption
        },
        { quoted: m }
      );
    }

  } catch (err) {
    console.error(err);
    m.reply(
`❌ Gagal membuat musik.

Error:
${err.message || err}`
    );
  }
};

handler.help = ["chatmusic", "aimusic"];
handler.tags = ["ai"];
handler.command = /^(chatmusic|aimusic|musicai)$/i;
handler.limit = true;

module.exports = handler;