const axios = require('axios')
const FormData = require('form-data')

let handler = async (m, { conn, text }) => {
  const enhanceImage = async (buffer, size) => {
    const valid = ['low', 'medium', 'high']
    if (!valid.includes(size)) throw new Error('Size tidak valid')

    const form = new FormData()
    form.append('method', '1')
    form.append('is_pro_version', 'false')
    form.append('is_enhancing_more', 'false')
    form.append('max_image_size', size)
    form.append('file', buffer, `enhance_${Date.now()}.jpg`)

    const { data } = await axios.post('https://ihancer.com/api/enhance', form, {
      headers: {
        ...form.getHeaders(),
        'accept-encoding': 'gzip',
        host: 'ihancer.com',
        'user-agent': 'Dart/3.5 (dart:io)'
      },
      responseType: 'arraybuffer'
    })

    return Buffer.from(data)
  }

  const q = m.quoted || m
  const mime = (q.msg || q).mimetype || ''
  if (!/image/.test(mime)) {
    return conn.sendMessage(m.chat, {
      text: `[+] Kirim atau balas gambar dengan perintah .hd [size]\nContoh: .hd medium\nTanpa size akan otomatis high`
    }, { quoted: m })
  }

  try {
    const buffer = await q.download()
    const args = text.trim().split(/\s+/)
    const size = args[0] && ['low', 'medium', 'high'].includes(args[0].toLowerCase())
      ? args[0].toLowerCase()
      : 'high'

    const enhanced = await enhanceImage(buffer, size)
    const label = { low: '360p', medium: '720p', high: '1080p' }[size]
    const caption = `[+] Gambar ditingkatkan ke ${label}`

    await conn.sendMessage(m.chat, { image: enhanced, caption }, { quoted: m })
  } catch (e) {
    await conn.sendMessage(m.chat, { text: `[+] Gagal: ${e.message}` }, { quoted: m })
  }
}

handler.help = ['hd [size]', 'remini [size]']
handler.tags = ['tools']
handler.command = /^(hd|remini)$/i
handler.limit = true

module.exports = handler