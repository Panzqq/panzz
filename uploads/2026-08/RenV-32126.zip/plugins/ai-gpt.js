const https = require('https');

const sessions = {};

function requestChatEverywhere(messages) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model: {
        id: 'gpt-3.5-turbo',
        name: 'GPT-3.5',
        maxLength: 12000,
        tokenLimit: 4000
      },
      messages,
      prompt: 'You are an AI language model named Chat Everywhere.',
      temperature: 0.5,
      enableConversationPrompt: true
    });

    const req = https.request(
      {
        hostname: 'chateverywhere.app',
        path: '/api/chat',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body),
          'user-browser-id': '62d64ff4-3571-4f89-b2de-4bcbb3094f33'
        },
        timeout: 60000
      },
      res => {
        let data = '';
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => {
          if (!data) return reject(new Error('Empty response'));
          resolve(data);
        });
      }
    );

    req.on('timeout', () => { req.destroy(new Error('Request timeout')); });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function requestSuggest(question, answer) {
  return new Promise((resolve) => {
    const body = JSON.stringify({
      model: {
        id: 'gpt-3.5-turbo',
        name: 'GPT-3.5',
        maxLength: 12000,
        tokenLimit: 4000
      },
      messages: [{
        role: 'user',
        content: `Berdasarkan pertanyaan: "\( {question}" dan jawaban: " \){answer.slice(0, 300)}"\n\n` +
                 `Buatkan tepat 3 pertanyaan lanjutan yang singkat dan relevan (maksimal 6 kata per pertanyaan).\n` +
                 `Format output: hanya 3 pertanyaan, dipisahkan newline, tanpa nomor, tanpa tanda tanya di akhir, tanpa penjelasan apapun.`
      }],
      prompt: 'You are a helpful assistant.',
      temperature: 0.7,
      enableConversationPrompt: false
    });

    const req = https.request(
      {
        hostname: 'chateverywhere.app',
        path: '/api/chat',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body),
          'user-browser-id': '62d64ff4-3571-4f89-b2de-4bcbb3094f33'
        },
        timeout: 15000
      },
      res => {
        let data = '';
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => resolve(data));
      }
    );

    req.on('timeout', () => { req.destroy(); resolve(''); });
    req.on('error', () => resolve(''));
    req.write(body);
    req.end();
  });
}

function parseResponse(res) {
  try {
    const json = JSON.parse(res);
    return json?.text || json?.message || json?.response || json?.answer || json?.content || res;
  } catch {
    return res;
  }
}

function cleanResponse(text) {
  return String(text || '').replace(/\r/g, '').trim();
}

function limitSession(id) {
  if (!sessions[id]) return;
  if (sessions[id].length > 10) sessions[id] = sessions[id].slice(-10);
}

function parseSuggest(raw, prefix, cmd) {
  const fallback = [
    `${prefix + cmd} jelaskan lebih detail`,
    `${prefix + cmd} beri contoh`,
    `${prefix + cmd} reset`
  ];

  if (!raw) return fallback;

  const lines = cleanResponse(parseResponse(raw))
    .split('\n')
    .map(l => l.replace(/^[-•*\d.]+\s*/, '').trim())
    .filter(l => l.length > 2 && l.length < 60)
    .slice(0, 3);

  if (lines.length < 1) return fallback;

  return lines.map(l => `${prefix + cmd} ${l}`);
}

// ==================== HANDLER ====================

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const prefix = usedPrefix || '.';
  const cmd = command || 'gpt';

  if (!text) {
    return m.reply(`*Chat GPT*

> Tanyakan apapun kepada AI.

> Penggunaan
${prefix + cmd} siapa presiden Indonesia

> Reset sesi
${prefix + cmd} reset`);
  }

  const id = m.sender;

  if (/^(reset|clear|hapus)$/i.test(text.trim())) {
    delete sessions[id];
    return m.reply(`*Chat GPT*

> Sesi berhasil direset.

> Ketik apapun untuk memulai percakapan baru.`);
  }

  if (!sessions[id]) sessions[id] = [];

  sessions[id].push({ role: 'user', content: text.trim() });
  limitSession(id);

  await conn.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });

  try {
    const res = await requestChatEverywhere(sessions[id]);
    const result = cleanResponse(parseResponse(res));

    if (!result || result.length < 2) throw new Error('Empty response');

    sessions[id].push({ role: 'assistant', content: result });
    limitSession(id);

    const suggestRaw = await requestSuggest(text.trim(), result).catch(() => '');
    const suggest = parseSuggest(suggestRaw, prefix, cmd);

    let replyText = `*Chat GPT*

> ${text.trim()}

> Jawaban
${result}`;

    // Tambahkan saran pertanyaan
    if (suggest && suggest.length > 0) {
      replyText += `\n\n> Pertanyaan lanjutan`;
      suggest.forEach(s => {
        replyText += `\n> ${s}`;
      });
    }

    await m.reply(replyText);
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (err) {
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    await m.reply(`*Chat GPT*

> Terjadi kesalahan.

> Error
${err.message || err}

> Coba ketik
${prefix + cmd} reset`);
  }
};

handler.help = ['gpt', 'chatglt'];
handler.command = ['gpt', 'chatglt'];
handler.tags = ['ai'];
handler.limit = true;
handler.register = true;

module.exports = handler;