const { sleep, fetchWithTimeout, formatCompactNumber, cutText } = require("../lib/utils");

const fetchFn = (...args) =>
  globalThis.fetch
    ? globalThis.fetch(...args)
    : import("node-fetch").then(({ default: fetch }) => fetch(...args));

const sessions = {};
const SESSION_EXPIRE = 10 * 60 * 1000;

const TIKWM_ENDPOINTS = [
  "https://www.tikwm.com/api/feed/search",
  "https://tikwm.com/api/feed/search",
];

function cleanSessions() {
  const now = Date.now();

  for (const sender in sessions) {
    if (now - sessions[sender].createdAt > SESSION_EXPIRE) {
      delete sessions[sender];
    }
  }
}

async function requestTikwm(query, options = {}) {
  const { limit = 10, cursor = 0, hd = true } = options;

  let lastError = "Request gagal";

  for (const endpoint of TIKWM_ENDPOINTS) {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const url = new URL(endpoint);

        url.searchParams.set("keywords", query);
        url.searchParams.set("count", String(limit));
        url.searchParams.set("cursor", String(cursor));
        url.searchParams.set("hd", hd ? "1" : "0");

        const res = await fetchWithTimeout(
          fetchFn,
          url.toString(),
          {
            headers: {
              accept: "application/json, text/plain, */*",
              "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
              "user-agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
              origin: "https://www.tikwm.com",
              referer: "https://www.tikwm.com/",
            },
          },
          45000
        );

        const raw = await res.text();

        if (!res.ok) {
          lastError = `HTTP ${res.status}`;

          if (raw) {
            lastError += ` - ${raw.slice(0, 120)}`;
          }

          if (res.status >= 500) {
            await sleep(1000 * attempt);
            continue;
          }

          return {
            ok: false,
            error: lastError,
          };
        }

        let json;

        try {
          json = JSON.parse(raw);
        } catch {
          lastError = "Response bukan JSON valid";
          await sleep(1000 * attempt);
          continue;
        }

        if (!json || json.code !== 0) {
          lastError = json?.msg || "TikWM menolak request";
          await sleep(1000 * attempt);
          continue;
        }

        return {
          ok: true,
          json,
        };
      } catch (e) {
        lastError =
          e.name === "AbortError"
            ? "Request timeout"
            : e.message || String(e);

        await sleep(1000 * attempt);
      }
    }
  }

  return {
    ok: false,
    error: lastError,
  };
}

async function tiktokSearch(query, options = {}) {
  const response = await requestTikwm(query, options);

  if (!response.ok) {
    return {
      query,
      results: [],
      error: response.error,
    };
  }

  const json = response.json;
  const videos = json.data?.videos || [];

  const normalizeImages = imgs => {
    if (!Array.isArray(imgs)) return null;

    return imgs
      .map(x =>
        typeof x === "string"
          ? x
          : x?.url || x?.display_image?.url_list?.[0] || null
      )
      .filter(Boolean);
  };

  const mapItem = v => {
    const images = normalizeImages(v.images);
    const isSlideshow = images && images.length > 0;
    const videoId = v.video_id || v.aweme_id || null;
    const username = v.author?.unique_id || null;

    return {
      id: videoId,
      type: isSlideshow ? "slideshow" : "video",
      description: v.title || "",
      videoUrl: !isSlideshow ? v.hdplay || v.play || null : null,
      videoUrlWatermarked: !isSlideshow ? v.wmplay || null : null,
      images: isSlideshow ? images : null,
      cover: v.cover || v.origin_cover || null,
      duration: Number(v.duration) || 0,
      likes: Number(v.digg_count) || 0,
      comments: Number(v.comment_count) || 0,
      shares: Number(v.share_count) || 0,
      views: Number(v.play_count) || 0,
      downloads: Number(v.download_count) || 0,
      createdAt: v.create_time
        ? new Date(v.create_time * 1000).toISOString()
        : null,
      music: {
        title: v.music_info?.title || null,
        author: v.music_info?.author || null,
        url: v.music || v.music_info?.play || null,
      },
      author: {
        id: v.author?.id || null,
        username,
        nickname: v.author?.nickname || "",
        avatar: v.author?.avatar || null,
      },
      postUrl:
        username && videoId
          ? `https://www.tiktok.com/@${username}/video/${videoId}`
          : null,
    };
  };

  return {
    query,
    count: videos.length,
    cursor: json.data?.cursor ?? null,
    hasMore: !!json.data?.hasMore,
    results: videos.map(mapItem),
  };
}

function makeResultText(result) {
  let teks = `乂 *T I K T O K  S E A R C H*\n\n`;
  teks += `*Query:* ${result.query}\n`;
  teks += `*Total:* ${result.count} hasil\n\n`;

  result.results.forEach((v, i) => {
    teks += `*${i + 1}. ${v.author.nickname || v.author.username || "Unknown"}*\n`;
    teks += `> Type : ${v.type}\n`;
    teks += `> User : @${v.author.username || "-"}\n`;
    teks += `> Likes : ${formatCompactNumber(v.likes)}\n`;
    teks += `> Views : ${formatCompactNumber(v.views)}\n`;
    teks += `> Desc : ${cutText(v.description, 90)}\n\n`;
  });

  teks += `Klik tombol *[ Pilih Video ]* untuk memilih hasil.`;

  return teks;
}

function makeNativeSelectData(result, usedPrefix) {
  return {
    title: `[ ${global.namebot || "Bot"} - TikTok Result ]`,
    sections: [
      {
        title: "🎵 Pilih Video TikTok",
        rows: result.results.slice(0, 10).map((v, i) => ({
          header: `${i + 1}. ${v.type.toUpperCase()} • @${v.author.username || "-"}`,
          title: cutText(v.description || v.author.nickname || "Tanpa caption", 45),
          description: `❤️ ${formatCompactNumber(v.likes)} | 👁 ${formatCompactNumber(v.views)} | 💬 ${formatCompactNumber(v.comments)}`,
          id: `${usedPrefix}tts get:${i + 1}`,
        })),
      },
    ],
  };
}

async function sendTikTokResult(conn, m, result, usedPrefix) {
  const buttons = [
    {
      id: "pilih-video",
      text: "[ Pilih Video ]",
      native: true,
    },
  ];

  return conn.sendButtonLoc(
    m.chat,
    buttons,
    makeResultText(result),
    ` [ ${global.namebot || "Bot"} Powered By ${global.nameown || "Owner"} ] `,
    m,
    {
      mentions: [m.sender],
      nativeSelectData: makeNativeSelectData(result, usedPrefix),
      thumbUrl:
        result.results[0]?.cover ||
        global.thumb ||
        "https://files.catbox.moe/toarxh.jpg",
      name: global.namebot || "Renvy",
      address: "TikTok Search Result",
    }
  );
}

async function sendTikTokAudio(conn, m, item) {
  if (!item.music?.url) return;

  try {
    await conn.sendAudioMessage(m.chat, item.music.url, ftroli, {
      fileName: `${item.music.title || "tiktok-audio"}.mp3`,
    });
  } catch (e) {
    await m.reply(`Audio tidak bisa dikirim.\n\nError: ${e.message || e}`);
  }
}

async function sendSelectedResult(conn, m, item) {
  const caption = `乂 *T I K T O K*

*Type:* ${item.type}
*Author:* ${item.author.nickname || "-"}
*Username:* @${item.author.username || "-"}
*Likes:* ${formatCompactNumber(item.likes)}
*Views:* ${formatCompactNumber(item.views)}
*Comments:* ${formatCompactNumber(item.comments)}
*Shares:* ${formatCompactNumber(item.shares)}

*Caption:*
${item.description || "-"}

*Music:* ${item.music.title || "-"}
*Post:* ${item.postUrl || "-"}`;

  await m.reply(global.wait || "⏳ Mengirim media...");

  if (item.type === "video") {
    if (!item.videoUrl) return m.reply("URL video tidak ditemukan.");

    await conn.sendMessage(
      m.chat,
      {
        video: {
          url: item.videoUrl,
        },
        caption,
      },
      {
        quoted: m,
      }
    );

    await sendTikTokAudio(conn, m, item);
    return;
  }

  if (item.type === "slideshow") {
    if (!item.images || !item.images.length) {
      return m.reply("Gambar slideshow tidak ditemukan.");
    }

    const imgs = item.images.slice(0, 10);

    for (let i = 0; i < imgs.length; i++) {
      await conn.sendMessage(
        m.chat,
        {
          image: {
            url: imgs[i],
          },
          caption: i === 0 ? caption : `Slide ${i + 1}/${imgs.length}`,
        },
        {
          quoted: m,
        }
      );
    }

    await sendTikTokAudio(conn, m, item);
    return;
  }

  return m.reply("Tipe media tidak dikenali.");
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    cleanSessions();

    const sender = m.sender;
    const prefix = usedPrefix || ".";

    if (text && text.startsWith("get:")) {
      const session = sessions[sender];

      if (!session) {
        return m.reply(
          `Belum ada hasil pencarian.\n\nContoh:\n${prefix}tts aesthetic videos`
        );
      }

      const index = parseInt(text.split(":")[1]) - 1;

      if (isNaN(index) || index < 0 || index >= session.results.length) {
        return m.reply(`Pilih nomor 1 sampai ${session.results.length}.`);
      }

      const item = session.results[index];
      return sendSelectedResult(conn, m, item);
    }

    if (!text) {
      return m.reply(
        `乂 *T I K T O K  S E A R C H*\n\nContoh:\n${prefix + command} aesthetic videos\n${prefix + command} anime edit`
      );
    }

    if (typeof conn.sendButtonLoc !== "function") {
      return m.reply("Fungsi `conn.sendButtonLoc` tidak ditemukan di bot kamu.");
    }

    await m.reply(global.wait || "⏳ Sedang mencari video TikTok...");

    const result = await tiktokSearch(text, {
      limit: 10,
      cursor: 0,
      hd: true,
    });

    if (result.error) {
      return m.reply(
        `❌ Gagal mencari video.\n\nError: ${result.error}\n\nKemungkinan endpoint TikWM sedang down atau kena limit. Coba lagi nanti atau ganti provider API.`
      );
    }

    if (!result.results.length) {
      return m.reply(`Tidak ada hasil untuk *${text}*.`);
    }

    sessions[sender] = {
      query: text,
      cursor: result.cursor,
      hasMore: result.hasMore,
      results: result.results,
      createdAt: Date.now(),
    };

    return sendTikTokResult(conn, m, result, prefix);
  } catch (e) {
    return m.reply(`❌ Error: ${e.message || e}`);
  }
};

handler.help = [
  "tts *<query>*",
  "ttsearch *<query>*",
  "tiktoksearch *<query>*",
];

handler.tags = ["download"];

handler.command = /^(tts|ttsearch|tiktoksearch|tiktoksesrch)$/i;

module.exports = handler;