const axios = require("axios")
const { sleep } = require("../lib/utils");

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0"

function cleanUrl(url) {
  if (!url) return null

  return String(url)
    .replace(/\\u002F/g, "/")
    .replace(/\\/g, "")
    .trim()
}

function cropText(text, max = 45) {
  text = String(text || "").trim()
  if (!text) return "-"
  return text.length > max ? text.slice(0, max) + "..." : text
}

function parseSetCookie(headers = {}) {
  const raw = headers["set-cookie"]

  if (!raw) return []

  if (Array.isArray(raw)) {
    return raw.map(v => v.split(";")[0].trim()).filter(Boolean)
  }

  return String(raw)
    .split(/,(?=\s*[^;,]+=)/g)
    .map(v => v.split(";")[0].trim())
    .filter(Boolean)
}

async function getSession() {
  const res = await axios.get("https://id.pinterest.com/", {
    headers: {
      "user-agent": UA,
      "accept-language": "en-US,en;q=0.9",
      accept:
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
    },
    timeout: 20000,
    validateStatus: () => true
  })

  const rawCookies = parseSetCookie(res.headers)
  const cookies = rawCookies.join("; ")

  const csrf =
    rawCookies
      .find(c => c.startsWith("csrftoken="))
      ?.match(/csrftoken=([^;]+)/)?.[1] || ""

  return {
    cookies,
    csrf
  }
}

async function pinterestSearch(query, options = {}) {
  const { limit = 5, scope = "pins", bookmark = null } = options

  const session = await getSession()

  const data = {
    options: {
      query,
      scope,
      page_size: limit,
      refine_search_with_filters: true,
      ...(bookmark ? { bookmarks: [bookmark] } : {})
    },
    context: {}
  }

  const sourceUrl = `/search/${scope}/?q=${encodeURIComponent(query)}`

  const apiUrl =
    "https://id.pinterest.com/resource/BaseSearchResource/get/?" +
    "source_url=" +
    encodeURIComponent(sourceUrl) +
    "&data=" +
    encodeURIComponent(JSON.stringify(data)) +
    "&_=" +
    Date.now()

  const res = await axios.get(apiUrl, {
    headers: {
      accept: "application/json, text/javascript, */*; q=0.01",
      "accept-language": "en-US,en;q=0.9",
      "user-agent": UA,
      referer: `https://id.pinterest.com${sourceUrl}`,
      "x-requested-with": "XMLHttpRequest",
      "x-app-version": "6d51d5a",
      "x-pinterest-appstate": "active",
      "x-pinterest-pws-handler": "www/search/[scope].js",
      "x-pinterest-source-url": sourceUrl,
      ...(session.csrf ? { "x-csrftoken": session.csrf } : {}),
      ...(session.cookies ? { cookie: session.cookies } : {})
    },
    timeout: 25000,
    validateStatus: () => true
  })

  if (res.status < 200 || res.status >= 300) {
    return {
      query,
      count: 0,
      bookmark: null,
      results: [],
      error: `HTTP ${res.status}`
    }
  }

  const json = res.data
  const payload = json?.resource_response?.data

  if (!payload) {
    return {
      query,
      count: 0,
      bookmark: null,
      results: [],
      error: "no data"
    }
  }

  const arr = Array.isArray(payload) ? payload : payload.results || []

  const mapPin = pin => ({
    title: pin.title || pin.grid_title || "",
    image: cleanUrl(pin.images?.orig?.url || pin.images?.["736x"]?.url || null),
    video:
      pin.videos?.video_list?.V_HLSV4?.url ||
      pin.videos?.video_list?.V_EXP7?.url ||
      pin.videos?.video_list?.V_720P?.url ||
      null,
    username: pin.pinner?.username || null,
    fullName: pin.pinner?.full_name || null,
    pinUrl: pin.id ? `https://id.pinterest.com/pin/${pin.id}/` : null
  })

  const results = arr
    .filter(x => x?.id)
    .map(mapPin)
    .filter(v => v.image)

  return {
    query,
    count: results.length,
    bookmark: payload.bookmark || null,
    results
  }
}

function makeCaption(data, query) {
  const list = data.results
    .slice(0, 5)
    .map((v, i) => {
      return [
        `> [${i + 1}] ${cropText(v.title, 50)}`,
        `>     By : ${v.fullName || v.username || "-"}`
      ].join("\n")
    })
    .join("\n")

  return [
    "```",
    "> [+] PIN RESULT",
    "",
    `> [+] Query  : ${query}`,
    `> [+] Total  : ${data.results.length} image`,
    "> [+] Source : Pinterest",
    "> [+] Domain : id.pinterest.com",
    "",
    list || "> [+] Data detail tidak tersedia",
    "```"
  ].join("\n")
}

async function sendPinterestAlbum(conn, m, data, query) {
  const urls = data.results.map(v => v.image).filter(Boolean)
  const caption = makeCaption(data, query)

  const albumMessage = urls.map((url, i) => ({
    image: { url },
    caption: i === 0 ? caption : ""
  }))

  try {
    return await conn.sendMessage(
      m.chat,
      {
        albumMessage
      },
      {
        quoted: m
      }
    )
  } catch (e) {
    console.error("Gagal kirim album, fallback satu-satu:", e.message)

    for (let i = 0; i < urls.length; i++) {
      await conn.sendMessage(
        m.chat,
        {
          image: { url: urls[i] },
          caption: i === 0 ? caption : ""
        },
        {
          quoted: m
        }
      )

      await sleep(1000)
    }
  }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      [
        "```",
        "> [+] PINTEREST SEARCH",
        "",
        `> [+] Example : ${usedPrefix + command} gajah`,
        `> [+] Example : ${usedPrefix + command} ideas logo | 5`,
        "```"
      ].join("\n")
    )
  }

  const blocked = [
    "bokep",
    "porn",
    "porno",
    "sex",
    "nsfw",
    "telanjang",
    "bugil",
    "nude"
  ]

  if (blocked.some(v => text.toLowerCase().includes(v))) {
    return m.reply("Pencarian tersebut tidak bisa digunakan.")
  }

  let [query, jumlah] = text.split("|").map(v => v.trim())

  if (!query) return m.reply("Query tidak boleh kosong.")

  let limit = Number(jumlah) || 5
  limit = Math.max(1, Math.min(limit, 10))

  try {
    await conn.sendPresenceUpdate?.("composing", m.chat)

    const data = await pinterestSearch(query, {
      limit,
      scope: "pins"
    })

    if (data.error || !data.results.length) {
      return m.reply(
        [
          "```",
          "> [+] PIN RESULT",
          "",
          "> [+] Status : Gagal",
          `> [+] Message: ${data.error || "Gambar tidak ditemukan"}`,
          "```"
        ].join("\n")
      )
    }

    await sendPinterestAlbum(conn, m, data, query)
  } catch (e) {
    console.error(e)

    return m.reply(
      [
        "```",
        "> [+] PIN RESULT",
        "",
        "> [+] Status : Error",
        `> [+] Message: ${e.message || e}`,
        "```"
      ].join("\n")
    )
  }
}

handler.help = handler.command = ["pin", "pinterest"]
handler.tags = ["internet"]

module.exports = handler