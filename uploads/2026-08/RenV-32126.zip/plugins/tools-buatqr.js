const QRCode = require('qrcode');

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const input = text?.trim();

    if (!input) {
        return m.reply(`Contoh penggunaan:\n${usedPrefix + command} https://google.com`);
    }

    let url = input;

    // Tambahkan https:// jika belum ada protocol
    if (!/^https?:\/\//i.test(url)) {
        url = `https://${url}`;
    }

    try {
        // Validasi URL
        new URL(url);

        const buffer = await QRCode.toBuffer(url, {
            type: 'png',
            width: 1024,
            margin: 2,
            color: {
                dark: '#000000',
                light: '#FFFFFF'
            }
        });

        await conn.sendMessage(m.chat, {
            image: buffer,
            caption: `✅ *QR Code berhasil dibuat*\n\n🔗 URL: ${url}`
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        return m.reply('❌ URL tidak valid. Mohon masukkan URL yang benar.');
    }
};

handler.help = ['qr <url>'];
handler.tags = ['tools'];
handler.command = /^(qr|qrcode|qrurl)$/i;

module.exports = handler;