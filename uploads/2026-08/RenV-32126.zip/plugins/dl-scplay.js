const axios = require('axios');
const cheerio = require('cheerio');

let cachedClientId = null;
let clientIdExpiry = 0;

async function getClientId() {
    const now = Date.now();
    if (cachedClientId && now < clientIdExpiry) return cachedClientId;

    const res = await axios.get('https://m.soundcloud.com/discover', {
        headers: { 'User-Agent': 'Mozilla/5.0' }
    });

    const $ = cheerio.load(res.data);
    const scripts = $('script').map((i, el) => $(el).html()).get();
    let clientId = null;

    for (const script of scripts) {
        if (script && script.includes('clientId')) {
            const match = script.match(/"clientId":"([^"]+)"/);
            if (match) {
                clientId = match[1];
                break;
            }
        }
    }

    if (!clientId) throw new Error('client id gak ketemu');

    cachedClientId = clientId;
    clientIdExpiry = now + 3600000;
    return clientId;
}

function formatDuration(seconds) {
    if (!seconds) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `contoh: ${usedPrefix + command} multo`;

    await conn.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });

    const clientId = await getClientId();

    const search = await axios.get('https://api-mobi.soundcloud.com/search', {
        params: {
            q: text,
            client_id: clientId,
            limit: 1
        },
        headers: {
            'Accept': 'application/json, text/javascript, */*; q=0.1',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Origin': 'https://m.soundcloud.com',
            'Referer': 'https://m.soundcloud.com/',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
        }
    });

    if (!search.data.collection?.length) throw 'lagu gak ketemu';

    const track = search.data.collection[0];

    const streamUrl = track.media?.transcodings?.find(v =>
        v.format?.protocol === 'progressive' &&
        v.format?.mime_type === 'audio/mpeg'
    )?.url;

    if (!streamUrl) throw 'stream gak ada';

    const stream = await axios.get(`${streamUrl}?client_id=${clientId}`, {
        headers: {
            'Accept': 'application/json, text/javascript, */*; q=0.1',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Origin': 'https://m.soundcloud.com',
            'Referer': 'https://m.soundcloud.com/',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
        }
    });

    const audioUrl = stream.data.url;
    if (!audioUrl) throw 'audio url gagal';

    const song = {
        title: track.title,
        artist: track.user?.username || 'Unknown',
        duration: formatDuration(track.duration / 1000),
        artwork: track.artwork_url?.replace('large', 't500x500'),
        permalink: track.permalink_url
    };

    let pp;
    try { pp = await conn.profilePictureUrl(m.sender, 'image'); } 
    catch { pp = 'https://telegra.ph/file/4cc2712be1a56e1c373a7.jpg'; }

    const caption = `*[ SoundCloud - Play ]*\n\n• 🎵 Judul: *${song.title}*\n• 👤 Artis: *${song.artist}*\n• ⏱️ Durasi: *${song.duration}*\n• 🔗 Tautan: *${song.permalink}*\n\n_Sabar, lagi ngirim audio..._`;

    await conn.sendButtonLoc(
        m.chat,
        [
            { id: `${usedPrefix}lirik ${song.title}`, text: "🎶 Lyrics" }
        ],
        caption,
        "SoundCloud Downloader",
        m,
        {
            name: "</> SoundCloud Play </>",
            address: "Cari lagu langsung dapet",
            thumbUrl: song.artwork || 'https://i.ibb.co.com/2WzLyGk/avatar-contact.png'
        }
    );

    await conn.sendAudioMessage(m.chat, audioUrl, ftroli);

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
};

handler.command = ['scplay', 'soundcloud'];
handler.tags = ["download"];
handler.help = ['soundcloud <query>'];

module.exports = handler;