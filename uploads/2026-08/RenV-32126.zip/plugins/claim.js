const axios = require('axios');

const TABLE = global.claim_table || 'claim_videos';
const BUCKET = global.supabase_bucket || 'claim-videos';
const SUPABASE_URL = global.supabase_url;
const SUPABASE_SERVICE_ROLE_KEY = global.supabase_service_role_key;
const MAX_MB = Number(global.claim_max_mb || 110);
const SEND_AS_DOCUMENT = String(global.claim_send_as_document ?? 'true') !== 'false';
const DELETE_AFTER_SEND = String(global.claim_delete_after_send ?? 'false') === 'true';

function headers() {
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('SUPABASE_URL dan SUPABASE_SERVICE_ROLE_KEY belum diisi di config.js bot.');
  }

  return {
    apikey: SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
    'Content-Type': 'application/json'
  };
}

function normalizeToken(input = '') {
  return String(input).trim().replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
}

function formatSize(bytes = 0) {
  return `${(Number(bytes) / 1024 / 1024).toFixed(2)} MB`;
}

async function findClaim(token) {
  const url = `${SUPABASE_URL}/rest/v1/${TABLE}?token=eq.${encodeURIComponent(token)}&select=*`;
  const { data } = await axios.get(url, { headers: headers(), timeout: 20000 });
  return Array.isArray(data) ? data[0] : null;
}

async function updateClaim(id, payload) {
  if (!id) return;
  const url = `${SUPABASE_URL}/rest/v1/${TABLE}?id=eq.${encodeURIComponent(id)}`;
  await axios.patch(url, payload, {
    headers: { ...headers(), Prefer: 'return=minimal' },
    timeout: 20000
  });
}

async function deleteStorageFile(storagePath) {
  if (!storagePath) return;
  const url = `${SUPABASE_URL}/storage/v1/object/${BUCKET}/${storagePath}`;
  await axios.delete(url, { headers: headers(), timeout: 20000 }).catch(() => null);
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const token = normalizeToken(text);

  if (!token) {
    return conn.sendMessage(m.chat, {
      text: `*[ CLAIM VIDEO ]*\n\nCara pakai:\n${usedPrefix + command} KODE\n\nContoh:\n${usedPrefix + command} A1B2C3D4`
    }, { quoted: m });
  }

  await conn.sendMessage(m.chat, {
    text: `⏳ Sedang mencari video dengan kode: *${token}*`
  }, { quoted: m });

  let claim;
  try {
    claim = await findClaim(token);
  } catch (e) {
    throw `Gagal menghubungkan ke database claim.\n${e.message}`;
  }

  if (!claim) {
    return conn.sendMessage(m.chat, {
      text: `❌ Kode claim *${token}* tidak ditemukan atau salah.`
    }, { quoted: m });
  }

  if (claim.status === 'uploading') {
    return conn.sendMessage(m.chat, {
      text: `⏳ Video dengan kode *${token}* masih proses upload. Coba lagi beberapa detik.`
    }, { quoted: m });
  }

  if (claim.status === 'claimed') {
    return conn.sendMessage(m.chat, {
      text: `⚠️ Kode *${token}* sudah pernah diclaim. Upload ulang video jika ingin membuat kode baru.`
    }, { quoted: m });
  }

  if (claim.status === 'failed') {
    return conn.sendMessage(m.chat, {
      text: `❌ Video dengan kode *${token}* berstatus gagal. Silakan upload ulang.`
    }, { quoted: m });
  }

  if (claim.expires_at && new Date(claim.expires_at).getTime() < Date.now()) {
    await updateClaim(claim.id, {
      status: 'expired',
      error_message: 'Token expired'
    }).catch(() => null);

    return conn.sendMessage(m.chat, {
      text: `⌛ Kode *${token}* sudah expired. Silakan upload ulang video.`
    }, { quoted: m });
  }

  if (Number(claim.size_bytes || 0) > MAX_MB * 1024 * 1024) {
    await updateClaim(claim.id, {
      status: 'failed',
      error_message: `File lebih dari limit bot ${MAX_MB} MB`
    }).catch(() => null);

    return conn.sendMessage(m.chat, {
      text: `❌ File terlalu besar untuk dikirim bot. Limit bot: ${MAX_MB} MB.`
    }, { quoted: m });
  }

  const fileUrl = claim.public_url;

  if (!fileUrl) {
    return conn.sendMessage(m.chat, {
      text: `❌ Link video tidak tersedia. Coba upload ulang.`
    }, { quoted: m });
  }

  try {
    const response = await axios.get(fileUrl, {
      responseType: 'arraybuffer',
      timeout: 120000,
      maxContentLength: Infinity,
      maxBodyLength: Infinity
    });

    const buffer = Buffer.from(response.data);
    const mime = claim.mime_type || 'video/mp4';
    const fileName = claim.file_name || `PanPan-${token}.mp4`;

    const caption = [
      `✅ *CLAIM VIDEO BERHASIL*`,
      ``,
      `Kode: ${token}`,
      `Ukuran: ${formatSize(buffer.length)}`,
      ``,
      SEND_AS_DOCUMENT
        ? `Video dikirim sebagai dokumen agar kualitas tetap aman.`
        : `Video dikirim sebagai video biasa.`
    ].join('\n');

    const payload = SEND_AS_DOCUMENT
      ? { document: buffer, mimetype: mime, fileName, caption }
      : { video: buffer, mimetype: mime, fileName, caption };

    await conn.sendMessage(m.chat, payload, { quoted: m });

    await updateClaim(claim.id, {
      status: 'claimed',
      claimed_at: new Date().toISOString(),
      claimed_by: m.sender
    }).catch(() => null);

    if (DELETE_AFTER_SEND) {
      await deleteStorageFile(claim.storage_path);
    }
  } catch (e) {
    await updateClaim(claim.id, {
      status: 'failed',
      error_message: e.message || 'Download/send failed'
    }).catch(() => null);

    throw `Gagal mengirim video.\n${e.message}`;
  }
};

handler.help = ['claim <kode>'];
handler.tags = ['tools'];
handler.command = /^(claim|ambilvideo|swclaim)$/i;
handler.limit = false;

module.exports = handler;