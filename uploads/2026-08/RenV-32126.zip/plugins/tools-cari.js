'use strict';

/**
 * plugins/maps.js
 * ─────────────────────────────────────────────────────────────────
 * Reverse-geocode share-location + `.cari <tempat>`, 100% gratis
 * pake OpenStreetMap. Gak butuh API key, gak butuh billing.
 *
 *   - Nominatim   -> reverse geocode (koordinat -> alamat)
 *   - Overpass API -> cari POI (nama tempat) di radius tertentu
 *
 * CATATAN: semua error di-handle langsung lewat m.reply/conn.sendMessage,
 * gak ada throw sama sekali - biar konsisten sama laporan suspectThrows
 * yang udah pernah di-audit sebelumnya (throw string/Error tanpa
 * di-catch dengan benar bikin stack trace ilang & sulit debug).
 *
 * CATATAN USAGE POLICY (biar gak diblokir OSM):
 *   - Wajib pake User-Agent yang jelas (udah di-set di bawah)
 *   - Nominatim max ~1 request/detik buat pemakaian wajar personal,
 *     jangan dipake buat bulk scraping
 *   - Data POI dari OSM kadang kurang lengkap dibanding Google Maps
 *     (rating/ulasan gak ada, beberapa tempat baru belum ke-tag)
 *
 * ENV (opsional):
 *   NOMINATIM_USER_AGENT   — custom identifier, default udah ada fallback
 *   OSM_SEARCH_RADIUS_M    — radius default pencarian (meter), default 5000
 *
 * PERINTAH:
 *   (share location)  — auto reverse-geocode, simpen sebagai titik acuan
 *   .cari <tempat>     — cari tempat + jarak dari titik acuan terakhir
 */

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '../data');
const LAST_LOCATION_FILE = path.join(DATA_DIR, 'last-location.json');

const NOMINATIM_REVERSE = 'https://nominatim.openstreetmap.org/reverse';

// Server publik overpass-api.de gampang ngasih 429 ke IP VPS/hosting.
// Rotasi ke beberapa mirror biar lebih reliable.
const OVERPASS_ENDPOINTS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
  'https://overpass.private.coffee/api/interpreter'
];

const DEFAULT_RADIUS_M = Number(process.env.OSM_SEARCH_RADIUS_M || 5000);
const MAX_RADIUS_M = 30000; // batas atas biar query gak ngebengkak & rawan timeout

const USER_AGENT = process.env.NOMINATIM_USER_AGENT || 'RenvyBail-WhatsAppBot/1.0 (personal use, non-commercial)';

fs.mkdirSync(DATA_DIR, { recursive: true });

// ───────────────────────── Storage titik acuan per user ─────────────────────────

function _loadLastLocations() {
  try { return JSON.parse(fs.readFileSync(LAST_LOCATION_FILE, 'utf-8')); }
  catch { return {}; }
}

function _saveLastLocation(jid, lat, lng, address) {
  const all = _loadLastLocations();
  all[jid] = { lat, lng, address, savedAt: Date.now() };
  fs.writeFileSync(LAST_LOCATION_FILE, JSON.stringify(all, null, 2));
}

function getLastLocation(jid) {
  return _loadLastLocations()[jid] || null;
}

// ───────────────────────── Helper geo ─────────────────────────

function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function fmtKm(km) {
  return km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(2)} km`;
}

// ───────────────────────── Nominatim (reverse geocode) ─────────────────────────
// Return { ok, address, error } - gak throw, biar caller yang tentuin cara balesnya.

async function reverseGeocode(lat, lng) {
  try {
    const url = `${NOMINATIM_REVERSE}?format=jsonv2&lat=${lat}&lon=${lng}&accept-language=id&zoom=18`;
    const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT } });
    const data = await res.json();

    if (!res.ok || data.error) {
      return { ok: false, error: `Reverse geocode gagal: ${data.error || res.status}` };
    }

    return { ok: true, address: data.display_name || 'Alamat tidak ditemukan' };
  } catch (e) {
    return { ok: false, error: `Reverse geocode error: ${e.message}` };
  }
}

// ───────────────────────── Overpass (cari POI by nama) ─────────────────────────

function buildAddress(tags = {}) {
  const parts = [
    tags['addr:street'],
    tags['addr:housenumber'],
    tags['addr:suburb'] || tags['addr:village'],
    tags['addr:city'] || tags['addr:town']
  ].filter(Boolean);
  return parts.length ? parts.join(', ') : 'Alamat detail tidak tersedia di data OSM';
}

// Kata generik Indonesia -> tag OSM asli. Dicek dulu sebelum fallback ke name-regex,
// karena banyak tempat (SPBU, ATM, dll) gak literally punya kata itu di nama-nya.
const CATEGORY_ALIASES = {
  'pom bensin': { key: 'amenity', value: 'fuel' },
  'pombensin': { key: 'amenity', value: 'fuel' },
  'spbu': { key: 'amenity', value: 'fuel' },
  'pertamina': { key: 'amenity', value: 'fuel' },
  'bensin': { key: 'amenity', value: 'fuel' },
  'apotek': { key: 'amenity', value: 'pharmacy' },
  'apotik': { key: 'amenity', value: 'pharmacy' },
  'atm': { key: 'amenity', value: 'atm' },
  'rumah sakit': { key: 'amenity', value: 'hospital' },
  'rs': { key: 'amenity', value: 'hospital' },
  'puskesmas': { key: 'amenity', value: 'clinic' },
  'klinik': { key: 'amenity', value: 'clinic' },
  'masjid': { key: 'amenity', value: 'place_of_worship' },
  'gereja': { key: 'amenity', value: 'place_of_worship' },
  'sekolah': { key: 'amenity', value: 'school' },
  'restoran': { key: 'amenity', value: 'restaurant' },
  'warung makan': { key: 'amenity', value: 'restaurant' },
  'minimarket': { key: 'shop', value: 'convenience' },
  'supermarket': { key: 'shop', value: 'supermarket' },
  'bank': { key: 'amenity', value: 'bank' },
  'sekolahan': { key: 'amenity', value: 'school' }
};

// Return { ok, data, error } - gak throw.
async function fetchOverpass(ql) {
  let lastErr = 'Semua mirror Overpass gagal diakses.';

  for (const endpoint of OVERPASS_ENDPOINTS) {
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': USER_AGENT
        },
        body: 'data=' + encodeURIComponent(ql)
      });

      if (res.status === 429 || res.status === 504) {
        lastErr = `${endpoint} lagi sibuk (${res.status}), coba mirror lain...`;
        continue; // lanjut ke endpoint berikutnya
      }

      if (!res.ok) {
        const err = await res.text().catch(() => '');
        lastErr = `Overpass query gagal (${res.status}): ${err.slice(0, 200)}`;
        continue;
      }

      const json = await res.json();
      return { ok: true, data: json };
    } catch (e) {
      lastErr = e.message;
    }
  }

  return { ok: false, error: lastErr };
}

// Return { ok, places, error } - gak throw.
async function searchPlaces(query, refLat, refLng, radiusM = DEFAULT_RADIUS_M) {
  const safeQuery = query.replace(/["\\]/g, '');
  const alias = CATEGORY_ALIASES[safeQuery.toLowerCase().trim()];

  let ql;
  if (alias) {
    // Search by kategori tag asli (lebih akurat & cepat buat istilah generik).
    ql = `
      [out:json][timeout:25];
      (
        node["${alias.key}"="${alias.value}"](around:${radiusM},${refLat},${refLng});
        way["${alias.key}"="${alias.value}"](around:${radiusM},${refLat},${refLng});
      );
      out center 20;
    `;
  } else {
    // Fallback: search by nama, tapi dibatasi ke elemen yang punya tag POI umum
    // (shop/amenity/tourism), bukan scan semua elemen ber-nama (jalan, gedung, dll)
    // yang bikin query berat & sering timeout diem-diem.
    ql = `
      [out:json][timeout:25];
      (
        node["shop"]["name"~"${safeQuery}",i](around:${radiusM},${refLat},${refLng});
        node["amenity"]["name"~"${safeQuery}",i](around:${radiusM},${refLat},${refLng});
        node["tourism"]["name"~"${safeQuery}",i](around:${radiusM},${refLat},${refLng});
        way["shop"]["name"~"${safeQuery}",i](around:${radiusM},${refLat},${refLng});
        way["amenity"]["name"~"${safeQuery}",i](around:${radiusM},${refLat},${refLng});
      );
      out center 20;
    `;
  }

  const result = await fetchOverpass(ql);
  if (!result.ok) {
    return { ok: false, error: `Gagal cari lokasi.\n${result.error}` };
  }

  const data = result.data;

  if (data.remark) {
    // Overpass sering balikin HTTP 200 tapi ada "remark" pas timeout/error internal.
    return { ok: false, error: `Overpass bermasalah: ${data.remark}` };
  }

  const elements = data.elements || [];

  const places = elements
    .map((el) => {
      const lat = el.lat ?? el.center?.lat;
      const lon = el.lon ?? el.center?.lon;
      if (lat == null || lon == null) return null;
      return {
        name: el.tags?.name || (alias ? `(${query})` : '(tanpa nama)'),
        lat,
        lon,
        address: buildAddress(el.tags)
      };
    })
    .filter(Boolean);

  return { ok: true, places };
}

// ───────────────────────── Handler ─────────────────────────

let handler = async (m, { conn, args }) => {
  let radiusKm = null;
  const last = args[args.length - 1];
  if (args.length > 1 && !isNaN(Number(last))) {
    radiusKm = Number(last);
    args = args.slice(0, -1);
  }

  const keyword = args.join(' ').trim();
  if (!keyword) {
    return conn.sendMessage(m.chat, {
      text: 'Pakai: `.cari <nama tempat> [radius_km]`\nContoh: `.cari indomaret`\nContoh: `.cari alfamart 10` (radius 10km)'
    }, { quoted: m });
  }

  const radiusM = radiusKm ? Math.min(radiusKm * 1000, MAX_RADIUS_M) : DEFAULT_RADIUS_M;

  const ref = getLastLocation(m.sender);
  if (!ref) {
    return m.reply('Belum ada titik acuan. Share location dulu (drop pin biasa, bukan live location), baru `.cari` bisa dipakai.');
  }

  await m.reply('`Mencari lokasi...`');

  const result = await searchPlaces(keyword, ref.lat, ref.lng, radiusM);
  if (!result.ok) {
    return m.reply(result.error);
  }

  const places = result.places;

  if (!places.length) {
    return conn.reply(
      m.chat,
      `Gaada hasil buat \`${keyword}\` dalam radius ${(radiusM / 1000).toFixed(1)}km dari titik acuan.\n\nCoba perbesar radius: \`.cari ${keyword} ${Math.min((radiusM / 1000) * 2, 30)}\``,
      m
    );
  }

  const withDistance = places
    .map((p) => ({ ...p, jarak: haversineKm(ref.lat, ref.lng, p.lat, p.lon) }))
    .sort((a, b) => a.jarak - b.jarak);

  const lines = [];
  lines.push(`\`HASIL PENCARIAN - ${keyword.toUpperCase()}\``);
  lines.push('');
  lines.push(`[+] Acuan     > ${ref.address}`);
  lines.push('');

  withDistance.slice(0, 8).forEach((p, i) => {
    lines.push(`[+] ${i + 1}. ${p.name}`);
    lines.push(`    > Alamat  : ${p.address}`);
    lines.push(`    > Jarak   : ${fmtKm(p.jarak)} dari titik acuan`);
    lines.push('');
  });

  lines.push('`Sumber data: OpenStreetMap`');

  await conn.sendMessage(m.chat, { text: lines.join('\n').trim() }, { quoted: m });
};

handler.help = ['cari <tempat>'];
handler.tags = ['tools'];
handler.command = /^cari$/i;
handler.limit = true;

// ── Auto reverse-geocode pas user share location (bukan command) ──
handler.all = async function (m) {
  if (!['locationMessage', 'liveLocationMessage'].includes(m.mtype)) return;

  const lat = m.msg?.degreesLatitude;
  const lng = m.msg?.degreesLongitude;
  if (typeof lat !== 'number' || typeof lng !== 'number') return;

  if (lat === 0 && lng === 0) {
    // Placeholder awal live location (belum ada GPS fix), tunggu update berikutnya.
    return;
  }

  const result = await reverseGeocode(lat, lng);

  if (!result.ok) {
    await this.sendMessage(m.chat, {
      text: `\`GAGAL PROSES LOKASI\`\n\n[+] Error > ${result.error}`
    }, { quoted: m });
    return;
  }

  _saveLastLocation(m.sender, lat, lng, result.address);

  const lines = [
    '`LOKASI DITERIMA`',
    '',
    `[+] Alamat    > ${result.address}`,
    `[+] Koordinat > ${lat}, ${lng}`,
    '',
    'Titik ini disimpen sebagai acuan buat `.cari <tempat>`.'
  ];
  await this.sendMessage(m.chat, { text: lines.join('\n') }, { quoted: m });
};

module.exports = handler;