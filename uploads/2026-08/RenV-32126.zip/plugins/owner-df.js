const fs = require('fs');
const syntaxError = require('syntax-error');
const path = require('path');
const util = require('util');

const _fs = fs.promises;

let handler = async (m, { text, usedPrefix, command }) => {
   let input = `[!] *wrong input*
	
Ex : ${usedPrefix + command} example.js`;

   if (!text) return m.reply(input);

   try {
      let filename = text.replace(/plugin(s)\//i, '');
      if (!(/\.(js|mjs)$/i.test(filename))) {
         filename += '.js';
      }

      let filePath = path.join(process.cwd(), 'plugins', filename);

      if (!fs.existsSync(filePath)) {
         throw `🚩 File *${filename}* tidak ditemukan`;
      }

      await _fs.unlink(filePath);

      m.reply(`
Successfully deleted *${filename}*
`.trim());

   } catch (e) {
      console.log(e);
      m.reply(util.format(e));
   }
};

handler.help = ['df <name file>'];
handler.tags = ['owner'];
handler.command = /^(df|delplug|deleteplugins)$/i;
handler.owner = true;

module.exports = handler;