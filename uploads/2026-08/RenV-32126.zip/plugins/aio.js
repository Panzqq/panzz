const axios = require("axios");

const BASE = "https://downr.org";
const ANALYTICS = `${BASE}/.netlify/functions/analytics`;
const DOWNLOAD = `${BASE}/.netlify/functions/download`;
const NYT = `${BASE}/.netlify/functions/nyt`;

const UA =
  "Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36";

const BLOCKED_DOMAINS = [
  "xnxx",
  "xvideos",
  "pornhub",
  "redtube",
  "youporn",
  "eporner",
  "spankbang",
  "xhamster"
];

function parseCookie(setCookie = []) {
  return setCookie.map(v => v.split(";")[0]).join("; ");
}

function parseData(data) {
  if (typeof data !== "string") return data;

  const text = data.trim();

  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}

function isOk(status, data) {
  const isObject = data && typeof data === "object";

  if (status < 200 || status >= 300) return false;
  if (data === null || data === undefined) return false;
  if (data === "") return false;
  if (data === "error") return false;
  if (data === "failed") return false;
  if (data === "user_retry_required") return false;
  if (isObject && data.error === true) return false;
  if (isObject && data.status === false) return false;
  if (isObject && data.success === false) return false;

  return true;
}

function getError(data, status) {
  if (typeof data === "string") return data || `HTTP ${status}`;
  if (data && typeof data === "object") {
    return data.message || data.error || data.status || data.reason || `HTTP ${status}`;
  }
  return `HTTP ${status}`;
}

async function getCookie() {
  const res = await axios.get(ANALYTICS, {
    timeout: 30000,
    validateStatus: () => true,
    responseType: "text",
    transformResponse: [v => v],
    headers: {
      accept: "*/*",
      referer: `${BASE}/`,
      "user-agent": UA
    }
  });

  return parseCookie(res.headers["set-cookie"] || []);
}

async function postEndpoint(endpoint, url, cookie = "") {
  const res = await axios.post(
    endpoint,
    { url },
    {
      timeout: 120000,
      validateStatus: () => true,
      responseType: "text",
      transformResponse: [v => v],
      headers: {
        accept: "*/*",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        "content-type": "application/json",
        cookie,
        origin: BASE,
        referer: `${BASE}/`,
        "sec-ch-ua": '"Chromium";v="137", "Not/A)Brand";v="24"',
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": '"Android"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": UA
      }
    }
  );

  return {
    endpoint,
    status: res.status,
    data: parseData(res.data)
  };
}

async function tryDownload(url) {
  let cookie = await getCookie();
  let result = await postEndpoint(DOWNLOAD, url, cookie);

  if (isOk(result.status, result.data)) return result;

  cookie = await getCookie();
  result = await postEndpoint(DOWNLOAD, url, cookie);

  if (isOk(result.status, result.data)) return result;

  result = await postEndpoint(NYT, url, cookie);

  return result;
}

async function downr(url) {
  try {
    if (!url || !/^https?:\/\//i.test(url)) {
      throw new Error("URL tidak valid.");
    }

    const result = await tryDownload(url);
    const ok = isOk(result.status, result.data);

    return {
      Status: ok,
      Code: result.status,
      Input: url,
      Endpoint: result.endpoint,
      Result: ok ? result.data : null,
      Error: ok ? null : getError(result.data, result.status)
    };
  } catch (err) {
    return {
      Status: false,
      Code: err.response?.status || 500,
      Input: url || null,
      Endpoint: null,
      Result: null,
      Error: err.message
    };
  }
}

function extractUrl(text = "") {
  const match = String(text).match(/https?:\/\/[^\s]+/i);
  return match ? match[0] : null;
}

function isBlockedUrl(url = "") {
  try {
    const host = new URL(url).hostname.toLowerCase();
    return BLOCKED_DOMAINS.some(domain => host.includes(domain));
  } catch {
    return true;
  }
}

function formatSize(size) {
  if (!size) return "-";
  if (typeof size === "string") return size;

  const num = Number(size);
  if (!num || isNaN(num)) return "-";

  if (num >= 1024 * 1024) return `${(num / 1024 / 1024).toFixed(2)} MB`;
  if (num >= 1024) return `${(num / 1024).toFixed(2)} KB`;
  return `${num} B`;
}

function getMediaList(result) {
  const data = result?.Result || result;

  if (!data) return [];

  if (Array.isArray(data.medias)) return data.medias;
  if (Array.isArray(data.media)) return data.media;
  if (Array.isArray(data.url)) return data.url;
  if (Array.isArray(data.data)) return data.data;

  if (data.url) {
    return [
      {
        url: data.url,
        type: data.type,
        extension: data.extension,
        quality: data.quality
      }
    ];
  }

  return [];
}

function getInfo(result) {
  const data = result?.Result || {};

  return {
    title: data.title || data.caption || data.desc || data.description || "Downloader Result",
    author: data.author || data.username || data.uploader || "-",
    source: data.source || data.platform || "-",
    thumbnail: data.thumbnail || data.cover || data.image || null,
    duration: data.duration || null
  };
}

function getExt(media = {}) {
  let ext = media.extension || media.ext || "";

  if (!ext && media.url) {
    try {
      const clean = media.url.split("?")[0];
      ext = clean.split(".").pop();
    } catch {}
  }

  ext = String(ext || "").toLowerCase().replace(".", "");

  if (ext.includes("/")) ext = "";
  if (ext.length > 5) ext = "";

  return ext || "mp4";
}

function getMediaType(media = {}) {
  const ext = getExt(media);
  const type = String(media.type || "").toLowerCase();

  if (type.includes("audio")) return "audio";
  if (type.includes("image")) return "image";
  if (type.includes("video")) return "video";

  if (["mp3", "m4a", "wav", "ogg", "aac"].includes(ext)) return "audio";
  if (["jpg", "jpeg", "png", "webp"].includes(ext)) return "image";
  if (["mp4", "mov", "mkv", "webm"].includes(ext)) return "video";

  return "document";
}

function mediaScore(media = {}) {
  const quality = String(media.quality || "").toLowerCase();
  const type = getMediaType(media);

  let score = 0;

  if (quality.includes("no_watermark")) score += 100000;
  if (quality.includes("hd")) score += 50000;

  if (type === "video") score += 30000;
  if (type === "audio") score += 20000;
  if (type === "image") score += 10000;

  const height = Number(media.height) || Number(String(quality).match(/\d+/)?.[0]) || 0;
  score += height;

  return score;
}

function pickBestMedia(medias = []) {
  return medias
    .filter(v => v && v.url)
    .sort((a, b) => mediaScore(b) - mediaScore(a))[0];
}

function cleanFileName(text = "file") {
  return String(text)
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 80) || "file";
}

async function sendMedia(conn, m, media, info, index = 1) {
  const type = getMediaType(media);
  const ext = getExt(media);
  const title = cleanFileName(info.title);
  const fileName = `${title}.${ext}`;

  const caption =
    `乂 *All in One Downloader*\n\n` +
    `◦ *Judul:* ${info.title}\n` +
    `◦ *Author:* ${info.author}\n` +
    `◦ *Source:* ${info.source}\n` +
    `◦ *Quality:* ${media.quality || "-"}\n` +
    `◦ *Size:* ${formatSize(media.data_size || media.size)}\n` +
    `◦ *File:* ${index}`;

  if (type === "image") {
    return conn.sendMessage(
      m.chat,
      {
        image: { url: media.url },
        caption
      },
      { quoted: m }
    );
  }

  if (type === "audio") {
    return conn.sendAudioMessage(m.chat, media.url, ftroli, { fileName });
  }

  if (type === "video") {
    return conn.sendMessage(
      m.chat,
      {
        video: { url: media.url },
        mimetype: "video/mp4",
        fileName,
        caption
      },
      { quoted: m }
    );
  }

  return conn.sendMessage(
    m.chat,
    {
      document: { url: media.url },
      mimetype: "application/octet-stream",
      fileName,
      caption
    },
    { quoted: m }
  );
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const url = extractUrl(text);

  if (!url) {
    return conn.reply(
      m.chat,
      `Masukkan URL yang ingin didownload.\n\nContoh:\n${usedPrefix + command} https://vt.tiktok.com/xxxxx/`,
      m
    );
  }

  if (isBlockedUrl(url)) {
    return conn.reply(m.chat, "URL ini tidak didukung oleh fitur ini.", m);
  }

  const sendAll = /--all/i.test(text);

  try {
    await conn.reply(m.chat, "⏳ Sedang memproses link, tunggu sebentar...", m);

    const result = await downr(url);

    if (!result.Status) {
      return conn.reply(
        m.chat,
        `Gagal mengambil media.\n\nError: ${result.Error || "Unknown error"}`,
        m
      );
    }

    const medias = getMediaList(result).filter(v => v && v.url);
    const info = getInfo(result);

    if (!medias.length) {
      return conn.reply(m.chat, "Media tidak ditemukan dari link tersebut.", m);
    }

    const onlyImages = medias.every(v => getMediaType(v) === "image");

    if (sendAll || onlyImages) {
      const list = medias.slice(0, 10);

      for (let i = 0; i < list.length; i++) {
        await sendMedia(conn, m, list[i], info, i + 1);
      }

      if (medias.length > 10) {
        await conn.reply(
          m.chat,
          `Berhasil mengirim 10 media pertama dari total ${medias.length} media.`,
          m
        );
      }

      return;
    }

    const best = pickBestMedia(medias);

    if (!best) {
      return conn.reply(m.chat, "Media valid tidak ditemukan.", m);
    }

    await sendMedia(conn, m, best, info, 1);
  } catch (err) {
    console.error(err);
    return conn.reply(
      m.chat,
      `Terjadi error:\n${err.message || err}`,
      m
    );
  }
};

handler.help = handler.command = ["aio", "downr", "alldl"];
handler.tags = ["downloader"];

module.exports = handler;