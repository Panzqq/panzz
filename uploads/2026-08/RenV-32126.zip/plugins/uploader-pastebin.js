const fetch = require('node-fetch');

let handler = async (m, { conn, text }) => {
  const quotedText = m.quoted && m.quoted.text ? m.quoted.text.trim() : null;
  const inputText = text?.trim();
  const kode = quotedText || inputText;

  if (!kode) {
    return m.reply(`Reply kode atau masukkan kode untuk di post di pastebin`);
  }

  const api_dev_key = '4bJXe3d9f8aW7_w57zvGhVEG1WK6YVvd';

  const formData = new URLSearchParams({
    api_dev_key,
    api_option: 'paste',
    api_paste_code: kode,
    api_paste_name: 'Kode dari pengguna',
    api_paste_format: 'text',
    api_paste_private: '1',
    api_paste_expire_date: '10M'
  });

  try {
    const res = await fetch('https://pastebin.com/api/api_post.php', {
      method: 'POST',
      body: formData
    });

    const url = await res.text();

    if (!res.ok || url.startsWith('Bad API request')) {
      return m.reply(`❌ Gagal upload:\n${url}`);
    }

    const pasteId = url.split('/').pop();
    const rawUrl = `https://pastebin.com/raw/${pasteId}`;

    return m.reply(`✅ Paste berhasil dibuat:\n${rawUrl}`);
  } catch (err) {
    return m.reply(`❌ Error koneksi ke Pastebin:\n${err.message}`);
  }
};

handler.help = ['uploadpastebin', 'paste'].map(v => v + ' <upload ke pastebin>');
handler.tags = ['uploader'];
handler.command = /^uploadpastebin$|^paste$/i;

module.exports = handler;