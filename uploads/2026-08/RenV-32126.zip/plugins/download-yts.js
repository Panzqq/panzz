const axios = require("axios");

const YT_HEADERS = {
  "content-type": "application/json",
  "x-youtube-client-name": "1",
  "x-youtube-client-version": "2.20260521.00.00",
  "user-agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/148.0.0.0 Safari/537.36",
};

const CONTEXT = {
  context: {
    client: {
      hl: "en",
      gl: "ID",
      clientName: "WEB",
      clientVersion: "2.20260521.00.00",
      platform: "DESKTOP",
    },
  },
};

async function ytRequest(endpoint, body) {
  const url = `https://www.youtube.com/youtubei/v1/${endpoint}?prettyPrint=false`;

  const { data } = await axios.post(url, body, {
    headers: YT_HEADERS,
    timeout: 20000,
  });

  return data;
}

async function searchYoutube(query, limit = 10) {
  try {
    const json = await ytRequest("search", {
      ...CONTEXT,
      query,
    });

    const result = extractVideos(json).slice(0, limit);
    if (result.length) return result;
  } catch (e) {
    console.error("Youtubei error:", e.message);
  }

  return searchYoutubeHtml(query, limit);
}

async function searchYoutubeHtml(query, limit = 10) {
  const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;

  const { data } = await axios.get(url, {
    headers: {
      "user-agent": YT_HEADERS["user-agent"],
      "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    },
    timeout: 20000,
  });

  const match = data.match(/var ytInitialData = (.*?);<\/script>/);
  if (!match) return [];

  const json = JSON.parse(match[1]);
  return extractVideos(json).slice(0, limit);
}

function extractVideos(json) {
  const results = [];

  function walk(obj) {
    if (!obj || typeof obj !== "object") return;

    if (obj.videoRenderer && obj.videoRenderer.videoId) {
      const v = obj.videoRenderer;

      const thumbnails = v.thumbnail?.thumbnails || [];

      const title =
        v.title?.runs?.map((x) => x.text).join("") ||
        v.title?.simpleText ||
        "Tanpa Judul";

      const description =
        v.detailedMetadataSnippets?.[0]?.snippetText?.runs
          ?.map((x) => x.text)
          .join("") || "-";

      const channel =
        v.ownerText?.runs?.[0]?.text ||
        v.longBylineText?.runs?.[0]?.text ||
        "-";

      const views =
        v.viewCountText?.simpleText ||
        v.shortViewCountText?.simpleText ||
        "-";

      const published = v.publishedTimeText?.simpleText || "-";
      const duration = v.lengthText?.simpleText || "-";

      const thumbnail =
        thumbnails[thumbnails.length - 1]?.url ||
        `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg`;

      results.push({
        videoId: v.videoId,
        title,
        description,
        channel,
        views,
        published,
        duration,
        thumbnail,
        url: `https://youtube.com/watch?v=${v.videoId}`,
      });
    }

    for (const key in obj) {
      walk(obj[key]);
    }
  }

  walk(json);

  const unique = [];
  const ids = new Set();

  for (const item of results) {
    if (!ids.has(item.videoId)) {
      ids.add(item.videoId);
      unique.push(item);
    }
  }

  return unique;
}

function makeCacheKey(m) {
  return `${m.chat}_${m.sender}`;
}

function saveCache(m, videos) {
  global.ytsCache = global.ytsCache || {};
  global.ytsCache[makeCacheKey(m)] = {
    time: Date.now(),
    videos,
  };
}

function getCacheVideo(m, videoId) {
  global.ytsCache = global.ytsCache || {};

  const data = global.ytsCache[makeCacheKey(m)];
  if (!data) return null;

  return data.videos.find((v) => v.videoId === videoId) || null;
}

async function sendVideoList(conn, m, videos, text, usedPrefix, command) {
  const resultText = videos
    .map((v, i) => {
      return `*${i + 1}. ${v.title}*

📺 *Channel:* ${v.channel}
⏱️ *Durasi:* ${v.duration}
👁️ *Views:* ${v.views}
🕒 *Upload:* ${v.published}
🔗 ${v.url}`;
    })
    .join("\n\n");

  const datas = {
    title: `[ ${global.namebot || "Bot"} - YouTube Result ]`,
    sections: [
      {
        title: "🎬 Pilih Video",
        rows: videos.map((v, i) => ({
          header: `Result ${i + 1}`,
          title: v.title,
          description: `${v.channel} • ${v.duration} • ${v.views}`,
          id: `${usedPrefix + command} yt-select:${v.videoId}`,
        })),
      },
    ],
  };

  return conn.sendButtonLoc(
    m.chat,
    [
      {
        id: "gada",
        text: "[ Pilih Video ]",
        native: true,
      },
      {
        id: `${usedPrefix}menu`,
        text: "[ Menu ]",
      },
    ],
    resultText,
    ` [ ${global.namebot || "Bot"} Powered By ${global.nameown || "Owner"} ] `,
    m,
    {
      mentions: [m.sender],
      nativeSelectData: datas,
      thumbUrl:
        videos[0]?.thumbnail ||
        global.thumb ||
        "https://files.catbox.moe/toarxh.jpg",
      name: global.namebot || "Renvy",
      address: `Search: ${text}`,
    }
  );
}

async function sendFormatChoice(conn, m, video, usedPrefix) {
  const url = video.url || `https://youtube.com/watch?v=${video.videoId}`;

  const info = `
🎬 *YouTube Downloader*

📌 *Title:* ${video.title}
📺 *Channel:* ${video.channel}
⏱️ *Durasi:* ${video.duration}
👁️ *Views:* ${video.views}
🕒 *Upload:* ${video.published}

🔗 ${url}

Pilih jenis download di bawah ini.
`.trim();

  return conn.sendButtonLoc(
    m.chat,
    [
      {
        id: `${usedPrefix}yta ${url}`,
        text: "[ Audio ]",
      },
      {
        id: `${usedPrefix}ytv ${url}`,
        text: "[ Video ]",
      },
    ],
    info,
    ` [ ${global.namebot || "Bot"} Powered By ${global.nameown || "Owner"} ] `,
    m,
    {
      mentions: [m.sender],
      thumbUrl:
        video.thumbnail ||
        global.thumb ||
        "https://files.catbox.moe/toarxh.jpg",
      name: global.namebot || "Renvy",
      address: "YouTube Downloader",
    }
  );
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    if (!text) {
      return m.reply(`🎧 *Contoh:* ${usedPrefix + command} demons`);
    }

    if (text.startsWith("yt-select:")) {
      const videoId = text.replace("yt-select:", "").trim();

      if (!videoId) return m.reply("❌ Video tidak valid.");

      let video = getCacheVideo(m, videoId);

      if (!video) {
        video = {
          videoId,
          title: "Video YouTube",
          channel: "-",
          duration: "-",
          views: "-",
          published: "-",
          thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
          url: `https://youtube.com/watch?v=${videoId}`,
        };
      }

      return sendFormatChoice(conn, m, video, usedPrefix);
    }

    await m.reply(global.wait || "⏳ Sedang mencari video YouTube...");

    const videos = await searchYoutube(text, 10);

    if (!videos.length) {
      return m.reply(`❌ Tidak ditemukan hasil untuk *"${text}"*.`);
    }

    saveCache(m, videos);

    return sendVideoList(conn, m, videos, text, usedPrefix, command);
  } catch (e) {
    console.error(e);
    return m.reply(`❌ Error: ${e.message || e}`);
  }
};

handler.help = handler.command = ["yts", "ytsearch"];
handler.tags = ["download"];

module.exports = handler;