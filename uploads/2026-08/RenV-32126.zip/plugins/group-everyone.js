let handler = (m) => m;

handler.before = async function (m, { conn, participants, isAdmin } = {}) {
  if (!m.isGroup) return;
  if (!m.text || !m.text.includes("@everyone")) return;
  if (!isAdmin) return;

  try {
    let memberJids = Array.isArray(participants)
      ? participants.map(v => v.id || v.jid || v.pn).filter(Boolean)
      : [];

    if (!memberJids.length) {
      const metadata = await conn.groupMetadata(m.chat).catch(() => null);
      memberJids = metadata?.participants?.map(v => v.id || v.jid || v.pn).filter(Boolean) || [];
    }

    if (!memberJids.length) return;

    return conn.sendMessage(m.chat, {
      text: m.text.replace(/@everyone/i, "@" + m.chat),
      contextInfo: {
        mentionedJid: memberJids,
        groupMentions: [
          {
            groupSubject: "everyone",
            groupJid: m.chat,
          },
        ],
      },
    });
  } catch (e) {}
};

module.exports = handler;
