
let handler = async (m, { conn, text = "" }) => {
  global._registerLocks = global._registerLocks || new Map();

  const sender = m.sender;
  const previousLock = global._registerLocks.get(sender);
  if (previousLock) {
    // Klik tombol yang sama kadang dikirim ulang oleh WhatsApp. Tunggu proses
    // pertama dan jangan mengirim respons kedua yang membingungkan.
    await previousLock.catch(() => {});
    return;
  }

  let finishLock;
  let registrationSucceeded = false;
  const lock = new Promise((resolve) => { finishLock = resolve; });
  global._registerLocks.set(sender, lock);

  try {
    let user = global.db.data.users[sender];
    if (!user) user = global.db.data.users[sender] = {};

    if (user.registered === true)
      throw "Kamu sudah terdaftar sebelumnya!\nIngin daftar ulang? ketik *.unreg*";

  // Default: nama dari profil WhatsApp, umur otomatis (tanpa perlu ketik apa-apa)
  let name = String(m.pushName || m.name || "").trim();
  let age;

  if (text && text.trim()) {
    // Mode manual: .register Nama.Umur (opsional, kalau mau set nama/umur sendiri)
    let [inputName, inputAge] = text.split(".");
    inputName = String(inputName || "").trim();
    inputAge = String(inputAge || "").trim();

    if (!inputAge || isNaN(inputAge))
      throw `*[ ! ]* Format salah.\n> Contoh: *.register Nama.Umur*\n> Atau ketik *.register* saja (tanpa data) untuk daftar otomatis.`;

    age = parseInt(inputAge);
    if (age < 5) throw "*[ ! ]* Umur terlalu kecil.";
    if (age > 80) throw "*[ ! ]* Umur terlalu besar.";
    if (inputName) name = inputName;
  } else {
    // Mode otomatis: umur di-generate, nama dari profil WA
    age = Math.floor(Math.random() * (60 - 18 + 1)) + 18;
  }

  if (!name) name = "Pengguna Baru";

  user.registered = true;
  user.name = name;
  user.age = age;
  user.regTime = +new Date();

  let sn = `RenV-${makeId(20)}`;
  user.sn = sn;

  let ppUrl = await conn.profilePictureUrl(m.sender, 'image').catch(() => "https://files.catbox.moe/a1wkxg.jpg");

  let caption = `✅ *Pendaftaran Berhasil!*\n\nSelamat datang, *${name}*!\n• Usia: *${age} tahun*\n• Untuk mulai menggunakan fitur, ketik *.menu*\n\n🔐 *Kode SN kamu:* ${sn}\n_(simpan SN ini, dibutuhkan kalau mau .unreg)_`;

  if (global.db && global.db._dirty === false) global.db._dirty = true;

  await conn.sendButtonLoc(
    m.chat,
    [
      { id: ".menu", text: "🚀 Buka Menu" },
      { id: ".profile", text: "👤 Cek Profile" }
    ],
    caption,
    global.wm || wm3,
    fdoc,
    {
      name: ` [ Hai, ${name}! ]`,
      address: "Selamat bergabung di Renvy!",
      thumbUrl: ppUrl,
      mentions: [m.sender]
    }
  );
  registrationSucceeded = true;
  } finally {
    finishLock();

    const release = () => {
      if (global._registerLocks.get(sender) === lock) {
        global._registerLocks.delete(sender);
      }
    };

    // Sesudah sukses, tahan sebentar untuk menyerap event tombol duplikat.
    // Kalau input/error gagal, lepas langsung agar user bisa segera mencoba lagi.
    if (registrationSucceeded) setTimeout(release, 3000).unref?.();
    else release();
  }
};

handler.help = ["register *[nama.umur]*"];
handler.tags = ["main"];
handler.command = /^(register|daftar|reg|verify|verifyauto)$/i;

module.exports = handler;

function makeId(length) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}
