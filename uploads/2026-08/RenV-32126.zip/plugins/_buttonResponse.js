/**
 * Normalisasi respons tombol/list menjadi command pada pesan yang SAMA.
 *
 * serialize.js sebenarnya sudah membaca selectedButtonId/paramsJson ke m.text.
 * Plugin lama membuat pesan sintetis lewat appendTextMessage(), sehingga satu
 * klik diproses dua kali: command pertama berhasil, command kedua mengira user
 * sudah terdaftar. Sekarang tidak ada emit pesan kedua lagi.
 */

const handler = (m) => m;

function safeJsonParse(value) {
  if (!value || typeof value !== "string") return {};
  try {
    return JSON.parse(value);
  } catch {
    return {};
  }
}

function firstString(...values) {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return "";
}

function getResponseCommand(m = {}) {
  const type = m.mtype || "";
  const msg = m.msg || {};

  if (type === "buttonsResponseMessage") {
    return firstString(msg.selectedButtonId, m.selectedButtonId, m.text);
  }

  if (type === "templateButtonReplyMessage") {
    return firstString(msg.selectedId, m.selectedId, m.text);
  }

  if (type === "listResponseMessage") {
    return firstString(
      msg.singleSelectReply?.selectedRowId,
      m.singleSelectReply?.selectedRowId,
      m.text
    );
  }

  if (type === "interactiveResponseMessage") {
    const native = msg.nativeFlowResponseMessage || m.nativeFlowResponseMessage || {};
    const params = safeJsonParse(native.paramsJson || native.buttonParamsJson);

    return firstString(
      params.id,
      params.selectedId,
      params.selected_id,
      params.selectedRowId,
      params.selected_row_id,
      params.buttonId,
      params.button_id,
      params.rowId,
      params.row_id,
      params.command,
      params.response,
      m.text
    );
  }

  return "";
}

handler.before = async (m) => {
  const commandId = getResponseCommand(m);
  if (!commandId || !commandId.startsWith(".")) return false;

  // Proses langsung dalam event yang sama. Jangan append/emit pesan baru.
  m.text = commandId;
  m.body = commandId;
  m.budy = commandId;
  m.__buttonCommandNormalized = true;

  return false;
};

module.exports = handler;
module.exports.getResponseCommand = getResponseCommand;
