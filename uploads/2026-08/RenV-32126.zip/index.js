;(() => {
  try {
    require('./lib/tmpManager').setup({ log: false });
  } catch (e) {
    console.log('[TMP MANAGER BOOT ERROR]', e.message);
  }
})();

;(() => {
  try {
    require('./lib/cleanModuleFolders').bootCleanModuleFolders('index');
  } catch (e) {
    console.log('[AUTO CLEAN BOOT ERROR]', e.message);
  }
})();

const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');
const chalk = require('chalk');
const boxen = require('boxen').default ?? require('boxen');
const chokidar = require('chokidar');
const tmpManager = require('./lib/tmpManager');
const { startModuleFolderCleaner, cleanModuleFoldersSync } = require('./lib/cleanModuleFolders');
const { getTheme } = require('./lib/theme');

cleanModuleFoldersSync('index start');
tmpManager.cleanNow({ maxAge: 5 * 60 * 1000, includeLegacy: true }).catch(() => {});
startModuleFolderCleaner();

const DATABASE_CONFIG_HOME = path.join(__dirname, 'database', '.config');

function setupDatabaseConfigHome() {
  try {
    fs.mkdirSync(DATABASE_CONFIG_HOME, { recursive: true });
    process.env.XDG_CONFIG_HOME = DATABASE_CONFIG_HOME;
    process.env.ADBLOCK = process.env.ADBLOCK || '1';
    process.env.DISABLE_OPENCOLLECTIVE = process.env.DISABLE_OPENCOLLECTIVE || '1';
  } catch (e) {
    console.log(chalk.redBright('[ CONFIG HOME ERROR ]'), e.message);
  }
}

setupDatabaseConfigHome();

function formatUptime(seconds) {
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor((seconds % (3600 * 24)) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${d}d ${h}h ${m}m ${s}s`;
}

function displaySystemInfo() {
  const theme = getTheme();
  const cyan = chalk.hex(theme.primary);
  const gray = chalk.hex(theme.muted || '#999999');
  const cpus = os.cpus();
  const net = os.networkInterfaces();

  return `
${gray('Platform')}   : ${os.platform()} ${os.release()} (${os.arch()})
${gray('Hostname')}   : ${os.hostname()}
${gray('Memory')}     : ${(os.freemem() / 1024 / 1024).toFixed(2)} MB free / ${(os.totalmem() / 1024 / 1024).toFixed(2)} MB total
${gray('Uptime')}     : ${formatUptime(os.uptime())}
${gray('Load Avg')}   : ${os.loadavg().map(v => v.toFixed(2)).join(' / ')}

${cyan.bold('CPU(s):')}
${cpus.map((c, i) => ` ${gray('[' + (i + 1) + ']')} ${c.model} @ ${c.speed} MHz`).join('\n')}

${cyan.bold('Network:')}
${Object.entries(net).map(([name, interfaces]) => 
  interfaces.map(i => `${gray(name)} (${i.family}) - ${i.address}`).join('\n')
).join('\n')}
`;
}

function asciiLogo() {
  return [
    chalk.hex('#8A2BE2')(` ########::'########:'##::: ##:'##::::'##:'##:::'##:`),
    chalk.hex('#0000FF')(` ##.... ##: ##.....:: ###:: ##: ##:::: ##:. ##:'##::`),
    chalk.hex('#FF0000')(` ##:::: ##: ##::::::: ####: ##: ##:::: ##::. ####:::`),
    chalk.hex('#8A2BE2')(` ########:: ######::: ## ## ##: ##:::: ##:::. ##:::`),
    chalk.hex('#0000FF')(` ##.. ##::: ##...:::: ##. ####:. ##:: ##::::: ##:::`),
    chalk.hex('#FF0000')(` ##::. ##:: ##::::::: ##:. ###::. ## ##:::::: ##:::`),
    chalk.hex('#8A2BE2')(` ##:::. ##: ########: ##::. ##:::. ###::::::: ##:::`),
    chalk.hex('#0000FF')(`..:::::..::........::..::::..:::::...::::::::..:::::`),
  ].join('\n');
}

function printStartupLogo() {
  const logo = asciiLogo();
  const systemInfo = displaySystemInfo();

  const box = boxen(`${logo}\n\n${systemInfo}`, {
    padding: 1,
    margin: 1,
    borderColor: getTheme().borderColor || 'cyan',
    borderStyle: 'round',
  });

  console.log(box);
}

let isRunning = false;
let childProcess = null;
let restartTimer = null;

function start(file) {
  if (isRunning) return;
  isRunning = true;

  printStartupLogo();

  const args = [path.join(__dirname, file), ...process.argv.slice(2)];
  const p = spawn(process.argv[0], args, {
    stdio: ['inherit', 'inherit', 'inherit', 'ipc'],
    env: {
      ...process.env,
      XDG_CONFIG_HOME: DATABASE_CONFIG_HOME,
      ADBLOCK: process.env.ADBLOCK || '1',
      DISABLE_OPENCOLLECTIVE: process.env.DISABLE_OPENCOLLECTIVE || '1'
    }
  });

  childProcess = p;

  p.on('message', (data) => {
    if (data === 'reset') {
      requestRestart('main.js requested reset');
    } else if (data === 'uptime') {
      p.send(process.uptime());
    }
  });

  p.on('exit', (code, signal) => {
    isRunning = false;
    if (childProcess === p) childProcess = null;
    console.log(chalk.redBright(`Bot exited with code ${code ?? '-'} signal ${signal ?? '-'}. Restarting...`));
    setTimeout(() => start('main.js'), 1000);
  });

  p.on('error', (err) => {
    console.log(chalk.redBright('Process error:'), err);
    isRunning = false;
    if (childProcess === p) childProcess = null;
    setTimeout(() => start('main.js'), 1000);
  });
}

function requestRestart(reason = 'file changed') {
  if (restartTimer) clearTimeout(restartTimer);

  restartTimer = setTimeout(() => {
    restartTimer = null;

    console.log(chalk.yellowBright(`\n[ AUTO RESTART ] ${reason}`));

    if (childProcess && !childProcess.killed) {
      childProcess.kill('SIGTERM');
      return;
    }

    isRunning = false;
    start('main.js');
  }, 700);
}

// ===== AUTO WATCH LIB =====
// Jika file di folder lib diubah / ditambah / dihapus,
// child process main.js akan otomatis direstart.
const watchTargets = [
  path.join(__dirname, 'lib')
];

const restartWatcher = chokidar.watch(watchTargets, {
  persistent: true,
  ignoreInitial: true,
  awaitWriteFinish: {
    stabilityThreshold: 1200,
    pollInterval: 100
  },
  ignored: [
    /(^|[\/\\])\../,
    /node_modules/,
    /sessions/,
    /tmp/,
    /database\.json$/
  ]
});

// Ekstensi yang dianggap "source code" — hanya perubahan pada file-file ini
// yang boleh memicu restart. Modul di lib/runtime (profiler.js, smartBackup.js)
// dan lib/renvy-ai (store.js) menulis file data (.json/.sqlite/.tmp/.log) saat
// bot berjalan; kalau file itu ikut dipantau, bot akan restart terus-menerus
// tiap kali modul itu menyimpan datanya sendiri — ini akar penyebab bot
// "mati nyala sendiri" tanpa ada perubahan kode apa pun.
const SOURCE_EXTENSIONS = new Set(['.js', '.mjs', '.cjs']);

restartWatcher.on('all', (event, filePath) => {
  const rel = path.relative(__dirname, filePath);
  if (!rel || rel.startsWith('..')) return;

  const ext = path.extname(filePath).toLowerCase();
  if (!SOURCE_EXTENSIONS.has(ext)) return;

  console.log(chalk.cyanBright(`\n[ LIB WATCHER ] ${event.toUpperCase()} : ${rel}`));
  requestRestart(`lib ${event}: ${rel}`);
});

restartWatcher.on('error', err => {
  console.log(chalk.redBright('[ LIB WATCHER ERROR ]'), err.message);
});

start('main.js');

process.on('unhandledRejection', (reason) => {
  console.error(chalk.redBright('Unhandled rejection:'), reason);
});

process.on('exit', (code) => {
  console.log(chalk.redBright(`Exiting with code ${code}`));
});
